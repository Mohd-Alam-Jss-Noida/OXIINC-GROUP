<style type="text/css">
	.note-editor {
		margin-bottom: 0px !important;
		resize: none;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="page-inner">
			<div class="page-header">
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Product</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Add Products</a>
					</li>
				</ul>
			</div>
			<div class="mt-2 mb-4">
				<h2 class="text-white pb-2">Add Video Sub Category Details</h2>
			</div>
			<form role="form" action="<?php echo base_url('Dashboard/video_sub_category_insert') ?>" method="POST" enctype="multipart/form-data">
				<div class="card">
					<div class="row">
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
						<div class="col-xl-8 col-lg-12 col-sm-12">
							<div class="form-group">
								<label for="successInput">Select Video Category Name</label>
								<select class="form-control" name="category_id" id="category_id" data-placeholder="Select Category" tabindex="1" autocomplete="off" required="">
									<option value="">Select Video Category Name</option>
									<?php foreach ($results as $key => $value) {?>
										<option value="<?php echo $value['category_id']; ?>" <?php echo set_select('category_id',  $value['category_id']); ?>><?php echo $value['category_name']; ?></option>
									<?php } ?>
								</select>
								<?php echo form_error('category_id'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Video Sub Category Name</label>
								<input type="text" class="form-control" value="<?php echo set_value('sub_category_name'); ?>" name="sub_category_name" id="sub_category_name" tabindex="2" autocomplete="off" placeholder="Enter Video Sub Category Name" required="">
								<?php echo form_error('sub_category_name'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">SEO Sub Category Name</label>
								<input type="text" class="form-control" value="<?php echo set_value('seo_sub_category_name'); ?>" name="seo_sub_category_name" id="seo_sub_category_name" tabindex="3" autocomplete="off" placeholder="Enter SEO Sub Category Name" required="">
								<?php echo form_error('seo_sub_category_name'); ?>
							</div>
							<div class="text_center">
								<input type="reset" value="Reset" class="btn btn-danger" tabindex="4">
  								<input type="submit" name="submit" value="Submit" class="btn btn-success" tabindex="5">
							</div>
						</div>
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
					</div>
				</div>
			</form>
		</div>
	</div>