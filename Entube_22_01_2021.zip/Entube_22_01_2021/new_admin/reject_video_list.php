<style type="text/css">
	.alert .close {
		background: transparent;
		top: 0px!important;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Reject Video List Details</h4>
					</div>
					<?php if($this->session->flashdata('msg')) { ?>
                		<div class="alert alert-success alert-dismissible fade show" role="alert" style="background-color: #dff0d8; color: #3c763d;">
                    		<?php echo $this->session->flashdata('msg');?>
                    		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    							<span aria-hidden="true">&times;</span>
  							</button>
						</div>
                	<?php } ?>
					<div class="card-body">
						<div class="table-responsive">
							<table id="basic-datatables" class="display table table-striped table-hover" >
								<thead>
									<tr class="text_center">
										<th>Sr No</th>
	                                    <th>User Name</th>
	                                    <th>Video Name</th>
	                                    <th>Video Title</th>
	                                    <th>Video Picture</th>
	                                    <th>Reason</th>
	                                    <th>Created data</th>
	                                    <th>Status</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$i=0;
									if(isset($results) && !empty($results)) {
										foreach ($results as $value) {
	                                        if ($value['status']=='1'){
												$status_label ="btn-success btn-sm";
												$status_desc = "Active";
											}else{
												$status_label ="btn-danger btn-sm";
												$status_desc = "Inactive";
											}
										?>
										<tr class="text_center"> 
											<td><?php echo ++$i;?></td> 
											<td>
												<?php
						                        $custumer_name = $this->Model->getData('custumer_login',array('id'=>$value['user_id'],'status'=>'1'));
						                        if($custumer_name){
						                        	echo $custumer_name[0]['user_name']." ".$custumer_name[0]['last_name'];
						                       	} else{
						                        	echo $value['user_id']." (E)";
						                      	} ?>
						                    </td>
											<td><?php echo ($value['Video_Name']) ? $value['Video_Name'] : '---' ;?></td>
											<td><?php echo ($value['Video_Title']) ? $value['Video_Title'] : '---' ;?></td>
											<?php
												$video_file = str_replace("'", "", $value['Video_Title']);
											?>
											<td onclick="myFunction(<?php echo $value['ID'] ;?>, '<?php echo $video_file ;?>');">
												<a href="#">
												<?php if ($value['picture'] == "") { ?>
													<img src="<?php echo base_url("uploads/product/no_image_available.png");?>" style="width: 100px; height: 75px; background: #fbfafa;">
												<?php }
												else { ?>
													<img src="<?php echo base_url().'uploads/product/'.$value['picture'];?>" style="width: 100px;height: 75px">
												<?php } ?>
												</a>
											</td>
											<td><p style="width: 400px;"> <?php echo $value['reason'];?> </p></td>
											<td><?php echo date('d-M-Y',strtotime($value['datatime']));?></td>
											<td><span class="<?php echo $status_label ?>"><?php echo $status_desc?></span></td>
										</tr> 
										<input type="text" id="video_id_<?php echo $value['ID'] ;?>" value="<?php echo $value['video'] ;?>" style="display:none;" >
									<?php } } 
									else {
									?>
									<tr class="odd">
										<td valign="top" colspan="8" class="dataTables_empty">Records not found</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>

	<!-- PLAY VIDEO MODEL CODE START HERE -->
	<div class="modal fade " id="myModal_video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header" style="display: block;">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel"></h4>
				</div>
				<div class="modal-body">
					<video id="video_play" style="width:100%; height:500px" controls="controls">
						<source src="" type="video/mp4" >
						<source src="mov_bbb.ogg" type="video/ogg">
						Your browser does not support HTML5 video.
					</video>
				</div>
			</div>
		</div>
	</div>
	<!-- PLAY VIDEO MODEL CODE END HERE -->

	<script type="text/javascript">
		//PLAY VIDEO MODEL JAVASCRIPT CODE START HERE
		function myFunction(video_id, video_name) {
			$("#myModalLabel").text(video_name);
  			var video_url = document.getElementById('video_id_'+ video_id).value;
  			document.getElementById('video_play').src = "https://www.entube.in/uploads/video/" + video_url;
  			document.getElementById("video_play").autoplay = true;
  			$('#myModal_video').modal('show');
		}

	</script>