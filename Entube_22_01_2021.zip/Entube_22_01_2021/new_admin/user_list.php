<style type="text/css">
	.alert .close {
		background: transparent;
		top: 0px!important;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">User List Details</h4>
					</div>
					<?php if($this->session->flashdata('msg')) { ?>
                		<div class="alert alert-success alert-dismissible fade show" role="alert" style="background-color: #dff0d8; color: #3c763d;">
                    		<?php echo $this->session->flashdata('msg');?>
                    		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    							<span aria-hidden="true">&times;</span>
  							</button>
						</div>
                	<?php } ?>
					<div class="card-body">
						<div class="table-responsive">
							<table id="basic-datatables" class="display table table-striped table-hover" >
								<thead>
									<tr>
										<th>Sr No</th>
                                        <th>Employee Name</th>
                                        <th>Employee Email</th>
                                        <th>Employee Contact Number</th>
                                        <th>Date Of Creation</th>
                                        <th>Status</th>
                                        <th>Action (Eidt)</th>
                                        <th>Action (Delete)</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$i=0;
									if(isset($results) && !empty($results)) {
										foreach ($results as $value) {
	                                        if ($value['status']=='1'){
												$status_label ="btn-success btn-sm";
												$status_desc = "Active";
											}else{
												$status_label ="btn-danger btn-sm";
												$status_desc = "Inactive";
											}
										?>
										<tr> 
											<td><?php echo ++$i;?></td> 
											<td><?php echo $value['user_name'];?></td>
											<td><?php echo $value['user_email'];?></td>
											<td><?php echo $value['contact_number'];?></td>
											<td><?php echo date('d-m-Y',strtotime($value['created']));?></td>
											<td><span class="<?php echo $status_label ?>"><?php echo $status_desc?></span></td>
											<td>
												<a title="Edit" href="<?php echo base_url('Category_new/video_category_edit?edit_id='.$value['id']); ?>">
													<i class="fas fa-edit" style="font-size: 20px;"></i>
												</a>
											</td>
											<td>
												<a title="Delete" onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('Category_new/video_category_delete?delete_id='.$value['id']); ?>">
													<i class="fas fa-trash-alt" style="font-size: 20px;"></i>
												</a>
											</td>
										</tr>
									<?php } } 
									else {
									?>
									<tr class="odd">
										<td valign="top" colspan="8" class="dataTables_empty">Records not found</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>