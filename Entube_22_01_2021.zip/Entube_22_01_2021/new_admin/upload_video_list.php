<style type="text/css">
	.alert .close {
		background: transparent;
		top: 0px!important;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Upload Video List Details</h4>
					</div>
					<?php if($this->session->flashdata('msg')) { ?>
                		<div class="alert alert-success alert-dismissible fade show" role="alert" style="background-color: #dff0d8; color: #3c763d;">
                    		<?php echo $this->session->flashdata('msg');?>
                    		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    							<span aria-hidden="true">&times;</span>
  							</button>
						</div>
                	<?php } ?>
					<div class="card-body">
						<div class="table-responsive">
							<table id="basic-datatables" class="display table table-striped table-hover" >
								<thead>
									<tr class="text_center">
                                        <th>Sr No</th>
                                        <th>Video  Name</th>
                                        <th>Video  Title</th>
                                        <th>Video Picture</th>
                                        <th>Created data</th>
                                        <th>Status</th>
                                        <th>Priority</th>
                                        <th>Recommened</th>
                                        <th>Action (Edit)</th>
                                        <th>Action (Delete)</th>
                                    </tr>
								</thead>
								<tbody>
									<?php
									$i=0;
									if(isset($results) && !empty($results)) {
										foreach ($results as $value) {
	                                        if ($value['status']=='1'){
												$status_label ="btn btn-success btn-sm";
												$status_desc = "Active";
											}else{
												$status_label ="btn btn-danger btn-sm";
												$status_desc = "Inactive";
											}
											if ($value['priority']=='1'){
												$priority_label ="btn btn-success btn-sm";
												$priority_desc = "High";
											}else{
												$priority_label ="btn btn-danger btn-sm";
												$priority_desc = "Low";
											}
											if ($value['recommended']=='1'){
												$recommended_label ="btn btn-success btn-sm";
												$recommended_desc = "Yes";
											}else{
												$recommended_label ="btn btn-danger btn-sm";
												$recommended_desc = "No";
											}
										?>
										<tr class="text_center"> 
											<td><?php echo ++$i;?></td> 
											<td><?php echo ($value['Video_Name']) ? $value['Video_Name'] : '---' ;?></td>
											<td><?php echo ($value['Video_Title']) ? $value['Video_Title'] : '---' ;?></td>
											<?php
												$video_file = str_replace("'", "", $value['Video_Name']);
											?>
											<td onclick="myFunction(<?php echo $value['ID'] ;?>, '<?php echo $video_file ;?>');">
												<a href="#">
												<?php if ($value['picture'] == "") { ?>
													<img src="<?php echo base_url("uploads/product/no_image_available.png");?>" style="width: 100px; height: 75px; background: #fbfafa;">
												<?php }
												else { ?>
													<img src="<?php echo base_url().'uploads/product/'.$value['picture'];?>" style="width: 100px;height: 75px">
												<?php } ?>
												</a>
											</td>
											<td><?php echo date('d-M-Y',strtotime($value['datatime']));?></td>
											<td onclick="videoStatus(<?php echo $value['status'] ;?>, <?php echo $value['ID'] ;?>);"><span class="<?php echo $status_label ?>"><?php echo $status_desc?></span></td>
											<td onclick="videoPriority(<?php echo $value['priority'] ;?>, <?php echo $value['ID'] ;?>);"><span class="<?php echo $priority_label ?>"><?php echo $priority_desc?></span></td>
											<td onclick="videoRecommened(<?php echo $value['recommended'] ;?>, <?php echo $value['ID'] ;?>);"><span class="<?php echo $recommended_label ?>"><?php echo $recommended_desc?></span></td>
											<td><a title="Edit" href="<?php echo base_url('Dashboard/upload_video_edit?edit_id='.$value['ID']); ?>"><i class="fas fa-edit" style="font-size: 20px;"></i></a></td>
											<td><a title="Delete" onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('Dashboard/upload_video_delete?delete_id='.$value['ID']); ?>"><i class="fas fa-trash-alt" style="font-size: 20px;"></i></a></td> 
										</tr> 
										<input type="text" id="video_id_<?php echo $value['ID'] ;?>" value="<?php echo $value['video'] ;?>" style="display:none;" >
									<?php } } 
									else {
									?>
									<tr class="odd">
										<td valign="top" colspan="8" class="dataTables_empty">Records not found</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>
	<!-- PLAY VIDEO MODEL CODE START HER -->
	<div class="modal fade " id="myModal_video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header" style="display: block;">
					<button type="button" class="close " data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel"></h4>
				</div>
				<div class="modal-body">
					<video id="video_play" controls style="width:100%; height:500px" controls autoplay>
						<source src="" type="video/mp4" >
						Your browser does not support HTML5 video.
					</video>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		function myFunction(video_id, video_name) {
			$("#myModalLabel").text(video_name);
  			var video_url = document.getElementById('video_id_'+video_id).value;
  			var url = '<?php echo base_url();?>';
  			document.getElementById('video_play').src = url+"uploads/video/" + video_url;
  			$('#myModal_video').modal('show');
		}
		function videoStatus(video_status, id) {
			var change_status = confirm('Are you sure want to change video status?');
			if (change_status) {
				var url = '<?php echo base_url("Dashboard/video_change_status");?>';
				$.ajax({
		          	type:"POST",
		          	url: url, 
		          	data: {"status":video_status, "id":id}, 
		          	success: function(data) {
		          		//alert(data);
		          		location.reload();
		    		},
		    		error: function(data) {
		    			alert("Something Went Wrong to change video status?.");
		          		location.reload();
		    		}
				});
			}
			else {
				return false;
			}
		}
		function videoPriority(video_priority, id) {
			var change_priority = confirm('Are you sure want to change video priority?');
			if (change_priority) {
				var url = '<?php echo base_url("Dashboard/video_change_priority");?>';
				$.ajax({
		          	type:"POST",
		          	url: url, 
		          	data: {"priority":video_priority, "id":id}, 
		          	success: function(data) {
		          		//alert(data);
		          		location.reload();
		    		},
		    		error: function(data) {
		    			alert("Something Went Wrong to change video priority?.");
		          		location.reload();
		    		}
				});
			}
			else {
				return false;
			}
		}
		function videoRecommened(video_recommended, id) {
			var change_recommended = confirm('Are you sure want to change video recommended?');
			if (change_recommended) {
				var url = '<?php echo base_url("Dashboard/video_change_recommended");?>';
				$.ajax({
		          	type:"POST",
		          	url: url, 
		          	data: {"recommended":video_recommended, "id":id}, 
		          	success: function(data) {
		          		//alert(data);
		          		location.reload();
		    		},
		    		error: function(data) {
		    			alert("Something Went Wrong to change video recommended?.");
		          		location.reload();
		    		}
				});
			}
			else {
				return false;
			}
		}

	</script>
	<!-- PLAY VIDEO MODEL CODE END HER -->