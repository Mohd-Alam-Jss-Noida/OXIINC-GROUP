<div class="main-panel">
	<div class="content">
		<div class="page-inner">
			<div class="page-header">
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">CMS Banner</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Add Banner</a>
					</li>
				</ul>
			</div>
			<div class="mt-2 mb-4">
				<h2 class="text-white pb-2">Add Banner Details Information</h2>
			</div>
			<form role="form" action="<?php echo base_url('Dashboard/banner_insert') ?>" method="POST" enctype="multipart/form-data">
				<div class="card">
					<div class="row">
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
						<div class="col-xl-8 col-lg-12 col-sm-12">
							<div class="form-group">
								<label for="successInput">Video Category</label>
								<select class="form-control" onchange="videoCategory()" name="category_id" id="category_id" data-placeholder="Select Category" tabindex="1" autocomplete="off">
									<option value="">Select Video Category</option>
									<?php foreach ($results as $key => $value) {?>
										<option value="<?php echo $value['category_id'];?>"> <?php echo $value['category_name'];?></option>
										<!-- <option value="<?php //echo $value['category_id']; ?>" <?php //echo set_select('category_id',  $value['category_id']); ?>><?php //echo $value['category_name']; ?></option> -->
									<?php } ?>
								</select>
								<?php echo form_error('category_id'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Video Sub Category</label>
								<select class="form-control" name="sub_category_id" id="sub_category_id" tabindex="2" autocomplete="off">
									<option value="" data-id="">Select Video Sub Category</option>
								</select>
								<?php echo form_error('sub_category_id'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Banner Name</label>
								<input type="text" class="form-control" value="<?php echo set_value('banner_name'); ?>" name="banner_name" id="banner_name" tabindex="3" autocomplete="off" placeholder="Enter Banner Name" required="">
								<?php echo form_error('banner_name'); ?>
							</div>
							<div class="form-group">
								<label for="exampleFormControlFile1">Upload Banner Image</label>
								<input type="file" class="form-control-file" value="<?php echo set_value('banner_Picture'); ?>" name="banner_Picture" id="banner_Picture" accept="Image/*" tabindex="4" required="">
								<?php echo form_error('banner_Picture'); ?>
							</div>
							<div class="text_center">
								<input type="reset" value="Reset" class="btn btn-danger" tabindex="5">
  								<input type="submit" name="submit" value="Submit" class="btn btn-success" tabindex="6">
							</div>
						</div>
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<script type="text/javascript">
	function videoCategory(){
		var category_id = $('#category_id').val();
		var postData = {
			'category_id' : category_id
		}
		$.post('<?php echo base_url('Dashboard/video_sub_category')?>',postData,function(data){
			var subcats = $.parseJSON(data);
			$('#select2-sub_category_id-container').html('Select Video Sub Category');
			$('#sub_category_id').html('');
			var html = '<option value="">Select Video Sub Category</option>';
			$.each(subcats,function(i,val){
				html += '<option value="'+val.sub_category_id+'" data-id="'+val.sub_category_name+'">'+val.sub_category_name+'</option>';
			})
			$('#sub_category_id').html(html);
		})
	}     
</script>


