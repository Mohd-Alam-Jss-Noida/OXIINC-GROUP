<style type="text/css">
	.alert .close {
		background: transparent;
		top: 0px!important;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Add User Role</h4>
					</div>
					<?php if($this->session->flashdata('msg')) { ?>
                		<div class="alert alert-success alert-dismissible fade show" role="alert" style="background-color: #dff0d8; color: #3c763d;">
                    		<?php echo $this->session->flashdata('msg');?>
                    		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    							<span aria-hidden="true">&times;</span>
  							</button>
						</div>
                	<?php } ?>
					<div class="card-body">
						<div class="table-responsive">
							<table id="basic-datatables" class="display table table-striped table-hover" >
								<thead>
									<tr>
										<th>Sr No</th>
                                        <th>Customer Name</th>
                                        <th>IP Address</th>
                                        <th>Co-ordinates</th>
                                        <th>User Type</th>
                                        <th>Date Of Logging</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$count = $this->uri->segment(3);
									if ($count == NULL ) {
										$count = 0;
									}
									if(isset($results) && !empty($results)) {
										foreach ($results as $value) {
	                                        if ($value['usertype']=='1'){
												$usertype ="E-Panelist";
											}else{
												$usertype ="Normal";
											}
										?>
										<tr> 
											<td><?php echo ++$count;?></td> 
											<td><?php echo $value['username'];?></td>
                                            <td><?php echo $value['user_ip'];?></td>
                                            <td><?php echo $value['lat_long'];?></td>
                                            <td><?php echo $usertype;?></td>
                                            <td><?php echo $value['date_1'];?></td>
										</tr>
									<?php } } 
									else {
									?>
									<tr class="odd">
										<td valign="top" colspan="8" class="dataTables_empty">Records not found</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="float-right"><?php echo $this->pagination->create_links();?></div>
	</div>