<!-- Sidebar -->
<div class="sidebar sidebar-style-2" data-background-color="dark2">
	<div class="sidebar-wrapper scrollbar scrollbar-inner">
		<div class="sidebar-content">
			<div class="user">
				<div class="avatar-sm float-left mr-2">
					<img src="<?php echo base_url();?>new_admin_assets/assets//img/profile.jpg" alt="..." class="avatar-img rounded-circle">
				</div>
				<div class="info">
					<a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
						<span>
							Hizrian
							<span class="user-level">Administrator</span>
							<span class="caret"></span>
						</span>
					</a>
					<div class="clearfix"></div>

					<div class="collapse in" id="collapseExample">
						<ul class="nav">
							<li>
								<a href="#profile">
									<span class="link-collapse">My Profile</span>
								</a>
							</li>
							<li>
								<a href="#edit">
									<span class="link-collapse">Edit Profile</span>
								</a>
							</li>
							<li>
								<a href="#settings">
									<span class="link-collapse">Settings</span>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>

			<style type="text/css">
				#img{
					    color: #8d9498;
					    margin-right: 15px;
					    width: 25px;
					    text-align: center;
					    vertical-align: middle;
					    float: left;
					    font-size: 18px;
					    line-height: 30px;
									}
			</style>


			<ul class="nav nav-primary">
				<li class="nav-item active">
					<a href="<?php echo base_url();?>Welcome_new/index">
						<!-- <i class="fas fa-home"></i> -->
						<img src="<?php echo base_url("new_admin_assets/assets/img/entube_icon/dashbord2.png");?>" id="img">
						<p>Dashboard</p>
					</a>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#DigitalProgram">
						<i class="fas fa-layer-group"></i>
						<p>Digital Program</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="DigitalProgram">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/digital_marketing_program">
									<span class="sub-item">Digital Marketing Program</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/digital_marketing_allow_video">
									<span class="sub-item">List Of Allow Video For Digital Marketing</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#UploadVideo">
						<i class="fas fa-pen-square"></i>
						<p>Upload Video</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="UploadVideo">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/upload_video_add">
									<span class="sub-item">Add Video</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/upload_video_list">
									<span class="sub-item">Add Video List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#AllowedVideo">
						<i class="fas fa-table"></i>
						<p>Allowed Video</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="AllowedVideo">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/allowed_video_list">
									<span class="sub-item">Allowed Video List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#VideoApproval">
						<i class="far fa-chart-bar"></i>
						<p>Video Approval</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="VideoApproval">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/approved_video_list">
									<span class="sub-item">Approved Video List</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/pending_video_list">
									<span class="sub-item">Pending Video List</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>Dashboard/reject_video_list">
									<span class="sub-item">Reject Video List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#EntubeGallery">
						<i class="far fa-chart-bar"></i>
						<p>Entube Gallery</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="EntubeGallery">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Dashboard/entube_gallery_add');?>">
									<span class="sub-item">Add Gallery</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Dashboard/entube_gallery_list');?>">
									<span class="sub-item">Gallery List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#VideosCategory">
						<i class="far fa-chart-bar"></i>
						<p>Videos Category</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="VideosCategory">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Dashboard/video_category_add');?>">
									<span class="sub-item">Add Header Product Category</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Dashboard/video_category_list');?>">
									<span class="sub-item">Header Product Category List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#VideosSub-Category">
						<i class="far fa-chart-bar"></i>
						<p>Videos Sub-Category</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="VideosSub-Category">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Dashboard/video_sub_category_add');?>">
									<span class="sub-item">Add Sub-Category</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Dashboard/video_sub_category_list');?>">
									<span class="sub-item">Sub-Category List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#CreateUser">
						<i class="far fa-chart-bar"></i>
						<p>Create User</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="CreateUser">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Create_user/user_role_add');?>">
									<span class="sub-item">Add User</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Create_user/user_role_add');?>">
									<span class="sub-item">Add User Role</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Create_user/user_list');?>">
									<span class="sub-item">List Of Department</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#CMSBanner">
						<i class="far fa-chart-bar"></i>
						<p>CMS Banner</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="CMSBanner">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Dashboard/banner_add');?>">
									<span class="sub-item">Add Banner</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Dashboard/banner_list');?>">
									<span class="sub-item">List Banner</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#BackendUsers">
						<i class="far fa-chart-bar"></i>
						<p>Backend Users</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="BackendUsers">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Create_user/user_add');?>">
									<span class="sub-item">Add Users</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Create_user/user_list');?>">
									<span class="sub-item">Users List</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#CreateCustomer">
						<i class="far fa-chart-bar"></i>
						<p>Create Customer</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="CreateCustomer">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Dashboard/customer_add');?>">
									<span class="sub-item">Add New Customer</span>
								</a>
							</li>
							<li>
								<a href="<?php echo base_url('Dashboard/customer_list');?>">
									<span class="sub-item">List Of Customer</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<li class="nav-item">
					<a data-toggle="collapse" href="#UserTrackingInfo">
						<i class="far fa-chart-bar"></i>
						<p>User Tracking Info</p>
						<span class="caret"></span>
					</a>
					<div class="collapse" id="UserTrackingInfo">
						<ul class="nav nav-collapse">
							<li>
								<a href="<?php echo base_url('Dashboard/user_tracking_information_list');?>">
									<span class="sub-item">List Of User Tracking info</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
			</ul>
		</div>
	</div>
</div>
<!-- End Sidebar -->