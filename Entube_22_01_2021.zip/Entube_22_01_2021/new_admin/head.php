<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="description" content="EnTube - Indian Video Social Media Company Improve-Express-Share">
    <meta name="author" content="EnTube - Indian Video Social Media Company Improve-Express-Share">
	<title>EnTube - Dashboard</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<!-- <link rel="icon" href="<?php echo base_url();?>new_admin_assets/assets//img/icon.ico" type="image/x-icon"/> -->
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.entube.in/black/img/logoo/iconn.png">

	<!-- Fonts and icons -->
	<script src="<?php echo base_url();?>new_admin_assets/assets//js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo base_url();?>new_admin_assets/assets//css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>
	<!-- COMMAN CSS TO USE ANY WHERE ADD BY MOHD ALAM -->
	<style type="text/css">
		.text_center {
			text-align: center;
		}
		.error_color {
			color: red;
			font-size: 13px;
		}
	</style>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo base_url();?>new_admin_assets/assets//css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>new_admin_assets/assets//css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="<?php echo base_url();?>new_admin_assets/assets//css/demo.css">
</head>
<body data-background-color="dark">