<?php
	$this->load->view('new_admin/head');
	$this->load->view('new_admin/header');
	$this->load->view('new_admin/sidebar');
	$this->load->view($main_containt);
	$this->load->view('new_admin/footer');
?>