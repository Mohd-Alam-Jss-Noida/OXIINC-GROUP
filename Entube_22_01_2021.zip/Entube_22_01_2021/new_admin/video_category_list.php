<style type="text/css">
	.alert .close {
		background: transparent;
		top: 0px!important;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4 class="card-title">Video Category List Details</h4>
					</div>
					<?php if($this->session->flashdata('msg')) { ?>
                		<div class="alert alert-success alert-dismissible fade show" role="alert" style="background-color: #dff0d8; color: #3c763d;">
                    		<?php echo $this->session->flashdata('msg');?>
                    		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    							<span aria-hidden="true">&times;</span>
  							</button>
						</div>
                	<?php } ?>
					<div class="card-body">
						<div class="table-responsive">
							<table id="basic-datatables" class="display table table-striped table-hover" >
								<thead>
									<tr>
										<th>Sr No</th>
                                        <th>Category ID</th>
                                        <th>Category Name</th>
                                        <th>Status</th>
                                        <th>Action (View)</th>
                                        <th>Action (View)</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$i=0;
									if(isset($results) && !empty($results)) {
										foreach ($results as $value) {
	                                        if ($value['status']=='1'){
												$status_label ="btn btn-success btn-sm";
												$status_desc = "Active";
											}else{
												$status_label ="btn btn-danger btn-sm";
												$status_desc = "Inactive";
											}
										?>
										<tr> 
											<td><?php echo ++$i;?></td> 
											<td><?php echo $value['category_id'];?></td>
											<td><?php echo $value['category_name'];?></td>
											<td onclick="videoCategoryStatus(<?php echo $value['status'] ;?>, <?php echo $value['category_id'] ;?>);"><span class="<?php echo $status_label ?>"><?php echo $status_desc?></span></td>
											<td><a title="Edit" href="<?php echo base_url('Dashboard/video_category_edit?edit_id='.$value['category_id']); ?>"><i class="fas fa-edit" style="font-size: 20px;"></i></a></td>
											<td><a title="Delete" onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('Dashboard/video_category_delete?delete_id='.$value['category_id']); ?>"><i class="fas fa-trash-alt" style="font-size: 20px;"></i>
												</a></td>
										</tr>
									<?php } } 
									else {
									?>
									<tr class="odd">
										<td valign="top" colspan="8" class="dataTables_empty">Records not found</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>
	<script type="text/javascript">
		function videoCategoryStatus(category_status, category_id) {
			var change_status = confirm('Are you sure want to change video category status?');
			if (change_status) {
				var url = '<?php echo base_url("Dashboard/video_category_status");?>';
				$.ajax({
		          	type:"POST",
		          	url: url, 
		          	data: {"status":category_status, "id":category_id}, 
		          	success: function(data) {
		          		//alert(data);
		          		location.reload();
		    		},
		    		error: function(data) {
		    			alert("Something Went Wrong to change video category status?.");
		          		location.reload();
		    		}
				});
			}
			else {
				return false;
			}
		}
	</script>