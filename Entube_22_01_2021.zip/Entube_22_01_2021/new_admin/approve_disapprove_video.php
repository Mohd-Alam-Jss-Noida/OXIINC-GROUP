<?php include 'head.php';?>
<?php include 'header.php';?>
<?php include 'sidebar.php';?>	
<div class="main-panel">
	<div class="content">
		<h1>approve_disapprove_video</h1>
	</div>
<?php include 'footer.php';?>