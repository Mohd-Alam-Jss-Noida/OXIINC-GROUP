<div class="main-panel">
	<div class="content">
		<div class="page-inner">
			<div class="page-header">
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Product</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Add Products</a>
					</li>
				</ul>
			</div>
			<div class="mt-2 mb-4">
				<h2 class="text-white pb-2">Update Video Category Details</h2>
			</div>
			<form role="form" action="<?php echo base_url('Dashboard/video_category_update') ?>" method="POST" enctype="multipart/form-data">
				<input type="hidden" name="category_id" value="<?php echo $results['category_id']?>">
				<div class="card">
					<div class="row">
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
						<div class="col-xl-8 col-lg-12 col-sm-12">
							<div class="form-group">
								<label for="successInput">Video Category Name</label>
								<input type="text" class="form-control" value="<?php echo $results['category_name']; ?>" name="category_name" id="category_name" tabindex="1" autocomplete="off"  placeholder="Enter Video Category Name">
								<?php echo form_error('category_name'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Seo Friendly Name</label>
								<input type="text" class="form-control" value="<?php echo $results['seo_category_name']; ?>" name="seo_category_name" id="seo_category_name" tabindex="2" autocomplete="off"  placeholder="Enter Seo Friendly Name">
								<?php echo form_error('seo_category_name'); ?>
							</div>
							<div class="text_center">
								<input type="reset" value="Reset" class="btn btn-danger" tabindex="3">
  								<input type="submit" name="submit" value="Update" class="btn btn-success" tabindex="4">
							</div>
						</div>
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
					</div>
				</div>
			</form>
		</div>
	</div>