<style type="text/css">
	.note-editor {
		margin-bottom: 0px !important;
		resize: none;
	}
</style>
<div class="main-panel">
	<div class="content">
		<div class="page-inner">
			<div class="page-header">
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Product</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Add Products</a>
					</li>
				</ul>
			</div>
			<div class="mt-2 mb-4">
				<h2 class="text-white pb-2">Update Video Details Information</h2>
			</div>
			<form role="form" action="<?php echo base_url('Dashboard/upload_video_update') ?>" method="POST" enctype="multipart/form-data">
				<input type="hidden" name="ID" value="<?php echo $get_records['ID']?>">
				<div class="card">
					<div class="row">
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
						<div class="col-xl-8 col-lg-12 col-sm-12">
							<div class="form-group">
								<label for="successInput">Video Category</label>
								<select class="form-control" onchange="videoCategory()" name="category_id" id="category_id" data-placeholder="Select Category" tabindex="1" autocomplete="off" >
									<option value="">Select Video Category</option>
									<?php foreach ($get_category as $key => $value) { ?>
										<option value="<?php echo $value['category_id']; ?>"<?php if($value['category_id'] == $get_records['category_id']){ echo "selected"; } ?>><?php echo $value['category_name']; ?></option>
									<?php } ?>
								</select>
								<?php echo form_error('category_id'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Video Sub Category</label>
								<select class="form-control" name="sub_category_id" id="sub_category_id" tabindex="2" autocomplete="off" >
									<?php
                                    $sub_category_list = $this->Model->getData('subcategory', array('status'=>'1', 'category_id'=>$get_records['category_id']));
                                    if(isset($sub_category_list) && !empty($sub_category_list)) {
                                        foreach ($sub_category_list as $key => $sub_value) { ?>
                                            <option value="<?php echo $sub_value['sub_category_id']; ?>"<?php if($sub_value['sub_category_id'] == $get_records['sub_category_id']){ echo "selected"; } ?> ><?php echo $sub_value['sub_category_name']; ?>
                                            </option>
                                    <?php } }
                                    else { ?>
                                    	<option value="">Select Video Sub Category</option>
                                    <?php } ?>
								</select>
								<?php echo form_error('sub_category_id'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Video Name</label>
								<input type="text" class="form-control" value="<?php echo $get_records['Video_Name']?>" name="video_name" id="video_name" tabindex="3" autocomplete="off" >
								<?php echo form_error('video_name'); ?>
							</div>
							<div class="form-group">
								<label for="successInput">Video Title</label>
								<input type="text" class="form-control" value="<?php echo $get_records['Video_Title']?>" name="video_title" id="video_title" tabindex="4" autocomplete="off" >
								<?php echo form_error('video_title'); ?>
							</div>
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<label for="exampleFormControlFile1">Upload Video Image</label>
										<input type="file" class="form-control-file" value="" value="<?php echo $get_records['picture']?>" name="multiple_image" id="multiple_image" accept="Image/*" tabindex="5"  >
										<?php echo form_error('multiple_image'); ?>
										<input type="hidden" name="old_image" value="<?php echo $get_records['picture']?>" size="49">
									</div>
									
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label for="exampleFormControlFile1">Upload Video</label>
										<input type="file" class="form-control-file" value="<?php echo $get_records['video']?>" name="multiple_video" id="multiple_video" accept="Video/*" tabindex="6" >
										<?php echo form_error('multiple_video'); ?>
										<input type="hidden" name="old_video" value="<?php echo $get_records['video']?>" size="49">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label for="comment">Shrot Description</label>
								<textarea class="form-control" name="short_description" id="short_description" tabindex="7" ><?php echo $get_records['Short_Description']?></textarea>
								<?php echo form_error('short_description'); ?>
							</div>
							<div class="form-group">
								<label for="comment">Large Description</label>
								<textarea class="form-control" name="large_description" id="large_description" tabindex="8" ><?php echo $get_records['large_Description']?></textarea>
								<?php echo form_error('large_description'); ?>
							</div>
							<div class="form-group">
								<label for="comment">Specification Description</label>
								<textarea class="form-control" name="specification_description" id="specification_description" tabindex="9" ><?php echo $get_records['Specification_Description']?></textarea>
								<?php echo form_error('specification_description'); ?>
							</div>
							<div class="text_center">
								<input type="reset" value="Reset" class="btn btn-danger" tabindex="10">
  								<input type="submit" name="update" value="Update" class="btn btn-success" tabindex="11">
							</div>
						</div>
						<div class="col-xl-2 col-lg-0 col-sm-12"></div>
					</div>
				</div>
			</form>
		</div>
	</div>

	<!--CSS AND JS LINK FOR HTML TEXT EDITOR ADD BY MOHD ALAM -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
	<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script> -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-bs4.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-bs4.js"></script>
	<script src="<?php echo base_url("new_admin_assets/assets/js/html_textbox.js");?>"></script>

	<script type="text/javascript">
	//JAVASCRIPT CODE FOR HTML TEXT EDITOR ADD BY MOHD ALAM
	$('textarea#short_description').summernote({
		placeholder: 'Description',
		tabsize: 2,
		height: 100,
		toolbar: [
		['style', ['style']],
		['font', ['bold', 'italic', 'underline', 'clear']],
    		// ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
    		//['fontname', ['fontname']],
   			// ['fontsize', ['fontsize']],
   			['color', ['color']],
   			['para', ['ul', 'ol', 'paragraph']],
   			['height', ['height']],
    		//['table', ['table']],
    		['insert', ['link', 'picture', 'hr']],
    		//['view', ['fullscreen', 'codeview']],
    		['help', ['help']]
    		],
    	});

	$('textarea#large_description').summernote({
		placeholder: 'Description',
		tabsize: 2,
		height: 100,
		toolbar: [
		['style', ['style']],
		['font', ['bold', 'italic', 'underline', 'clear']],
    		// ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
    		//['fontname', ['fontname']],
   			// ['fontsize', ['fontsize']],
   			['color', ['color']],
   			['para', ['ul', 'ol', 'paragraph']],
   			['height', ['height']],
    		//['table', ['table']],
    		['insert', ['link', 'picture', 'hr']],
    		//['view', ['fullscreen', 'codeview']],
    		['help', ['help']]
    		],
    	});

	$('textarea#specification_description').summernote({
		placeholder: 'Description',
		tabsize: 2,
		height: 100,
		toolbar: [
		['style', ['style']],
		['font', ['bold', 'italic', 'underline', 'clear']],
    		// ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
    		//['fontname', ['fontname']],
   			// ['fontsize', ['fontsize']],
   			['color', ['color']],
   			['para', ['ul', 'ol', 'paragraph']],
   			['height', ['height']],
    		//['table', ['table']],
    		['insert', ['link', 'picture', 'hr']],
    		//['view', ['fullscreen', 'codeview']],
    		['help', ['help']]
    		],
    	});

	function videoCategory(){
		var category_id = $('#category_id').val();
		var postData = {
			'category_id' : category_id
		}
		$.post('<?php echo base_url('Dashboard/video_sub_category')?>',postData,function(data){
			var subcats = $.parseJSON(data);
			$('#select2-sub_category_id-container').html('Select Video Sub Category');
			$('#sub_category_id').html('');
			var html = '<option value="">Select Video Sub Category</option>';
			$.each(subcats,function(i,val){
				html += '<option value="'+val.sub_category_id+'" data-id="'+val.sub_category_name+'">'+val.sub_category_name+'</option>';
			})
			$('#sub_category_id').html(html);
		})
	}     
</script>


