<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// FUNCTIONLITY CODE START BY MOHD ALAM ON 25/03/2020
class Dashboard extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
        $this->load->model('Model');
        $this->load->model('Customer_login_Information');
        $this->load->library('form_validation'); //load validation library
        $this->load->helper('file'); //load file helper
        date_default_timezone_set('Asia/Kolkata');
        // $this->load->model('Orders_model');
         
        if(!$this->session->userdata('is_logged_in')){
         	redirect('Login');
        }
	}
    public function index() {
        $data['main_containt']='new_admin/dashbord';
        /*$add_video = $this->Model->getDataOrderBy('add_video',array('status'=>'0','reason'=>' '),'ID','DESC');
        $data['add_video'] = $add_video;*/
        $this->load->view('new_admin/containt', $data);
    }
    public function digital_marketing_program(){
        $get_records = $this->Model->getDataOrderBy('add_video',array('allow_video'=>'0', 'status' => "1"),'ID','DESC');
        $data['results'] = $get_records;
        $data['main_containt'] = 'new_admin/digital_marketing_program';
        $this->load->view('new_admin/containt', $data);
    }
    public function digital_marketing_allow_video(){
        $get_records = $this->Model->getDataOrderBy('add_video',array('allow_video'=>'1',  'status' => "1"),'ID','DESC');
        $data['results'] = $get_records;
        $data['main_containt'] = 'new_admin/digital_marketing_allow_video';
        $this->load->view('new_admin/containt',$data);
    }
    public function upload_video_add(){
        $get_records = $this->Model->getData('category');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/upload_video_add';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_sub_category(){
        $postData = $_POST;
        $sub_category_list = $this->Model->getData('subcategory',array('status'=>'1'));
        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['category_id'] == $value['category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }
    public function upload_video_insert() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            //echo "<pre>";print_r($post_data);die();
            if (isset($post_data["submit"]) && !empty($post_data["submit"])) {
                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                $this->form_validation->set_rules('category_id', 'Category Name', 'required');
                $this->form_validation->set_rules('sub_category_id', 'Sub Category Name', 'required');
                $this->form_validation->set_rules('video_name', 'Video Name', 'required');
                $this->form_validation->set_rules('video_title', 'Video Title', 'required');
                $this->form_validation->set_rules('short_description', 'Short Description', 'required');
                $this->form_validation->set_rules('large_description', 'Large Description', 'required');
                $this->form_validation->set_rules('specification_description', 'Specification Description', 'required');
                $this->form_validation->set_rules('multiple_image', '', 'callback_file_check');
                if (empty($_FILES['multiple_video']['name'])) {
                    $this->form_validation->set_rules('multiple_video', 'Upload Video', 'required');
                }

                if ($this->form_validation->run() == FALSE) {
                    $get_records = $this->Model->getData('category');
                    $data['results'] = $get_records;
                    $data['main_containt']='new_admin/upload_video_add';
                    $this->load->view('new_admin/containt',$data);
                }
                else {
                    if(!empty($_FILES['multiple_image']['name'])) {             //Check whether user upload Image
                        $config['upload_path'] = 'uploads/product/';            // check path is correct
                        $config['allowed_types'] = 'jpg|jpeg|png|gif';          // add Image extenstion on here
                        $config['file_name'] = rand()."_entube_image".".png";
                        $this->load->library('upload',$config);                 //Load upload library and initialize configuration
                        $this->upload->initialize($config);
                        if($this->upload->do_upload('multiple_image')) {
                            $uploadData = $this->upload->data();
                            $picture = $uploadData['file_name'];
                        }
                        else {
                            $picture = '';
                        }
                    }
                    else {
                        $picture = '';
                    }

                    if(!empty($_FILES['multiple_video']['name'])){        //Check whether user upload Image
                        $configVideo['upload_path'] = 'uploads/video/';   // check path is correct
                        $configVideo['allowed_types'] = '*';              // add video extenstion on here
                        $configVideo['overwrite'] = FALSE;
                        $configVideo['remove_spaces'] = TRUE;
                        $exploded = explode('.',$_FILES['multiple_video']['name']);
                        $ext = $exploded[count($exploded) - 1];
                        $configVideo['file_name'] = "entube".rand().".mp4";
                        $this->load->library('upload', $configVideo);
                        $this->upload->initialize($configVideo);

                        if($this->upload->do_upload('multiple_video')){
                            $uploadData = $this->upload->data();
                            $video = $uploadData['file_name'];
                        }else {
                                $video = '';
                        }
                    }
                    else {
                        $video = '';
                    }

                    $userData = array(
                        'category_id' => $this->input->post('category_id'),
                        'sub_category_id' => $this->input->post('sub_category_id'),
                        'Video_Name' => $this->input->post('video_name'),
                        'Video_Title' => $this->input->post('video_title'),
                        'Short_Description' => $this->input->post('short_description'),
                        'large_Description' => $this->input->post('large_description'),
                        'Specification_Description' => $this->input->post('specification_description'),
                        'status' => "1",
                        'priority' => "0",
                        'recommended' => "0",
                        'upload_time' => date('d-m-Y'),
                        'picture' => $picture,
                        'video' => $video
                    );
                    $this->Model->insertData('add_video',$userData);
                    $this->session->set_flashdata('msg','Video Details Successfully Uploaded.');
                    redirect('Dashboard/upload_video_list');
                }
            }
        }
    }
    public function file_check($str){
        $allowed_mime_type_arr = array('image/gif','image/jpeg','image/pjpeg','image/png','image/x-png');
        $mime = get_mime_by_extension($_FILES['multiple_image']['name']);
        if(isset($_FILES['multiple_image']['name']) && $_FILES['multiple_image']['name'] != ""){
            if(in_array($mime, $allowed_mime_type_arr)){
                return true;
            }else{
                $this->form_validation->set_message('file_check', 'Please select only gif/jpg/png file.');
                return false;
            }
        }else{
            $this->form_validation->set_message('file_check', 'Please choose a Image to upload.');
            return false;
        }
    }
    public function upload_video_list(){
        $get_records = $this->Model->getDataOrderBy('add_video',array(),'ID','DESC');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/upload_video_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function upload_video_edit(){
        $edit_id = $this->input->get_post('edit_id');
        $data['get_category'] = $this->Model->getData('category');
        $records = $this->Model->getData('add_video',array('ID'=>$edit_id));
        $data['get_records'] = $records[0];
        $data['main_containt']='new_admin/upload_video_edit';
        $this->load->view('new_admin/containt',$data);
    }
    public function upload_video_update() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            if (isset($post_data["update"]) && !empty($post_data["update"])) {
                $this->form_validation->set_rules('category_id', 'Category Name', 'required');
                $this->form_validation->set_rules('sub_category_id', 'Sub Category Name', 'required');
                $this->form_validation->set_rules('video_name', 'Video Name', 'required');
                $this->form_validation->set_rules('video_title', 'Video Title', 'required');
                //$this->form_validation->set_rules('multiple_image', 'Upload Video Image', 'required');
                //$this->form_validation->set_rules('multiple_video', 'Upload Video', 'required');
                $this->form_validation->set_rules('short_description', 'Short Description', 'required');
                $this->form_validation->set_rules('large_description', 'Large Description', 'required');
                $this->form_validation->set_rules('specification_description', 'Specification Description', 'required');
                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                if ($this->form_validation->run() == FALSE) {
                    $get_records = $this->Model->getData('category');
                    $data['results'] = $get_records;
                    $data['main_containt']='new_admin/upload_video_add';
                    $this->load->view('new_admin/containt',$data);
                }
                else {
                    if(!empty($_FILES['multiple_image']['name'])) {             //Check whether user upload Image
                        $config['upload_path'] = 'uploads/product/';            // check path is correct
                        $config['allowed_types'] = 'jpg|jpeg|png|gif';          // add Image extenstion on here
                        $config['file_name'] = rand()."_entube_image".".png";
                        $this->load->library('upload',$config);                 //Load upload library and initialize configuration
                        $this->upload->initialize($config);
                        if($this->upload->do_upload('multiple_image')) {
                            $uploadData = $this->upload->data();
                            $picture = $uploadData['file_name'];
                        }
                        else {
                            $picture = '';
                        }
                    }
                    else {
                        $picture = $this->input->post('old_image');
                    }

                    if(!empty($_FILES['multiple_video']['name'])) {        //Check whether user upload Image
                        $configVideo['upload_path'] = 'uploads/video/';   // check path is correct
                        $configVideo['allowed_types'] = '*';              // add video extenstion on here
                        $configVideo['overwrite'] = FALSE;
                        $configVideo['remove_spaces'] = TRUE;
                        $exploded = explode('.',$_FILES['multiple_video']['name']);
                        $ext = $exploded[count($exploded) - 1];
                        $configVideo['file_name'] = "entube".rand().".mp4";
                        $this->load->library('upload', $configVideo);
                        $this->upload->initialize($configVideo);

                        if($this->upload->do_upload('multiple_video')){
                            $uploadData = $this->upload->data();
                            $video = $uploadData['file_name'];
                        }else {
                                $video = '';
                        }
                    }
                    else {
                        $video = $this->input->post('old_video');
                    }

                    $userData = array(
                        'ID' => $this->input->post('ID'),
                        'category_id' => $this->input->post('category_id'),
                        'sub_category_id' => $this->input->post('sub_category_id'),
                        'Video_Name' => $this->input->post('video_name'),
                        'Video_Title' => $this->input->post('video_title'),
                        'Short_Description' => $this->input->post('short_description'),
                        'large_Description' => $this->input->post('large_description'),
                        'Specification_Description' => $this->input->post('specification_description'),
                        'upload_time' => date('d-m-Y'),
                        'picture' => $picture,
                        'video' => $video
                    );
                    $update_result = $this->Model->updateData('add_video',$userData, array('ID'=>$userData['ID']));
                    if ($update_result) {
                        $this->session->set_flashdata('msg','Video Details Successfully Update.');
                        redirect('Dashboard/upload_video_list');
                    }
                    else {
                        $this->session->set_flashdata('msg','Something Went Wrong to Update Video Details.');
                        redirect('Dashboard/upload_video_list');
                    }
                }
            }
        }
    }
    public function video_change_status(){
        $status = $this->input->post('status');
        if ($status == 0) {
           $status = 1;
        }
        else {
            $status = 0;
        }
        $userData = array(
            'ID' => $this->input->post('id'),
            'status' => $status
        );
        $ststus_result = $this->Model->updateData('add_video',$userData, array('ID'=>$userData['ID']));
        echo $ststus_result;
    }
    public function video_change_priority(){
        $priority = $this->input->post('priority');
        if ($priority == 0) {
           $priority = 1;
        }
        else {
            $priority = 0;
        }
        $userData = array(
            'ID' => $this->input->post('id'),
            'priority' => $priority
        );
        //echo "<pre>";print_r($userData);die();
        $priority_result = $this->Model->updateData('add_video',$userData, array('ID'=>$userData['ID']));
        echo $priority_result;
    }
    public function video_change_recommended(){
        $recommended = $this->input->post('recommended');
        if ($recommended == 0) {
           $recommended = 1;
        }
        else {
            $recommended = 0;
        }
        $userData = array(
            'ID' => $this->input->post('id'),
            'recommended' => $recommended
        );
        //echo "<pre>";print_r($userData);die();
        $recommended_result = $this->Model->updateData('add_video',$userData, array('ID'=>$userData['ID']));
        echo $recommended_result;
    }
    public function upload_video_delete(){
        $delete_id = $this->input->get_post('delete_id');
        $method_name = $this->input->get_post('method_name');
        $this->Model->deleteData('add_video',array('ID'=>$delete_id));
        $this->session->set_flashdata('msg' ,'Video Details Successfully Deleted.');
        if ($method_name == "digital_marketing_program") {
            redirect('Dashboard/digital_marketing_program');
        }
        redirect('Dashboard/upload_video_list');
    }
    public function allowed_video_list(){
        $givenDate=date("Y-m-d");
        $Next_Monday=date('Y-m-d', strtotime('next monday', strtotime($givenDate)));
        $Previous_Monday= date('Y-m-d', strtotime('previous monday', strtotime($givenDate)));
        //$query = $this->db->query('select * from allow_data_my_digital where allow_year_month_data between "'.$Previous_Monday.'"  and "'.$Next_Monday.'" ');
        $query = $this->db->query('SELECT * FROM allow_data_my_digital WHERE allow_year_month_data BETWEEN "2019-03-01" AND "2019-03-07" ');
        $get_records = $query->result_array();
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/allowed_video_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function approved_video_list(){
        $get_records = $this->Model->getDataOrderBy('add_video',array('status'=>'1'),'approved_time','DESC');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/approved_video_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function pending_video_list(){
        $get_records = $this->Model->getDataOrderBy('add_video',array('status'=>'0','reason'=>' '),'ID','DESC');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/pending_video_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function reject_video_list(){
        $strSql = "SELECT * FROM add_video WHERE status='0' AND reason !=' ' ORDER BY ID DESC";
        $data['countries'] =$this->Model->getSqlData($strSql);
        $get_records = $this->Model->getSqlData($strSql);
        $data['results'] = $get_records;
        $data['main_containt'] = 'new_admin/reject_video_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function entube_gallery_add() {
        $data['main_containt']='new_admin/entube_gallery_add';
        $this->load->view('new_admin/containt',$data);
    }
    public function entube_gallery_list(){
        echo "MOHF ALAM";
        /*$this->Add_category_model->insertData($_POST);
        $this->session->set_flashdata('msg',' Successfully your Category Add');
        redirect('Category/entube_gallery_list');*/
    }
    public function video_category_add() {
        $data['main_containt']='new_admin/video_category_add';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_category_insert() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            //echo "<pre>";print_r($post_data);die();
            if (isset($post_data["submit"]) && !empty($post_data["submit"])) {
                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                $this->form_validation->set_rules('category_name', 'Video Category Name', 'required');
                $this->form_validation->set_rules('seo_category_name', 'Seo Friendly Name', 'required');
                if ($this->form_validation->run() == TRUE) {
                    $userData = array(
                        'category_name' => $this->input->post('category_name'),
                        'seo_category_name' => $this->input->post('seo_category_name')
                    );
                    $insert_result = $this->Model->insertData('category',$userData);
                    if ($insert_result) {
                        $this->session->set_flashdata('msg','Video Category Details Added Successfully.');
                        redirect('Dashboard/video_category_list');
                    }
                    else {
                        $this->session->set_flashdata('msg','Something Went Worng Video Category Details Added Failed.');
                        redirect('Dashboard/video_category_list');
                    }
                }
                else {
                    $data['main_containt']='new_admin/video_category_add';
                    $this->load->view('new_admin/containt',$data);
                }
            }
        }
    }
    public function video_category_list() {
        //$get_records = $this->Model->getData('category');
        $get_records = $this->Model->getDataOrderBy('category',array(),'category_id','DESC');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/video_category_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_category_edit(){
        $edit_id = $this->input->get_post('edit_id');
        $get_records = $this->Model->getData('category',array('category_id'=>$edit_id));
        $data['results'] = $get_records[0];
        $data['main_containt']='new_admin/video_category_edit';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_category_update() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            //echo "<pre>";print_r($post_data);die();
            if (isset($post_data["submit"]) && !empty($post_data["submit"])) {

                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                $this->form_validation->set_rules('category_name', 'Video Category Name', 'required');
                $this->form_validation->set_rules('seo_category_name', 'Seo Friendly Name', 'required');
                if ($this->form_validation->run() == TRUE) {
                    $userData = array(
                        'category_id' => $this->input->post('category_id'),
                        'category_name' => $this->input->post('category_name'),
                        'seo_category_name' => $this->input->post('seo_category_name')
                    );
                    $update_result = $this->Model->updateData('category',$userData, array('category_id'=>$userData['category_id']));
                    if ($update_result) {
                        $this->session->set_flashdata('msg','Video Category Details Updated Successfully.');
                        redirect('Dashboard/video_category_list');
                    }
                    else {
                        $this->session->set_flashdata('msg','Something Went Worng Video Category Details Updated Failed.');
                        redirect('Dashboard/video_category_list');
                    }
                }
                else {
                    $data['main_containt']='new_admin/video_category_add';
                    $this->load->view('new_admin/containt',$data);
                }
            }
        }
    }
    public function video_category_delete(){
        $delete_id = $this->input->get_post('delete_id');
        $delete_result = $this->Model->deleteData('category',array('category_id'=>$delete_id));
        if ($delete_result) {
            $this->session->set_flashdata('msg' ,'Video Category Successfully Deleted.');
            redirect('Dashboard/video_category_list');
        }
        else {
            $this->session->set_flashdata('msg' ,'Something Went Worng Video Category Details Deleted Failed.');
            redirect('Dashboard/video_category_list');
        }
    }
    public function video_category_status(){
        $status = $this->input->post('status');
        if ($status == 0) {
           $status = 1;
        }
        else {
            $status = 0;
        }
        $userData = array(
            'category_id' => $this->input->post('id'),
            'status' => $status
        );
        $ststus_result = $this->Model->updateData('category',$userData, array('category_id'=>$userData['category_id']));
        echo $ststus_result;
    }
    public function video_sub_category_add() {
        $get_records = $this->Model->getData('category');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/video_sub_category_add';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_sub_category_insert() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            //echo "<pre>";print_r($post_data);die();
            if (isset($post_data["submit"]) && !empty($post_data["submit"])) {
                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                $this->form_validation->set_rules('category_id', 'Select Video Category Name', 'required');
                $this->form_validation->set_rules('sub_category_name', 'Video Sub Category Name', 'required');
                $this->form_validation->set_rules('seo_sub_category_name', 'SEO Sub Category Name', 'required');
                if ($this->form_validation->run() == TRUE) {
                    $userData = array(
                        'category_id' => $this->input->post('category_id'),
                        'sub_category_name' => $this->input->post('sub_category_name'),
                        'seo_sub_category_name' => $this->input->post('seo_sub_category_name')
                    );
                    $insert_result = $this->Model->insertData('subcategory',$userData);
                    if ($insert_result) {
                        $this->session->set_flashdata('msg','Video Sub Category Details Added Successfully.');
                        redirect('Dashboard/video_sub_category_list');
                    }
                    else {
                        $this->session->set_flashdata('msg','Something Went Worng Video Sub Category Details Added Failed.');
                        redirect('Dashboard/video_sub_category_list');
                    }
                }
                else {
                    $get_records = $this->Model->getData('category');
                    $data['results'] = $get_records;
                    $data['main_containt']='new_admin/video_sub_category_add';
                    $this->load->view('new_admin/containt',$data);
                }
            }
        }
    }
    public function video_sub_category_list() {
        $this->db->select('subcategory.*, category.category_name');
        $this->db->from('subcategory');
        $this->db->join('category','category.category_id = subcategory.category_id');
        $this->db->order_by("sub_category_id", "DESC");
        $query = $this->db->get();
        if ($query->num_rows() > 0){
            $get_records = $query->result_array();
        }else{
            $get_records = FALSE;
        }
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/video_sub_category_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_sub_category_edit(){
        $edit_id = $this->input->get_post('edit_id');
        $get_records = $this->Model->getData('subcategory',array('sub_category_id'=>$edit_id));
        $data['results'] = $get_records[0];
        echo "<pre>";print_r($data);die();
        $data['main_containt']='new_admin/video_sub_category_edit';
        $this->load->view('new_admin/containt',$data);
    }
    public function video_sub_category_update() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            //echo "<pre>";print_r($post_data);die();
            if (isset($post_data["submit"]) && !empty($post_data["submit"])) {

                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                $this->form_validation->set_rules('category_name', 'Video Category Name', 'required');
                $this->form_validation->set_rules('seo_category_name', 'Seo Friendly Name', 'required');
                if ($this->form_validation->run() == TRUE) {
                    $userData = array(
                        'category_id' => $this->input->post('category_id'),
                        'category_name' => $this->input->post('category_name'),
                        'seo_category_name' => $this->input->post('seo_category_name')
                    );
                    $update_result = $this->Model->updateData('category',$userData, array('category_id'=>$userData['category_id']));
                    if ($update_result) {
                        $this->session->set_flashdata('msg','Video Category Details Updated Successfully.');
                        redirect('Dashboard/video_category_list');
                    }
                    else {
                        $this->session->set_flashdata('msg','Something Went Worng Video Category Details Updated Failed.');
                        redirect('Dashboard/video_category_list');
                    }
                }
                else {
                    $data['main_containt']='new_admin/video_category_add';
                    $this->load->view('new_admin/containt',$data);
                }
            }
        }
    }
    public function video_sub_category_delete(){
        $delete_id = $this->input->get_post('delete_id');
        echo "<pre>";print_r($delete_id);die();
        $delete_result = $this->Model->deleteData('category',array('category_id'=>$delete_id));
        if ($delete_result) {
            $this->session->set_flashdata('msg' ,'Video Category Successfully Deleted.');
            redirect('Dashboard/video_category_list');
        }
        else {
            $this->session->set_flashdata('msg' ,'Something Went Worng Video Category Details Deleted Failed.');
            redirect('Dashboard/video_category_list');
        }
    }
    public function video_sub_category_status(){
        $status = $this->input->post('status');
        if ($status == 0) {
           $status = 1;
        }
        else {
            $status = 0;
        }
        $userData = array(
            'sub_category_id' => $this->input->post('id'),
            'status' => $status
        );
        $ststus_result = $this->Model->updateData('subcategory',$userData, array('sub_category_id'=>$userData['sub_category_id']));
        echo $ststus_result;
    }
    public function banner_add(){
        $get_records = $this->Model->getData('category');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/banner_add';
        $this->load->view('new_admin/containt',$data);
    }
    public function banner_insert() {
        if($this->input->post()) {
            $post_data = $this->input->post();
            //echo "<pre>";print_r($post_data);die();
            if (isset($post_data["submit"]) && !empty($post_data["submit"])) {
                $this->form_validation->set_error_delimiters('<div class="error_color">', '</div>');
                //$this->form_validation->set_rules('category_id', 'Category Name', 'required');
                //$this->form_validation->set_rules('sub_category_id', 'Sub Category Name', 'required');
                $this->form_validation->set_rules('banner_name', 'Banner Name', 'required');
                if (empty($_FILES['banner_Picture']['name'])) {
                    $this->form_validation->set_rules('banner_Picture', 'Upload Banner Image', 'required');
                }

                if ($this->form_validation->run() == FALSE) {
                    $get_records = $this->Model->getData('category');
                    $data['results'] = $get_records;
                    $data['main_containt']='new_admin/banner_add';
                    $this->load->view('new_admin/containt',$data);
                }
                else {
                    if(!empty($_FILES['banner_Picture']['name'])) {             //Check whether user upload Image
                        $config['upload_path'] = 'uploads/banner/';            // check path is correct
                        $config['allowed_types'] = 'jpg|jpeg|png|gif';          // add Image extenstion on here
                        $config['file_name'] = rand()."_banner_image".".png";
                        $this->load->library('upload',$config);                 //Load upload library and initialize configuration
                        $this->upload->initialize($config);
                        if($this->upload->do_upload('banner_Picture')) {
                            $uploadData = $this->upload->data();
                            $picture = $uploadData['file_name'];
                        }
                        else {
                            $picture = '';
                        }
                    }
                    else {
                        $picture = '';
                    }

                    $userData = array(
                        'category_id' => $this->input->post('category_id'),
                        'sub_category_id' => $this->input->post('sub_category_id'),
                        'banner_name' => $this->input->post('banner_name'),
                        'banner_Picture' => $picture,
                        'created' => date('Y-m-d'),
                        'modified' =>date('Y-m-d')

                    );
                    $insert_result = $this->Model->insertData('banner',$userData);
                    $this->session->set_flashdata('msg','Banner Details Successfully Uploaded.');
                    redirect('Dashboard/banner_list');
                }
            }
        }
    }
    public function banner_list() {
        $get_records = $this->Model->getDataOrderBy('banner',array(),'ID','DESC');
        $data['results'] = $get_records;
        $data['main_containt'] = 'new_admin/banner_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function customer_add() {
        $data['main_containt'] = 'new_admin/customer_add';
        $this->load->view('new_admin/containt',$data);
    }
    public function customer_list() {
        $get_records = $this->Model->getDataOrderBy('custumer_login',array(),'id','DESC');
        $data['results'] = $get_records;
        $data['main_containt']='new_admin/customer_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function user_tracking_information_list() {
        $query1 = $this->db->query('SELECT * FROM users_tracking ORDER BY id  DESC');
        $this->load->library('pagination');
        $config=[
            'base_url' => base_url("Dashboard/user_tracking_information_list"),
            'per_page' =>10,
            'total_rows' => $query1->num_rows(),
            'full_tag_open' => '<ul class="pagination">',
            'full_tag_close' => '</ul>',
            'num_tag_open' => '<li class="page-item"><span class="page-link">',
            'num_tag_close' => '</span></li>',
            'cur_tag_open' => '<li class="page-item active"><a class="page-link" href="#">',
            'cur_tag_close' => '</a></li>',
            'prev_tag_open' => '<li class="page-item"><span class="page-link">',
            'prev_tag_close' => '</span></li>',
            'next_tag_open' => '<li class="page-item"><span class="page-link">',
            'next_tag_close' => '</span></li>',
            /*'prev_link' => '<i class="icon-backward"></i>',
            'next_link' => '<i class="icon-forward"></i>',*/
            'last_tag_open' => '<li class="page-item"><span class="page-link">',
            'last_tag_close' => '</span></li>',
            'first_tag_open' => '<li class="page-item"><span class="page-link">',
            'first_tag_close' => '</span></li>'

        ];
        if($this->uri->segment(3)){
            $limit = $this->uri->segment(3);
            $limit1 = $limit+10;
            $query = $this->db->query("SELECT * FROM users_tracking ORDER BY id  DESC LIMIT $limit,10");   
        }
        else {
            $limit1 = 0;
            $limit = 10;
            $query = $this->db->query("SELECT * FROM users_tracking ORDER BY id  DESC LIMIT $limit1,10");
        }
        $data['results']= $query->result_array();
        $this->pagination->initialize($config);
        $data['main_containt']='new_admin/user_tracking_information_list';
        $this->load->view('new_admin/containt',$data);
    }
    // FUNCTIONLITY CODE END BY MOHD ALAM

public function View()
	{
		$id = $_GET['id'];
		$table = $this->Model->getData('slider',array('id'=>$id));
		$data['view'] = $table;
		$data['main_containt']='view_slider';
        
        $this->load->view('new_admin/containt',$data);
	}
	public function Slider_eidt()
	{
            // echo '<pre>'; print_r($_GET); exit;
		$id = $_GET['id'];
		
		$data['table'] = $this->Model->getData('slider',array('id'=>$id));
// echo '<pre>'; print_r($data); exit;
		$data['main_containt']='edit_slider';
        
        $this->load->view('new_admin/containt',$data);
	}
	function Delete(){
        $user_id = $this->input->get_post('id');
        $this->Model->deleteData('slider',array('id'=>$user_id));
        
        $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

        redirect('Dashboard/Slide_list');
    }
//     public function delete_image($id){
//     $image_path = base_url().'uploads/images/'; // your image path

//     // get db record from image to be deleted
//     $query_get_image = $this->db->get_where('slider', array('id' => $id));
//     foreach ($query_get_image->result() as $record)
//     {
//         // delete file, if exists...
//         $filename = $image_path . $record->picture; 
//         if (file_exists($filename))
//         {
//             unlink($filename);
//         }

//         // ...and continue with your code
//         $this->model->delete($id);
//         $query = $this->db->get("slider");
//         $data['records'] = $query->result();
//         $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');
//         redirect('orders/camera_wrap');
//     }
// }
    function Edit(){
          $postData = $_POST;
        $id = $this->input->get_post('id');

        if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/images/';
            $uploadfile = $uploaddir . basename($_FILES['picture']['name']);

            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['picture'] = basename($_FILES['picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('slider',$postData,array('id'=>$id)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
        
        $table = $this->Model->getData('slider');
        $data['sliderpicture'] = $table;
        $data['main_containt']='Slide_list';
        $this->load->view('new_admin/containt',$data);

         // $this->Model->updateData('slider',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The File has been updated successfully.');
         //   redirect('Orders/Camera_wrap');
}

function Add_Pro_banner(){
    $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
    $data['main_containt']='Add_Pro_banner';
        
        $this->load->view('new_admin/containt',$data);
}
function List_Pro_banner(){

    $Pro_banner = $this->Model->getData('pro_banner');
        $data['Pro_banner'] = $Pro_banner;
        $data['main_containt']='List_Pro_banner';
        $this->load->view('new_admin/containt',$data);
}
function List_Of_Cancel_Product(){

    $cancellation_request = $this->Model->getData('cancellation_request',array('status'=>'1'));
            // $strSql = "SELECT * FROM cancellation_request  payment_method='enpay'OR payment_method='PayUMoney'";
            //     $cancellation_request =$this->Model->getSqlData($strSql);
        $data['cancellation_request'] = $cancellation_request;
        $data['main_containt']='cancellation_request';
        $this->load->view('new_admin/containt',$data);
}
function List_Of_Return_Product(){

    $return_order = $this->Model->getData('return_order',array('status'=>'1'));
     // $Pincode = $return_order[0]['address_id'];
     // echo '<pre>'; print_r($Pincode); 
     
     // $return_orderasa = $this->Model->getData('manage_addresses',array('ID'=>$Pincode));
     // echo '<pre>'; print_r($return_orderasa); exit;
//      $address_id = $return_order[0]['address_id'];
// echo '<pre>'; print_r($address_id); exit;
        $data['return_order'] = $return_order;
        $data['main_containt']='return_order_page';
        $this->load->view('new_admin/containt',$data);
}
function Pro_Banner_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('pro_banner',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

        redirect('Dashboard/List_Pro_banner');
    }
public function Pro_Banner_eidt()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Banner_eidt'] = $this->Model->getData('pro_banner',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Banner_eidt']); exit;
        $data['main_containt']='Pro_Banner_eidt';
        
        $this->load->view('new_admin/containt',$data);
    }
    function Pro_Banner_edit_form(){

        $postData = $_POST;
        $ID = $this->input->get_post('ID');
// echo '<pre>'; print_r($postData); exit;
        if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/product/';
            $image= rand()."_entube_gagan".".png";
            $uploadfile = $uploaddir . $image;

            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['picture'] = $image;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('add_video',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
         redirect('Dashboard/list_of_upload');
        // $Pro_banner = $this->Model->getData('pro_banner');
        // $data['Pro_banner'] = $Pro_banner;
        // $data['main_containt']='List_Pro_banner';
        // $this->load->view('new_admin/containt',$data);
      

         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Dashboard/list_banner');
}

  public function Pro_Video_eidt()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Video_eidt'] = $this->Model->getData('add_video',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Video_eidt']); exit;
        $data['main_containt']='Pro_Video_eidt';
        
        $this->load->view('new_admin/containt',$data);
    }
       function Pro_Video_edit_form(){

        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['video'])){
            $uploaddir = './uploads/video/';
             $video=rand()."_entube_gagan".".mp4";
            $uploadfile = $uploaddir . $video;

            if (move_uploaded_file($_FILES['video']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['video'] = $video;
            }
        }
        // echo '<pre>'; print_r($postData['video']); exit;
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('add_video',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
         redirect('Dashboard/list_of_upload');
        // $Pro_banner = $this->Model->getData('pro_banner');
        // $data['Pro_banner'] = $Pro_banner;
        // $data['main_containt']='List_Pro_banner';
        // $this->load->view('new_admin/containt',$data);
      

         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Dashboard/list_banner');
}

    public function Banner_eidt()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];
         $data['categpry_list'] = $this->Model->getData('category',array('status'=>'1'));
        $data['sub_category_list'] =$this->Model->getData('subcategory',array('status'=>'1'));
        $data['banner'] = $this->Model->getData('banner',array('ID'=>$ID));

        $data['main_containt']='banner_eidt';
        
        $this->load->view('new_admin/containt',$data);
    }
    function Banner_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('banner',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The Banner has been deleted successfully.');

        redirect('Dashboard/List_banner');
    }
    function getSubCategory(){
       $postData = $_POST;
        // $postData['category_id'] = 1;

        $sub_category_list = $this->Model->getData('subcategory',array('status'=>'1'));

        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['category_id'] == $value['category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }
      function Banner_edit_form(){
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['banner_Picture'])){
            $gagan=rand().".png";
            $uploaddir = './uploads/banner/';
            $uploadfile = $uploaddir . $gagan;

            if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['banner_Picture'] = $gagan;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('banner',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
        
        redirect('Dashboard/List_banner');


         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Dashboard/list_banner');
}
public function Camera_wrap()
    {
        // $table = $this->Model->getData('slider');
        // $data['sliderpicture'] = $table;
         $data['main_containt']='Slider';
        
        $this->load->view('new_admin/containt',$data);
    }
    function Upend_heading_List(){
        $upend_list = $this->Model->getData('upend_wrapper');
        $data['upend_list'] = $upend_list;
        $data['main_containt']='upend_heading_List';
        $this->load->view('new_admin/containt',$data);    
    }
    public function Upend_eidt()
    {
        $upend_id = $_GET['upend_id'];
        
        $data['table'] = $this->Model->getData('upend_wrapper',array('upend_id'=>$upend_id));
        $data['main_containt']='upend_eidt';

        $this->load->view('new_admin/containt',$data);
    }
    function Upend_delete(){
        $upend_id = $this->input->get_post('upend_id');
        $this->Model->deleteData('upend_wrapper',array('upend_id'=>$upend_id));
        
        $this->session->set_flashdata('msg' ,'The Upend Heading has been deleted successfully.');

        redirect('Dashboard/upend_heading_List');
    }
    public function Edit_upend_form()
    {

        $this->Model->updateData('upend_wrapper',$_POST,array('upend_id'=>$_POST['upend_id']));
        $this->session->set_flashdata('msg','Upend Update Successfully ');
        redirect('Dashboard/upend_heading_List');
    }
    public function Upend_information_list()
    {
        $product_list = $this->Model->getData('wrapper_wellness');
        $data['product_list'] = $product_list;
        $data['main_containt']='Upend_information_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function Append_information_eidt()
    {
        $ID = $_GET['ID'];
        
        $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
        $data['main_containt']='Append_information_eidt';

        $this->load->view('new_admin/containt',$data);
    }
    function Append_information_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('wrapper_wellness',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

        redirect('Dashboard/Upend_information_list');
    }
    public function Slide_list()
    {
        // echo '<pre>'; print_r($_POST);exit;

        $table = $this->Model->getData('slider');
        $data['sliderpicture'] = $table;
        $data['main_containt']='Slide_list';
        $this->load->view('new_admin/containt',$data);
    }
    public function Url_Upend_heading()
    {

        $data['main_containt']='Url_Upend_heading';

        $this->load->view('new_admin/containt',$data);
    }
    public function url_Enter_upend()
    {
        $url_enter=$_POST;
        // echo '<pre>'; print_r($_POST);exit;

        // $this->Add_category_model->insertupend($_POST);
         $this->Model->insertData('url_append_heading',$url_enter);
        $this->session->set_flashdata('msg',' Successfully your Url upend_heading Add');
        redirect('Dashboard/Url_Upend_heading');
    }
    public function Url_Append_information()
    { 
         // $category_data = $this->Model->getData('category');
   //      $data['category_data'] = $category_data;
        $data['upend_information'] = $this->Model->getAllData('url_append_heading');
         $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
        $data['main_containt']='Url_Append_information';

        $this->load->view('new_admin/containt',$data);
    }
    function Url_Upend_heading_List(){
        $table = $this->Model->getData('url_append_heading');
        $data['url_append_heading'] = $table;
        $data['main_containt']='url_append_heading_list';
        $this->load->view('new_admin/containt',$data);
    }
    function Url_Upend_delete(){
        $url_id = $this->input->get_post('url_id');
        $this->Model->deleteData('url_append_heading',array('url_id'=>$url_id));
        
        $this->session->set_flashdata('msg' ,'The Url Upend Heading has been deleted successfully.');

        redirect('Dashboard/Url_Upend_heading_List');
    }
    public function Url_Upend_eidt()
    {
        $url_id = $_GET['url_id'];
        
        $data['table'] = $this->Model->getData('url_append_heading',array('url_id'=>$url_id));
        $data['main_containt']='url_upend_head_eidt';

        $this->load->view('new_admin/containt',$data);
    }
    public function url_Enter_upend_edit()
    {

        $this->Model->updateData('url_append_heading',$_POST,array('url_id'=>$_POST['url_id']));
        $this->session->set_flashdata('msg','Append Heading Update Successfully ');
        redirect('Dashboard/Url_Upend_heading_List');
    }
      function Add_Promo_Code_2(){
        $custumer_login = $this->Model->getData('custumer_login');
        $data['custumer_login'] = $custumer_login;
        $data['main_containt']='Add_Promo_Code_2';
        
        $this->load->view('new_admin/containt',$data);
}
    function Add_Advertisement_banner(){
    
       $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
        $data['main_containt']='Add_Advertisement_banner';
        
        $this->load->view('new_admin/containt',$data);
}
function Url_Upend_information_list(){

    $product_list = $this->Model->getData('url_append_info');
        $data['product_list'] = $product_list;
        $data['main_containt']='Url_Upend_information_list';
        $this->load->view('new_admin/containt',$data);
}
function Url_Append_information_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('url_append_info',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

        redirect('Dashboard/Url_Upend_information_list');
    }
    function Url_Append_information_eidt(){
        $ID = $_GET['ID'];
        $data['url_append_heading'] = $this->Model->getData('url_append_heading',array('status'=>'1'));
         $data['product_category_name'] = $this->Model->getData('product_category',array('status'=>'1'));
        $data['table'] = $this->Model->getData('url_append_info',array('ID'=>$ID));
        $data['main_containt']='Url_Append_information_eidt';

        $this->load->view('new_admin/containt',$data);

    }
    function Url_append_edit_form(){
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Product_Picture'])){
            $uploaddir = './uploads/append/';
            $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

            if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('url_append_info',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        
        $product_list = $this->Model->getData('url_append_info');
        $data['product_list'] = $product_list;
        $data['main_containt']='Url_Upend_information_list';
        $this->load->view('new_admin/containt',$data);
    }
    function Edit_Upend_Product(){
        // echo '<pre>'; print_r($_POST); exit;
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Product_Picture'])){
            $uploaddir = './uploads/wrapper/wellness/';
            $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

            if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('wrapper_wellness',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        
        $product_list = $this->Model->getData('wrapper_wellness');
        $data['product_list'] = $product_list;
        $data['main_containt']='Upend_information_list';
        $this->load->view('new_admin/containt',$data);
    }
    function List_Advertisement_banner(){

    $advertisement = $this->Model->getData('advertisement');
        $data['advertisement'] = $advertisement;
        $data['main_containt']='advertisement_list';
        $this->load->view('new_admin/containt',$data);
}
function Advertisement_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('advertisement',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Advertisement Banner has been deleted successfully.');

        redirect('Dashboard/List_Advertisement_banner');
    }
    function Advertisement_eidt(){
        $ID = $_GET['ID'];
         $data['category_name'] = $this->Model->getData('category',array('status'=>'1'));
        $data['sub_category_name'] = $this->Model->getData('subcategory',array('status'=>'1'));
      
        $data['table'] = $this->Model->getData('advertisement',array('ID'=>$ID));
        $data['main_containt']='Advertisement_eidt';

        $this->load->view('new_admin/containt',$data);

    }
    function Edit_advertisment_banner(){
        // echo '<pre>'; print_r($_POST); exit;
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Advertisement_Picture'])){
            $uploaddir = './uploads/Advertisement/';
            $uploadfile = $uploaddir . basename($_FILES['Advertisement_Picture']['name']);

            if (move_uploaded_file($_FILES['Advertisement_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Advertisement_Picture'] = basename($_FILES['Advertisement_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('advertisement',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Advertisement has been Updated successfully.');
        
        $advertisement = $this->Model->getData('advertisement');
        $data['advertisement'] = $advertisement;
        $data['main_containt']='advertisement_list';
        $this->load->view('new_admin/containt',$data);
    }
    
    function Add_customer_info()
    {
       $user_name = $this->input->get_post('user_name');
       $last_name = $this->input->get_post('last_name');
        $email_id =  $this->input->get_post('email_id');
        $password = $this->input->get_post('password');
        $contact_number =  $this->input->get_post('contact_number');
        

        if($user_name!='' && $email_id!='' && $password!='' && $contact_number!=''){
            $email_info=$this->Model->getData('custumer_login',array('email_id'=>$email_id));
            $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$contact_number));

            if(isset($email_info) && empty($email_info)){
                if(isset($mobile_info) && empty($mobile_info)){
                    $array_data=array(
                        'user_name'=>$user_name,
                        'last_name'=>$last_name,
                        'email_id'=>$email_id,
                        'password'=>md5($password),
                        'contact_number'=>$contact_number,
                        'resigtation_month'=> date('m'),
                        'resigtation_year'=> date('Y'),
                        'resigtation_day'=> date('d'),
                        'resigtation_year_month'=> date('Y-m'),
                        'resigtation_year_month_data' =>date('Y-m-d'),
                        'resigtation_year_month_data_time'=> date('Y-m-d H:i:s'),
                        
                    );
                     $user_inserted_id=$this->Model->insertData('custumer_login',array_map('strtoupper', $array_data));

                     if(!empty($_FILES['Pan_Picture']['name'])){
                         $config['upload_path'] = 'uploads/Customer_pan/';
                         $config['allowed_types'] = 'jpg|jpeg|png|gif';
                        $config['file_name'] = $_FILES['Pan_Picture']['name'];
                        
                        //Load upload library and initialize configuration
                        $this->load->library('upload',$config);
                        $this->upload->initialize($config);
                        
                        if($this->upload->do_upload('Pan_Picture')){
                            $uploadData = $this->upload->data();
                            $picture = $uploadData['file_name'];
                        }else{
                            $picture = '';
                        }
                    }else{
                        $picture = 'no';
                    }
                 $userData = array(
                'Customer_id' =>  $user_inserted_id, 
                'pan_number' => $this->input->post('pan_number'),
                'Pan_Full_Name' => $this->input->post('Pan_Full_Name'),
                'Pan_Picture' => $picture
                 );
                 $this->Customer_login_Information->insert($userData);
                 if($user_inserted_id){

                        $this->session->set_flashdata('msg' ,'Customer account has been registered successfully.');
                        redirect('Dashboard/Add_new_Customer');
                    }else{

                        $this->session->set_flashdata('msg' ,'Error while signing up. please try again.');
                        redirect('Dashboard/Add_new_Customer');

                    }
                        // $user = "oxiinc";
                        // $password = "microlan@123";
                        // $senderId = "OXIINC";
                        // $channel = "Trans";
                        // $dcs = "0";
                        // $flashsms = "0";
                        // $route = "6";
                        // $mobile = $contact_number;
                        // $text_message = "Dear ". $user_name. ". Thank you for Register with us, We have received your Number no ".$contact_number.". We will process your Register at your chosen date and time.";
                        // $sms = urlencode($text_message);

                        // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

                        // try  
                        // {
                        //     $ch = curl_init();
                        //     curl_setopt($ch, CURLOPT_HEADER, 0);
                        //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        //     curl_setopt($ch, CURLOPT_URL, $smsurl);
                        //     $data = curl_exec($ch);
                        //     curl_close($ch);
                        //     $response = $data;
                        // }  
                        // catch (Exception $e)  
                        // {  
                        //     $response = $e->getMessage();  
                        // }
                    
                   

                }else{

                    $this->session->set_flashdata('msg' ,'Mobile number is already registered with us.');
                        redirect('Dashboard/Add_new_Customer');

                }
            }else{

                $this->session->set_flashdata('msg' ,'Email address is already registered with us. Please enter unique email address');
                        redirect('Dashboard/Add_new_Customer');

            }
        }else{
            

            $this->session->set_flashdata('msg' ,'Required parameters are missing.');
                        redirect('Dashboard/Add_new_Customer');
    }
}
 
function Customer_eidt(){
     $ID = $_GET['id'];
        
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
        $data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$ID));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Customer_eidt';

        $this->load->view('new_admin/containt',$data);
}
function edit_customer_info(){

   $user_name = $this->input->get_post('user_name');
       $last_name = $this->input->get_post('last_name');
        $email_id =  $this->input->get_post('email_id');
        $id = $this->input->get_post('id');
        $contact_number =  $this->input->get_post('contact_number');
        $status =  $this->input->get_post('status');
        
                    $array_data=array(
                        'user_name'=>$user_name,
                        'last_name'=>$last_name,
                        'email_id'=>$email_id,
                        // 'password'=>md5($password),
                        'contact_number'=>$contact_number,
                        'status'=>$status,
                        
                    );
                     $this->Model->updateData('custumer_login',$array_data,array('id'=>$id)); 
                     


                        $this->session->set_flashdata('msg' ,'Customer account Updated has been registered successfully.');
                        redirect('Dashboard/List_of_customer');      

}
function Pan_information(){
     $id = $_GET['id'];
      $data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$id));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Pan_information';

        $this->load->view('new_admin/containt',$data);
}
function Promo_Code(){
     $id = $_GET['id'];
      $data['customer_login_info'] = $this->Model->getData('custumer_login',array('id'=>$id));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Promo_Code';

        $this->load->view('new_admin/containt',$data);
}
function Edit_customer_pan_info(){

    $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Pan_Picture'])){
            $uploaddir = './uploads/Customer_pan/';
            $uploadfile = $uploaddir . basename($_FILES['Pan_Picture']['name']);

            if (move_uploaded_file($_FILES['Pan_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Pan_Picture'] = basename($_FILES['Pan_Picture']['name']);
            }
        }
        // echo '<pre>'; print_r($postData['Pan_Picture']); exit;
         $this->Model->updateData('customer_pan_info',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
         redirect('Dashboard/List_of_customer'); 
}
function Customer_Delete(){
        $id = $this->input->get_post('id');
        $this->Model->deleteData('custumer_login',array('id'=>$id));
        $this->session->set_flashdata('msg' ,'The Customer Account has been deleted successfully.');

        redirect('<?php echo base_url();?>new_admin_assets/assets/List_of_customer');
    }
    function Add_customer_Promo_info(){

        $promo_codo = $_POST;
        // echo '<pre>'; print_r($promo_codo); exit;
       $id = $this->Model->insertData('promo_codo',$promo_codo);
       // echo '<pre>'; print_r($id); exit;
       $this->session->set_flashdata('msg' ,'The Promo code has been add successfully.');
       redirect('Dashboard/Add_Promo_Code_2');
    }
      function Add_Promo_info(){

        $promo_codo = $_POST;
        // echo '<pre>'; print_r($promo_codo); exit;
       $id = $this->Model->insertData('promo_codo',$promo_codo);
       // echo '<pre>'; print_r($id); exit;
       $this->session->set_flashdata('msg' ,'The Promo code has been add successfully.');
       redirect('Dashboard/Add_Promo_Code');
    }
     function List_Of_Promo_Code(){

    $promo_codo = $this->Model->getData('promo_codo');
        $data['promo_codo'] = $promo_codo;
        $data['main_containt']='List_Of_Promo_Code';
        $this->load->view('new_admin/containt',$data);
}
     function enpay(){

     $custumer_login = $this->Model->getData('custumer_login');
        $data['custumer_login'] = $custumer_login;
        $data['main_containt']='enpay';
        $this->load->view('new_admin/containt',$data);
}
function enpay_Balance(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        //  $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        // $data['customer_enpay'] = $customer_enpay;
    $data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
        // echo '<pre>'; print_r($data); exit;
        $data['main_containt']='enpay_Balance';
        $this->load->view('new_admin/containt',$data);

}
function Debits_enpay(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        //  $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        // $data['customer_enpay'] = $customer_enpay;
        $data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
        $data['main_containt']='Debits_enpay';
        $this->load->view('new_admin/containt',$data);

}
function Add_enpay_amount(){
 $this->Model->updateData('custumer_login',$_POST,array('id'=>$_POST['id']));
        $this->session->set_flashdata('msg','enpay amount Update Successfully ');
 redirect('Dashboard/enpay');
}
function Add_debits_amount(){
 $this->Model->insertData('customer_enpay',$_POST);
        $this->session->set_flashdata('msg','enpay amount Update Successfully ');
 redirect('Dashboard/enpay');
}
function Credits_enpay(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
         $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        $data['customer_enpay'] = $customer_enpay;
        $data['main_containt']='Credits_enpay';
        $this->load->view('new_admin/containt',$data);

}
function Promo_code_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('promo_codo',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Promo Code has been deleted successfully.');

        redirect('Dashboard/List_Of_Promo_Code');
    }
    function Promo_code_eidt(){
     $ID = $_GET['ID'];
        
        // $data['custumer_login'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
        $data['promo_codo'] = $this->Model->getData('promo_codo',array('ID'=>$ID));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Promo_code_eidt';
// echo '<pre>'; print_r($data['promo_codo']); exit;
        $this->load->view('new_admin/containt',$data);
}
   public function Edit_Promo_code_info()
    {

        $this->Model->updateData('promo_codo',$_POST,array('ID'=>$_POST['ID']));
        $this->session->set_flashdata('msg','Promo code Update Successfully ');
        redirect('Dashboard/List_Of_Promo_Code');
    }
 function List_Of_Wishlist(){

    $wishlist = $this->Model->getData('wishlist');
        $data['wishlist'] = $wishlist;
        $data['main_containt']='List_Of_Wishlist';
        $this->load->view('new_admin/containt',$data);
}
 function append_List_Of_Wishlist(){

    // $wishlist = $this->Model->getData('wishlist');
        // $data['wishlist'] = $wishlist;
        $data['main_containt']='append_List_Of_Wishlist';
        $this->load->view('new_admin/containt',$data);
}
 function List_Of_order_confirmation(){

    $data['customer_order_data'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1'),'ID','DESC');
    // echo '<pre>'; print_r($data['customer_order_data']); exit;
        $data['main_containt']='List_Of_order_confirmation';
        $this->load->view('new_admin/containt',$data);
}
function Product_invoice(){
    $ID = $_GET['ID'];
  $data['Product_invoice'] = $this->Model->getData('order_data',array('ID'=>$ID));
  // echo '<pre>'; print_r($data['Product_invoice']); exit;
   $this->load->view('new_admin/Product_invoice',$data);
}
function Invoice_print(){
     $ID = $_GET['ID'];
  $data['Product_invoice'] = $this->Model->getData('order_data',array('ID'=>$ID));
  $this->load->library('pdfgenerator');
  $html = $this->load->view('new_admin/admin_pdf_invoice', $data, true);
   // $this->load->view('new_admin/admin_pdf_invoice', $data);
  $filename = 'Invoice'.time();
                $this->pdfgenerator->generate($html, $filename, true, 'A4', 'letter');
}
// function order_Confirmation(){
//     // echo '<pre>'; print_r($_GET); exit;
//     $ID = $_GET['ID'];
//     // echo '<pre>'; print_r($ID); exit;
//     $status['dispatchment_confirmation']='1';
//     $this->Model->updateData('order_data',$status,array('ID'=>$ID));
//     $this->session->set_flashdata('msg','Promo code Update Successfully ');
//     redirect('Dashboard/List_Of_order_confirmation');
//     // echo '<pre>'; print_r($ID); exit;
// }
function List_Of_Dispatchment(){
     $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'0'),'ID','DESC');
     // $data['dispatchment_confirmation'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='List_Of_Dispatchment';
        $this->load->view('new_admin/containt',$data);
}
function  E_panelist_List_Of_Dispatchment(){
         $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'0'),'ID','DESC');
     // $data['dispatchment_confirmation'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='E_panelist_List_Of_Dispatchment';
        $this->load->view('new_admin/containt',$data);
}
function Dispatchment_Confirmation(){
 

    $ID = $_POST['ID'];
    $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];

    // echo '<pre>'; print_r($ID); exit;
    $status['dispatchment_confirmation']='1';
    $status['dispatchment_confirmation_info']=$dispatchment_confirmation_info;
  $Update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
    redirect('Dashboard/List_Of_Dispatchment');
    // echo '<pre>'; print_r($ID); exit;
}
function  E_panelist_Dispatchment_Confirmation(){
        $ID = $_POST['ID'];
    $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];

    // echo '<pre>'; print_r($ID); exit;
    $status['dispatchment_confirmation']='1';
    $status['dispatchment_confirmation_info']=$dispatchment_confirmation_info;
  $Update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
    redirect('Dashboard/E_panelist_List_Of_Dispatchment');
}
function List_Of_Shipping(){

     $data['shipping_confirmation'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='List_Of_Shipping';
        $this->load->view('new_admin/containt',$data);
}
function  E_panelist_List_Of_Shipping(){

     $data['shipping_confirmation'] = $this->Model->getData('e_paenlist_order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='E_panelist_List_Of_Shipping';
        $this->load->view('new_admin/containt',$data);
}
function shipping_Confirmation(){

    $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];

    $status['shipping_confirmation']='1';
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Dashboard/List_Of_Shipping');
    // echo '<pre>'; print_r($ID); exit;
}
function E_panelist_shipping_Confirmation(){
        $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];

    $status['shipping_confirmation']='1';
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Dashboard/E_panelist_List_Of_Shipping');
}
function List_Of_Vendor(){
 $data['order_delivered'] = $this->Model->getData('order_data',array('shipping_confirmation'=>'1','order_intransit'=>'0','out_for_delivery'=>'0'));
 $data['main_containt']='List_Of_Vendor';
  $this->load->view('new_admin/containt',$data);
}
function E_panelist_List_Of_Vendor(){
     $data['order_delivered'] = $this->Model->getData('e_paenlist_order_data',array('shipping_confirmation'=>'1','order_intransit'=>'0','out_for_delivery'=>'0'));
 $data['main_containt']='E_panelist_List_Of_Vendor';
  $this->load->view('new_admin/containt',$data);
}
function Out_For_Delivery(){
 $data['Out_For_Delivery'] = $this->Model->getData('order_data',array('order_intransit'=>'1','out_for_delivery'=>'0'));
 $data['main_containt']='Out_For_Delivery';
  $this->load->view('new_admin/containt',$data);
}
function E_panelist_Out_For_Delivery(){
     $data['Out_For_Delivery'] = $this->Model->getData('e_paenlist_order_data',array('order_intransit'=>'1','out_for_delivery'=>'0'));
 $data['main_containt']='E_panelist_Out_For_Delivery';
  $this->load->view('new_admin/containt',$data);
}
function Delivered_Confirmation(){
    // echo '<pre>'; print_r($_GET); exit;
    $ID = $_GET['ID'];
    // echo '<pre>'; print_r($ID); exit;
    $status['order_delivered']='1';
    $this->Model->updateData('order_data',$status,array('ID'=>$ID));
    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Dashboard/List_Of_Vendor');
    // echo '<pre>'; print_r($ID); exit;
}
function In_transit_Confirmation(){

    $ID = $_POST['ID'];
    $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];

    $status['order_intransit']='1';
    $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Dashboard/List_Of_Vendor');

}
function E_panelist_In_transit_Confirmation(){
    $ID = $_POST['ID'];
    $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];

    $status['order_intransit']='1';
    $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Dashboard/E_panelist_List_Of_Vendor');
}
function Out_for_Delivery_Confirmation(){

     $ID = $_POST['ID'];
    $Out_For_Delivery_confirmation_info = $_POST['Out_For_Delivery_confirmation_info'];

     $status['out_for_delivery']='1';
    $status['Out_For_Delivery_confirmation_info']=$Out_For_Delivery_confirmation_info;

  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Dashboard/Out_For_Delivery');

}
function E_panelist_Out_for_Delivery_Confirmation(){
         $ID = $_POST['ID'];
    $Out_For_Delivery_confirmation_info = $_POST['Out_For_Delivery_confirmation_info'];

     $status['out_for_delivery']='1';
    $status['Out_For_Delivery_confirmation_info']=$Out_For_Delivery_confirmation_info;

  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Dashboard/E_panelist_Out_For_Delivery');
}
function Deliverd_info_Confirmation(){
      $ID = $_POST['ID'];
    $Delivered_confirmation_info = $_POST['Delivered_confirmation_info'];

     $status['order_delivered']='1';
    $status['Delivered_confirmation_info']=$Delivered_confirmation_info;

  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Dashboard/List_Of_Delivered');
}
function E_panelist_Deliverd_info_Confirmation(){
          $ID = $_POST['ID'];
    $Delivered_confirmation_info = $_POST['Delivered_confirmation_info'];

     $status['order_delivered']='1';
    $status['Delivered_confirmation_info']=$Delivered_confirmation_info;

  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Dashboard/E_panelist_List_Of_Delivered');
}
function List_Of_Delivered(){
    $data['List_Of_Delivered'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'0'),'ID','DESC');
     $data['main_containt']='List_Of_Delivered';
        $this->load->view('new_admin/containt',$data);
}
function E_panelist_List_Of_Delivered(){
      $data['List_Of_Delivered'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'0'),'ID','DESC');
     $data['main_containt']='E_panelist_List_Of_Delivered';
        $this->load->view('new_admin/containt',$data);
}
function List_Of_Order_Delivered_product(){
     $data['List_Of_Order_Delivered_product'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1'),'ID','DESC');
     $data['main_containt']='List_Of_Order_Delivered_product';
        $this->load->view('new_admin/containt',$data);
}
function E_panelist_List_Of_Order_Delivered_product(){
         $data['List_Of_Order_Delivered_product'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1'),'ID','DESC');
     $data['main_containt']='E_panelist_List_Of_Order_Delivered_product';
        $this->load->view('new_admin/containt',$data);
}
function cancel_enpay_debits(){
   $ID = $_GET['ID'];
    // echo '<pre>'; print_r($ID); exit;
   $cancellation_request = $this->Model->getData('cancellation_request',array('ID'=>$ID));
   $cancel['Customer_id'] = $cancellation_request[0]['customer_id'];
   $cancel['customer_name'] = $cancellation_request[0]['user_name'];
   $cancel['custumer_email']   = $cancellation_request[0]['email_id'];
   $cancel['debits_amount']   = $cancellation_request[0]['Prices'];
   $cancel['debits_status']   = '1';
 $id =   $this->Model->insertData('customer_enpay',$cancel);
 
    $status['status']='0';
  $ID =   $this->Model->updateData('cancellation_request',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','cancellation Request Amount Update Successfully ');
    redirect('Dashboard/List_Of_Cancel_Product');
}
function Cancellation_Confirm(){
   $ID = $_GET['ID'];
 $status['status']='0';
  $ID =   $this->Model->updateData('cancellation_request',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','cancellation Request Amount Update Successfully ');
    redirect('Dashboard/List_Of_Cancel_Product');
}
function Return_Confirm_account(){
   $ID = $_GET['ID'];
 $status['status']='0';
  $ID =   $this->Model->updateData('return_order',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Return Product Update Successfully ');
    redirect('Dashboard/List_Of_Return_Product');
}
public function Total_GST_Report()
    {
        $order_data = $this->Model->getData('order_data',array('order_confirmation'=>'1'));
        $data['order_data'] = $order_data;
         $data['main_containt']='Total_GST_Report';
        
        $this->load->view('new_admin/containt',$data);
    }
    function Order_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('order_data',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The order has been deleted successfully.');

        redirect('Dashboard/List_Of_order_confirmation');
    }
    public function Registred_users()
    {
        $Registred_users_COUNT = $this->Model->CountWhereRecord('custumer_login',array('status'=>'1'));
         $data['Registred_users_COUNT'] = $Registred_users_COUNT;
        $Registred_users = $this->Model->getData('custumer_login',array('status'=>'1'));
        $data['Registred_users'] = $Registred_users;
         $data['main_containt']='Registred_users';
        
        $this->load->view('new_admin/containt',$data);
    }
     function List_chart(){

        $data['main_containt']='List_chart';
        $this->load->view('new_admin/containt',$data);
}
   function List_Login_Logout(){

        $data['main_containt']='List_Login_Logout';
        $this->load->view('new_admin/containt',$data);
}
 function Add_seminar_information(){

        $data['main_containt']='Add_seminar_information';
        $this->load->view('new_admin/containt',$data);
}
function enter_seminar_information(){
$seminar_info = $_POST;
 
   $this->Model->insertData('add_seminar_information',$seminar_info);
 $this->session->set_flashdata('msg','Seminar Information Add successfully');
    redirect('Dashboard/Add_seminar_information');
}
function Seminar_Information_List(){
    $Add_seminar_information = $this->Model->getData('add_seminar_information');
        $data['Add_seminar_information'] = $Add_seminar_information;
         $data['main_containt']='Seminar_Information_List';
        
        $this->load->view('new_admin/containt',$data);
}
function update_seminar_information(){
    $this->Model->updateData('add_seminar_information',$_POST,array('ID'=>$_POST['ID']));
$this->session->set_flashdata('msg','Seminar Information Update successfully');
        redirect('Dashboard/Seminar_Information_List');
}
function List_Of_Ticket_Book_Customer(){
    $summary = $this->Model->getData('summary');
        $data['summary'] = $summary;
         $data['main_containt']='List_Of_Ticket_Book_Customer';
        
        $this->load->view('new_admin/containt',$data);

}
function delete_seminar_ticket(){
      $ID = $this->input->get_post('ID');
        $this->Model->deleteData('summary',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The Ticket has been deleted successfully.');

        redirect('Dashboard/List_Of_Ticket_Book_Customer');

}
function Add_user_role_by_department(){
    $data['id'] = $_POST['id'];
    // echo '<pre>'; print_r($data['id']); exit;
    $data['Add_user'] = $this->Model->getData('users',array('id'=>$_POST['id']));
    // echo '<pre>'; print_r($data['Add_user']); exit;
    $data['main_containt']='Add_user_role_by_department';
        $this->load->view('new_admin/containt',$data);
}
function add_user_role_insert(){
$id = $this->Model->updateData('users',$_POST,array('id'=>$_POST['user_id']));
// echo '<pre>'; print_r($id); exit;
$this->session->set_flashdata('msg' ,'User Role Add successfully.');
redirect('Usersadmin/Add_User_Role');
}



function My_Digital_allow(){
   // echo '<pre>'; print_r($_POST); 
    $video_allow_id = $_POST['video_allow_id'];
    $i = 0;
        foreach ($video_allow_id as $key => $value) {

             $PQR =  mt_rand(10000,999999);
            $SKU = 'OXIINC'.$PQR;
// echo '<pre>'; print_r($SKU); exit;
$var['allow_video'] = '1';
 $this->Model->updateData('add_video',$var,array('ID'=>$value));


            $product_data = $this->Model->getData('add_video',array('ID'=>$value));
            // echo '<pre>'; print_r($product_data); exit;
            $allow_data = array(
                   
                    'category_id'=>$product_data[0]['category_id'],
                    'Video_Name'=>$product_data[0]['Video_Name'],
                    'Video_Title'=>$product_data[0]['Video_Title'],
                    'Short_Description'=>$product_data[0]['Short_Description'],
                    'large_Description'=>$product_data[0]['large_Description'],
                    'Specification_Description'=>$product_data[0]['Specification_Description'],
                    'picture'=>$product_data[0]['picture'],
                    'video'=>$product_data[0]['video'],
                    
                    'video_ID'=>$product_data[0]['ID'],
                    'video_allow_id'=>$value,
                    'panel_name'=>$_POST['panel_name'],
                    'expirey_date'=>$_POST['expirey_date'],
                    'caption_code'=>$SKU,
                    'allow_information'=>$_POST['Shipping_confirmation_info'],

                    'allow_month'=> date('m'),
                    'allow_year'=> date('Y'),
                    'allow_day'=> date('d'),
                    'allow_year_month'=> date('Y-m'),
                    'allow_year_month_data' =>date('Y-m-d'),
                    'allow_year_month_data_time'=> date('Y-m-d H:i:s')
                    
                );
         $order_id = $this->Model->insertData('allow_data_my_digital',$allow_data);
        
        $i++;
        }
        $this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Dashboard/digital_markating_program');
       // echo '<pre>'; print_r($i); 
// echo '<pre>'; print_r($allow_data); exit;
}

function My_Digital_allow_no(){
    $product_allow_id = $_POST['video_allow_id'];
    $i = 0;
        foreach ($product_allow_id as $key => $value) {
            $var['allow_video'] = '0';
 $this->Model->updateData('add_video',$var,array('ID'=>$value));
               $i++;
        }
         $this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Dashboard/digital_marketing_allow_video');
}

public function Update_allowed()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Banner_eidt'] = $this->Model->getData('allow_data_my_digital',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Banner_eidt']); exit;
        $data['main_containt']='Edit_allowed';
        
        $this->load->view('new_admin/containt',$data);
    }
    
          function Pro_allowed_edit_form(){

        $postData = $_POST;
        $ID = $this->input->get_post('ID');
// echo '<pre>'; print_r($_FILES['picture']); exit;
        if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/product/';
            $image= rand()."entube_gagan".".png";
            $uploadfile = $uploaddir . $image;

            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['picture'] = $image;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('allow_data_my_digital',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
         redirect('Dashboard/allowed');
        
}
function allowed_delete_video(){
    $ID = $this->input->get_post('ID');
    // echo  $ID;
        $this->Model->deleteData('allow_data_my_digital',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The video has been deleted successfully.');

        redirect('Dashboard/allowed');
}


function Pending(){
    $add_video = $this->Model->getDataOrderBy('add_video',array('status'=>'0','reason'=>' '),'ID','DESC');
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='Approve_Disapprove_video';
        $this->load->view('new_admin/approve_disapprove_video',$data);
}

function Approve_video(){
    
//   echo "<pre>"; print_r($_POST);
    $data['status'] ="1";
    $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
// if($conn){
//    echo "connect"; 
// }else{
//     echo "not connect"; 
// }





   
    $data['status'] ="1";
    $data['priority'] =$_POST['priority'];
  date_default_timezone_set('Asia/Kolkata');
      $data['approved_time'] =date('d-m-Y H:i');
    $add_video= $this->Model->getData('add_video',array('ID'=>$_POST['ID']));
    
    // echo "<pre>"; print_r($data);exit();
       $login_gagan_info = $this->Model->getData('custumer_login',array('id'=>$add_video[0]['user_id'],'status'=>'1'));
                                  if(!$login_gagan_info){

                                      $email=$add_video[0]['user_id'];
                                      // echo 'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"';
              $result=mysqli_query($conn,'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"');
$customer_information=mysqli_fetch_assoc($result);
$to_email_address=$customer_information['email'];
// echo "<pre>";print_r($customer_information['email']);


                                  }else{

                                    if($login_gagan_info[0]['channel_name']){
                                       $email= $login_gagan_info[0]['channel_name'];
                                      }else{
                                     $email= $login_gagan_info[0]['user_name']." ".$login_gagan_info[0]['last_name'];
                                      }
                                      $to_email_address= $login_gagan_info[0]['email_id'];
                                  }
                                 
                                   $subject = 'Your video has been approved';
                $emailer = 'emailer/approve.html';
                $mail_content = file_get_contents($emailer);
                 $img_url='https://www.entube.in/uploads/product/'.$add_video[0]['picture'];
                // echo '<pre>'; print_r($mail_content); exit;
                 $mail_content = str_replace('@__imgurl__@', $img_url, $mail_content);
                 $mail_content = str_replace('@_users_names_@', $email, $mail_content);
                 $mail_content = str_replace('@_video_@', $add_video[0]['ID'], $mail_content);
                 // $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                 $mail_content = str_replace('@_title_@', $add_video[0]['Video_Name'], $mail_content);

                 $this->load->library('email');
                

                            $config = Array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.oxiinc.in',
    'smtp_port' => 587,
    'smtp_user' => 'noreply@entube.in',
    'smtp_pass' => '@@entube',
     'mailtype' => 'html',
    'charset' => 'iso-8859-1'
);

                    
$this->email->initialize($config);
$this->email->from('noreply@entube.in', 'Entube');
$this->email->to($to_email_address);
// // $this->email->cc('another@another-example.com');
// // $this->email->bcc('them@their-example.com');

$this->email->subject($subject); 
$this->email->message($mail_content);
// $this->email->attach($mail_content);
$this->email->send();
    $this->Model->updateData('add_video',$data,array('ID'=>$_POST['ID']));
    redirect('Dashboard/Approve');
    
}
function Dis_Approve_video(){
    
   
    // $data['status'] ="1";
    //  print_r($_POST);
    // exit();
    $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
$add_video= $this->Model->getData('add_video',array('ID'=>$_POST['ID']));
       $login_gagan_info = $this->Model->getData('custumer_login',array('id'=>$add_video[0]['user_id'],'status'=>'1'));
                                  if(!$login_gagan_info){

                                      $email=$add_video[0]['user_id'];
                                      // echo 'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"';
              $result=mysqli_query($conn,'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"');
$customer_information=mysqli_fetch_assoc($result);
$to_email_address=$customer_information['email'];
// echo "<pre>";print_r($customer_information['email']);


                                  }else{

                                    if($login_gagan_info[0]['channel_name']){
                                       $email= $login_gagan_info[0]['channel_name'];
                                      }else{
                                     $email= $login_gagan_info[0]['user_name']." ".$login_gagan_info[0]['last_name'];
                                      }
                                      $to_email_address= $login_gagan_info[0]['email_id'];
                                  }
                                 
                                   $subject = 'Your video has been rejected';
                $emailer = 'emailer/reject.html';
                $mail_content = file_get_contents($emailer);
                 $img_url='https://www.entube.in/uploads/product/'.$add_video[0]['picture'];
                // echo '<pre>'; print_r($mail_content); exit;
                 $mail_content = str_replace('@__imgurl__@', $img_url, $mail_content);
                 $mail_content = str_replace('@_users_names_@', $email, $mail_content);
                 $mail_content = str_replace('@_video_@', $add_video[0]['ID'], $mail_content);
                 $mail_content = str_replace('@_reason_@', $_POST['reason'], $mail_content);
                 // $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                 $mail_content = str_replace('@_title_@', $add_video[0]['Video_Name'], $mail_content);

                 $this->load->library('email');
                

                            $config = Array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.oxiinc.in',
    'smtp_port' => 587,
    'smtp_user' => 'noreply@entube.in',
    'smtp_pass' => '@@entube',
     'mailtype' => 'html',
    'charset' => 'iso-8859-1'
);

                    
$this->email->initialize($config);
$this->email->from('noreply@entube.in', 'Entube');
$this->email->to($to_email_address);
// // $this->email->cc('another@another-example.com');
// // $this->email->bcc('them@their-example.com');

$this->email->subject($subject); 
$this->email->message($mail_content);
// $this->email->attach($mail_content);
$this->email->send();
 date_default_timezone_set('Asia/Kolkata');
      $_POST['approved_time'] =date('d-m-Y H:i');
    $this->Model->updateData('add_video',$_POST,array('ID'=>$_POST['ID']));
    redirect('Dashboard/Approve');
    
}
function Dis_Approve_video_list(){
    
   
    // $data['status'] ="1";
    //  print_r($_POST);
    // exit();
     $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
$add_video= $this->Model->getData('add_video',array('ID'=>$_POST['ID']));
       $login_gagan_info = $this->Model->getData('custumer_login',array('id'=>$add_video[0]['user_id'],'status'=>'1'));
                                  if(!$login_gagan_info){

                                      $email=$add_video[0]['user_id'];
                                      // echo 'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"';
              $result=mysqli_query($conn,'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"');
$customer_information=mysqli_fetch_assoc($result);
$to_email_address=$customer_information['email'];
// echo "<pre>";print_r($customer_information['email']);


                                  }else{

                                    if($login_gagan_info[0]['channel_name']){
                                       $email= $login_gagan_info[0]['channel_name'];
                                      }else{
                                     $email= $login_gagan_info[0]['user_name']." ".$login_gagan_info[0]['last_name'];
                                      }
                                      $to_email_address= $login_gagan_info[0]['email_id'];
                                  }
                                 
                                   $subject = 'Your video has been rejected';
                $emailer = 'emailer/reject.html';
                $mail_content = file_get_contents($emailer);
                 $img_url='https://www.entube.in/uploads/product/'.$add_video[0]['picture'];
                // echo '<pre>'; print_r($mail_content); exit;
                 $mail_content = str_replace('@__imgurl__@', $img_url, $mail_content);
                 $mail_content = str_replace('@_users_names_@', $email, $mail_content);
                 $mail_content = str_replace('@_video_@', $add_video[0]['ID'], $mail_content);
                 $mail_content = str_replace('@_reason_@', $_POST['reason'], $mail_content);
                 // $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                 $mail_content = str_replace('@_title_@', $add_video[0]['Video_Name'], $mail_content);

                 $this->load->library('email');
                

                            $config = Array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.oxiinc.in',
    'smtp_port' => 587,
    'smtp_user' => 'noreply@entube.in',
    'smtp_pass' => '@@entube',
     'mailtype' => 'html',
    'charset' => 'iso-8859-1'
);

                    
$this->email->initialize($config);
$this->email->from('noreply@entube.in', 'Entube');
$this->email->to($to_email_address);
// // $this->email->cc('another@another-example.com');
// // $this->email->bcc('them@their-example.com');

$this->email->subject($subject); 
$this->email->message($mail_content);
// $this->email->attach($mail_content);
$this->email->send();
date_default_timezone_set('Asia/Kolkata');
      $_POST['approved_time'] =date('d-m-Y H:i');
    $this->Model->updateData('add_video',$_POST,array('ID'=>$_POST['ID']));
    redirect('Dashboard/approved_list');
    
}
    // function Url_append_edit_form(){
    //     // echo '<pre>'; print_r($_POST); exit;
    //     $ID = $this->input->get_post('ID');
    //     $Product_Name = $this->input->get_post('Product_Name');
    //     $Product_offer = $this->input->get_post('Product_offer');
    //     $Product_short_name = $this->input->get_post('Product_short_name');

        

            
    //         if($_FILES['Product_Picture']['name'] != ''){

    //             $uploaddir = './uploads/append/';
    //             $filename = rand().basename($_FILES['Product_Picture']['name']);
    //             $uploadfile = $uploaddir.$filename;
                

    //             if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
    //               echo "File is valid, and was successfully uploaded.\n";
    //               $picture = $filename;
    //             } else {
    //                echo "Upload failed";
    //                $picture = "";
    //             }
    //         }
    //         else{
    //            $picture =  $_POST['Product_Picture'];
    //         }
    //         $update_data = array(
    //             'Product_Name'=>$Product_Name,
    //             'Product_offer'=>$Product_offer,
    //             'Product_short_name'=>$Product_short_name,
                
    //             'Product_Picture' => $picture
    //         );
    //         $this->Model->updateData('url_append_info',$update_data,array('ID'=>$ID));

             
    //         $this->session->set_flashdata('msg','Supplier updated successfully.');
    //         redirect('Dashboard/Url_Upend_information_list');
    //     }
//     function editprojectimage_pro($ID)  
// {

//   $config['upload_path'] = './uploads/append/';
//   $config['allowed_types'] = 'jpg|jpeg|png|gif';
//   // $config['max_size'] = '2000';


//   $this->load->library('upload', $config);

//   if ( ! $this->upload->do_upload())
//   {
//    //check for errors with the upload
//    $error = array('error' => $this->upload->display_errors());
//    // $this->load->view('new_admin/templates/header');
//    // $this->load->view('new_admin/edit-project-image');
//    // $this->load->view('new_admin/templates/footer');
//   }
//   else
//   {
//    //upload the new image
//    $upload_data = $this->upload->data();
//    $image_name = $upload_data['Product_Picture'];

//    if($_POST){

//    $data = array(
//     'Product_Name' => $this->input->post('Product_Name'),
//                 'Product_offer' => $this->input->post('Product_offer'),
//                 'Product_short_name' => $this->input->post('Product_short_name'),
//     'Product_Picture'=>$image_name
    
//    );

//                         //update
//    $this->Text->update_project($data);
//    }
  
//    redirect(base_url().'Dashboard/Add_Advertisement_banner');

//   }
// }
    // function Url_append_edit_form(){
    //     $ID = $this->input->get_post('ID');

    //     if($this->input->post('userSubmit')){
    //         // echo '<pre>'; print_r($_FILES); exit;
            
    //         //Check whether user upload picture
    //         if(!empty($_FILES['Product_Picture']['name'])){
    //             $config['upload_path'] = 'uploads/Advertisement/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['Product_Picture']['name'];
                
    //             //Load upload library and initialize configuration
    //             $this->load->library('upload',$config);
    //             $this->upload->initialize($config);
                
    //             if($this->upload->do_upload('Product_Picture')){
    //                 $uploadData = $this->upload->data();
    //                 $picture = $uploadData['file_name'];
    //             }else{
    //                 $picture = '';
    //             }
    //         }else{
    //             $picture = '';
    //         }
            
    //         //Prepare array of user data
    //         $userData = array(
    //             'Product_Name' => $this->input->post('Product_Name'),
    //             'Product_offer' => $this->input->post('Product_offer'),
    //             'Product_short_name' => $this->input->post('Product_short_name'),
    //             'Product_Picture' => $picture
    //         );

            
    //         //Pass user data to model
    //         $this->Model->updateData('url_append_info',$userData,array('ID'=>$ID));
    //         // $insertUserData = $this->Advertisement_add->insert($userData);
    //         $this->session->set_flashdata('msg','successfully your Banner image uploaded');
    //         redirect('Dashboard/Add_Advertisement_banner');
            
            
    //     }
    //     //Form for adding user data
    //     // $this->load->view('new_admin/views/camera_wrap');
        
    // }
    // function update_supplier_form(){
    //     $ID = $this->input->get_post('ID');
    //     $banner_name = $this->input->get_post('banner_name');
    //     $category_id = $this->input->get_post('category_id');
    //     $sub_category_id = $this->input->get_post('sub_category_id');
 
    //         if(!empty($_FILES['banner_Picture']['name']))
    //         {

    //             $config['upload_path'] = 'uploads/banner/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['banner_Picture']['name'];
    //              $this->load->library('upload',$config);
    //              $this->upload->initialize($config);

    //             if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $config)) {
    //               echo "File is valid, and was successfully uploaded.\n";
    //               $picture = $file_name;
    //             } else {
    //                echo "Upload failed";
    //                $picture = "";
    //             }
    //         }
    //         else{
    //            $picture =  $_POST['picture'];
    //         }
            
          
    //         $update_data = array(
    //             'banner_name'=>$banner_name,
    //             'category_id'=>$category_id,
    //             'sub_category_id'=>$sub_category_id,
    //             'banner_Picture' => $picture
    //         );
    //         // print_array($update_data);
    //         $this->model->updateData('banner',$update_data,array('ID'=>$ID)); 
    //         $this->session->set_flashdata('msg','banner updated successfully.');
    //         redirect('Dashboard/list_banner');
        
    //   }
    //   function add(){
    //     if($this->input->post('userSubmit')){
    //         // echo '<pre>'; print_r($_FILES); exit;
            
    //         //Check whether user upload picture
    //         if(!empty($_FILES['Product_Picture']['name'])){
    //             $config['upload_path'] = 'uploads/product/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['Product_Picture']['name'];
                
    //             //Load upload library and initialize configuration
    //             $this->load->library('upload',$config);
    //             $this->upload->initialize($config);
                
    //             if($this->upload->do_upload('Product_Picture')){
    //                 $uploadData = $this->upload->data();
    //                 $picture = $uploadData['file_name'];
    //             }else{
    //                 $picture = '';
    //             }
    //         }else{
    //             $picture = '';
    //         }
            
    //         //Prepare array of user data
    //         $userData = array(
    //             'Product_Name' => $this->input->post('Product_Name'),
    //             'category_id' => $this->input->post('category_id'),
    //             'sub_category_id' => $this->input->post('sub_category_id'),
    //             'sub_category_name' => $this->input->post('sub_category_name'),
    //             'Short_Description' => $this->input->post('Short_Description'),
    //             'Original_Prices' => $this->input->post('Original_Prices'),
    //             'Prices' => $this->input->post('Prices'),
    //             'Product_Picture' => $picture
    //         );

            
    //         //Pass user data to model
    //         $insertUserData = $this->wellness_add->insert($userData);
    //         $this->session->set_flashdata('msg','successfully your Product image uploaded');
    //         redirect('Product/add_product');
            
            
    //     }
    //     //Form for adding user data
    //     // $this->load->view('new_admin/views/camera_wrap');
        
    // }


public function user_tracking_information_pagination()
{ 
    if($_POST['username']){
     $sql="select * from users_tracking where username='".$_POST['username']."' and date_1 between '" .$_POST['start']. " 00:00:00' and  '" . $_POST['end'] . " 00:00:00'  order by id  desc";
     $data['username']=$_POST['username'];
     $data['start']=$_POST['start'];
     $data['end']=$_POST['end'];
    }else{
  $sql="select * from users_tracking where   date_1 between '" .$_POST['start']. " 00:00:00' and  '" . $_POST['end'] . " 00:00:00'  order by id  desc";
  $data['start']=$_POST['start'];
  $data['end']=$_POST['end'];
    }
    $query1 = $this->db->query($sql);
    $this->load->library('pagination');
         $config=[
        'base_url' => base_url("Dashboard/user_tracking_information_pagination_call/".$_POST['username']."/".$_POST['start']."/".$_POST['end']),
        'per_page' =>10,
        'total_rows' => $query1->num_rows(),

        'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
        'full_tag_close'=>'</ul>',

        'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
        'cur_tag_close'=>'</a></li>',

        'num_tag_open'=>'<li>',
        'num_tag_close'=>'</li>',

        'first_link'=>'First',
        'first_tag_open'=>'<li>',
        'first_tag_close'=>'</li>',

        'last_link'=>'Last',
        'last_tag_open'=>'<li>',
        'last_tag_close'=>'</li>',

        'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
        'prev_tag_open'=>'<li>',
        'prev_tag_close'=>'</li>',

        'next_link'=>'<span aria-hidden="true">&raquo;</span>',
        'next_tag_open'=>'<li>',
        'next_tag_close'=>'</li>'
 ];
//  $config["num_links"] = 10;
 if($this->uri->segment(6)){
   $limit=$this->uri->segment(6);  
   $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
   $run_data=$sql." limit $limit,10";
 
 }else{
     $limit1=0;
     $limit=10;  
     
$run_data= $sql." limit $limit1,10";
 }
 // echo $run_data;
 $query_data = $this->db->query($run_data);   
$data['user_tracking_info']= $query_data->result_array();
  $this->pagination->initialize($config);
 $data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r( $query_data->result_array());exit();
  $this->load->view('new_admin/containt',$data);
}

public function user_tracking_information_pagination_call()
{ 
    if($this->uri->segment(3)){
     $sql="select * from users_tracking where username='".$this->uri->segment(3)."' and date_1 between '" .$this->uri->segment(4). " 00:00:00' and  '" . $this->uri->segment(5) . " 00:00:00'  order by id  desc";

     $data['username']=$_POST['username'];
     $data['start']=$_POST['start'];
     $data['end']=$_POST['end'];
    }else{
  $sql="select * from users_tracking where   date_1 between '" .$this->uri->segment(4). " 00:00:00' and  '" . $this->uri->segment(5) . " 00:00:00'  order by id  desc";
     $data['start']=$_POST['start'];
     $data['end']=$_POST['end'];
    }
    $query1 = $this->db->query($sql);
    $this->load->library('pagination');
         $config=[
        'base_url' => base_url("Dashboard/user_tracking_information_pagination_call/".$this->uri->segment(3)."/".$this->uri->segment(4)."/".$this->uri->segment(5)),
        'per_page' =>10,
        'total_rows' => $query1->num_rows(),

        'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
        'full_tag_close'=>'</ul>',

        'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
        'cur_tag_close'=>'</a></li>',

        'num_tag_open'=>'<li>',
        'num_tag_close'=>'</li>',

        'first_link'=>'First',
        'first_tag_open'=>'<li>',
        'first_tag_close'=>'</li>',

        'last_link'=>'Last',
        'last_tag_open'=>'<li>',
        'last_tag_close'=>'</li>',

        'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
        'prev_tag_open'=>'<li>',
        'prev_tag_close'=>'</li>',

        'next_link'=>'<span aria-hidden="true">&raquo;</span>',
        'next_tag_open'=>'<li>',
        'next_tag_close'=>'</li>'
 ];
//  $config["num_links"] = 10;
 if($this->uri->segment(6)){
   $limit=$this->uri->segment(6);  
   $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
   $run_data=$sql." limit $limit,10";
 
 }else{
     $limit1=0;
     $limit=10;  
     
$run_data= $sql." limit $limit1,10";
 }
 // echo $run_data;
 $query_data = $this->db->query($run_data);   
$data['user_tracking_info']= $query_data->result_array();
  $this->pagination->initialize($config);
 $data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r($sql);exit();
  $this->load->view('new_admin/containt',$data);
}
function budget_and_audience($value=''){
    $add_video = $this->Model->getDataOrderBy('budget_and_audience',array('status!='=>'3'),'created_date','DESC');
        $data['budget_and_audience'] = $add_video;
     $data['main_containt']='budget_and_audience';
 // echo"<pre>";print_r($sql);exit();
  $this->load->view('new_admin/containt',$data);
}
function budget_and_audience_add($value=''){
    // echo "<pre>";print_r($_POST);exit();
    if(!empty($_POST['id'])){
          $this->Model->updateData('budget_and_audience',$_POST,array('id'=>$_POST['id']));
          redirect('Dashboard/budget_and_audience');
    }else{
         $this->Model->insertData('budget_and_audience',$_POST);
         redirect('Dashboard/budget_and_audience');
    }
  
}
function advertisement_list($value=''){
     $givenDate=date("Y-m-d");
     $from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
     $to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));
     $sql ="SELECT  shad.*,svv.*
	   FROM allow_data_my_digital AS shad 
	   LEFT JOIN sponsored_video_view AS svv ON shad.ID = svv.a_id
	   WHERE shad.allow_year_month_data >='".$to_date."'
	   AND shad.allow_year_month_data <='".$from_date."' order by shad.ID DESC ";
    $data['advertisement_list'] = $this->Model->getSqlData($sql);
    $data['main_containt']='advertisement_list_view';
    $this->load->view('new_admin/containt',$data);
}
function advertisement_list_fetch($value=''){
	 $givenDate=date("Y-m-d");
     $from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
     $to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));
     $sql ="SELECT  shad.*,svv.*
	   FROM allow_data_my_digital AS shad 
	   LEFT JOIN sponsored_video_view AS svv ON shad.ID = svv.a_id
	   WHERE shad.allow_year_month_data >='".$to_date."'
	   AND shad.allow_year_month_data <='".$from_date."' AND shad.ID ='".$_POST['id']."'  ";
	   $strSql = "SELECT * FROM countries";
  $data['countries'] =$this->Model->getSqlData($strSql);
  $budget_and_audience = "SELECT * FROM budget_and_audience where status!=3";
  $data['budget_and_audience'] =$this->Model->getSqlData($budget_and_audience);
    $data['advertisement_list'] = $this->Model->getSqlData($sql);
     $this->load->view('new_admin/advertisement_list_fetch',$data);
}
function sponsored_video_submit($value=''){
	$data=$_POST;
	$this->Model->updateData('allow_data_my_digital',$data,array('ID'=>$_POST['id']));
    redirect('Dashboard/advertisement_list');
}
function sponsored_video_delete($value=''){
	$this->Model->deleteData('allow_data_my_digital',array('ID'=>$this->uri->segment(3)));
	redirect('Dashboard/advertisement_list');
}
}