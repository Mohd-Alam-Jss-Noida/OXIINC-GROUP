<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class part1 extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
        $this->load->model('part1_model');
        
        if(!$this->session->userdata('is_logged_in')){
         	redirect('login');
         }
	}
	public function abcd()
	{
		$this->load->view('part1');
	}
	public function add()
	{
		// echo '<pre>'; print_r($_POST);exit;
		$this->part1_model->add($_POST);
		redirect('part1/list');
	}
	public function list()
	{
		$table = $this->part1_model->get('table');
		$data['h'] = $table;
		$this->load->view('list',$data);

	}
	public function edit()
	{
		
		$id = $_GET['id'];
		$data['table'] = $this->part1_model->get('table',array('id'=>$id));
        // echo '<pre>';
		// print_r($table);
		$this->load->view('edit',$data);
	}
	public function update()
	{
		// echo '<pre>'; print_r($_POST);exit;
		$this->part1_model->update('table',$_POST,array('id'=>$_POST['id']));
		redirect('part1/list');
	}


}
