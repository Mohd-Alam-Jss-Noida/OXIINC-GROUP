<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usersadmin extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
         // $this->load->model('Addusers');
         // $this->load->model('Orders_model');

         if(!$this->session->userdata('is_logged_in')){
         	redirect('login');
         }
	}
	public function Add_users()
	{

		$data['main_containt']='add_users';

        $this->load->view('containt',$data);
	}
	public function Add_users_info()
	{
           $user_array = $_POST;
           $user_array['status'] = '1';
           $user_array['user_password'] = md5($user_array['user_password']);
           $this->Model->insertData('users',$user_array);
		// $this->addusers->insertData($_POST);
  //       $data['user_password'] = md5($data['user_password']);
		$this->session->set_flashdata('msg',' User Added Successfully ');
		redirect('usersadmin/add_users');
	}
	public function Users_List()
	{
        $users_list = $this->Model->getData('users');
		$data['users_list'] = $users_list;
		$data['main_containt']='users_List';
        $this->load->view('containt',$data);
	}
	function Users_delete(){
        $id = $this->input->get_post('id');
        $this->Model->deleteData('users',array('id'=>$id));
        
        $this->session->set_flashdata('msg' ,'The Users has been deleted successfully.');

        redirect('usersadmin/users_List');
    }
	public function Users_eidt()
	{
        $id = $_GET['id'];
		
		$data['user_edit'] = $this->Model->getData('users',array('id'=>$id));
		$data['main_containt']='user_edit';

        $this->load->view('containt',$data);
	}
	public function Edit_user_form()
	{

		$this->Model->updateData('users',$_POST,array('id'=>$_POST['id']));
        $this->session->set_flashdata('msg','Users Update Successfully ');
		redirect('usersadmin/users_List');
	}
	public function Add_User_Role(){
		  $users_list = $this->Model->getData('users');
		$data['users_list'] = $users_list;
		$data['main_containt']='Add_User_Role';
        $this->load->view('containt',$data);
	}
}
