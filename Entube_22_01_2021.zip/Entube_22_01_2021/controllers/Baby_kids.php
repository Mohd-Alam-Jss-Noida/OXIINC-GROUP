<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Baby_kids extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Baby_kids_add');
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function add(){
        if($this->input->post('userSubmit')){
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['Product_Picture']['name'])){
                $config['upload_path'] = 'uploads/babykids/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['Product_Picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('Product_Picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'Product_Name' => $this->input->post('Product_Name'),
                'baby_kids_type' => $this->input->post('baby_kids_type'),
                'Short_Description' => $this->input->post('Short_Description'),
                'Original_Prices' => $this->input->post('Original_Prices'),
                'Prices' => $this->input->post('Prices'),
                'Product_Picture' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->Baby_kids_add->insert($userData);
            $this->session->set_flashdata('msg','successfully your Product image uploaded');
            redirect('Product/baby_kids');
            
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}