<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_login_page extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
          $this->load->model('Text');
          // $this->load->model('Cart_model');
          //  $this->load->model('Add_category_model');
           // $this->load->model('customer');
          if($this->session->userdata('logged_in')){
         
         }else if($this->session->userdata('entube_customer_logged_in') ){
             
         }else{
             	redirect('Home');
         }

     }
     public function Playlist_Add_()
	{
		// echo '<pre>'; print_r($_POST); exit;
			if ($_POST['create_new'] =='') {
// echo '<pre>'; print_r($_POST); exit;
		$video_information = $this->Model->getData('add_video',array('status'=>1,'ID'=>$_POST['video_id']));
	// echo '<pre>'; print_r($video_information);
		foreach ($_POST['playlistname_ID'] as $key => $value) {
			// echo '<pre>'; print_r($value); exit;
		$playlist_video_select['normal_id']=$this->session->userdata('id');
			$playlist_video_select['playlistname_id']=$value;
			$playlist_video_select['video_id']=$_POST['video_id'];
			$playlist_video_select['video_name']=$video_information[0]['Video_Name'];
			$playlist_video_select['video_category_id']=$video_information[0]['category_id'];
			// echo '<pre>'; print_r($playlist_video_select); exit;

			$this->Model->insertData('playlist_video_select',$playlist_video_select);
			
		}
		redirect($_POST['url']);
	}elseif ($_POST['create_new'] !=''){
		// echo '<pre>'; print_r('hii'); exit;
		
			$playlist_video_select1['normal_id']=$this->session->userdata('id');
			$playlist_video_select1['playlistname']=$_POST['create_new'];

			$ID=$this->Model->insertData('playlist_names',$playlist_video_select1);
			// echo '<pre>'; print_r($ID); exit;

		$video_information = $this->Model->getData('add_video',array('status'=>1,'ID'=>$_POST['video_id']));

	
			$playlist_video_select['normal_id']=$this->session->userdata('id');
			$playlist_video_select['playlistname_id']=$ID;
			$playlist_video_select['video_id']=$_POST['video_id'];
			$playlist_video_select['video_name']=$video_information[0]['Video_Name'];
			$playlist_video_select['video_category_id']=$video_information[0]['category_id'];

			$this->Model->insertData('playlist_video_select',$playlist_video_select);
			redirect($_POST['url']);
	}else{
		redirect($_POST['url']);
	}
	}
	public function report_information_video_()
	{
		$playlist_video_select['v_id']=$_POST['video_id'];
	$playlist_video_select['video_report_info']=$_POST['report_info'];
			$playlist_video_select['normal_id']=$this->session->userdata('id');
			
			

			$this->Model->insertData('report_video',$playlist_video_select);
			redirect($_POST['url']);
	}
	public function Subscribe_channel()
	{
		  $jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['report'];
        // echo '<pre>'; print_r($array_entity); exit;
        $datainfo['channel_id'] = $array_entity['value_info'];
        $datainfo['my_id'] = $array_entity['my_id'];
        // echo '<pre>'; print_r($datainfo); exit;
		$insert_id = $this->Model->insertData('subscribe_channel',$datainfo);
		//echo '<pre>'; print_r($ID); exit;
		if ($insert_id) {
        	$data['status'] = $insert_id;
        }
        else{
        	$data['status'] = 0;
        }
        echo json_encode($data);
	}
	public function Subscribe_channel_after($value='')
	{
		$jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['report'];
        // echo '<pre>'; print_r($array_entity); exit;
        $datainfo['channel_id'] = $array_entity['value_info'];
        $datainfo['my_id'] = $array_entity['my_id'];
// echo '<pre>'; print_r($datainfo); exit;
        $delete_id = $this->Model->deleteData('subscribe_channel',array('channel_id'=>$datainfo['channel_id'],'my_id'=>$datainfo['my_id']));
        if ($delete_id) {
        	$data['status'] = $delete_id;
        }
        else{
        	$data['status'] = $delete_id;
        }
        echo json_encode($data);
	}
	public function like_dislike_comment($value='')
	{
		$jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['report'];
        // echo '<pre>'; print_r($array_entity); exit;
        $datainfo['comment_id'] = $array_entity['comment_id'];
        $datainfo['customer_id'] = $array_entity['customer_id'];
        $datainfo['video_id'] = $array_entity['video_id'];
        $datainfo['like1'] = $array_entity['like1'];
        $datainfo['dislike'] = $array_entity['dislike'];
        //$datainfo['user_type'] = $array_entity['user_type'];
        // echo '<pre>'; print_r($datainfo); exit;

        //COMMENT BT MOHD ALAM 15/05/2020
        /*$strQry = "SELECT DISTINCT ID FROM like_dislike_comment WHERE comment_id='".$datainfo['comment_id']."'
        AND customer_id='".$datainfo['customer_id']."' AND video_id='".$datainfo['video_id']."' AND user_type='".$datainfo['user_type']."'  ORDER BY ID DESC";*/

        $strQry = "SELECT DISTINCT ID FROM like_dislike_comment WHERE comment_id='".$datainfo['comment_id']."'
        AND customer_id='".$datainfo['customer_id']."' AND video_id='".$datainfo['video_id']."' ORDER BY ID DESC";

		$Information_present = $this->Model->getSqlData($strQry);
		//echo '<pre>'; var_dump($Information_present); //exit;

		if ($Information_present) {
			$insert_update_like = $this->Model->updateData('like_dislike_comment',$datainfo,array('ID'=>$Information_present[0]['ID']));
		}
		else {
			$insert_update_like = $this->Model->insertData('like_dislike_comment',$datainfo);
		}
		if ($insert_update_like) {
			echo '<pre>'; print_r($datainfo['comment_id']); exit;
		}
		else{
			echo "Something Went worng.";exit;
		}
		
	}

	public function comment_reply_information($value='')
	{
	$jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['report'];
        // echo '<pre>'; print_r($array_entity); exit;
         $data['comment_id'] = $array_entity['comment_id'];
        $data['customer_id'] = $array_entity['customer_id'];
        $data['video_id'] = $array_entity['video_id'];
        $data['comment_reply'] = $this->Model->getData('comment_reply',array('video_id'=>$data['video_id'],'comment_id'=>$data['comment_id']));
        // echo '<pre>'; print_r($data); exit;
        $this->load->view('comment_reply_information',$data);
	}
	public function comment_reply_information_khan($value='')
	{
		$jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['report'];
        // echo '<pre>'; print_r($array_entity); exit;
         $data['comment_id'] = $array_entity['comment_id'];
        $data['customer_id'] = $array_entity['customer_id'];
        $data['video_id'] = $array_entity['video_id'];
        $data['comment_reply'] = $array_entity['comment_reply'];
        // echo '<pre>'; print_r($data); exit;
        $this->Model->insertData('comment_reply',$data);

        $data['comment_reply'] = $this->Model->getData('comment_reply',array('video_id'=>$data['video_id'],'comment_id'=>$data['comment_id']));
        $this->load->view('comment_reply_information',$data);
	}
	public function watch_later_video(){
		   // echo '<pre>'; print_r('hii'); exit;
		  

          $query = $this->db->query("select * from watch_later where user_id='".$this->session->userdata('id')."' order by id desc limit 0,8 ");

$data['like'] = $query->result_array();



		  // $this->Model->getDataOrderBy('watch_later',array('status'=>'1','user_id'=>$this->session->userdata('id')),'id','DESC');
		  
		$this->load->view('watch_later_video_khan',$data);
	}
	public function watch_later_video_loadmore(){
		   // echo '<pre>'; print_r('hii'); exit;
		  $query = $this->db->query("select * from watch_later where user_id='".$this->session->userdata('id')."' order by id desc limit 0,".$_POST['id']." ");

$like = $query->result_array();
		  
		// $this->load->view('watch_later_video_khan',$data);
		  ?>




           <?php if(isset($like) && !empty($like)) foreach ($like as $key) {
// echo '<pre>'; print_r($key); exit;
 $add_video = $this->Model->getDataOrderBy('add_video',array('status'=>'1','ID'=>$key['v_id']),'ID','DESC');
 // echo '<pre>'; print_r($add_video);
 $category_id = $this->Model->getDataOrderBy('category',array('status'=>'1','category_id'=>$add_video[0]['category_id']),'category_id','DESC');
 // echo '<pre>'; print_r($category_id); exit;
  ?>


<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 prs_upcom_slide_first">
                        <div class="prs_upcom_movie_box_wrapper prs_mcc_movie_box_wrapper">
                          <div class="prs_upcom_movie_img_box">
                            <img src="<?php echo base_url().'uploads/product/'.$add_video[0]['picture'];?>" alt="<?php echo $add_video[0]['Video_Name'];?>" style="width: 100%;height: 177px">
                            <div class="prs_upcom_movie_img_overlay"></div>
                            <div class="prs_upcom_movie_img_btn_wrapper">
                              <ul>
                                <li><a href="<?php echo base_url('watch/'.$category_id[0]['category_name']."/").$add_video[0]['ID'];?>">View Trailer</a>
                                </li>
                                <li><a href="<?php echo base_url('watch/'.$category_id[0]['category_name']."/").$add_video[0]['ID'];?>">View Details</a>
                                </li>
                              </ul>
                            </div>
                          </div>
                          <div class="prs_upcom_movie_content_box">
                            
                            
                            
                            
                            <div class="video-title"    style="back">
                                  <a href="<?php echo base_url('watch/'.$category_id[0]['category_name']."/").$add_video[0]['ID'];?>" style="font-size: 15px;font-weight: 800;color:black;font-weight: 800;display: block;
  width: 175px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;" data-toggle="tooltip" data-placement="top" title="<?php echo $add_video[0]['Video_Name'];?>"><?php echo $add_video[0]['Video_Name'];?></a>
                              </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                          </div>
                        </div>
                      </div>


<?php  } ?>




		  <?php
	}
	public function liked_video(){
          $query = $this->db->query("select * from like_dislike where user_id='".$this->session->userdata('id')."' and like1=1 order by id desc limit 0,8 ");

$data['like'] = $query->result_array();

		 // $data['like'] = $this->Model->getDataOrderBy('like_dislike',array('like1'=>'1','user_id'=>$this->session->userdata('id')),'id','DESC');
		  // echo '<pre>'; print_r($data['like']); 
		$this->load->view('liked_video_khan',$data);
	}
		public function liked_video_loadmore(){
          $query = $this->db->query("select * from like_dislike where user_id='".$this->session->userdata('id')."' and like1=1 order by id desc limit 0,".$_POST['id']." ");

$like = $query->result_array();




?>
<?php
// echo '<pre>'; print_r($like); exit;

if(isset($like) && !empty($like)) foreach ($like as $key) {

 $add_video = $this->Model->getDataOrderBy('add_video',array('ID'=>$key['v_id']),'ID','DESC');
 // echo '<pre>'; print_r($add_video);
 $category_id = $this->Model->getDataOrderBy('category',array('status'=>'1','category_id'=>$add_video[0]['category_id']),'category_id','DESC');
 // echo '<pre>'; print_r($category_id); exit;
  ?>


<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 prs_upcom_slide_first">
                        <div class="prs_upcom_movie_box_wrapper prs_mcc_movie_box_wrapper">
                          <div class="prs_upcom_movie_img_box">
                            <img src="<?php echo base_url().'uploads/product/'.$add_video[0]['picture'];?>" alt="<?php echo $add_video[0]['Video_Name'];?>" style="width: 100%;height: 177px">
                            <div class="prs_upcom_movie_img_overlay"></div>
                            <div class="prs_upcom_movie_img_btn_wrapper">
                              <ul>
                                <li><a href="<?php echo base_url('watch/'.$category_id[0]['category_name']."/").$add_video[0]['ID'];?>">View Trailer</a>
                                </li>
                                <li><a href="<?php echo base_url('watch/'.$category_id[0]['category_name']."/").$add_video[0]['ID'];?>">View Details</a>
                                </li>
                              </ul>
                            </div>
                          </div>
                          <div class="prs_upcom_movie_content_box">
                            


                        <div class="video-title">
                                  <a href="<?php echo base_url('watch/'.$category_id[0]['category_name']."/").$add_video[0]['ID'];?>" style="font-size: 15px;font-weight: 800;color:black;font-weight: 800;display: block;
  width: 175px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;" data-toggle="tooltip" data-placement="top" title="<?php echo $add_video[0]['Video_Name'];?>"><?php echo $add_video[0]['Video_Name'];?></a>
                              </div>





                           
                          </div>
                        </div>
                      </div>


<?php  } ?>
<?php
		 // $data['like'] = $this->Model->getDataOrderBy('like_dislike',array('like1'=>'1','user_id'=>$this->session->userdata('id')),'id','DESC');
		  // echo '<pre>'; print_r($data['like']); 
		// $this->load->view('liked_video_khan',$data);
	}
	public function Subscription_channel($value='')
	{
		 $data['subscribe_channel'] = $this->Model->getDataOrderBy('subscribe_channel',array('my_id'=>$this->session->userdata('id'),'status'=>1),'ID','DESC');
		  // echo '<pre>'; print_r($data['like']); 
		$this->load->view('Subscription_channel_khan',$data);
	}
	public function Subscription_channel_information()
	{
		 $data['subscribe_channel'] = $this->Model->getDataOrderBy('subscribe_channel',array('my_id'=>$this->uri->segment(3),'status'=>1),'ID','DESC');
		  // echo '<pre>'; print_r($data['subscribe_channel']); 
		$this->load->view('Subscription_channel_information_khan',$data);
	}
	public function Subscription_channel_video(){
	         if ($this->session->userdata('id') || $this->session->userdata('username')) {
       	// echo '<pre>'; print_r($this->session->userdata('logged_in') || $this->session->userdata('username')); 

       $strSql = "SELECT DISTINCT channel_id FROM subscribe_channel WHERE my_id='".$this->session->userdata('id')."' OR my_id='".$this->session->userdata('username')."' ";
			  $data['subscribe_channel'] =$this->Model->getSqlData($strSql);
          // echo "<pre>";print_r($where);

           $where = [];
foreach($data['subscribe_channel'] as $row){
   $where[] = $row['channel_id'];
}
// echo "<pre>";print_r($where);
$data['subscribe_channel_list']=$where;
// echo "----------------------------------------------------------------------------";
$this->db->select('ID,user_id,picture,Video_Name,datatime');
$this->db->from('add_video');
$this->db->where('status', "1");

// $this->db->where(array('approved_time !=' => "")); 
$this->db->where_in('user_id', $where);
$this->db->order_by('approved_time', 'DESC');

$this->db->limit(16);
$query = $this->db->get();
 $data['subscribe_channel_customer']= $query->result_array();
 
// $result=array_diff_key($watch123,$row1);
// print_r();
//   echo "<pre>";print_r($data['subscribe_channel_customer']);
//         	exit;

       }
       	$this->load->view('Subscription_channel_video',$data);
	}
	function Subscription_channel_video_load(){
	    $json=json_decode($_POST['cat'], true);
	   // echo "<pre>"; print_r(json_decode($_POST['cat'], true));exit();
	   // echo "<pre>";print_r($json);exit();
	    
	    $this->db->select('ID,user_id,picture,Video_Name,datatime');
$this->db->from('add_video');
$this->db->where('status', "1");

// $this->db->where(array('approved_time !=' => "")); 
$this->db->where_in('user_id', $json);
$this->db->order_by('approved_time', 'DESC');

$this->db->limit($_POST['id']);
$query = $this->db->get();
 $subscribe_channel_customer= $query->result_array();
//   echo "<pre>";print_r($data['subscribe_channel_customer']);
	    ?>
	         <?php if(isset($subscribe_channel_customer) && !empty($subscribe_channel_customer)) foreach ($subscribe_channel_customer as $key) {
                     $login_gagan = $this->Model->getData('custumer_login',array('id'=>$key['user_id'],'status'=>'1'));
                     if($key['user_id']){
                                  if(!$login_gagan){
                                     $channal_name=$key['user_id'];
                                  }else{
                                      if($login_gagan[0]['channel_name'])
                                      {
                                          $channal_name=$login_gagan[0]['channel_name']; 
                                      }else
                                      {
                                        $channal_name=$login_gagan[0]['user_name']." ".$login_gagan[0]['last_name'];   
                                      }
                                      
                                      }
                         
                                    }else{
                                      $channal_name="oxiinc_group";
                                  }
                     ?>

                     <div class="col-xl-3 col-sm-6 mb-3">

                        <div class="video-card" style="

    background-color: white;

">

                           <div class="video-card-image" >

                              <a class="play-icon" href="<?php echo base_url('watch/'.$channal_name."/").$key['ID']."?".md5(rand());?>"><i class="fas fa-play-circle"></i></a>

                              <a href="<?php echo base_url('watch/'.$channal_name."/").$key['ID']."?".md5(rand());?>"><img class="img-fluid" src="<?php echo base_url().'uploads/product/'.$key['picture'];?>" style="width:100%;height:128px" alt=""></a>

                              
                           </div>

                           <div class="video-card-body">

                              <div class="video-title">

                                <a href="<?php echo base_url('watch/'.$channal_name."/").$key['ID']."?".md5(rand());?>" data-toggle="tooltip" title="<?php echo $key['Video_Name'];?>"><p style="color:black;display: block;

  width:200px;overflow: hidden;white-space: nowrap;

  text-overflow: ellipsis;" ><?php echo $key['Video_Name'];?></p></a>

                              </div>

                              <div class="video-page text-success">

                                      <?php  
                                 if($key['user_id']){
                                  if(!$login_gagan){
                                      
                                                                         $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");               
      $result_i_m=mysqli_query($conn,"select * from customers where emp_code = '".$key['user_id']."'");
                                                      $member_i_m=mysqli_fetch_assoc($result_i_m);
                                      
                                      ?>
                                      <a href="<?php echo base_url("Home/channel/".$key['user_id']) ?>" style='color:#23D794'><?php echo $member_i_m['first_name']." ".$member_i_m['surname']; ?></a>
                                      <?php
                                      
                                  }else{
                                      if($login_gagan[0]['channel_name']){
                                          ?>
                                           <a href="<?php echo base_url("Home/channel/".$key['user_id']) ?>" style='color:#23D794'><?php echo $login_gagan[0]['channel_name']; ?></a>
                                          <?php
                                         
                                        
                                      }else{
                                          ?>
                                           <a href="<?php echo base_url("Home/channel/".$key['user_id']) ?>" style='color:#23D794'><?php echo $login_gagan[0]['user_name']." ".$login_gagan[0]['last_name']; ?></a>
                                          <?php
                                           
                                     
                                      }
                                  }}else{
                                      echo 'Oxiinc Channel';
                                  }
                                  
                                 
                                 ?><a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>

                              </div>

                              <div class="video-view">
<?php 
 $watch_most = $this->Model->getData('watched_user',array('post_id'=>$key['ID']));
                                            echo $watch_most[0]['view'];
                                           

                                           

                                           ?>
                                   views &nbsp;<i class="fas fa-calendar-alt"></i> <?php 

                              $FromDate = new DateTime(date("Y-m-d H:i:s"));

  $ToDate   = new DateTime($key['datatime']);

  $Interval = $FromDate->diff($ToDate);



  $Difference["Hours"] = $Interval->h;



  $Difference["Weeks"] = floor($Interval->d/7);

  $Difference["Days"] = $Interval->d % 7;

  $Difference["Months"] = $Interval->m;

   $Difference["minute"] = $Interval->i;

   $Difference["second"] = $Interval->s;

   $Difference["Year"] = $Interval->y;



  

   

   if($Difference["Year"]){

   echo $Difference["Year"]." "."Year";

   }else

   if($Difference["Months"]){

  echo $Difference["Months"]." "."Months";

   }else

   if($Difference["Weeks"]){

   echo $Difference["Weeks"]." "."Weeks";

   }else

   if($Difference["Days"]){

   echo $Difference["Days"]." "."Days";

   }else

   if($Difference["Hours"]){

   echo $Difference["Hours"]." "."Hours";

   }else

   if($Difference["minute"]){

    echo $Difference["minute"]." "."Minute";

   }else

   if($Difference["second"]){

   echo $Difference["second"]." "."Second";

   } 

   echo " "."ago";

                              

                              

  ?>

                              </div>

                           </div>

                        </div>

                     </div>

                     <?php  } ?>
	    <?php
	}
	public function Customize_channel($value='')
	{
	$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

		$this->load->view('Customize_channel',$data);
	}
	public function edit_channel_info($value='')
	{
			$postData = $this->security->xss_clean($_POST);
		// echo "<pre>";print_r($postData);exit();
		$this->Model->updateData('custumer_login',$postData,array('id'=>$this->session->userdata('id')));
		$this->session->set_flashdata('msg' ,'Channelk Information update successfully.');
		redirect('Customer_login_page/Customize_channel');
	}

	public function edit_channel_banner_image($value='')
	{
		// echo '<pre>'; print_r($_FILES); exit;
		            if(!empty($_FILES['channel_banner']['name'])){
                $config['upload_path'] = 'uploads/channel_banner/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = rand()."_entube_image".".png";
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('channel_banner')){
                    $uploadData = $this->upload->data();
                    $postData['channel_banner'] = $uploadData['file_name'];
                }else{
                    $postData['channel_banner'] = '';
                }
            }else{
                $postData['channel_banner'] = '';
            }

			// $postData = $_POST;
		// echo "<pre>";print_r($postData['channel_banner']);exit();
		$this->Model->updateData('custumer_login',$postData,array('id'=>$this->session->userdata('id')));
		$this->session->set_flashdata('msg' ,'CHannel banner update successfully.');
		redirect('Customer_login_page/Customize_channel');
	}
	public function edit_channel_icon_image($value='')
	{
		// echo '<pre>'; print_r($_FILES); exit;
		if(!empty($_FILES['photo']['name'])){
                $config['upload_path'] = 'uploads/Customer_pan/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                 $config['file_name'] = rand()."_entube_image".".png";
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('photo')){
                    $uploadData = $this->upload->data();
                    $postData['photo'] = $uploadData['file_name'];
                }else{
                    $postData['photo'] = '';
                }
            }else{
                $postData['photo'] = '';
            }

			// $postData = $_POST;
		// echo "<pre>";print_r($postData['photo']);exit();
		$this->Model->updateData('custumer_login',$postData,array('id'=>$this->session->userdata('id')));
		$this->session->set_flashdata('msg' ,'CHannel Icon update successfully.');
		redirect('Customer_login_page/Customize_channel');
	}
	function channel(){


$this->load->view('channel');
}
public function channel_customoze($value='')
{
	$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

		$this->load->view('channel_customoze',$data);
}
public function select_one_home_screen($value='')
{
	// echo '<pre>'; print_r($_POST); exit;
	   $ID = $_POST['select_video'];
 $status['select_video']='1';
  $ID =   $this->Model->updateData('add_video',$status,array('ID'=>$ID));
// echo '<pre>'; print_r($ID); exit;
   $this->session->set_flashdata('msg','Your Select Video Add In Home Screen ');
    redirect('Customer_login_page/channel_customoze/'.$this->session->userdata('id'));
}
public function delect_select_one_home_screen($value='')
{
	 $ID = $_POST['select_video'];
 $status['select_video']='0';
  $ID =   $this->Model->updateData('add_video',$status,array('ID'=>$ID));

   $this->session->set_flashdata('msg','Your Select Video Delect successfully ');
    redirect('Customer_login_page/channel_customoze/'.$this->session->userdata('id'));
}
public function edit_select_one_home_screen($value='')
{
	$select_video_order = $_POST['select_video_order'];
 $status['select_video']='0';
  $ID =   $this->Model->updateData('add_video',$status,array('ID'=>$select_video_order));

  $select_video = $_POST['select_video'];

$statusak['select_video']='1';
  $ID =   $this->Model->updateData('add_video',$statusak,array('ID'=>$select_video));

   $this->session->set_flashdata('msg','Your Select Video Edit successfully ');
    redirect('Customer_login_page/channel_customoze/'.$this->session->userdata('id'));
}
public function Play_all_videos($value='')
{
			// echo '<pre>'; print_r($this->uri->segment(3)); exit;
		$ID = $this->uri->segment(3);


		$add_video_khanashfak = $this->Model->getDataOrderBy('add_video',array('user_id'=>$this->session->userdata('id')),'ID','DESC');
		// echo '<pre>'; print_r($add_video_khanashfak); exit;
		if ($add_video_khanashfak) {
			
			$last_id_video =  $add_video_khanashfak[0]['ID'];
			// echo '<pre>'; print_r($last_id_video); exit;
				$ip = $this->input->ip_address();
	

        $query = $this->db->query('SELECT count( DISTINCT(ip) ) FROM views WHERE post_id='.$last_id_video);

         $row= $query->result_array();
         $query1 = $this->db->query('SELECT count(DISTINCT(user_id)) FROM views WHERE post_id='.$last_id_video);

         $row1= $query1->result_array();
         $one=$row[0]['count( DISTINCT(ip) )'];
         $two=$row1[0]['count(DISTINCT(user_id))'];
         $data['views'] = $one+$two;
		$watch = $this->Model->getData('add_video',array('status'=>'1','ID'=>$last_id_video));
		$data['watch'] = $watch;
		$category_id = $watch[0]['category_id'];

		// $data['Category_videos'] = $this->Model->getDataOrderBy('add_video',array('user_id'=>$this->uri->segment(3)),'ID','DESC');

				$strQry = "SELECT DISTINCT * FROM add_video WHERE user_id='".$this->uri->segment(3)."' AND status='1' AND ID!='".$last_id_video."' ORDER BY ID DESC";
		  $data['Category_videos'] = $this->Model->getSqlData($strQry);
		

		$this->load->view('watch',$data);


		}else{
			redirect('Customer_login_page/channel_customoze/'.$this->session->userdata('id'));
		}




}
     public function my_profile()
	{	
		

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

		$this->load->view('my_profile',$data);
		// echo "<pre>";print_r($data);exit;
	}
	

	 public function Customer_orders()
	{	
		

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['Customer_orders'] = $this->Model->getDataOrderBy('order_data',array('customer_id'=>$id),'ID','DESC');
// echo '<pre>'; print_r($data['Customer_orders']); exit;
		$this->load->view('Customer_orders',$data);
		// echo "<pre>";print_r($data);exit;
	}
	public function customer_enpay(){
				$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
// echo '<pre>'; print_r($data['customer_enpay']); exit;
		$this->load->view('customer_enpay',$data);
	}
	  function customer_Promo_code(){
		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['order_delivered'] = $this->Model->getData('promo_codo',array('customer_id'=>$id));
// 		$data['promo_codo'] = $this->Model->getDataOrderBy('promo_codo',array('customer_id'=>$id),'ID','DESC');
		// echo '<pre>'; print_r($data['promo_codo']); exit;
    	$this->load->view('customer_Promo_code',$data);

    }
	function Order_details(){

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		// echo '<pre>'; print_r($_GET); exit;
		$txid = $_GET['id'];
		$Order_details = $this->Model->getData('order_data',array('txnid'=>$txid));
		$data['Order_details'] = $Order_details;
        $data['Order_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$Order_details[0]['address_id']));

		$this->load->view('Order_details',$data);
		// echo '<pre>'; print_r($data['Order_details']); exit;
	}
	function Order_RETURN(){
		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$primary_reason = $this->Model->getData('primary_reason');
        $data['primary_reason'] = $primary_reason;
		$ID = $_GET['ID'];
		$Order_details = $this->Model->getData('order_data',array('ID'=>$ID,'order_delivered'=>'1'));
		$data['Order_details'] = $Order_details;
		$this->load->view('Order_RETURN',$data);
	}
	function Order_Change(){
		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$ID = $_GET['ID'];
		// echo '<pre>'; print_r($ID); exit;
		$Order_details = $this->Model->getData('order_data',array('ID'=>$ID,'order_confirmation'=>'1'));
		// echo '<pre>'; print_r($Order_details); exit;
		$data['Order_details'] = $Order_details;
		// echo '<pre>'; print_r($data['Order_details']); exit;
		$this->load->view('Order_Change',$data);
	}
	function Cancellation_request(){
		// echo '<pre>'; print_r($_POST); exit;
		$ID = $this->input->post('ID');
		
// echo '<pre>'; print_r($_POST); exit;
		$Order_details = $this->Model->getData('order_data',array('ID'=>$ID,'order_confirmation'=>'1'));
		// echo '<pre>'; print_r($Order_details); exit;
		$data['reason_info'] = $this->input->post('reason_info');
		$data['Cancellation_info'] = $this->input->post('Cancellation_info');
		$data['can_Payment_method'] = $this->input->post('can_Payment_method');
		$data['ordre_id'] = $Order_details[0]['ID'];
		$data['customer_id'] = $Order_details[0]['customer_id'];
		$data['email_id'] = $Order_details[0]['email_id'];
		$data['user_name'] = $Order_details[0]['user_name'];
		$data['contact_number'] = $Order_details[0]['contact_number'];
		$data['product_id'] = $Order_details[0]['product_id'];
		$data['Product_Name'] = $Order_details[0]['Product_Name'];
		$data['Product_Picture'] = $Order_details[0]['Product_Picture'];
		$data['Prices'] = $Order_details[0]['Prices'];
		$data['gst_price'] = $Order_details[0]['gst_price'];
		$data['total_gst'] = $Order_details[0]['total_gst'];
		$data['product_qty'] = $Order_details[0]['product_qty'];
		$data['Original_Prices'] = $Order_details[0]['Original_Prices'];
		$data['txnid'] = $Order_details[0]['txnid'];
		$data['total_amount'] = $Order_details[0]['total_amount'];
		$data['after_discounted_amount'] = $Order_details[0]['after_discounted_amount'];
		$data['payment_method'] = $Order_details[0]['payment_method'];
		$data['address_id'] = $Order_details[0]['address_id'];
		$data['order_date_time'] = $Order_details[0]['order_date_time'];
		$data['cancel_month']=  date('m');
		$data['cancel_year']= date('Y');
		$data['cancel_day']= date('d');
		$data['cancel_year_month']= date('Y-m');
		$data['rcancel_year_month_data']=date('Y-m-d');
		$data['cancel_year_month_data_time']= date('Y-m-d H:i:s');
// echo '<pre>'; print_r($data); exit;
         $id=$this->Model->insertData('cancellation_request',$data);
// echo '<pre>'; print_r($id); exit;





		$status['order_confirmation']='0';
    $this->Model->updateData('order_data',$status,array('ID'=>$ID));
    redirect('Customer_login_page/Customer_orders');
	}
	function getSecondary(){
       $postData = $_POST;
        // $postData['category_id'] = 1;

        $sub_category_list = $this->Model->getData('secondary_reason',array('status'=>'1'));

        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['Primary_id'] == $value['Primary_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }
    function returnAddress(){
    	$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		// $data['customer_account_info'] = $this->Model->getData('customer_account_info',array('id'=>$id));
    	$ID = $this->input->post('ordre_id');
    	$data['txnid'] = $this->input->post('txnid');
    	$data['Primary_Reason'] = $this->input->post('Primary_Reason');
    	$data['Secondary_Reason'] = $this->input->post('Secondary_Reason');
    	$Order_details = $this->Model->getData('order_data',array('ID'=>$ID));
    	$data['Order_details'] = $Order_details;
    	// echo '<pre>'; print_r($Order_details); exit;
    	
    	$this->load->view('returnAddress',$data);

    }

    function Accounts_info(){
    	// echo '<pre>'; print_r($_POST); exit;
    	$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		// echo '<pre>'; print_r($data['manage_addresses']); exit;
    	$customer_account_info['Customer_id'] =  $this->session->userdata('id'); 
    	$customer_account_info['ordre_id'] = $this->input->post('ordre_id');
    	$customer_account_info['txnid'] = $this->input->post('txnid');
    	$data['Primary_Reason'] = $this->input->post('Primary_Reason');
    	$data['Secondary_Reason'] = $this->input->post('Secondary_Reason');
    	$customer_account_info['accound_holder_name'] = $this->input->post('accound_holder_name');
    	$customer_account_info['Bank_name'] = $this->input->post('Bank_name');
    	$customer_account_info['Account_Number'] = $this->input->post('Account_Number');
    	$customer_account_info['IFSC_Code'] = $this->input->post('IFSC_Code');
    	$customer_account_info['Save_details'] = $this->input->post('Save_details');
    	$customer_account_info['confirm'] = $this->input->post('confirm');
    	// $customer_account_info = $_POST;
    	// echo '<pre>'; print_r($customer_account_info); 
    	 $data['id']=$this->Model->insertData('customer_account_info',$customer_account_info);
    	 // echo '<pre>'; print_r($data['id']); exit;
    	 $this->load->view('return_order_Address',$data);
    }
    function Confirm_return(){
    	// echo '<pre>'; print_r($_POST); exit;
    	$id =  $this->session->userdata('id'); 
		$datas['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
    	$customer_account_id = $this->input->post('customer_account_id');
    	$customer_account_info = $this->Model->getData('customer_account_info',array('ID'=>$customer_account_id));
    	$datas['customer_account_info'] =$customer_account_info;
    	// echo '<pre>'; print_r($data['customer_account_info']); 
    	$ordre_id = $customer_account_info[0]['ordre_id'];
    	$order_data = $this->Model->getData('order_data',array('ID'=>$ordre_id));
    	$datas['order_data'] =$order_data;
    	
    	// echo '<pre>'; print_r($order_data);
    	$Primary_Reason_id = $this->input->post('Primary_Reason_id');
    	$primary_reason = $this->Model->getData('primary_reason',array('Primary_id'=>$Primary_Reason_id));
    	$datas['primary_reason'] = $primary_reason;
    	// echo '<pre>'; print_r($primary_reason); exit;
    	$Secondary_Reason_id = $this->input->post('Secondary_Reason_id');
    	$secondary_reason = $this->Model->getData('secondary_reason',array('secondary_id'=>$Secondary_Reason_id));
    	$datas['secondary_reason'] = $secondary_reason;
    	$address_id = $this->input->post('address_id');
    	$manage_addresses = $this->Model->getData('manage_addresses',array('ID'=>$address_id));
    	$datas['manage_addresses'] =  $manage_addresses;
    	// echo '<pre>'; print_r($manage_addresses); exit;



        $data['customer_id'] = $order_data[0]['customer_id'];
        $data['order_id'] = $order_data[0]['ID'];
        $data['email_id'] = $order_data[0]['email_id'];
        $data['Primary_Reason'] = $primary_reason[0]['Primary_Name'];
        $data['Secondary_Reason'] = $secondary_reason[0]['secondary_name'];
        $data['user_name'] = $order_data[0]['user_name'];
        $data['contact_number'] = $order_data[0]['contact_number'];
        $data['product_id'] = $order_data[0]['product_id'];
        $data['Product_Name'] = $order_data[0]['Product_Name'];
        $data['Product_Picture'] = $order_data[0]['Product_Picture'];
        $data['Prices'] = $order_data[0]['Prices'];
        $data['product_qty'] = $order_data[0]['product_qty'];
        $data['Original_Prices'] = $order_data[0]['Original_Prices'];
        $data['txnid'] = $order_data[0]['txnid'];
        $data['gst_price'] = $order_data[0]['gst_price'];
        $data['total_gst'] = $order_data[0]['total_gst'];
        $data['total_amount'] = $order_data[0]['total_amount'];
        $data['after_discounted_amount'] = $order_data[0]['after_discounted_amount'];
        $data['payment_method'] = $order_data[0]['payment_method'];
        $data['address_id'] = $order_data[0]['address_id'];
        $data['order_date_time'] = $order_data[0]['order_date_time'];
        $data['accound_holder_name'] = $customer_account_info[0]['accound_holder_name'];
        $data['Bank_name'] = $customer_account_info[0]['Bank_name'];
        $data['Account_Number'] = $customer_account_info[0]['Account_Number'];
        $data['IFSC_Code'] = $customer_account_info[0]['IFSC_Code'];
        $data['Name'] = $manage_addresses[0]['Name'];
        $data['Phone_number'] = $manage_addresses[0]['Phone_number'];
        $data['Pincode'] = $manage_addresses[0]['Pincode'];
        $data['Locality'] = $manage_addresses[0]['Locality'];
        $data['address'] = $manage_addresses[0]['address'];
        $data['City'] = $manage_addresses[0]['City'];
        $data['state'] = $manage_addresses[0]['state'];
        $data['Landmark'] = $manage_addresses[0]['Landmark'];
        $data['Alternate_Phone'] = $manage_addresses[0]['Alternate_Phone'];
        $data['Address_type'] = $manage_addresses[0]['Address_type'];
        $data['return_month'] = date('m');
		$data['return_year'] = date('Y');
		$data['return_day'] = date('d');
		$data['return_year_month'] =date('Y-m');
		$data['return_year_month_data' ] =date('Y-m-d');
		$data['return_year_month_data_time'] = date('Y-m-d H:i:s');
       

       $status['return_order']='1';
        $this->Model->updateData('order_data',$status,array('ID'=>$data['order_id']));
        
       $data['id']=$this->Model->insertData('return_order',$data);



    	$this->load->view('Confirm_return',$datas);
    }
    function Order_EXCHANGE(){
		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$primary_reason = $this->Model->getData('primary_reason');
        $data['primary_reason'] = $primary_reason;
		$ID = $_GET['ID'];
		$Order_details = $this->Model->getData('order_data',array('ID'=>$ID,'order_delivered'=>'1'));
		$data['Order_details'] = $Order_details;
		$this->load->view('Order_EXCHANGE',$data);
	}
	public function my_profile_edit()
	{	
		

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

		$this->load->view('my_profile_edit',$data);
		// echo "<pre>";print_r($data);exit;
	}
	public function edit_cutomer_info()
	{

		$this->Model->updateData('custumer_login',$_POST,array('id'=>$_POST['id']));

		redirect('customer_login_page/my_profile');
	}
	 public function rewards()
	{	
		

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

		$this->load->view('rewards',$data);
		// echo "<pre>";print_r($data);exit;
	}
	public function reviews()
	{	
		

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		// $data['Reviews_Ratings'] = $this->Model->getData('reviews_ratings',array('Customer_id'=>$id));
       $strQry = "SELECT DISTINCT * FROM reviews_ratings WHERE Customer_id='".$id."' AND status='1'ORDER BY ID DESC";
		  $data['Reviews_Ratings'] = $this->Model->getSqlData($strQry);
		$this->load->view('reviews',$data);
		// echo "<pre>";print_r($data);exit;
	}
	public function Notifications()
	{	
		

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
         $strQry = "SELECT DISTINCT * FROM notify WHERE Customer_id='".$id."' AND status='1'ORDER BY ID DESC";
		  $data['Notify'] = $this->Model->getSqlData($strQry);
		$this->load->view('Notifications',$data);
		// echo "<pre>";print_r($data);exit;
	}
	public function wishlist(){
         $id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['wishlist'] = $this->Model->getData('wishlist',array('Customer_id'=>$id));
		$data['total_row'] = $this->Model->CountWhereRecord('wishlist',array('Customer_id'=>$id));
		 // $strQry = "SELECT DISTINCT * FROM wishlist WHERE Customer_id='".$id."' AND status='1'";
		 //  $data['wishlist'] = $this->Model->getSqlData($strQry);
		 // echo '<pre>'; print_r($data['wishlist']); exit;
 //         $Product_id = $this->Model->getSqlData($strQry);
		 // $data['Product_info'] = $this->Text->Product_id($id);
		 // echo '<pre>'; print_r($data['Product_info']); exit;
		$this->load->view('wishlist',$data);
	}	
	function Delect_whishlist(){
		$ID = $this->input->get_post('ID');
        $this->Model->deleteData('wishlist',array('ID'=>$ID));
        // $this->session->set_flashdata('msg' ,'The Customer Account has been deleted successfully.');

        redirect('Customer_login_page/wishlist');
	}
	function Delect_Notify(){
		// $ID = $_GET([$ID]);
		// echo '<pre>'; print_r($ID); exit;
		$ID = $this->input->get_post('ID');
        $this->Model->deleteData('notify',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Notify has been deleted successfully.');

        redirect('Customer_login_page/Notifications');
	}
	// public function wishlist()
	// {	
		

	// 	$id =  $this->session->userdata('id'); 
	// 	$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
	// 	 $strQry = "SELECT DISTINCT Product_id FROM wishlist WHERE Customer_id='".$id."' AND status='1'";
	// 	 // echo '<pre>'; print_r($strQry); exit;
 //         $Product_id = $this->Model->getSqlData($strQry);
 //         // error_reporting(0);
 //       //    $result = mysql_query("SELECT MAX(c_id) FROM customers");
	// 		    // $row = mysql_fetch_row($result);
	// 		    // $highest_id = $row[0];
 //         // echo '<pre>'; print_r($Product_id); exit;
 //         $i=0;
 //       while ( $i<= 19) {
 //      $t=$Product_id[$i];
 //         	$stQry = "SELECT DISTINCT * FROM wellness WHERE ID=".$t['Product_id'];
 //         $Product_info = $this->Model->getSqlData_row($stQry);
 //         echo '<pre>'; print_r( $Product_info);
 //         ++$i;
 //       }
 //          // echo '<pre>'; print_r($Product_id); exit;
 //         // for ($i=0; $i <50 ; $i++) { 
 //         // 	 $t=$Product_id[$i];
 //         // 	$stQry = "SELECT DISTINCT * FROM wellness WHERE ID=".$t['Product_id'];
 //         // $Product_info = $this->Model->getSqlData($stQry);
 //         // echo '<pre>'; print_r( $Product_info); exit;
 //         // }
        
 //         // echo '<pre>'; print_r($t['Product_id']); exit;
 //         // $stQry = "SELECT DISTINCT * FROM wellness WHERE ID=".$t['Product_id'];
 //         // $Product_info = $this->Model->getSqlData($stQry);
 //         // echo '<pre>'; print_r( $Product_info); exit;
 //         // echo '<pre>'; print_r($has_sub_cat); exit;
	// 	// $wishlist = $this->Model->getData('wishlist',array('Customer_id'=>$id));
	// 	// echo '<pre>'; print_r($wishlist); exit;
	// 	// $total_rows = $this->Model->CountWhereRecord('wellness');
	// 	// $i=0;
	// 	// while ($i<=30) {
	// 	//  	# code...
		
	// 	// 	 $Product_id= $wishlist[$i]['Product_id'];
 //  //        $Customer_id= $wishlist[$i]['Customer_id'];
 //  //        // echo '<pre>'; print_r($Product_id);
 //  //        $data['wishlist'] = $this->Model->getData('wellness',array('ID'=>$Product_id));
 //  //      print_r( $data['wishlist']); 
	// 	//  $i++;
	// 	// }
 //      $this->load->view('wishlist',$data);
         
	// 	// echo "<pre>";print_r($data);exit;
	// }
	public function PAN_card(){

		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$id));
		$data['Custumer_login_PanInfo'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$id));
// echo '<pre>'; print_r($data['Custumer_login_PanInfo']); exit;
		$this->load->view('PAN_card',$data);

	}
	public function Edit_cutomer_Pan_info(){
		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['Custumer_login_PanInfo'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$id));
		$this->load->view('Edit_cutomer_Pan_info',$data);


	}
	public function Manage_Addresses(){
		$id =  $this->session->userdata('id'); 
		$data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$this->load->view('Manage_Addresses',$data);

	}
	function Manage_address_Delect(){
		$ID = $this->input->get_post('ID');
        $this->Model->deleteData('manage_addresses',array('ID'=>$ID));
        // $this->session->set_flashdata('msg' ,'The Customer Account has been deleted successfully.');

        redirect('Customer_login_page/Manage_Addresses');
	}
	function Manage_address_eitd(){
		 $ID = $_GET['ID'];
        $id =  $this->session->userdata('id');
        $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$ID));
       $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        // echo '<pre>'; print_r($data['custumer_login']); exit;
        $this->load->view('Manage_address_eitd',$data);
	}
	public function Manage_address_from_edit()
	{

		$this->Model->updateData('manage_addresses',$_POST,array('ID'=>$_POST['ID']));

		redirect('customer_login_page/Manage_Addresses');
	}
	public function Deactive_Account(){
		// echo '<pre>'; print_r($_POST); exit;
		if ($_POST['your_Password']==$_POST['confirm_your_Password']) {
			# code...
			// echo '<pre>'; print_r($_POST['your_Password']); exit;
			 $user_email = $_POST['email_id'];
		$password = md5($_POST['your_Password']);
		
		$login = $this->Model->getData('custumer_login',array('email_id'=>$user_email,'password'=>$password));
		    if ($login) {
		    	# code...
		    	$status['status']='0';
		$this->Model->updateData('custumer_login',$status,array('email_id'=>$user_email));
		$this->session->set_userdata(array('logged_in' => FALSE));
		$this->session->sess_destroy();
		$this->session->set_flashdata('msg','Deactive Account successfully');
		redirect(base_url());

		    }
		    else{
		    	$this->session->set_flashdata('msg','Sorry');
		    	redirect('Customer_login_page/my_profile');
		    }
		}else{
			$this->session->set_flashdata('msg','Password ');
		    	redirect('Customer_login_page/my_profile');
		}
	}
	public function Upload_customer_profile(){
		echo '<pre>'; print_r($_FILES); exit;
	}
	public function Manage_address_from(){
		// $user_array['Customer_id'] =  $this->session->userdata('id');
		//  $user_array['Name'] = $this->input->post('Name');
		//  $user_array['Phone_number'] = $this->input->post('Phone_number');
		//  $user_array['Pincode'] = $this->input->post('Pincode');
		//  $user_array['Locality'] = $this->input->post('Locality');
		//  $user_array['address'] = $this->input->post('address');
		//  $user_array['City'] = $this->input->post('City');
		//  $user_array['state'] = $this->input->post('state');
		//  $user_array['Landmark'] = $this->input->post('Landmark');
		//  $user_array['Alternate_Phone'] = $this->input->post('Alternate_Phone');
		//  $user_array['Address_type'] = $this->input->post('Address_type');
  //        echo '<pre>'; print_r($user_array); exit;
		$userData = array(
                'Customer_id' => $this->session->userdata('id'),
                'Name' => $this->input->post('Name'),
                 'Phone_number' => $this->input->post('Phone_number'),
                'Pincode' => $this->input->post('Pincode'),
                'Locality' => $this->input->post('Locality'),
                'address' => $this->input->post('address'),
                'City' => $this->input->post('City'),
                'state' => $this->input->post('state'),
                'Landmark' => $this->input->post('Landmark'),
                'Alternate_Phone' => $this->input->post('Alternate_Phone'),
                'Address_type' => $this->input->post('Address_type')
                
            );
		// echo '<pre>'; print_r($userData); exit;
		$this->Model->insertData('manage_addresses',$userData);
		redirect('Customer_login_page/Manage_Addresses');
	}
	
	public function edit_from_customer_pan(){
		$postData = $_POST;
        $Customer_id = $this->session->userdata('id');

        if(!empty($_FILES['Pan_Picture'])){
            $uploaddir = './uploads/Customer_pan/';
            $uploadfile = $uploaddir . basename($_FILES['Pan_Picture']['name']);

            if (move_uploaded_file($_FILES['Pan_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Pan_Picture'] = basename($_FILES['Pan_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('customer_pan_info',$postData,array('Customer_id'=>$Customer_id)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        redirect('Customer_login_page/my_profile');
        
	}
	public function cash_on_delvery()
	{
		// echo '<pre>'; print_r($_POST); 
		$id =  $this->session->userdata('id'); 
		// $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$customer_id = $this->input->post('customer_id');
		$Shipping_address = $this->input->post('Shipping_address');
		$product_id = $this->input->post('product_id');
		// echo '<pre>'; print_r($product_id); 
		$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
		$data['txnid'] = $txnid;
		$user_Poduct_data = $this->Model->getData('wellness',array('ID'=>$product_id));
		$data['product_id'] =  $user_Poduct_data[0]['ID'];
		$data['Product_Name'] =  $user_Poduct_data[0]['Product_Name'];
		$data['Prices'] =  $user_Poduct_data[0]['Prices'];
		$data['Original_Prices'] =  $user_Poduct_data[0]['Original_Prices'];
		$user_data = $this->Model->getData('custumer_login',array('id'=>$customer_id));
		$data['Customer_id'] =  $user_data[0]['id'];
		$data['email_id'] =  $user_data[0]['email_id'];
		$user_name =  $user_data[0]['user_name'];
		$data['user_name'] = $user_name;
		$contact_number =  $user_data[0]['contact_number'];
		$data['contact_number'] = $contact_number;
		$user_Shi_address = $this->Model->getData('manage_addresses',array('ID'=>$Shipping_address));
		$data['shipping_ID'] =  $user_Shi_address[0]['ID'];
		$data['Name'] =  $user_Shi_address[0]['ID'];
		$data['Phone_number'] =  $user_Shi_address[0]['Phone_number'];
		$data['Pincode'] =  $user_Shi_address[0]['Pincode'];
		$data['Locality'] =  $user_Shi_address[0]['Locality'];
		$data['address'] =  $user_Shi_address[0]['address'];
		$data['City'] =  $user_Shi_address[0]['City'];
		$data['state'] =  $user_Shi_address[0]['state'];
		$data['Landmark'] =  $user_Shi_address[0]['Landmark'];
		$data['Alternate_Phone'] =  $user_Shi_address[0]['Alternate_Phone'];
		$data['Address_type'] =  $user_Shi_address[0]['Address_type'];
		$data['order_date_time'] = date('Y-m-d H:i:s');
		$data['order_date_time1'] = date('Y-M-d');
		$data['payment_method'] = 'COD';
		$data['product_qty'] = '1';
		$data['Product_Picture'] = $this->input->post('Product_picture');





        $GST_Persentage =  $user_Poduct_data[0]['GST_Persentage'];
        $Shipping_Charges =  $user_Poduct_data[0]['Shipping_Charges'];

        if (!empty($_POST['cod'])) {

        if ($Shipping_Charges > 0) {
        	$Shipping_Charges = $Shipping_Charges;
        }else{
        	$Shipping_Charges = 0;
        }
        $data['Shipping_Charges'] = $Shipping_Charges;
       if($GST_Persentage >0 ){
      $gst_value = $GST_Persentage/100; 
      $gst_price = $gst_value*$user_Poduct_data[0]['Prices'];
      $data['gst_price'] = $gst_price;
      // echo '<pre>'; print_r($gst_price); 
      $total_price = $user_Poduct_data[0]['Prices']+$gst_price+$Shipping_Charges;
      $data['total_price'] = $total_price;
      // echo '<pre>'; print_r($total_price); exit;
       // echo '<div class="col-sm-6"><p>₹'.$total_price.'</p></div>';
        }else{
        	$gst_price = 0;
        	$data['gst_price'] = $gst_price;
        	$total_price = $user_Poduct_data[0]['Prices']+$gst_price+$Shipping_Charges;
        	$data['total_price'] = $total_price;
             // echo '<div class="col-sm-6"><p>₹0</p></div>';
        }



		// echo '<pre>'; print_r($user_Shi_address); exit;
       if($Shipping_address!="" && $product_id!="" && $customer_id!=""){
           $order_data = array(
					'customer_id'=>$data['Customer_id'],
					'email_id'=>$data['email_id'],
					'user_name'=>$data['user_name'],
					'contact_number'=>$data['contact_number'],
					'product_id'=>$data['product_id'],
					'Product_Name'=>$data['Product_Name'],
					'Product_Picture'=>$data['Product_Picture'],
					'Prices'=>$data['Prices'],
					'product_qty' => $data['product_qty'],
					'Original_Prices'=>$data['Original_Prices'],
					'txnid'=>$data['txnid'],
					'gst_price'=>$gst_price,
					'total_gst'=>$gst_price,
					'Shipping_Charges'=>$Shipping_Charges,
					'total_amount'=>$total_price,
					'after_discounted_amount'=>'0',
					'payment_method'=>$data['payment_method'],
					'address_id'=>$Shipping_address,
					'order_date_time'=>$data['order_date_time'],
					'order_month'=> date('m'),
                    'order_year'=> date('Y'),
                    'order_day'=> date('d'),
                    'order_year_month'=> date('Y-m'),
                    'order_year_month_data' =>date('Y-m-d'),
                    'order_year_month_data_time'=> date('Y-m-d H:i:s'),
					
				);
           // echo '<pre>'; print_r($order_data); exit;

         $user = "oxiinc";
		$password = "microlan@123";
		$senderId = "OXIINC";
		$channel = "Trans";
		$dcs = "0";
		$flashsms = "0";
		$route = "6";
		$mobile = '7710929568';
        $text_message = "Dear ". $user_name. ". Thank you for Create order with us, We have received your Number no ".$contact_number.". We will process your Register at your chosen date and time.";
	    $sms = urlencode($text_message);

	    $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

	    try  
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $smsurl);
            $datas = curl_exec($ch);
            curl_close($ch);
            $response = $datas;

        }  
        catch (Exception $e)  
        {  
            $response = $e->getMessage();  
            echo '<pre>'; print_r($response); exit;
        }
				$order_id = $this->Model->insertData('order_data',$order_data);
				// echo '<pre>'; print_r($data); exit;
				$this->load->view('buy_now_success',$data);
       }else{
       	echo 'fail';
       }
   }
   if (!empty($_POST['payumoney'])) {
   
   }
		// echo '<pre>'; print_r($Shipping_address); exit;
		
	}
	function order_create_sms($user_name,$contact_number){
		$user = "oxiinc";
		$password = "microlan@123";
		$senderId = "OXIINC";
		$channel = "Trans";
		$dcs = "0";
		$flashsms = "0";
		$route = "6";
		$mobile = $contact_number;
        $text_message = "Dear ". $user_name. ". Thank you for Create order with us, We have received your Number no ".$contact_number.". We will process your Register at your chosen date and time.";
	    $sms = urlencode($text_message);

	    $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

	    try  
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $smsurl);
            $data = curl_exec($ch);
            curl_close($ch);
            $response = $data;
        }  
        catch (Exception $e)  
        {  
            $response = $e->getMessage();  
        }
	}
	public function checkout_cash_on_delvery()
	{
		// echo '<pre>'; print_r($_POST); exit;




if (!empty($_POST['cod'])) {
	// echo '<pre>'; print_r($_POST); exit;
		$id =  $this->session->userdata('id'); 
		$size = $this->input->post('size');
		// $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		$data['total_cart'] = $this->cart->total_items();
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$product_id = $this->input->post('product_id');
		$quantity = $this->input->post('quantity');
		$product_name = $this->input->post('product_name');
		$Product_Picture = $this->input->post('Product_picture');
		// echo '<pre>'; print_r($product_name); exit;
		$company_name = $this->input->post('company_name');
		$subtotal = $this->input->post('subtotal');
		$original = $this->input->post('original');
		$gst_price = $this->input->post('gst_price');
		$Shipping_Charges = $this->input->post('Shipping_Charges');
		$total_gst = $this->input->post('total_gst');
		$Promo_amount = $this->input->post('Promo_amount');
		$total_shipping = $this->input->post('total_shipping');
		$customer_id = $this->input->post('customer_id');
		$total_price = $this->input->post('total_price');
		$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
		$user_data = $this->Model->getData('custumer_login',array('id'=>$customer_id));
		$data['Customer_id'] =  $user_data[0]['id'];
		$data['email_id'] =  $user_data[0]['email_id'];
		$data['user_name'] =  $user_data[0]['user_name'];
		$data['contact_number'] =  $user_data[0]['contact_number'];




          $promo_id = $this->input->post('promo_id');

          if ($promo_id) {
          	$promo_code_id = $promo_id;
          }else{
          	$promo_code_id = '0';
          }


          if($Promo_amount){

          	$promo_amout = $Promo_amount;

          }else{
          	$promo_amout = 0;
          }

     




		 if($Shipping_address!="" && $product_id!="" && $customer_id!=""){
		$i=0;
		foreach ($product_id as $key => $value) {
			
		    $order_data = array(
					'customer_id'=>$customer_id,
					'email_id'=>$data['email_id'],
					'user_name'=>$data['user_name'],
					'contact_number'=>$data['contact_number'],
					'product_id'=>$value,
					'Product_Name'=>$product_name[$i],
					'Product_Picture'=>$Product_Picture[$i],
					'Prices' => $subtotal[$i],
					'product_qty' => $quantity[$i],
					'Original_Prices'=>$original[$i],
					'size'=>$size[$i],
					'gst_price'=>$gst_price[$i],
					'total_gst'=>$total_gst,
					'promo_code_id'=>$promo_code_id,
					'Promo_amount'=>$promo_amout,
					'Shipping_Charges'=>$Shipping_Charges[$i],
					'total_shipping'=>$total_shipping,
					'txnid'=>$txnid,
					'total_amount'=>$total_price,
					'after_discounted_amount'=>'0',
					'payment_method'=>'COD',
					'address_id'=>$Shipping_address,
					'order_date_time'=>date('Y-m-d H:i:s'),
					'order_month'=> date('m'),
                    'order_year'=> date('Y'),
                    'order_day'=> date('d'),
                    'order_year_month'=> date('Y-m'),
                    'order_year_month_data' =>date('Y-m-d'),
                    'order_year_month_data_time'=> date('Y-m-d H:i:s'),
					
				);
		 $order_id = $this->Model->insertData('order_data',$order_data);
		// $order_id = $this->Model->insertData('order_data',array_map('strtoupper', $order_data));
		 $i++;
		}



       if($promo_id){

       	$status['Active_states']='0';
    $this->Model->updateData('promo_codo',$status,array('ID'=>$promo_id));

       }




		$user_order_data = $this->Model->getData('order_data',array('txnid'=>$txnid));
		$data['user_order_data'] = $user_order_data;
		$data['user_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$user_order_data[0]['address_id']));
		// echo '<pre>'; print_r($data['user_manage_addresses']); exit;
		$this->cart->destroy();
		$this->load->view('checkout_now_success',$data);
	}else{
       	echo 'fail';
      }
}



if (!empty($_POST['payumoney'])) {

	    $id =  $this->session->userdata('id'); 
	    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$data['manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$Shipping_address));
		$subtotal = $this->input->post('subtotal');
		$Promo_amount = $this->input->post('Promo_amount');
		$customer_id = $this->input->post('customer_id');
		$user_data = $this->Model->getData('custumer_login',array('id'=>$customer_id));
		$data['user_data'] = $user_data;
		$Customer_id =  $user_data[0]['id'];
		$email_id =  $user_data[0]['email_id'];
		$user_name =  $user_data[0]['user_name'];
		$contact_number =  $user_data[0]['contact_number'];


          $data['promo_id'] = $this->input->post('promo_id');
          if($Promo_amount){

          	$data['promo_amout'] = $Promo_amount;

          }else{
          	$data['promo_amout'] = 0;
          }




          //payumoney details
          $amount = $this->input->post('total_price');
          $data['total_price'] = $amount;
          // echo '<pre>'; print_r($amount); exit;
          $total_cart = $this->cart->total_items();
          $data['total_cart'] = $total_cart;
          $product_info = 'Total '.$total_cart.' product in cart';
          $data['product_info'] = $product_info;
          $customer_name = $user_name;
          $data['customer_name'] = $customer_name;
		  $customer_emial = $email_id;
		  $data['customer_emial'] = $customer_emial;
		  $customer_mobile = $contact_number;
		  $data['customer_mobile'] = $customer_mobile;
		  $customer_address = $this->input->post('customer_address');

           $MERCHANT_KEY = "0U3Ee2uh"; //change  merchant with yours
           $data['MERCHANT_KEY'] =  $MERCHANT_KEY;
	       $SALT = "Mt1vS3WJzu";  //change salt with yours 
           $data['SALT'] =  $SALT;


	        $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	        $data['txnid'] =  $txnid;
	         //optional udf values 
	        $udf1 = '';
	        $udf2 = '';
	        $udf3 = '';
	        $udf4 = '';
	        $udf5 = '';

	          $hashstring = $MERCHANT_KEY . '|' . $txnid . '|' . $amount . '|' . $product_info . '|' . $customer_name . '|' . $customer_emial . '|' . $udf1 . '|' . $udf2 . '|' . $udf3 . '|' . $udf4 . '|' . $udf5 . '||||||' . $SALT;
	         $hash = strtolower(hash('sha512', $hashstring));
              $data['hash'] =  $hash;

	          $success = base_url() . 'Status';  
	           $data['success'] =  $success;
	        $fail = base_url() . 'Status';
	         $data['fail'] =  $fail;
	        $cancel = base_url() . 'Status';
	         $data['cancel'] =  $cancel;


	            $data['action'] = "https://secure.payu.in"; //for live change action  https://secure.payu.in


// echo '<pre>'; print_r($data); exit;

$this->load->view('Payumoney_confirm',$data);



}
if (!empty($_POST['enpay'])) {
    $size = $this->input->post('size');
	$total_pricess = $this->input->post('total_price');
	// $i=0;
 //           foreach ($this->cart->contents() as $items){
 //           	 $i++;
 //       }
 $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$this->session->userdata('id')));

 $total_sum_credit=0; $total_sumzcz=0; $i=0;
foreach ($customer_enpay as $key => $value) {
	
 if ($value['debits_amount']>0) {
                         $debits_amount =  $value['debits_amount'];
                        
                      }else{
                        $debits_amount = 0;
                      }

                       if ($value['Credits_amount']>0) {
                         $Credits_amount =  $value['Credits_amount'];
                        
                      }else{
                        $Credits_amount = 0;
                      }


	$total_sumzcz+=$debits_amount;
    $total_sum_credit+=$Credits_amount;
}

$enpay_amount = $total_sumzcz-$total_sum_credit;
// echo '<pre>'; print_r($enpay_amount);
// echo '<pre>'; print_r($total_pricess); exit;


	if ($total_pricess == $enpay_amount) {
		// echo '<pre>'; print_r($_POST); exit;
		$id =  $this->session->userdata('id'); 

		// $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		$data['total_cart'] = $this->cart->total_items();
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$product_id = $this->input->post('product_id');
		$quantity = $this->input->post('quantity');
		$product_name = $this->input->post('product_name');
		$Product_Picture = $this->input->post('Product_picture');
		// echo '<pre>'; print_r($product_name); exit;
		$company_name = $this->input->post('company_name');
		$subtotal = $this->input->post('subtotal');
		$original = $this->input->post('original');
		$gst_price = $this->input->post('gst_price');
		$Shipping_Charges = $this->input->post('Shipping_Charges');
		$total_gst = $this->input->post('total_gst');
		$Promo_amount = $this->input->post('Promo_amount');
		$total_shipping = $this->input->post('total_shipping');
		$customer_id = $this->input->post('customer_id');
		// $total_price = $this->input->post('total_price');
		$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
		$user_data = $this->Model->getData('custumer_login',array('id'=>$customer_id));
		$data['Customer_id'] =  $user_data[0]['id'];
		$data['email_id'] =  $user_data[0]['email_id'];
		$data['user_name'] =  $user_data[0]['user_name'];
		$data['contact_number'] =  $user_data[0]['contact_number'];








          $promo_id = $this->input->post('promo_id');


           if ($promo_id) {
          	$promo_code_id = $promo_id;
          }else{
          	$promo_code_id = '0';
          }


          if($Promo_amount){

          	$promo_amout = $Promo_amount;

          }else{
          	$promo_amout = 0;
          }

     




		 if($Shipping_address!="" && $product_id!="" && $customer_id!=""){
		$i=0;
		foreach ($product_id as $key => $value) {
			
		    $order_data = array(
					'customer_id'=>$customer_id,
					'email_id'=>$data['email_id'],
					'user_name'=>$data['user_name'],
					'contact_number'=>$data['contact_number'],
					'product_id'=>$value,
					'Product_Name'=>$product_name[$i],
					'Product_Picture'=>$Product_Picture[$i],
					'Prices' => $subtotal[$i],
					'product_qty' => $quantity[$i],
					'Original_Prices'=>$original[$i],
					'size'=>$size[$i],
					'gst_price'=>$gst_price[$i],
					'total_gst'=>$total_gst,
					'promo_code_id'=>$promo_code_id,
					'Promo_amount'=>$promo_amout,
					'Shipping_Charges'=>$Shipping_Charges[$i],
					'total_shipping'=>$total_shipping,
					'txnid'=>$txnid,
					'total_amount'=>'0',
					'after_discounted_amount'=>'0',
					'payment_method'=>'enpay',
					'address_id'=>$Shipping_address,
					'order_date_time'=>date('Y-m-d H:i:s'),
					'order_month'=> date('m'),
                    'order_year'=> date('Y'),
                    'order_day'=> date('d'),
                    'order_year_month'=> date('Y-m'),
                    'order_year_month_data' =>date('Y-m-d'),
                    'order_year_month_data_time'=> date('Y-m-d H:i:s'),
					
				);
		 $order_id = $this->Model->insertData('order_data',$order_data);
		// $order_id = $this->Model->insertData('order_data',array_map('strtoupper', $order_data));
		 $i++;
		}



       if($promo_id){

       	$status['Active_states']='0';
    $this->Model->updateData('promo_codo',$status,array('ID'=>$promo_id));

       }
$debits_amountss['Customer_id']= $this->session->userdata('id');
  $debits_amountss['Credits_amount']= $total_pricess;
    $this->Model->insertData('customer_enpay',$debits_amountss);

        $user_order_data = $this->Model->getData('order_data',array('txnid'=>$txnid));
		$data['user_order_data'] = $user_order_data;
		$data['user_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$user_order_data[0]['address_id']));
		// echo '<pre>'; print_r($data['user_manage_addresses']); exit;
		$this->cart->destroy();
// echo '<pre>'; print_r($data); exit;

		$this->load->view('checkout_now_success',$data);
}else{
       	echo 'fail';
      }

	}
	if ($total_pricess > $enpay_amount) {
    $id =  $this->session->userdata('id'); 
	$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$data['manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$Shipping_address));
		$subtotal = $this->input->post('subtotal');
		$Promo_amount = $this->input->post('Promo_amount');
		$customer_id = $this->input->post('customer_id');
		$user_data = $this->Model->getData('custumer_login',array('id'=>$customer_id));
		$data['user_data'] = $user_data;
		$Customer_id =  $user_data[0]['id'];
		$email_id =  $user_data[0]['email_id'];
		$user_name =  $user_data[0]['user_name'];
		$contact_number =  $user_data[0]['contact_number'];


          $data['promo_id'] = $this->input->post('promo_id');
          if($Promo_amount){

          	$data['promo_amout'] = $Promo_amount;

          }else{
          	$data['promo_amout'] = 0;
          }




          //payumoney details
          $total_price = $this->input->post('total_price');
          $amount =  $total_price - $enpay_amount;         
          $data['total_price'] = $amount;
          $data['enpay'] = $enpay_amount;
          // echo '<pre>'; print_r($amount); exit;
          $total_cart = $this->cart->total_items();
          $data['total_cart'] = $total_cart;
          $product_info = 'Total '.$total_cart.' product in cart';
          $data['product_info'] = $product_info;
          $customer_name = $user_name;
          $data['customer_name'] = $customer_name;
		  $customer_emial = $email_id;
		  $data['customer_emial'] = $customer_emial;
		  $customer_mobile = $contact_number;
		  $data['customer_mobile'] = $customer_mobile;
		  $customer_address = $this->input->post('customer_address');

           $MERCHANT_KEY = "0U3Ee2uh"; //change  merchant with yours
           $data['MERCHANT_KEY'] =  $MERCHANT_KEY;
	       $SALT = "Mt1vS3WJzu";  //change salt with yours 
           $data['SALT'] =  $SALT;


	        $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	        $data['txnid'] =  $txnid;
	         //optional udf values 
	        $udf1 = '';
	        $udf2 = '';
	        $udf3 = '';
	        $udf4 = '';
	        $udf5 = '';

	          $hashstring = $MERCHANT_KEY . '|' . $txnid . '|' . $amount . '|' . $product_info . '|' . $customer_name . '|' . $customer_emial . '|' . $udf1 . '|' . $udf2 . '|' . $udf3 . '|' . $udf4 . '|' . $udf5 . '||||||' . $SALT;
	         $hash = strtolower(hash('sha512', $hashstring));
              $data['hash'] =  $hash;

	          $success = base_url() . 'Enpay';  
	           $data['success'] =  $success;
	        $fail = base_url() . 'Enpay';
	         $data['fail'] =  $fail;
	        $cancel = base_url() . 'Enpay';
	         $data['cancel'] =  $cancel;


	            $data['action'] = "https://secure.payu.in"; //for live change action  https://secure.payu.in


// echo '<pre>'; print_r($data); exit;

// $this->load->view('Payumoney_confirm',$data);
      $this->load->view('enpay_total_amount_greater',$data);

	}
	if ($total_pricess < $enpay_amount) {
// echo '<pre>'; print_r($_POST); exit;
$id =  $this->session->userdata('id'); 
		// $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		$data['total_cart'] = $this->cart->total_items();
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$product_id = $this->input->post('product_id');
		$quantity = $this->input->post('quantity');
		$product_name = $this->input->post('product_name');
		$Product_Picture = $this->input->post('Product_picture');
		// echo '<pre>'; print_r($product_name); exit;
		$company_name = $this->input->post('company_name');
		$subtotal = $this->input->post('subtotal');
		$original = $this->input->post('original');
		$gst_price = $this->input->post('gst_price');
		$Shipping_Charges = $this->input->post('Shipping_Charges');
		$total_gst = $this->input->post('total_gst');
		$Promo_amount = $this->input->post('Promo_amount');
		$total_shipping = $this->input->post('total_shipping');
		$customer_id = $this->input->post('customer_id');
		$total_price = $this->input->post('total_price');
		$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
		$user_data = $this->Model->getData('custumer_login',array('id'=>$customer_id));
		$data['Customer_id'] =  $user_data[0]['id'];
		$data['email_id'] =  $user_data[0]['email_id'];
		$data['user_name'] =  $user_data[0]['user_name'];
		$data['contact_number'] =  $user_data[0]['contact_number'];








          $promo_id = $this->input->post('promo_id');


          if ($promo_id) {
          	$promo_code_id = $promo_id;
          }else{
          	$promo_code_id = '0';
          }


          if($Promo_amount){

          	$promo_amout = $Promo_amount;

          }else{
          	$promo_amout = 0;
          }

     




		 if($Shipping_address!="" && $product_id!="" && $customer_id!=""){
		$i=0;
		foreach ($product_id as $key => $value) {
			
		    $order_data = array(
					'customer_id'=>$customer_id,
					'email_id'=>$data['email_id'],
					'user_name'=>$data['user_name'],
					'contact_number'=>$data['contact_number'],
					'product_id'=>$value,
					'Product_Name'=>$product_name[$i],
					'Product_Picture'=>$Product_Picture[$i],
					'Prices' => $subtotal[$i],
					'product_qty' => $quantity[$i],
					'Original_Prices'=>$original[$i],
					'size'=>$size[$i],
					'gst_price'=>$gst_price[$i],
					'total_gst'=>$total_gst,
					'promo_code_id'=>$promo_code_id,
					'Promo_amount'=>$promo_amout,
					'Shipping_Charges'=>$Shipping_Charges[$i],
					'total_shipping'=>$total_shipping,
					'txnid'=>$txnid,
					'total_amount'=>'0',
					'after_discounted_amount'=>'0',
					'payment_method'=>'enpay',
					'address_id'=>$Shipping_address,
					'order_date_time'=>date('Y-m-d H:i:s'),
					'order_month'=> date('m'),
                    'order_year'=> date('Y'),
                    'order_day'=> date('d'),
                    'order_year_month'=> date('Y-m'),
                    'order_year_month_data' =>date('Y-m-d'),
                    'order_year_month_data_time'=> date('Y-m-d H:i:s'),
					
				);
		 $order_id = $this->Model->insertData('order_data',$order_data);
		// $order_id = $this->Model->insertData('order_data',array_map('strtoupper', $order_data));
		 $i++;
		}



       if($promo_id){

       	$status['Active_states']='0';
    $this->Model->updateData('promo_codo',$status,array('ID'=>$promo_id));

       }
    //  $debits_amountss['Customer_id']= $this->session->userdata('id');
    //  $debits_amountss['Credits_amount']= $total_pricess;
    // $this->Model->insertData('customer_enpay',$debits_amountss);

        $user_order_data = $this->Model->getData('order_data',array('txnid'=>$txnid));
		$data['user_order_data'] = $user_order_data;
		$data['user_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$user_order_data[0]['address_id']));

		$debits_amountss['Customer_id']= $this->session->userdata('id');
        $debits_amountss['Credits_amount']= $total_price;
        $this->Model->insertData('customer_enpay',$debits_amountss);


		// echo '<pre>'; print_r($data['user_manage_addresses']); exit;
		$this->cart->destroy();
// echo '<pre>'; print_r($data); exit;

		$this->load->view('checkout_now_success',$data);



		// echo '<pre>'; print_r($_POST); exit;
	}
	}else{
       	echo 'fail';
      }

}


	}
	function create_order(){
		$jsonObj = $this->input->get_post('jsonObj');
		$jsonObj = stripslashes($jsonObj);
		$user_object = json_decode($jsonObj,true); 
		
		//print_array($user_object);
		if(isset($user_object) && $user_id!=""){
			$orderNo = 'DF'.date('Ymd').time();
			$order_data = $user_object['order_data'];
			$user_id = $order_data['user_id'];
			$address_id= $order_data['address_id'];
			$delivery_date= $order_data['delivery_date'];
			$delivery_time= $order_data['delivery_time'];
			$total_amount= $order_data['total_amount'];
			$delivery_charges= $order_data['delivery_charges'];

			$order_details= $order_data['order_details'];
			
			$user_data = $this->model->getData('user',array('user_id'=>$user_id));

			if(isset($order_details) && !empty($order_details)){
				
				$order_data = array(
					'user_id'=>$user_id,
					'order_number'=>$orderNo,
					'total_amount'=>$total_amount,
					'delivery_charges'=>$delivery_charges,
					'after_discounted_amount'=>$total_amount,
					'payment_method'=>'COD',
					'address_id'=>$address_id,
					'user_expected_order_date'=>date('Y-m-d',strtotime($delivery_date)),
					'user_expected_order_time_slot'=>$delivery_time,
					'order_date_time'=>date('Y-m-d H:i:s'),
					'order_source'=>'2',
				);
				$order_id = $this->model->insertData('order_data',$order_data);

				foreach ($order_details as $key => $value) {
					$product_data = $this->model->getData('product',array('product_id'=>$value['product_id']));
					$price = $product_data[0]['price'];
					$unit_total = upto2Decimal($value['product_quantity']*$price);
					
					$array_cart_item=array(
						'user_id'=>$user_id,
						'order_id'=>$order_id,
						'order_number'=>$orderNo,
						'product_id'=>$value['product_id'],
						'qty'=>$value['product_quantity'],
						'price'=>$price,
						'unit_total'=>$unit_total,
					);
					$this->model->insertData('order_data_details',$array_cart_item);
				}

				$this->send_order_confirmation_mail($order_id,$address_id);
				$this->sms_order_confirmation_to_user($order_id,$user_data[0]['mobile_number'],$user_data[0]['full_name']);
		        $this->sms_order_confirmation_to_admin($order_id,'9029921216',$user_data[0]['full_name']);

				$data['status'] = '1';
				$data['msg'] = 'Your order number <br><br> #'.$orderNo.' <br><br>has been placed successfully.';
				
			}else{
				$data['status'] = '0';
				$data['msg'] = 'Order details has not found.';
			}
		}else{
			$data['status'] = '0';
			$data['msg'] = 'Invalid parameter send';
		}
		echo json_encode($data);
	}
function confirm_summary_ticket(){
	// echo '<pre>'; print_r($_POST); exit;

		$user_name = $this->input->post('user_name');
		$Email = $this->input->post('Email');
		$Mobile_Number = $this->input->post('Mobile_Number');
		$quanity = $this->input->post('quanity');
		$Total_seat_amount = $this->input->post('Total_seat_amount');
		$Total_enpay = $this->input->post('Total_enpay');
		$Seminar_Date = $this->input->post('Seminar_Date');
		$Seminar_address = $this->input->post('Seminar_address');
		$Seminar_Price = $this->input->post('Seminar_Price');
		$Seminar_City = $this->input->post('Seminar_City');
		$Sponsor_Name = $this->input->post('Sponsor_Name');
		$Sponsor_email = $this->input->post('Sponsor_email');
		// $random_number = mt_rand(100,9999);
		$random_number = substr(hash('sha256', mt_rand() . microtime()), 0, 6);

		$order_id = 'Ticket_No_'.$random_number;
		// echo '<pre>'; print_r($order_id); exit;
		// echo '<pre>'; print_r($Seminar_Date); 
		// echo '<pre>'; print_r(date('Y-m-d')); exit;
		if ($Seminar_Date>=date('Y-m-d')) {
		if ($Total_enpay>=$Total_seat_amount) {
		// echo '<pre>'; print_r($_POST); exit;
		$summary['Customer_id'] = $this->session->userdata('id');
		$summary['user_name'] = $user_name;
		$summary['Email'] = $Email;
		$summary['Mobile_Number'] = $Mobile_Number;
		$summary['quanity'] = $quanity;
		$summary['Total_seat_amount'] = $Total_seat_amount;
		$summary['order_id'] = $order_id;
		$summary['Total_enpay'] = $Total_enpay;
		$summary['Seminar_Date'] = $Seminar_Date;
		$summary['Seminar_address'] = $Seminar_address;
		$summary['Seminar_Price'] = $Seminar_Price;
		$summary['Seminar_City'] = $Seminar_City;
		$summary['Sponsor_Name'] = $Sponsor_Name;
		$summary['Sponsor_email'] = $Sponsor_email;
		$summary['summary_month']= date('m');
        $summary['summary_year']= date('Y');
        $summary['summary_day']= date('d');
        $summary['summary_year_month']= date('Y-m');
        $summary['summary_year_month_data'] =date('Y-m-d');

		$summary_ID = $this->Model->insertData('summary',$summary);
// echo '<pre>'; print_r($summary); exit;
		$debits_amountss['Customer_id']= $this->session->userdata('id');
        $debits_amountss['Credits_amount']= $Total_seat_amount;
        $this->Model->insertData('customer_enpay',$debits_amountss);

        $id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['summary'] = $this->Model->getData('summary',array('ID'=>$summary_ID));
        $this->load->view('Seminar_success',$data);
		}else{
			$this->session->set_flashdata('msg','Sorry Your Enpay Balance  Is Insufficient For Payment.');
		
		redirect(base_url("Home/Summary_ticket"));
		}

	}else{
		$this->session->set_flashdata('msg','Seminar Date was Expire.');
		
		redirect(base_url("Home/Summary_ticket"));
	}

}
function customer_ticket(){
		$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['summary'] = $this->Model->getDataOrderBy('summary',array('Customer_id'=>$id),'ID','DESC');
// echo '<pre>'; print_r($data['Customer_orders']); exit;
		$this->load->view('customer_ticket',$data);
}
function print_customer_ticket(){
	$ID = $_GET['ID'];
	// echo '<pre>'; print_r($ID); exit;
	$id =  $this->session->userdata('id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
	$data['summary'] = $this->Model->getDataOrderBy('summary',array('ID'=>$ID),'ID','DESC');
	// echo '<pre>'; print_r($data); exit;
	$this->load->view('print_customer_ticket',$data);
}
// function Ticket_pdf_Print(){

// 		// require('././third_party/pdf/fpdf/fpdf.php');
//   //       include("././third_party/pdf/mpdf/mpdf.php");
//   //       require('././third_party/pdf/WriteHTML.php');

//   //       $pdf = new mPDFs();
//   //       // echo '<pre>'; print_r($pdf); exit;
//   //       $ID = $this->input->get_post('ID');
//   //       $data['summary'] = $this->Model->getData('summary',array('ID'=>$ID));
//   //      $html = $this->load->view('Ticket_pdf_Print',$data);
//   //       // echo '<pre>'; print_r($ID); exit;
//   //       $pdf->WriteHTML($html);

//   //       $filename = 'Seminar_ticket'.$data['summary'][0]['user_name'].'_'.rand().'.pdf';

//         // $pdf->Output($filename,'I');


//          require('././third_party/pdf/fpdf/fpdf.php');
//         include("././third_party/pdf/mpdf/mpdf.php");
//         require('././third_party/pdf/WriteHTML.php');

//         $pdf = new mPDF();
        
//          $ID = $this->input->get_post('ID');
//         $data['summary'] = $this->Model->getData('summary',array('ID'=>$ID));
//        $html = $this->load->view('Ticket_pdf_Print',$data);
        
//         $pdf->WriteHTML($html);
//           $filename = 'Seminar_ticket_'.rand().'.pdf';
//         // $filename = 'purchase_order_'.$data['supplier_data'][0]['supplier_name'].'_'.rand().'.pdf';

//         $pdf->Output($filename,'I');
// }



		// public function Pan_cart_info(){
	
	
		
	// 	if(!empty($_FILES['Pan_Picture'])){
 //            $uploaddir = './uploads/Customer_pan/';
 //            $uploadfile = $uploaddir . basename($_FILES['Pan_Picture']['name']);

 //            if (move_uploaded_file($_FILES['Pan_Picture']['tmp_name'], $uploadfile)) {
 //              echo "File is valid, and was successfully uploaded.\n";
 //              $postData['Pan_Picture'] = basename($_FILES['Pan_Picture']['name']);
 //            }
 //        }
 //       echo '<pre>'; print_r($postData['Pan_Picture']); exit;

	// 	$postData = array(
			
 //        	'Customer_id' =>  $this->session->userdata('id'), 
 //                'pan_number' => $this->input->post('pan_number'),
 //                'Pan_Full_Name' => $this->input->post('Pan_Full_Name'),
        
 //        );

	// 	 $this->Model->insertData('customer_pan_info',$postData); 
 //         $this->session->set_flashdata('msg' ,'The Pan Information has been Uploaded successfully.');
 //         redirect('Customer_login_page/my_profile');
	// }
// 	function Pan_cart_info(){
//         if($this->input->post('userSubmit')){
//             // echo '<pre>'; print_r($_FILES); exit;
            
//             //Check whether user upload picture
//             if(!empty($_FILES['Product_Picture']['name'])){
//                 $config['upload_path'] = 'uploads/Customer_pan/';
//                 $config['allowed_types'] = 'jpg|jpeg|png|gif';
//                 $config['file_name'] = $_FILES['Product_Picture']['name'];
                
//                 //Load upload library and initialize configuration
//                 $this->load->library('upload',$config);
//                 $this->upload->initialize($config);
                
//                 if($this->upload->do_upload('Product_Picture')){
//                     $uploadData = $this->upload->data();
//                     $picture = $uploadData['file_name'];
//                 }else{
//                     $picture = '';
//                 }
//             }else{
//                 $picture = '';
//             }
            
//             //Prepare array of user data
//             $userData = array(
//             	'Customer_id' =>  $this->session->userdata('id'), 
//                 'pan_number' => $this->input->post('pan_number'),
//                 'Pan_Full_Name' => $this->input->post('Pan_Full_Name'),
                
//                 'Product_Picture' => $picture
//             );
// echo '<pre>'; print_r($userData); exit;
            
//             //Pass user data to model
//             $id=$this->Model->insertData('customer_pan_info',$userData); 
//             // echo '<pre>'; print_r($id); exit;
//             // $insertUserData = $this->Advertisement_add->insert($userData);
//             $this->session->set_flashdata('msg' ,'The Pan Information has been Uploaded successfully.');
//          redirect('Customer_login_page/my_profile');
            
            
//         }
//         //Form for adding user data
//         // $this->load->view('views/camera_wrap');
        
//     }
    
			
}