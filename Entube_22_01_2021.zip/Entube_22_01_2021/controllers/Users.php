<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Users extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('user');
        
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function Add(){
        if($this->input->post('userSubmit')){
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['picture']['name'])){
                $config['upload_path'] = 'uploads/images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'name' => $this->input->post('name'),
                'Label_1' => $this->input->post('Label_1'),
                'Label_2' => $this->input->post('Label_2'),
                'Label_3' => $this->input->post('Label_3'),
                'picture' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->user->insert($userData);
            $this->session->set_flashdata('msg','this picture now you can see in your home page');
            redirect('orders/camera_wrap');
            
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}