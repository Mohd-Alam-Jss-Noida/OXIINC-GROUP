<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Upload_video extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Wellness_add');
        $this->load->model('Model');
        $this->load->model('Files');
        $this->load->helper('string');
        $this->load->helper('url');
        $this->load->model('Dbs');
        // if(!$this->session->userdata('logged_in')){
        //     redirect('home');
        //  }
    }
    public function index()
    {
        # code...
      $category_data = $this->Model->getData('category',array('status'=>'1'));
        $data['category_data'] = $category_data;
        $this->load->view('upload',$data);
    }
    function Add(){
         date_default_timezone_set("Asia/Calcutta");
    //   echo '<pre>'; print_r($_POST); exit;
// echo $this->session->userdata('id');
// print_r($_FILES);
       // exit();

     // /*** convert video to flash ***/
     // exec("ffmpeg -i video.avi -ar 22050 -ab 32 -f flv -s 320x240 video.flv");

     //        exit();
        // echo '<pre>'; print_r($_FILES); exit;
         // echo '<pre>'; print_r($this->input->post('Multiple_Picture_color')); exit;
        // if($this->input->post('userSubmit')){
            // print_r($_POST);exit();
            
            //Check whether user upload picture
         if (!empty($_FILES['Multiple_image']['name'])) {
           # code...
        
$image = $_FILES['Multiple_image']['name'];
$image_ext = pathinfo($image, PATHINFO_EXTENSION);
$Video = $_FILES['Multiple_Video']['name'];
$Video_ext = pathinfo($Video, PATHINFO_EXTENSION);
if (($image_ext=="png" || $image_ext=="jpg" || $image_ext=="gif") && ($Video_ext=="mp4") ) {
if(!empty($_FILES['Multiple_image']['name'])){
$config['upload_path'] = 'uploads/product/';
$config['allowed_types'] = 'jpg|jpeg|png|gif';

$config['file_name'] = rand()."_entube_image_gagan".".png";

//Load upload library and initialize configuration
$this->load->library('upload',$config);
$this->upload->initialize($config);

if($this->upload->do_upload('Multiple_image')){
$uploadData = $this->upload->data();
$picture = $uploadData['file_name'];
}else{
$picture = '';
}
}else{
$picture = '';
}
if(!empty($_FILES['Multiple_Video']['name'])){


$configVideo['upload_path'] = 'uploads/video/'; # check path is correct
$configVideo['allowed_types'] = '*'; # add video extenstion on here
$configVideo['overwrite'] = FALSE;
$configVideo['remove_spaces'] = TRUE;
$configVideo['maintain_ratio'] = FALSE;
$configVideo['max_width'] = '500';
$configVideo['max_height'] = '500';
// $video_name = random_string('numeric', 5);
$exploded = explode('.',$_FILES['Multiple_Video']['name']);
$ext = $exploded[count($exploded) - 1];
// print_r($ext);exit();
$configVideo['file_name'] = rand()."entube.mp4";
// print_r($configVideo['file_name']);exit();
$this->load->library('upload', $configVideo);
// $this->load->library('image_lib', $configVideo);
//                    $this->image_lib->resize();
$configVideo['image_library'] = 'gd2';
$this->upload->initialize($configVideo);
if($ext=="mp4"){
if($this->upload->do_upload('Multiple_Video')){
$uploadData = $this->upload->data();
$video = $uploadData['file_name'];
}else{
$video = '';
}
}else{
$this->session->set_flashdata('msg','something went wrong.........');
redirect("Upload_video/List_Of_Upload");
}
}else{
$video = '';
}
if($this->session->userdata('entube_customer_logged_in')){
$user_id_upload=$this->session->userdata('username');
$userData = array(
'category_id' => $this->input->post('category_id'),
'Video_Name' => $this->input->post('Video_Name'),
'Video_Title' => $this->input->post('Video_Title'),
'Short_Description' => $this->input->post('Short_Description'),

'user_id'=>$user_id_upload,
'upload_time' => date('d-m-Y'),
'picture' => $picture,
'video' => $video,
'user_info' => "1",
'f_name' => $this->session->userdata('name')
);
}elseif($this->session->userdata('logged_in')){
$user_id_upload=$this->session->userdata('id');
$user_name=$this->session->userdata('user_name');
$userData = array(
'category_id' => $this->input->post('category_id'),
'Video_Name' => $this->input->post('Video_Name'),
'Video_Title' => $this->input->post('Video_Title'),
'Short_Description' => $this->input->post('Short_Description'),

'user_id'=>$user_id_upload,
'upload_time' => date('d-m-Y'),
'picture' => $picture,
'video' => $video,
'user_info' => "0",
'f_name' => $user_name
);
}else{
redirect(base_url());
}





$this->Dbs->add('add_video',$this->security->xss_clean($userData));
// $ID=$this->Model->insertData('add_video',$userData);
// $this->video_add($video,$ID);
// Loop through process
// Tell user that the process is completed
// echo '<pre>'; print_r($userData); exit;
              $this->session->set_flashdata('msg','successfully your Video uploaded');
              redirect("Upload_video/List_Of_Upload");
              
              }else{
                $this->session->set_flashdata('msg','something went wrong.........');
              redirect("Upload_video/List_Of_Upload");
              }
   }else{
     $this->session->set_flashdata('msg','something went wrong.........');
              redirect("Upload_video/List_Of_Upload");
   }
          //Form for adding user data
          // $this->load->view('views/camera_wrap');
          
      }

    public function video_add($video,$ID)
{
    # code...
    // 
  // $video2 ="C:/xampp1/htdocs/entube_update/uploads/video/".rand()."_entube_updated".".mp4";
    set_time_limit(500000);
    // $video1=rand()."_entube_updated".".png";
  // echo  $video1='https://www.entube.in/uploads/video/entube2145587811.mp4';
      $video2=rand()."_entube_updated".".mp4";
  // exit();
    // echo "Starting ffmpeg...\n\n";
    //  echo shell_exec("ffmpeg -i C:/xampp1/htdocs/entube_update/uploads/video/$video -ss 00:03:00 -frames:v 1 C:/xampp1/htdocs/entube_update/uploads/video/$video1");
   echo shell_exec("ffmpeg -i C:/xampp1/htdocs/entube_update/uploads/video/$video -vf scale=200:400,setsar=1:1 C:/xampp1/htdocs/entube_update/uploads/low/$video2");
$data['video_id']=$ID;
$data['video_name']=$video2;
// echo "<pre>"; print_r($data); exit();
   $this->Model->insertData('video',$data);
  
    // echo "Done.\n";


}

function List_Of_Upload(){
    // $add_video = $this->Model->getDataOrderBy('add_video',array('user_id'=>$this->session->userdata('id')),'ID','DESC');
    //     $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        // $data['main_containt']='List_Of_Upload';
        $this->load->view('creator-studio');
}
function List_Of_Upload1(){
    if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload=$this->session->userdata('username');
             
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload=$this->session->userdata('id');
          
        }
    $add_video = $this->Model->getDataOrderBy('add_video',array('user_id'=>$user_id_upload),'ID','DESC');
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        // $data['main_containt']='List_Of_Upload';
        $this->load->view('creator-studio1',$data);
}
  function Edit(){
    //   echo $this->uri->segment(3);
    if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload=$this->session->userdata('username');
             
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload=$this->session->userdata('id');
          
        }
    $add_video = $this->Model->getDataOrderBy('add_video',array('user_id'=>$user_id_upload,'ID'=>$this->uri->segment(3)),'ID','DESC');
        $data['Pro_Banner_eidt'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
    //     // $data['main_containt']='List_Of_Upload';
        $this->load->view('video_edit',$data);
}  

  function delete(){
    //   echo $this->uri->segment(3);
    if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload=$this->session->userdata('username');
             
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload=$this->session->userdata('id');
          
        }
    // $add_video = $this->Model->getDataOrderBy('add_video',array('user_id'=>$user_id_upload,'ID'=>$this->uri->segment(3)),'ID','DESC');
        $this->Model->deleteData('add_video',array('ID'=>$this->uri->segment(3)));
        $this->Model->deleteData('views',array('post_id'=>$this->uri->segment(3)));
        $this->Model->deleteData('watched_user',array('post_id'=>$this->uri->segment(3)));
         $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');
         redirect('Upload_video/List_Of_Upload');
}

function Pro_Banner_edit_form(){

   $image = $_FILES['picture']['name'];
  $image_ext = pathinfo($image, PATHINFO_EXTENSION);
  if(!$_FILES['picture']['size'] == 0){
    //  echo "<pre>";print_r("hi");
    // echo "<pre>";print_r($_FILES);exit();
    if ($image_ext=="png" || $image_ext=="jpg" || $image_ext=="gif") {
  # code...

      $postData = $_POST;
      $ID = $this->input->get_post('ID');
      if(!empty($_FILES['picture'])){
        $uploaddir = './uploads/product/';
        $image= rand()."entube_gagan".".png";
        $uploadfile = $uploaddir . $image;

        if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              
          $postData['picture'] = $image;
        }
      }


      $this->Model->updateData('add_video',$this->security->xss_clean($postData),array('ID'=>$ID)); 
      $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
      redirect('Upload_video/List_Of_Upload');
    }else{
      $this->session->set_flashdata('msg','something went wrong.........');
      redirect('Upload_video/List_Of_Upload');
    }
  }else{
    // echo "<pre>";print_r("no");exit();

    $postData = $_POST;

    $ID = $this->input->get_post('ID');
    $this->Model->updateData('add_video',$this->security->xss_clean($postData),array('ID'=>$ID)); 
    $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
    redirect('Upload_video/List_Of_Upload');
  }
        // $Pro_banner = $this->Model->getData('pro_banner');
        // $data['Pro_banner'] = $Pro_banner;
        // $data['main_containt']='List_Pro_banner';
        // $this->load->view('containt',$data);
      

         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}
function sponsored_video($value=''){
  $add_video = $this->Model->getDataOrderBy('add_video',array('user_id'=>$this->session->userdata('username')),'ID','DESC');
  $data['add_video'] = $add_video;
  $strSql = "SELECT * FROM countries";
  $data['countries'] =$this->Model->getSqlData($strSql);
  $budget_and_audience = "SELECT * FROM budget_and_audience where status!=3";
  $data['budget_and_audience'] =$this->Model->getSqlData($budget_and_audience);
  // echo "<pre>";print_r($data['add_video']);
  $this->load->view('sponsored_video',$data);
}
function sponsored_video_submit($value=''){
  // $allow_data="";


  // echo "<pre>";print_r($_FILES['product_image']);exit();
  $add_money = $this->db->query('SELECT SUM(amount) AS amount FROM wallet WHERE emp_id='.$this->session->userdata('employee_id'));
  $add_money_amount= $add_money->result_array();
  if ($_POST['total_payable']<=$add_money_amount[0]['amount']) {
   
  $video_allow_id = $_POST['video_id'];
  $var['allow_video'] = '1';
  $PQR =  mt_rand(10000,999999);
  $SKU = 'OXIINC'.$PQR;
  $this->Model->updateData('add_video',$var,array('ID'=>$_POST['video_id']));
  $video_data = $this->Model->getData('add_video',array('ID'=>$_POST['video_id']));
  $allow_data = array(
                    'employee_id'=>$this->session->userdata('employee_id'),
                    'emp_code'=>$this->session->userdata('username'),
                    'category_id'=>$video_data[0]['category_id'],
                    'Video_Name'=>$video_data[0]['Video_Name'],
                    'Video_Title'=>$video_data[0]['Video_Title'],
                    'Short_Description'=>$video_data[0]['Short_Description'],
                    'large_Description'=>$video_data[0]['large_Description'],
                    'Specification_Description'=>$video_data[0]['Specification_Description'],
                    'picture'=>$video_data[0]['picture'],
                    'video'=>$video_data[0]['video'],
                    'video_ID'=>$video_data[0]['ID'],
                    'video_allow_id'=>$video_data[0]['ID'],
                    'panel_name'=>$_POST['panel_name'],
                    'budget'=>$_POST['budget'],
                    'target_audience'=>$_POST['target_audience'],
                    'country'=>$_POST['country'],
                    'payable_amount'=>$_POST['total_payable'],
                    'gst'=>$_POST['gst'],
                    'city'=>$_POST['city'],
                    'manage'=>$_POST['manage'],
                    'gender'=>$_POST['gender'],
                    'perclickcharge'=>$_POST['perclickcharge'],
                    'expirey_date'=>$_POST['expirey_date'],
                    'caption_code'=>$SKU,
                    'allow_year_month_data' =>$_POST['allow_year_month_data'],
                    'allow_year_month_data_time'=> date('Y-m-d H:i:s')
                    
                );
  if(!empty($_FILES['product_image'])){
  $uploaddir = 'uploads/product/';
  $oxiinc=rand().".png";
  $uploadfile = $uploaddir . $oxiinc;
    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadfile)) {
      $allow_data['product_image'] = $oxiinc;
      $allow_data['product_link'] = $_POST['product_link'];
    }
}
  // echo "<pre>";print_r($allow_data);exit();
  $a_id = $this->Model->insertData('allow_data_my_digital',$allow_data);
  $data=array(
                'emp_id' =>$this->session->userdata('employee_id'),
                'user_id' =>$this->session->userdata('user_id'),
                'emp_code' =>$this->session->userdata('employee_code'),
                'amount' =>'-'.$_POST['total_payable'],
                'created_date' =>date('d-M-Y')
                 );
              $this->Model->insertData('wallet',$data);
  $sponsored_video_view = array(
                    'v_id'=>$video_data[0]['ID'],
                    'a_id'=>$a_id,
                    'target_audience'=>$_POST['target_audience']
                );
  $this->Model->insertData('sponsored_video_view',$sponsored_video_view);
  redirect('Upload_video/sponsored_video');
}else{
  $this->session->set_flashdata('msg1','You have insufficient balance..');
              redirect('Home');
}
}
}