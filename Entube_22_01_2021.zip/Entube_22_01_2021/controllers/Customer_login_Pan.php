<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Customer_login_Pan extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Customer_login_Information');
         if(!$this->session->userdata('logged_in')){
            redirect('Home');
         }
    }
    
    function Add(){
        
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['Pan_Picture']['name'])){
                $config['upload_path'] = 'uploads/Customer_pan/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['Pan_Picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('Pan_Picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = 'no';
            }
            
            //Prepare array of user data
            $userData = array(
                'Customer_id' =>  $this->session->userdata('id'), 
                'pan_number' => $this->input->post('pan_number'),
                'Pan_Full_Name' => $this->input->post('Pan_Full_Name'),
                'Pan_Picture' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->Customer_login_Information->insert($userData);
            $this->session->set_flashdata('msg','successfully your Product image uploaded');
            redirect('Customer_login_page/my_profile');
            
            
       
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}