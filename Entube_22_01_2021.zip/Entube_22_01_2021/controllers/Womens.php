<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Womens extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Womens_add');
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function add(){
        if($this->input->post('userSubmit')){
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['Product_Picture']['name'])){
                $config['upload_path'] = 'uploads/Womens/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['Product_Picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('Product_Picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'Product_Name' => $this->input->post('Product_Name'),
                'Womens_type' => $this->input->post('Womens_type'),
                'Short_Description' => $this->input->post('Short_Description'),
                'Original_Prices' => $this->input->post('Original_Prices'),
                'Prices' => $this->input->post('Prices'),
                'Product_Picture' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->Womens_add->insert($userData);
            $this->session->set_flashdata('msg','successfully your Product image uploaded');
            redirect('Product/womens');
            
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}