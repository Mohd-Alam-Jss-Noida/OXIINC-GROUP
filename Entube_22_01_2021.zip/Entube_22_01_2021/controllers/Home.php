<?php
header('Access-Control-Allow-Origin: *');

defined('BASEPATH') OR exit('No direct script access allowed');


class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();

        $this->load->model('Model');
        $this->load->model('Text');
        $this->load->model('Files');
        $this->load->model('Cart_model');
        $this->load->model('Add_category_model');
        $this->load->helper('cookie');
        date_default_timezone_set("Asia/Calcutta");

           // $this->load->model('customer');

           //  if (!$this->session->userdata('customer_table_api')=='1') {
           //   $mydigital_api=$this->mydigital_api();
           //   $customer_tablle_a = json_decode($mydigital_api,true);
           //   $new_customers=[];
           //  foreach ($customer_tablle_a as $key => $values) {
           //    $new_customers[$values['emp_code']]=$values;
           //  }
           //  $_SESSION['customer_table_api']='1';
           //  $_SESSION['customer_table']=$new_customers;
           // }




    }
    public function index()
    {

    // echo "string"; exit;
        $items=[];
        $data['slider'] = $this->Model->getData('slider',array('status'=>1));

        $data['add_video'] = $this->Model->getData('add_video',array('status'=>'1'));
        $data['add_category'] = $this->Model->getData('category',array('category_id'=>'1'));


        $query = $this->db->query('SELECT post_id FROM views WHERE  post_id!="my-profile.php" AND post_id!="index.html" AND dateandtime > "'.date('Y-m-d H:i:s', strtotime(' -14 day')).'" AND dateandtime<= "'.date('Y-m-d H:i:s', strtotime(' +1 day')).'" GROUP BY post_id LIMIT 8');

        $row= $query->result_array();

        foreach ($row as $value) {

          $query11 = $this->db->query("SELECT count( DISTINCT(ip) ) FROM views WHERE post_id!='login.html' AND post_id!='my-profile.php' AND  post_id='".$value['post_id']."' AND dateandtime > '".date('Y-m-d H:i:s', strtotime(' -14 day'))."' AND dateandtime<= '".date('Y-m-d H:i:s', strtotime(' -7 day'))."'");

          $row11= $query11->result_array();
          $query1 = $this->db->query("SELECT count(DISTINCT(user_id)) FROM views WHERE post_id!='login.html' AND post_id!='my-profile.php' AND post_id='".$value['post_id']."' AND dateandtime > '".date('Y-m-d H:i:s', strtotime(' -14 day'))."' AND dateandtime<= '".date('Y-m-d H:i:s', strtotime(' -7 day'))."'  ");

          $row1= $query1->result_array();
          $one=$row11[0]['count( DISTINCT(ip) )'];
          $two=$row1[0]['count(DISTINCT(user_id))'];
          $data['views'] = $one+$two;


        //   $items[] = $value['post_id'];
          $items[] = array(

            'views' => $data['views'],
            'id' => $value['post_id']
        );

        //   $items['gagan1'] = $value['post_id'];
        //  echo "<pre>".$value['post_id']."====";print_r($data['views']);echo"<br>";

      }
    //   echo '<pre>'; print_r($items); exit;
      $data['trading']=$items;

      if ($this->session->userdata('id') || $this->session->userdata('username')) {

      	// $login = $this->Model->getData('custumer_login',array('id'=>$this->session->userdata('id'),'status'=>'1'));
      	// echo '<pre>'; print_r($login); exit;

       $strSql = "SELECT  post_id FROM views WHERE user_id='".$this->session->userdata('id')."' OR user_id='".$this->session->userdata('username')."' GROUP BY post_id ORDER BY RAND() limit 8";
       $data['iprecommatition'] =$this->Model->getSqlData($strSql);
			  // echo '<pre>'; print_r($data['iprecommatition']); exit;
   }else{

       $strSql = "SELECT post_id FROM views WHERE ip='".$this->input->ip_address()."' GROUP BY post_id ORDER BY RAND()  limit 8";
       $data['iprecommatition'] =$this->Model->getSqlData($strSql);
// echo '<pre>'; print_r($master); exit;
   }

// echo '<pre>'; print_r($data['iprecommatition']); exit;
   $date=date('Y-m-d');
   $start_date = date('Y-m-d', strtotime($date . ' +1 day'));
   $stop_date = date('Y-m-d', strtotime($date . ' -6 day'));

   $strSql = "SELECT ID,user_id,datatime,Video_Name,picture,f_name FROM add_video WHERE STATUS='1' AND allow_video='0' 
   GROUP BY user_id ORDER BY datatime DESC LIMIT 16";
   $data['Recently_uploaded'] =$this->Model->getSqlData($strSql);
// echo '<pre>'; print_r( $data['Recently_uploaded']); exit;
   $strSql = "SELECT * FROM add_video WHERE status='1' AND recommended='1' Order by RAND()  LIMIT 6 ";
   $data['rand'] =$this->Model->getSqlData($strSql);






   if ($this->session->userdata('logged_in')) {

       $login = $this->Model->getData('custumer_login',array('id'=>$this->session->userdata('id'),'status'=>'1'));
      	// echo '<pre>'; print_r($login); exit;


       $query = $this->db->query('SELECT  post_id FROM views WHERE post_id!="login.html" AND post_id!="my-profile.php" AND user_id=  "'.$login[0]['user_name'].'" AND dateandtime > "'.date('Y-m-d H:i:s', strtotime(' -14 day')).'" AND dateandtime<= "'.date('Y-m-d H:i:s', strtotime(' -7 day')).'" GROUP BY post_id LIMIT 6');

       $variable12= $query->result_array();
			  // echo '<pre>'; print_r($data['iprecommatition']); exit;
   }else{

       $query = $this->db->query('SELECT  post_id FROM views WHERE post_id!="login.html" AND post_id!="my-profile.php" AND ip=  "'.$this->input->ip_address().'" AND dateandtime > "'.date('Y-m-d H:i:s', strtotime(' -14 day')).'" AND dateandtime<= "'.date('Y-m-d H:i:s').'" GROUP BY post_id LIMIT 25');

       $variable12= $query->result_array();
// echo '<pre>'; print_r($master); exit;
   }
// echo '<pre>'; print_r($variable12); exit;
   $teamarray = [];
   foreach ($variable12 as $key => $value) {

       $strSql12xxasx = "SELECT  category_id FROM add_video where ID ='".$value['post_id']."'";


       $query12 = $this->db->query($strSql12xxasx);

       $row12= $query12->row();
			  // echo '<pre>'; print_r($row12->category_id); exit;
       if(!empty($row12)){
          $teamarray[]=$row12->category_id;
      }
			 //  // echo '<pre>'; print_r($teamarray); 
  }

      // print_r(array_unique($teamarray));exit;
  $data['categoryinfo'] = array_unique($teamarray);
  $data['staticinformation'] =  
  Array ( "0" => 1 , "1" => 4,"2" => 16)
  ;
// echo '<pre>'; print_r($array); exit;
  $strSql_rec = "SELECT ID,user_id,datatime,Video_Name,picture,f_name FROM add_video WHERE STATUS='1' AND recommended='1' 
  ORDER BY datatime DESC LIMIT 16";
  $data['Recommended'] =$this->Model->getSqlData($strSql_rec);
  $this->load->view('index',$data);
}


public function load_more_video()
{

   $strSql = "SELECT ID,user_id,datatime,Video_Name,picture,f_name FROM add_video WHERE STATUS='1' AND allow_video='0' AND user_info!='' ORDER BY ID DESC LIMIT ".$_POST['id'];
   $data_rand =$this->Model->getSqlData($strSql);
//            $servername_11='49.50.117.106';
// $username_11='membero_oxiinc';
// $password_11='YD4{B@Cp;[wS';
// $dbname_11 = "membero_oxiinc";
// $conn_11=mysqli_connect($servername_11,$username_11,$password_11,"$dbname_11");



   ?>

   <?php
   foreach ($data_rand as $value_ip) {
      $watch_ip = $this->Model->getData('add_video',array('status'=>'1','ID'=>$value_ip['ID']));
      if(!empty($watch_ip)){
        $watch1_ru = $this->Model->getData('watched_user',array('post_id'=>$value_ip['ID']));
        $login_gagan_ip = $this->Model->getData('custumer_login',array('id'=>$watch_ip[0]['user_id'],'status'=>'1'));
        if($watch_ip[0]['user_id']){
          if(!$login_gagan_ip){
             $channal_name_ip=$watch_ip[0]['user_id'];
         }else{
          if($login_gagan_ip[0]['channel_name'])
          {
            $channal_name_ip=$login_gagan_ip[0]['channel_name']; 
        }else
        {
            $channal_name_ip=$login_gagan_ip[0]['user_name']." ".$login_gagan_ip[0]['last_name'];   
        }

    }

}else{
    $channal_name_ip="oxiinc_group";
}
?>
<a>

 <div class="col-xl-3 col-sm-6 mb-3">

    <div class="video-card">

       <div class="video-card-image">

          <a class="play-icon" href="<?php echo base_url("watch/$channal_name_ip/".$watch_ip[0]['ID']."?".md5(rand())); ?>"><i class="fas fa-play-circle"></i></a>

          <a href="<?php echo base_url("watch/$channal_name_ip/".$watch_ip[0]['ID']."?".md5(rand())); ?>"><img class="img-fluid img-responsive" src="<?php echo base_url().'uploads/product/'.$watch_ip[0]['picture'];?>" style="width:100%;height:128px; object-fit: cover;object-position: center;" alt=""></a>



      </div>

      <div class="video-card-body" style="

      background-color: white;

      ">

      <div class="video-title">

       <a href="<?php echo base_url("watch/$channal_name_ip/".$watch_ip[0]['ID']."?".md5(rand())); ?>" style="color:black;display: block;

       width:200px;overflow: hidden;white-space: nowrap;

       text-overflow: ellipsis;"><?php echo $watch_ip[0]['Video_Name'];?></a>

   </div>

   <div class="video-page text-success">

       <?php 
       if($watch_ip[0]['user_id']){
          if(!$login_gagan_ip){

      // $result_i_m=mysqli_query($conn_11,"select * from customers where emp_code = '".$watch_ip[0]['user_id']."'");
            $member_i_m['full_name']=$watch_ip[0]['f_name'];
            ?>
            <a href="<?php echo base_url("Home/channel/".$watch_ip[0]['user_id']) ?>" style='color:#23D794'><?php echo $member_i_m['full_name']; ?></a>
            <?php

        }else{
            if($login_gagan_ip[0]['channel_name']){
              ?>
              <a href="<?php echo base_url("Home/channel/".$watch_ip[0]['user_id']) ?>" style='color:#23D794'><?php echo $login_gagan_ip[0]['channel_name']; ?></a>
              <?php


          }else{
              ?>
              <a href="<?php echo base_url("Home/channel/".$watch_ip[0]['user_id']) ?>" style='color:#23D794'><?php echo $login_gagan_ip[0]['user_name']." ".$login_gagan_ip[0]['last_name']; ?></a>
              <?php


          }
      }}else{
        echo 'Oxiinc Channel';
    }


    ?><a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>

</div>

<div class="video-view">

   <?php echo $watch1_ru[0]['view']; ?> views &nbsp;<i class="fas fa-calendar-alt"></i> <?php 

   $FromDate = new DateTime(date("Y-m-d H:i:s"));

   $ToDate   = new DateTime($watch_ip[0]['datatime']);

   $Interval = $FromDate->diff($ToDate);



   $Difference["Hours"] = $Interval->h;



   $Difference["Weeks"] = floor($Interval->d/7);

   $Difference["Days"] = $Interval->d % 7;

   $Difference["Months"] = $Interval->m;

   $Difference["minute"] = $Interval->i;

   $Difference["second"] = $Interval->s;

   $Difference["Year"] = $Interval->y;







   if($Difference["Year"]){

     echo $Difference["Year"]." "."Year";

 }else

 if($Difference["Months"]){

  echo $Difference["Months"]." "."Months";

}else

if($Difference["Weeks"]){

   echo $Difference["Weeks"]." "."Weeks";

}else

if($Difference["Days"]){

   echo $Difference["Days"]." "."Days";

}else

if($Difference["Hours"]){

   echo $Difference["Hours"]." "."Hours";

}else

if($Difference["minute"]){

    echo $Difference["minute"]." "."Minute";

}else

if($Difference["second"]){

 echo $Difference["second"]." "."Second";

} 

echo " "."ago";





?>

</div>

</div>

</div>

</div>
<?php }}  ?>

<?php

}


public function recommended($value='')
{

  if ($this->session->userdata('logged_in')) {

     $login = $this->Model->getData('custumer_login',array('id'=>$this->session->userdata('id'),'status'=>'1'));
      	// echo '<pre>'; print_r($login); exit;

     $strSql = "SELECT post_id FROM views WHERE user_id='".$login[0]['user_name']."' GROUP BY post_id limit 28 ";
     $data['iprecommatition'] =$this->Model->getSqlData($strSql);
			  // echo '<pre>'; print_r($data['iprecommatition']); exit;
 }else{

     $strSql = "SELECT post_id FROM views WHERE ip='".$this->input->ip_address()."' GROUP BY post_id limit 28";
     $data['iprecommatition'] =$this->Model->getSqlData($strSql);
// echo '<pre>'; print_r($master); exit;
 }
 $this->load->view('recommended',$data);
}
public function Recently_uploaded($value='')
{
   $strSql = "SELECT DISTINCT ID FROM add_video WHERE status='1' limit 20";
   $data['Recently_uploaded'] =$this->Model->getSqlData($strSql);

   $this->load->view('Recently_uploaded',$data);
}
public function Recently_uploaded_loadmore($value='')
{

   $strSql = "SELECT DISTINCT ID FROM add_video WHERE status='1' limit 0,".$_POST['id'];
   $Recently_uploaded =$this->Model->getSqlData($strSql);
// echo '<pre>'; print_r($Recently_uploaded); exit;
			 // $this->load->view('Recently_uploaded',$data);
   ?>


   <?php if(isset($Recently_uploaded) && !empty($Recently_uploaded)) foreach ($Recently_uploaded as $value) { 
                        // echo '<pre>'; print_r($value); exit;

     $row1 = $this->Model->getData('add_video',array('status'=>1,'ID'=>$value['ID']));

     $category_name_info_khan = $this->Model->getData('category',array('status'=>1,'category_id'=>$row1[0]['category_id']));


     ?>

     <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 prs_upcom_slide_first">
        <div class="prs_upcom_movie_box_wrapper prs_mcc_movie_box_wrapper">
           <div class="prs_upcom_movie_img_box">
              <img src="<?php echo base_url().'uploads/product/'.$row1[0]['picture'];?>" alt="<?php echo "#"."Recommended  ".$row1[0]['Video_Title']; ?>" style="width: 100%;height: 177px">
              <div class="prs_upcom_movie_img_overlay"></div>
              <div class="prs_upcom_movie_img_btn_wrapper">
                 <ul>
                    <li><a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['ID']); ?>">View Trailer</a>
                    </li>
                    <li><a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['ID']); ?>">View Details</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="prs_upcom_movie_content_box">
            <div class="prs_upcom_movie_content_box_inner">
               <h2><a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['ID']); ?>" style="font-size: 15px;font-weight: 800;color:black;font-weight: 800;display: block;
               width: 175px;
               overflow: hidden;
               white-space: nowrap;
               text-overflow: ellipsis;"><?php echo "#"."Recommended  ".$row1[0]['Video_Title']; ?></a></h2>
               <!-- <p>Drama , Acation</p> -->
															<!-- 	<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i> -->
														</div>
														<!--<div class="prs_upcom_movie_content_box_inner_icon">-->
                                                          <!--	<ul>-->
                                                            <!--		<li><a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['ID']); ?>">-->
                                                               <!-- <i class="flaticon-cart-of-ecommerce"></i> -->
                                                               <!--		</a>-->
                                                               <!--		</li>-->
                                                               <!--	</ul>-->
                                                               <!--</div>-->
                                                           </div>
                                                       </div>
                                                   </div>

                                               <?php } ?>




                                               <?php
                                           }

                                           public function entube_recommended_you($value='')
                                           {
                                            $strSql = "SELECT DISTINCT ID FROM add_video Order by RAND()  LIMIT 20 ";
                                            $data['rand'] =$this->Model->getSqlData($strSql);
                                            $this->load->view('entube_recommended_you',$data);
                                        }

                                        public function Login_page($value='')
                                        {
                                            $this->load->view('login12');
                                        }
                                        public function watch_later_normal()
                                        {
                                            $this->Model->insertData('watch_later',$_POST);
                                        }
                                        public function E_panelist_page($value='')
                                        {
                                            $this->load->view('E_panelist_page_login12');
                                        }
                                        //MODIFY BY MOHD ALAM 07/05/2020
                                        public function Sign_Up_page($value='') {
                                            $strSql = "SELECT * FROM countries";
                                            $data['countries'] =$this->Model->getSqlData($strSql);
                                            $this->load->view('Sign_Up_page',$data);

                                            //$data['main_containt']='new_user/sign_up_page';
                                            //$this->load->view('new_user/containt', $data);
                                        }
                                        public function register_process($value='') {
                                            $jsonObj = $_POST['jsonObj']; 
                                            $array_data = json_decode($jsonObj,true);
                                            $array_entity = $array_data['login'];

                                            $username = $array_entity['username'];
                                            $email = $array_entity['email'];
                                            $phone = $array_entity['phone'];
                                            $password = $array_entity['password'];
                                            $passwordconfirm = $array_entity['passwordconfirm'];
                                            $userSubmit = $array_entity['userSubmit'];
                                            $email_id = $username;
                                            if (!$username) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> please enter Your User Name';	
                                               echo json_encode($data);
                                               exit;
                                           }
                                           if (!$email) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> please enter Your Email Address';	
                                               echo json_encode($data);
                                               exit;
                                           }
                                           if (!$phone) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> please enter Your phone No';	
                                               echo json_encode($data);
                                               exit;
                                           }
                                           if (!$password) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> please enter Your password';	
                                               echo json_encode($data);
                                               exit;
                                           }
                                           if (!$passwordconfirm) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> please enter Confirm Password';	
                                               echo json_encode($data);
                                               exit;
                                           }
                                           if ($password!=$passwordconfirm) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> Your Password And Confirm Password Is Not Same';	
                                               echo json_encode($data);
                                               exit;
                                           }

                                           $email_info=$this->Model->getData('custumer_login',array('email_id'=>$email));

                                           if ($email_info) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> This Email Address already registered with as';	
                                               echo json_encode($data);
                                               exit;
                                           }

                                           $phone_info=$this->Model->getData('custumer_login',array('contact_number'=>$phone));

                                           if ($phone_info) {
                                               $data['status'] = '0';
                                               $data['msg'] = '<strong>Sorry!</strong> This Phone Number already registered with as';	
                                               echo json_encode($data);
                                               exit;
                                           }

                                           if (isset($email_info) && empty($email_info)) {
                                               if (isset($phone_info) && empty($phone_info)) {
                                                  $array_data=array(
                                                    'user_name'=>$username,
                                                    'email_id'=>$email,
                                                    'password'=>md5($password),
                                                    'contact_number'=>$phone,
                                                    'countries'=> $array_entity['countries'],
                                                    'states'=> $array_entity['states'],
                                                    'cities'=> $array_entity['cities'],
                                                    'isd'=> $array_entity['isd'],
                                                    'resigtation_month'=> date('m'),
                                                    'resigtation_year'=> date('Y'),
                                                    'resigtation_day'=> date('d'),
                                                    'resigtation_year_month'=> date('Y-m'),
                                                    'resigtation_year_month_data' =>date('Y-m-d'),
                                                    'resigtation_year_month_data_time'=> date('Y-m-d H:i:s'),
                                                );
                                                  $user_inserted_id=$this->Model->insertData('custumer_login',array_map('strtoupper', $array_data));

                                                  $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$phone));

                // INSERT DATA IN OTP TABLE AND SEND SMS
                                                  $otp_code = mt_rand(10000,999999);
                                                  $array_otp_data=array(
                                                    'mobile'=>$mobile_info[0]['contact_number'],
                                                    'email'=>$mobile_info[0]['email_id'],
                                                    'otp'=>$otp_code,
                                                    'created'=>date("Y-m-d H:i:s"),
                                                    'modified'=>date("Y-m-d H:i:s"),
                                                );
                                                  $otp_inserted = $this->Model->insertData('otp',array_map('strtoupper', $array_otp_data));

                // SEND SMS CODE BY MOHD ALAM 14/05/2020
                                                  $user = "OXIINCHEALTH";
                                                  $password = "OXIINC@185";
                                                  $senderId = "ENTUBE";
                                                  $channel = "Trans";
                                                  $dcs = "0";
                                                  $flashsms = "0";
                                                  $route = "6";
                                                  $mobile = $mobile_info[0]['contact_number'];

                                                  $text_message = $otp_code." is your EnTube Registration verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
                // echo '<pre>'; print_r($text_message);
                                                  $sms = urlencode($text_message);

                // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

                                                  $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=ENTUBE&accusage=1';

                                                  try {
                                                    $ch = curl_init();
                                                    curl_setopt($ch, CURLOPT_HEADER, 0);
                                                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                                    curl_setopt($ch, CURLOPT_URL, $smsurl);
                                                    $data = curl_exec($ch);
                                                    curl_close($ch);
                                                    $response = $data;
                                                }  
                                                catch (Exception $e) {  
                                                    $response = $e->getMessage();  
                                                }
                // echo '<pre>'; print_r($response);

                // SEND MAIL CODE COMMENT BY MOHD ALAM 14/05/2020
                /*$user_name = $mobile_info[0]['user_name'];
                $user_names = $mobile_info[0]['user_name'];
                $to_email_address =$mobile_info[0]['email_id'];
                $subject = 'Thankyou For Register With as, Oxiinc Group';
                $emailer = 'emailer/OTP.html';
                $mail_content = file_get_contents($emailer);

                $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);
                $mail_content = str_replace('@_users_names_@', $user_names, $mail_content);
                $mail_content = str_replace('@_email_id_@', $mobile_info[0]['email_id'], $mail_content);
                $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                $mail_content = str_replace('@_otp_@', $otp_code, $mail_content);

                $headers = "From:no-reply@oxiinc.in\r\n" .
                'Reply-To: myorder@oxiinc.in' . "\r\n" .
                "MIME-Version: 1.0\r\n".
                "Content-Type: text/html; charset=ISO-8859-1\r\n";
                'X-Mailer: PHP/';

                $this->load->library('email');
                $config = Array(
                        'protocol'  => 'mail',
                        'smtp_host' => 'mail.oxiinc.in',
                        'smtp_port' => 25,
                        'smtp_user' => 'noreply@oxiinc.com',
                        'smtp_pass' => '@@noreply@@',
                        'mailtype'  => 'html',
                        'charset'   => 'iso-8859-1'
                    ); 
                $this->email->initialize($config);

                $this->email->from('noreply@oxiinc.com', 'Thankyou For Register With as, Oxiinc Group');
                $this->email->to($to_email_address);
                $this->email->subject($subject); 
                $this->email->message($mail_content);

                if($this->email->send()){
                }
                else{
                }*/
                $data = [];
                if(!empty($user_inserted_id) && !empty($otp_inserted)){
                  $data['status'] = '1';
                  $data['phone'] = $phone;
                  $data['email'] = $email;
                  $data['msg'] = '<strong>Well done!</strong> Registration Is Complete .Plz Verify it through OTP sent on you email id and phone number.';
                  echo json_encode($data);
                  exit;
              }
              else{
                  $data['status'] = '0';
                  $data['msg'] = '<strong>Sorry!</strong> Registration failed.';    
                  echo json_encode($data);
                  exit;
              }
          }
      }
  }

  public function resend_otp($value=''){
    $jsonObj = $_POST['jsonObj']; 
    $array_data = json_decode($jsonObj,true);
    $array_entity = $array_data['login'];
    $phone = $array_entity['phone'];

    $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$phone));
        //echo '<pre>'; var_dump($mobile_info); exit();
    $data = [];

    if ($mobile_info) {
      $mobile = $mobile_info[0]['contact_number'];
      $email = $mobile_info[0]['email_id'];
      $count_info=$this->Model->getData('otp',array('mobile'=>$mobile,'email'=>$email));
            //echo "<pre>";print_r($count_info);die();
      $otp_count = $count_info[0]["otp_count"];
      if ($otp_count < 3) {
        $data = [];
        $otp_code = mt_rand(10000,999999);
        $user = "OXIINCHEALTH";
        $password = "OXIINC@185";
        $senderId = "ENTUBE";
        $channel = "Trans";
        $dcs = "0";
        $flashsms = "0";
        $route = "6";
        $mobile = $mobile_info[0]['contact_number'];

        $text_message = $otp_code." is your EnTube Registration verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
                // echo '<pre>'; print_r($text_message);
        $sms = urlencode($text_message);

                // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

        $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=ENTUBE&accusage=1';

        try {
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_HEADER, 0);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch, CURLOPT_URL, $smsurl);
          $data = curl_exec($ch);
          curl_close($ch);
          $response = $data;
      }  
      catch (Exception $e) {  
          $response = $e->getMessage();  
      }
                // echo '<pre>'; print_r($response);

                // SEND MAIL CODE COMMENT BY MOHD ALAM 14/05/2020
                /*$user_name = $mobile_info[0]['user_name'];
        		$user_names = $mobile_info[0]['user_name'];
        	    $to_email_address =$mobile_info[0]['email_id'];
                $subject = 'Thankyou For Register With as, Oxiinc Group';
                $emailer = 'emailer/OTP.html';
                $mail_content = file_get_contents($emailer);
                // echo '<pre>'; print_r($mail_content); exit;

                $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);
                $mail_content = str_replace('@_users_names_@', $user_names, $mail_content);
                $mail_content = str_replace('@_email_id_@', $mobile_info[0]['email_id'], $mail_content);
                $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                $mail_content = str_replace('@_otp_@', $otp_code, $mail_content);
                //echo '<pre>'; print_r($mail_content); exit;

                $headers = "From:no-reply@oxiinc.in\r\n" .
                'Reply-To: myorder@oxiinc.in' . "\r\n" .
                "MIME-Version: 1.0\r\n".
                "Content-Type: text/html; charset=ISO-8859-1\r\n";
                'X-Mailer: PHP/';

                $this->load->library('email');

                $config = Array(
                        'protocol'  => 'mail',
                        'smtp_host' => 'mail.oxiinc.in',
                        'smtp_port' => 25,
                        'smtp_user' => 'noreply@oxiinc.com',
                        'smtp_pass' => '@@noreply@@',
                        'mailtype'  => 'html',
                        'charset'   => 'iso-8859-1'
                    ); 

                $this->email->initialize($config);

                $this->email->from('noreply@oxiinc.com', 'Thankyou For Register With as, Oxiinc Group');
                $this->email->to($to_email_address);
                $this->email->subject($subject); 
                $this->email->message($mail_content);

                if($this->email->send()){
                }
                else{
                }*/

                if ($count_info) {
                  $array_data=array(
                    'otp'=>$otp_code,
                    'otp_count'=>++$otp_count,
                    'modified'=>date("Y-m-d H:i:s")
                );
                  $otp_update_insert = $this->Model->updateData('otp', $array_data, array('mobile'=>$mobile,'email'=>$email));
              }
              else{
                  $array_data=array(
                    'mobile'=>$mobile_info[0]['contact_number'],
                    'email'=>$mobile_info[0]['email_id'],
                    'otp'=>$otp_code,
                    'created'=>date("Y-m-d H:i:s"),
                    'modified'=>date("Y-m-d H:i:s")
                );
                  $otp_update_insert = $this->Model->insertData('otp',array_map('strtoupper', $array_data));
              }
              $data = [];
              if ($otp_update_insert) {
                  $data["status"] = "1";
                  $data['msg'] = '<strong>Well done!</strong> OTP Resent on your phone number.';
                  echo json_encode($data);
                  exit;
              }
              else{
                  $data["status"] = "0";
                  $data['msg'] = '<strong>Sorry!</strong> Resend OTP failed.';    
                  echo json_encode($data);
                  exit;
              }
          }
          else{
            $data["status"] = "0";
            $data['msg'] = '<strong>Sorry!</strong> Resend OTP send only three times.';    
            echo json_encode($data);
            exit;
        }
    }
    else{
      $data["status"] = "0";
      $data['msg'] = '<strong>Sorry!</strong> Resend OTP failed? Becouse Mobile number not valid.';    
      echo json_encode($data);
      exit;
  }

        //$this->load->view('Otp_verfication');
}

public function Ashfak_khan_otp_verfication($value=''){
    $jsonObj = $_POST['jsonObj']; 
    $array_data = json_decode($jsonObj,true); 
    $array_entity = $array_data['login'];

    $phone = $array_entity['phone'];
    $email = $array_entity['email'];
    $otp = $array_entity['otp'];

    $mobile_info=$this->Model->getData('otp',array('mobile'=>$phone,'email'=>$email,'otp'=>$otp));
        //echo "<pre>";var_dump($mobile_info);die();

    if ($mobile_info) {
      $var['status'] = '1';

      $this->Model->updateData('custumer_login',$var,array('contact_number'=>$phone,'email_id'=>$email));

      $login = $this->Model->getData('custumer_login',array('contact_number'=>$phone,'email_id'=>$email));
      $newdata = array(
        'id'=>$login[0]['id'],
        'user_id'=>$login[0]['email_id'],
        'user_name'=>$login[0]['user_name'],
        'user_role'=>$login[0]['contact_number'],
        'user_role'=>$login[0]['phone_number'],
        'user_role'=>$login[0]['shipping_address'],
        'user_role'=>$login[0]['billing_address'],
        'user_role'=>$login[0]['aadhar_number'],
        'user_role'=>$login[0]['pan_number'],
        'user_role'=>$login[0]['password'],
        'logged_in'=>TRUE
    );

      $this->session->set_userdata($newdata);
      $this->session->set_flashdata('msg','You have logged in successfully');
      $data['status'] = '1';
      $data['msg']= '<strong>Well done!</strong> Your Verfication Is done. Please wait while we are redirecting you on Home Page';
      echo json_encode($data);
      exit;
  }
  else {
      $data['status'] = '0';
      $data['msg'] = $array_entity['otp'];	
      echo json_encode($data);
      exit;
  }
}
public function autocomplete(){
		// echo '<pre>'; print_r($_POST);
    $product_keyword = $this->input->get_post('search_data');		
    if($product_keyword!=''){
       $sqlQuery = "Video_Title LIKE '%".$product_keyword."%'";
   }else{
       $sqlQuery = "Video_Title LIKE '%".$product_keyword."%'";
   }
   $Query = 'SELECT * FROM add_video WHERE '.$sqlQuery.' AND status="1" LIMIT 5';

   $searched_product_data = $this->Model->getSqlData($Query);
		// echo '<pre>'; print_r($searched_product_data);
   if (!empty($searched_product_data))
   {
    foreach ($searched_product_data as $row):
      echo "<li class='list-group-item' onclick='addgoingtext(\"".$row['Video_Name']."\")'><a href='#'>" . $row['Video_Name'] . "</a></li>";
  endforeach;
}
else
{
 echo "<li class='list-group-item'> <em> Not found ... </em> </li>";
}
}
function loadMoreData(){

       //  $conditions = array();

       //  // Get last post ID
       // $lastID = $this->input->post('id');

       //  // Get post rows num
       //  $conditions['where'] = array('ID <'=>$lastID);
       //  $conditions['returnType'] = 'count';
       //  $data['postNum'] = $this->post->getRows($conditions);

       //  // Get posts data from the database
       //  $conditions['returnType'] = '';
       //  $conditions['order_by'] = "ID DESC";
       //  $conditions['limit'] = $this->perPage;

       //  $data['add_video'] = $this->post->getRows($conditions);
       //   // print_r($data['add_video']);exit();
       //   $data['add_category'] = $this->Model->getData('category',array('category_id'=>'5'));
       //  // Pass the post data to view

       //  $data['postLimit'] = $this->perPage;

       //  // Pass data to view
    	// print_r($data['limt']=$_POST);
   $data['limt']=$_POST;
   $data['add_category'] = $this->Model->getData('category',array('category_id'=>'1'));
   $this->load->view('load-more-data', $data, false);
}
public function comment_section(){
    $data = $this->security->xss_clean($_POST);
    // echo "<pre>";print_r($data);exit();
    $this->Model->insertData('comment_section',$data);
    redirect($_POST['url']);
}
function watch_later(){ 
		// echo "<pre>";print_r()
    $this->Model->insertData('watch_later',$_POST);
}
function comment_update(){


 $order_data = array(


    'comment'=>$_POST['comment'],

                    // 'sub_option' => $sub_option[$i],


);
 $this->Model->updateData('comment_section',$order_data,array('id'=>$_POST['id']));
 redirect($_POST['url']);

}
public function Category_videos()
{
		// echo '<pre>'; print_r($this->uri->segment(3)); exit;
  $ID = $this->uri->segment(3);
  $data['category_name_'] = $this->uri->segment(2);
  $query = $this->db->query("select * from  add_video where category_id=$ID and status=1 order by id desc limit 0,16");

  $data['Category_videos']= $query->result_array();


  $query_type = $this->db->query("select * from  category where category_id=$ID");
  $category_type= $query_type->result_array();
  $data['category_type']= $category_type[0]['category_name'];




// 		$data['Category_videos'] = $this->Model->getDataOrderBy('add_video',array('status'=>'1','category_id'=>$ID),'ID','DESC');
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('Category_videos12',$data);

}
public function Category_videos_loadmore()
{
// 		echo '<pre>'; print_r($_POST); exit;
  $ID = $_POST['cat'];
  $data['category_name_'] = $this->uri->segment(2);
  $query = $this->db->query("select * from  add_video where category_id=$ID and status=1 order by id desc limit 0,".$_POST['id']);

  $Category_videos= $query->result_array();
// 		$data['Category_videos'] = $this->Model->getDataOrderBy('add_video',array('status'=>'1','category_id'=>$ID),'ID','DESC');
		// echo '<pre>'; print_r($data); exit;
// 		$this->load->view('Category_videos12',$data);
  ?>


  <?php if(isset($Category_videos) && !empty($Category_videos)) foreach ($Category_videos as $key) {
// echo '<pre>'; print_r($key); exit;
     $login_gagan = $this->Model->getData('custumer_login',array('id'=>$key['user_id'],'status'=>'1'));
     if($key['user_id']){
        if(!$login_gagan){
           $channal_name=$key['user_id'];
       }else{
        if($login_gagan[0]['channel_name'])
        {
          $channal_name=$login_gagan[0]['channel_name']; 
      }else
      {
          $channal_name=$login_gagan[0]['user_name']." ".$login_gagan[0]['last_name'];   
      }

  }

}else{
  $channal_name="oxiinc_group";
}
?>
<div class="col-xl-3 col-sm-6 mb-3">

  <div class="video-card" style="

  background-color: white;

  ">

  <div class="video-card-image" >

    <a class="play-icon" href="<?php echo base_url('watch/'.$channal_name."/").$key['ID']."?".md5(rand());?>"><i class="fas fa-play-circle"></i></a>

    <a href="<?php echo base_url('watch/'.$channal_name."/").$key['ID']."?".md5(rand());?>"><img class="img-fluid img-responsive" src="<?php echo base_url().'uploads/product/'.$key['picture'];?>" style="width:100%;height:128px; object-fit: cover;object-position: center;" alt=""></a>


</div>

<div class="video-card-body">

    <div class="video-title">

      <a href="<?php echo base_url('watch/'.$channal_name."/").$key['ID']."?".md5(rand());?>" data-toggle="tooltip" title="<?php echo $key['Video_Name'];?>"><p style="color:black;display: block;

      width:200px;overflow: hidden;white-space: nowrap;

      text-overflow: ellipsis;" ><?php echo $key['Video_Name'];?></p></a>

  </div>

  <div class="video-page text-success">

      <?php  
      if($key['user_id']){
        if(!$login_gagan){
//                                       $servername='49.50.117.106';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");  
//   $result_i_m=mysqli_query($conn,"select * from customers where emp_code = '".$key['user_id']."'");
           $member_i_m['full_name']=$key['f_name'];


           ?>
           <a href="<?php echo base_url("Home/channel/".$key['user_id']) ?>" style='color:#23D794'><?php echo $member_i_m['full_name']; ?></a>
           <?php

       }else{
        if($login_gagan[0]['channel_name']){
          ?>
          <a href="<?php echo base_url("Home/channel/".$key['user_id']) ?>" style='color:#23D794'><?php echo $login_gagan[0]['channel_name']; ?></a>
          <?php


      }else{
          ?>
          <a href="<?php echo base_url("Home/channel/".$key['user_id']) ?>" style='color:#23D794'><?php echo $login_gagan[0]['user_name']." ".$login_gagan[0]['last_name']; ?></a>
          <?php


      }
  }}else{
    echo 'Oxiinc Channel';
}


?><a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>

</div>

<div class="video-view"> <?php 
$watch_most = $this->Model->getData('watched_user',array('post_id'=>$key['ID']));
echo $watch_most[0]['view'];




?> views &nbsp;<i class="fas fa-calendar-alt"></i> <?php 

$FromDate = new DateTime(date("Y-m-d H:i:s"));

$ToDate   = new DateTime($key['datatime']);

$Interval = $FromDate->diff($ToDate);



$Difference["Hours"] = $Interval->h;



$Difference["Weeks"] = floor($Interval->d/7);

$Difference["Days"] = $Interval->d % 7;

$Difference["Months"] = $Interval->m;

$Difference["minute"] = $Interval->i;

$Difference["second"] = $Interval->s;

$Difference["Year"] = $Interval->y;







if($Difference["Year"]){

   echo $Difference["Year"]." "."Year";

}else

if($Difference["Months"]){

    echo $Difference["Months"]." "."Months";

}else

if($Difference["Weeks"]){

 echo $Difference["Weeks"]." "."Weeks";

}else

if($Difference["Days"]){

 echo $Difference["Days"]." "."Days";

}else

if($Difference["Hours"]){

 echo $Difference["Hours"]." "."Hours";

}else

if($Difference["minute"]){

  echo $Difference["minute"]." "."Minute";

}else

if($Difference["second"]){

   echo $Difference["second"]." "."Second";

} 

echo " "."ago";





?>

</div>

</div>

</div>

</div>


<?php  } ?>

















<?php	

}

public function Sub_Category_videos()
{
// 		echo '<pre>'; print_r($this->uri->segment(3)); exit;
  $ID = $this->uri->segment(3);
  $data['category_name_'] = $this->uri->segment(2);

  $data['Category_videos'] = $this->Model->getDataOrderBy('add_video',array('status'=>'1','sub_category_id'=>$ID),'ID','DESC');
// 		echo '<pre>'; print_r(	$data['Category_videos']); exit;
  $this->load->view('Sub_Category_videos',$data);

}
public function watch()
{
		// echo '<pre>'; print_r($this->uri->segment(3)); exit;

  $ID = filter_var($this->uri->segment(3), FILTER_SANITIZE_NUMBER_INT);
  $ip = $this->input->ip_address();
  $user_id=$this->session->userdata('username');
  if (!empty($user_id)) {
     	# code...
    $vistor['post_id'] = $ID;
    $vistor['ip'] = "1";
    $vistor['user_id'] = $this->session->userdata('username');
    $watched = $this->Model->getData('views',array('post_id'=>$ID,'user_id'=>$vistor['user_id']));
    if(!$watched){
      $this->Model->insertData('views',$vistor);
      $watched_user = $this->Model->getData('watched_user',array('post_id'=>$ID));
      if(!$watched_user){
        $this->Model->insertData('watched_user',array('post_id'=>$ID,'view'=>'1'));
    }else{
         	// $this->Model->updateData('watched_user',$vistor,array('id'=>$login_information_id));
        $strSqldwre123yyy="UPDATE watched_user SET view = view + 1 WHERE post_id ='".$ID."'";
        $this->db->query($strSqldwre123yyy);


    }
}
} elseif($this->session->userdata('logged_in')){


    $vistor['post_id'] = $this->uri->segment(3);
    $vistor['ip'] = "1";
    $vistor['user_id'] = $this->session->userdata('id');
    $watched = $this->Model->getData('views',array('post_id'=>$this->uri->segment(3),'user_id'=>$vistor['user_id']));
    if(!$watched){
      $this->Model->insertData('views',$vistor);
      $watched_user = $this->Model->getData('watched_user',array('post_id'=>$this->uri->segment(3)));
      if(!$watched_user){
        $this->Model->insertData('watched_user',array('post_id'=>$this->uri->segment(3),'view'=>'1'));
    }else{
         	// $this->Model->updateData('watched_user',$vistor,array('id'=>$login_information_id));
        $strSqldwre123="UPDATE watched_user SET view = view + 1 WHERE post_id ='".$this->uri->segment(3)."'";
         	// $this->Model->getSqlData($strSql);
        $this->db->query($strSqldwre123);

    }
}
}else{

    $vistor['post_id'] = $this->uri->segment(3);
    $vistor['ip'] = $ip;

    $watched = $this->Model->getData('views',array('post_id'=>$this->uri->segment(3),'ip'=>$ip));
    if(!$watched){
      $this->Model->insertData('views',$vistor);
      $watched_user = $this->Model->getData('watched_user',array('post_id'=>$this->uri->segment(3)));
      if(!$watched_user){
        $this->Model->insertData('watched_user',array('post_id'=>$this->uri->segment(3),'view'=>'1'));
    }else{
         	// $this->Model->updateData('watched_user',$vistor,array('id'=>$login_information_id));
        $strSqldwre="UPDATE watched_user SET view = view + 1 WHERE post_id ='".$this->uri->segment(3)."'";
         	// $this->Model->getSqlData($strSqldwre);
        $this->db->query($strSqldwre);

    }
}


}
$query = $this->db->query('SELECT count( DISTINCT(ip) ) FROM views WHERE post_id='.$ID);

$row= $query->result_array();
$query1 = $this->db->query('SELECT count(DISTINCT(user_id)) FROM views WHERE post_id='.$ID);

$row1= $query1->result_array();
$one=$row[0]['count( DISTINCT(ip) )'];
$two=$row1[0]['count(DISTINCT(user_id))'];
$data['views'] = $one+$two;
$watch = $this->Model->getData('add_video',array('status'=>'1','ID'=>$ID));
$data['watch'] = $watch;
$category_id = $watch[0]['category_id'];
$data['load_more_cat']=$category_id;
// 		$data['Category_videos'] = $this->Model->getDataOrderBy('add_video',array('status'=>'1','category_id'=>$category_id),'ID','DESC');
$add_video_khan = "SELECT * FROM add_video WHERE status='1' AND category_id='".$category_id."' Order by RAND() limit 10";
$data['Category_videos'] =$this->Model->getSqlData($add_video_khan);
		// echo '<pre>'; print_r($data['Category_videos']); exit;
$this->load->view('watch',$data);
}
function load_more_cat()
{

//      $servername_11='49.50.117.106';
// $username_11='membero_oxiinc';
// $password_11='YD4{B@Cp;[wS';
// $dbname_11 = "membero_oxiinc";
// $conn_11=mysqli_connect($servername_11,$username_11,$password_11,"$dbname_11");
  ?>

  <?php
  $watch_most=0;
  $add_video_khan = "SELECT * FROM add_video WHERE status='1' AND category_id='".$_POST['category_id']."' Order by RAND() limit ".$_POST['limit'];
  $Category_videos =$this->Model->getSqlData($add_video_khan);
  if(isset($Category_videos) && !empty($Category_videos)) foreach ($Category_videos as $key) {
     if($key['user_id']){
       $login_gagan = $this->Model->getData('custumer_login',array('id'=>$key['user_id'],'status'=>'1'));
       $watch_most = $this->Model->getData('watched_user',array('post_id'=>$key['ID']));
       if(!$login_gagan){
          $channel_load= $key['user_id'];
                                       // $result_i_m=mysqli_query($conn_11,"select * from customers where emp_code = '".$key['user_id']."'");
          $member_i_m['full_name']=$key['f_name'];
      }else{
          if($login_gagan[0]['channel_name']){
            $channel_load= $login_gagan[0]['channel_name'];
        }else{
            $channel_load= $login_gagan[0]['user_name']." ".$login_gagan[0]['last_name'];
        }
    }}else{
      $channel_load= 'Oxiinc Channel';
  }
  ?>
  <div class="video-card video-card-list gaganbansode">
      <div class="video-card-image">
         <a class="play-icon" href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>"><img src="https://www.entube.in/black/img/logoo/iconn.png" alt="" style="width: 20px; height: 22px !important; opacity: 1"></a>
         <a href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>"><img class="img-fluid img-responsive" src="<?php echo base_url().'uploads/product/'.$key['picture'];?>" alt=""></a>
         <!--<div class="time">3:50</div>-->
     </div>
     <div class="video-card-body">
         <div class="btn-group float-right right-action">
            <a href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>" class="right-action-link text-gray" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <img src="<?php echo base_url();?>image/drop/dot.png">
           </a>
           <div class="dropdown-menu dropdown-menu-right">
               <a class="dropdown-item" href="#"><i class="fas fa-fw fa-star"></i> &nbsp; Top Rated</a>
               <a class="dropdown-item" href="#"><i class="fas fa-fw fa-signal"></i> &nbsp; Viewed</a>
               <a class="dropdown-item" href="#"><i class="fas fa-fw fa-times-circle"></i> &nbsp; Close</a>
           </div>
       </div>
       <div class="video-title">
          <a href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>"><?php echo $key['Video_Name'];  ?></a>
      </div>
      <?php 

      if($key['user_id']){
          if(!$login_gagan){?>
             <div class="video-page text-success">
                <a href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>" style="color: #7EBC49"> <?php echo $member_i_m['full_name']; ?> </a> <a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fa fa-check" aria-hidden="true" style="color: green"></i></a>
            </div>
        <?php }else{ ?>
           <div class="video-page text-success">
              <a href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>" style="color: #7EBC49"> <?php echo $channel_load?> </a> <a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fa fa-check" aria-hidden="true" style="color: green"></i></a>
          </div>
      <?php } }else{?>
        <div class="video-page text-success">
          <a href="<?php echo base_url('watch/'.$channel_load."/").$key['ID']."?".md5(rand());?>" style="color: #7EBC49"> <?php echo $channel_load?> </a> <a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fa fa-check" aria-hidden="true" style="color: green"></i></a>
      </div>
  <?php } ?>
  <div class="video-view" style="color:#3D4490">
     <?php echo $watch_most[0]['view']; ?>views &nbsp;<i class="fas fa-calendar-alt"></i> 


     <?php
     $FromDate = new DateTime(date("Y-m-d H:i:s"));
     $ToDate   = new DateTime($key['datatime']);
     $Interval = $FromDate->diff($ToDate);

     $Difference["Hours"] = $Interval->h;

     $Difference["Weeks"] = floor($Interval->d/7);
     $Difference["Days"] = $Interval->d % 7;
     $Difference["Months"] = $Interval->m;
     $Difference["minute"] = $Interval->i;
     $Difference["second"] = $Interval->s;
     $Difference["Year"] = $Interval->y;



     if($Difference["Year"]){
       echo $Difference["Year"]." "."Year";
   }else
   if($Difference["Months"]){
    echo $Difference["Months"]." "."Months";
}else
if($Difference["Weeks"]){
 echo $Difference["Weeks"]." "."Weeks";
}else
if($Difference["Days"]){
 echo $Difference["Days"]." "."Days";
}else
if($Difference["Hours"]){
 echo $Difference["Hours"]." "."Hours";
}else
if($Difference["minute"]){
  echo $Difference["minute"]." "."Minute";
}else
if($Difference["second"]){
   echo $Difference["second"]." "."Second";
} 
echo " "."ago";

?>

</div>
</div>
</div>

<?php  } ?>
<?php


}
function comment_load()
{
  ?>

  <?php 
  $query = $this->db->query("select * from comment_section where v_id=
    ".$_POST['v_id']." order by id  DESC limit ".$_POST['id']);

  $row= $query->result_array(); 
  if(!empty($row)) foreach ($row as $gagan){
    ?>

    <div class="col-sm-1" style="margin-bottom: 20px;">
      <div class="single-video-author ">
        <!--<?php echo $gagan['id'] ?>-->
        <img class="img-fluid img-responsive" src="<?php echo $gagan['photo'] ?>" alt="">
    </div>
</div>

<div class="col-sm-11" style="margin-bottom: 20px;">

  <div class="single-video-author ">

    <p><a href="#" style="color:gray"><strong><?php echo $gagan['user_id'] ?></strong></a></p>


    <p style="font-size: 14px;color: gray"><?php echo $gagan['comment']; ?></p>
    <!-- <br> -->

    <div class="comment-title">


      <div class="row">
        <div class="col-sm-12">

          <div class="comment-title">
            <?php 

            $like1= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1'));
            $dislike= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1'));
            ?>
            <?php if ($this->session->userdata('logged_in')) {?>

              <?php 
              $like1_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
              ?>
              <?php 
              if ($like1_khan) {
                ?>

                <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-up" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button> 
            <?php }else{?>
                <button  style="background-color: transparent;border: none;" onclick="like_comment(<?php echo  $gagan['id']; ?>);"><i class="fa fa-thumbs-up" style="color: #909090!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button>
            <?php }?>
            <?php 
            $dislike_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
// echo '<pre>'; print_r($dislike); 
            ?>
            <?php 
            if ($dislike_khan) {
                ?>


                <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>   

            <?php }else{?>
                <button  onclick="dilike_copmment(<?php echo  $gagan['id']; ?>);" style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: #909090!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>
            <?php }?>
            <?php 

            $comment_reply_khan= $this->Model->CountWhereRecord('comment_reply',array('comment_id'=>$gagan['id'],'video_id'=>$this->uri->segment(3)));

            ?>


            <!--  <button class="reply_btn" style="background-color: transparent;border: none;"><i class="fa fa-reply" aria-hidden="true"></i> Reply</button> -->

        <?php }else if($this->session->userdata('entube_customer_logged_in')) {?>
          <?php 
          $like1_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('employee_id')));
          ?>
          <?php 
          if ($like1_khan) {
            ?>

            <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-up" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button> 
        <?php }else{?>
            <button  style="background-color: transparent;border: none;" onclick="like_comment1(<?php echo  $gagan['id']; ?>);"><i class="fa fa-thumbs-up" style="color: #909090!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button>
        <?php }?>
        <?php 
        $dislike_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('employee_id')));
// echo '<pre>'; print_r($dislike); 
        ?>
        <?php 
        if ($dislike_khan) {
            ?>


            <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>   

        <?php }else{?>
            <button  onclick="dilike_copmment1(<?php echo  $gagan['id']; ?>);" style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: #909090!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>
        <?php }?>
        <?php 

        $comment_reply_khan= $this->Model->CountWhereRecord('comment_reply',array('comment_id'=>$gagan['id'],'video_id'=>$this->uri->segment(3)));

        ?>


        <!-- <button class="reply_btn" style="background-color: transparent;border: none;"><i class="fa fa-reply" aria-hidden="true"></i> Reply</button> -->

    <?php }else {?>
      <a href="<?php echo base_url('Home/E_panelist_page'); ?>">
        <button  class="ashfakkhan" style="background-color: transparent;border: none;" ><i class="fa fa-thumbs-up" style="color: #909090!important"></i> &nbsp;&nbsp;<?php echo  $like1; ?> </button></a>
        <a href="<?php echo base_url('Home/E_panelist_page'); ?>">
          <button  class="ashfakkhan"  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: #909090!important"></i> &nbsp;&nbsp;<?php echo  $dislike; ?> </button></a>
          <!-- <button class="ashfakkhan" style="background-color: transparent;border: none;"><i class="fa fa-reply" aria-hidden="true"></i> Reply</button> -->
      <?php } ?>


  </div>
  <div class="reply-form">
    <form method="POST" action="/org/post/{comment_id}" >

      <div class="form-group">
        <div class="group">
          <input type="text" required>
          <span class="highlight"></span>
          <span class="bar"></span>

      </div>

  </div>
  <div class="button-group" style="float: right;    margin-top: -30px;">
    <button type="submit" value="Post Comment">Post comment</button>
    <button type="button" class="cancel_btn" value="Cancel">Cancel</button>
</div>

</form>

</div>
<style>
    .reply-form {
      display: none
  }
</style>

<script>
    $(function() {
      $(".reply_btn").click(function() {
        $(this).parent().parent().children('.reply-form').show();
    });
      $(".cancel_btn").click(function() {
        $(this).parent().parent().hide();
    });
  });
</script>

</div>

</div>

</div>

</div>
</div>
<?php  } ?>

<?php
}

function Epanelist_login(){
  $user_id = $this->input->post('user_id');
  $username = $this->input->post('username');
  $name = $this->input->post('name');
  $account_type = $this->input->post('account_type');
  $email_verified = $this->input->post('email_verified');
  $employee_id = $this->input->post('employee_id');
  $employee_code = $this->input->post('employee_code');
  $profileImage = $this->input->post('profileImage');

  $epanelist_login = array(
    'user_id'=>$user_id,
    'username'=>$username,
    'name'=>$name,
    'account_type'=>$account_type,
    'email_verified'=>$email_verified,
    'employee_id'=>$employee_id,
    'employee_code'=>$employee_code,
    'profileImage'=>$profileImage,
    'entube_customer_logged_in'=>TRUE
);

  $this->session->set_userdata($epanelist_login);
  $login_information_id =  $this->session->userdata('employee_id');
			// echo '<pre>'; print_r($login_information_id); exit;
  $this->session->set_flashdata('msg','login Successfully.');
  redirect('Home');
}

public function cart_shopping()
{	

  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

  $this->load->view('add_to_cart1',$data);
		// echo "<pre>";print_r($data);exit;
}

public function liked_video(){
   if($this->session->userdata('entube_customer_logged_in')){
     $query = $this->db->query('SELECT * FROM like_dislike WHERE like1=1  AND  user_id="'.$this->session->userdata('username').'" ORDER BY id DESC');
 }elseif($this->session->userdata('logged_in')){
  $query = $this->db->query('SELECT * FROM like_dislike WHERE like1=1  AND  user_id="'.$this->session->userdata('id').'" ORDER BY id DESC'); 
}
$row['like']= $query->result_array();

$this->load->view('liked_video',$row);
}
public function watch_later_video(){
    if($this->session->userdata('entube_customer_logged_in')){
       $query = $this->db->query('SELECT DISTINCT v_id FROM watch_later WHERE status=1  AND  user_id="'.$this->session->userdata('username').'" ');
   }elseif($this->session->userdata('logged_in')){
    $query = $this->db->query('SELECT DISTINCT v_id FROM watch_later WHERE status=1  AND  user_id="'.$this->session->userdata('id').'" ');
}
$row['like']= $query->result_array();

$this->load->view('watch_later_video_khan',$row);
}
public function watch_history(){
   if($this->session->userdata('entube_customer_logged_in')){
     $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('username').'" LIMIT 0,16');
 }elseif($this->session->userdata('logged_in')){
     $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('id').'" LIMIT 0,16'); 
 }else{
  $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  ip="'.$this->input->ip_address().'" LIMIT 0,16'); 
}
$row['like']= $query->result_array();

$this->load->view('watch_history',$row);
}
public function watch_history_loadmore(){
   if($this->session->userdata('entube_customer_logged_in')){
     $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('username').'" LIMIT 0,'.$_POST['id']);
 }elseif($this->session->userdata('logged_in')){
     $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('id').'" LIMIT 0,'.$_POST['id']); 
 }else{
  $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  ip="'.$this->input->ip_address().'" LIMIT 0,'.$_POST['id']); 
}
$like= $query->result_array();
		  // echo "<pre>";print_r($row['like']);
		// $this->load->view('watch_history12',$row);
?>

<?php
// echo '<pre>'; print_r($like); exit;
if(isset($like) && !empty($like)) foreach ($like as $value) { 
                        // echo '<pre>'; print_r($value); exit;

	$row1 = $this->Model->getData('add_video',array('ID'=>$value['post_id']));
// echo '<pre>'; print_r($row1); 
  if($row1){
    $category_name_info_khan = $this->Model->getData('category',array('status'=>1,'category_id'=>$row1[0]['category_id']));

    ?>

    <div class="video-card video-card-list" id="div1">
      <div class="video-card-image">

         <a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['post_id']); ?>"><img class="img-fluid img-responsive" src="<?php echo base_url().'uploads/product/'.$row1[0]['picture'];?>" alt="<?php echo "#"."History  ".$row1[0]['Video_Title']; ?>"></a>
         <!--<div class="time">3:50</div>-->
     </div>
     <div class="video-card-body">
         <div class="btn-group float-right right-action">
            <a href="#" class="right-action-link text-gray" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <button style="background-color: transparent;
               border: none;" id="avinash">  <i class="fa fa-times" ></i></button>
           </a>


           <script>
            $(document).ready(function(){
              $("#avinash").click(function(){
                $("#div1").remove();

                                                     // alert("avinash");
                                                 });
          });
      </script>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


  </div>
  <div class="video-title">
      <a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['post_id']); ?>" style="    font-size: 15px;color:black !important; " ><?php echo $row1[0]['Video_Title']; ?></a>
  </div>
  <div class="video-page text-success">
      <?php echo $category_name_info_khan[0]['seo_category_name']; ?>   <a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>
  </div>
  <div class="video-view" style="    font-size: 15px;color:black">
   <?php 
   $watch_most = $this->Model->getData('watched_user',array('post_id'=>$row1[0]['ID']));
   echo $watch_most[0]['view'];




   ?> views &nbsp;<i class="fas fa-calendar-alt"></i> 
   <?php 
   $FromDate = new DateTime(date("Y-m-d H:i:s"));
   $ToDate   = new DateTime($row1[0]['datatime']);
   $Interval = $FromDate->diff($ToDate);

   $Difference["Hours"] = $Interval->h;

   $Difference["Weeks"] = floor($Interval->d/7);
   $Difference["Days"] = $Interval->d % 7;
   $Difference["Months"] = $Interval->m;
   $Difference["minute"] = $Interval->i;
   $Difference["second"] = $Interval->s;
   $Difference["Year"] = $Interval->y;



   if($Difference["Year"]){
     echo $Difference["Year"]." "."Year";
 }else
 if($Difference["Months"]){
  echo $Difference["Months"]." "."Months";
}else
if($Difference["Weeks"]){
   echo $Difference["Weeks"]." "."Weeks";
}else
if($Difference["Days"]){
   echo $Difference["Days"]." "."Days";
}else
if($Difference["Hours"]){
   echo $Difference["Hours"]." "."Hours";
}else
if($Difference["minute"]){
    echo $Difference["minute"]." "."Minute";
}else
if($Difference["second"]){
 echo $Difference["second"]." "."Second";
} 
echo " "."ago";


?>
</div>
</div>
</div>

<?php } }?>   



<?php
}
public function add()
{
  $this->load->model('Cart_model');

  $insert_room = array(
     'id' => $this->input->post('ID'),
     'name' => $this->input->post('Product_Name'),
     'price' => $this->input->post('Prices'),
     'qty' => 1
 );		

  $this->cart->insert($insert_room);

  redirect('home/cart_shopping');
}	

public function like_dislike()
{	
  if($this->session->userdata('entube_customer_logged_in')){
     $query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$_POST['v_id'].'  AND  user_id="'.$this->session->userdata('username').'"');
 } elseif($this->session->userdata('logged_in')){

     $query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$_POST['v_id'].'  AND  user_id="'.$this->session->userdata('id').'"');
 }
 $row= $query->result_array();
 $num=$query->num_rows();


 if ($num) {
		  	# code...
  $this->Model->updateData('like_dislike',$_POST,array('id'=>$row[0]['id']));
}else{

  $this->Model->insertData('like_dislike',$_POST);
		// echo "<pre>";print_r($_POST);exit;
}
}





public function get_limit(){
  $limit = 5;
  return $limit;
}
public function trending(){

  $query = $this->db->query('SELECT  post_id FROM views WHERE post_id!="login.html" AND post_id!="my-profile.php" AND post_id!="index.html" AND post_id!="videos-page.php" AND post_id!="contact.html" AND dateandtime > "'.date('Y-m-d H:i:s', strtotime(' -7 day')).'" AND dateandtime<= "'.date('Y-m-d H:i:s').'" GROUP BY post_id ');

  $row= $query->result_array();


  foreach ($row as $value) {

    $query11 = $this->db->query("SELECT count( DISTINCT(ip) ) FROM views WHERE post_id='".$value['post_id']."' AND dateandtime > '".date('Y-m-d H:i:s', strtotime(' -7 day'))."' AND dateandtime<= '".date('Y-m-d H:i:s')."'  ");

    $row11= $query11->result_array();
    $query1 = $this->db->query("SELECT count(DISTINCT(user_id)) FROM views WHERE post_id='".$value['post_id']."' AND dateandtime > '".date('Y-m-d H:i:s', strtotime(' -7 day'))."' AND dateandtime<= '".date('Y-m-d H:i:s')."'  ");

    $row1= $query1->result_array();
    $one=$row11[0]['count( DISTINCT(ip) )'];
    $two=$row1[0]['count(DISTINCT(user_id))'];
    $data['views'] = $one+$two;
    $data['views'];

        //   $items[] = $value['post_id'];
    $items[] = array(

      'views' => $data['views'],
      'id' => $value['post_id']
  );

        //   $items['gagan1'] = $value['post_id'];
        //  echo "<pre>".$value['post_id']."====";print_r($data['views']);echo"<br>";

}
$data1['ashfaq']=$items;
$this->load->view('trending',$data1);
}
public function get_offer(){
  $offset = $this->url->segment(4);
  if(!is_numberic($offset)){
     $offset=0;
 }
 return $offset;
}
public function get_setting_public_bootstrap(){


  $settings['num_links'] = 10;

  $settings['full_tag_open']='<nav aria-label="Page navigation"><ul class="pagination">';
  $settings['full_tag_close']='</ul>';

  $settings['cur_tag_open']='<li class="disabled"><a href="#"';
  $settings['cur_tag_close']='</a></li>';

  $settings['num_tag_open']='<li>';
  $settings['num_tag_close']='</li>';

  $settings['first_link']='First';
  $settings['first_tag_open']='<li>';
  $settings['first_tag_close']='</li>';

  $settings['last_link']='Last';
  $settings['last_tag_open']='<li>';
  $settings['last_tag_close']='</li>';

  $settings['prev_link']='<span aria-hidden="true">&laquo;</span>';
  $settings['prev_tag_open']='<li>';
  $settings['prev_tag_close']='</li>';

  $settings['next_link']='<span aria-hidden="true">&raquo;</span>';
  $settings['next_tag_open']='<li>';
  $settings['next_tag_close']='</li>';
  return $settings;
}


public function add_to_cart()
{

  $ID = $_GET['ID'];
		// echo '<pre>'; print_r($ID); exit;
  $table = $this->Model->getData('wellness',array('ID'=>$ID));
		// echo '<pre>'; print_r($table); exit;
  $data['table']=$table;
  $product_category_id = $table[0]['product_category_id'];
  $sub_category_id = $table[0]['sub_category_id'];
  $category_id = $table[0]['category_id'];





  if ($this->session->userdata('logged_in')) {

    $id =  $this->session->userdata('id'); 
    $custumer_login = $this->Model->getData('custumer_login',array('id'=>$id));
    $vistor['user_name'] = $custumer_login[0]['user_name'];
    $vistor['email_id'] = $custumer_login[0]['email_id'];
    $vistor['contact_number'] = $custumer_login[0]['contact_number'];
    $vistor['customer_id'] = $custumer_login[0]['id'];
    $vistor['product_id'] = $table[0]['ID'];
    $vistor['product_category_id'] = $table[0]['product_category_id'];
    $vistor['sub_category_id'] = $table[0]['sub_category_id'];
    $vistor['category_id'] = $table[0]['category_id'];
    $vistor['sub_category_name'] = $table[0]['sub_category_name'];
    $vistor['Product_Name'] = $table[0]['Product_Name'];
    $vistor['Original_Prices'] = $table[0]['Original_Prices'];
    $vistor['Prices'] = $table[0]['Prices'];
    $vistor['GST_Persentage'] = $table[0]['GST_Persentage'];
    $vistor['Shipping_Charges'] = $table[0]['Shipping_Charges'];
    $vistor['SKU'] = $table[0]['SKU'];
    $vistor['Vistor_month'] = date('m');
    $vistor['Vistor_year'] = date('Y');
    $vistor['Vistor_day'] = date('d');
    $vistor['Vistor_year_month'] = date('Y-m');
    $vistor['Vistor_year_month_data'] = date('Y-m-d');
    $vistor['Vistor_year_month_data_time'] = date('Y-m-d H:i:s');
// echo '<pre>'; print_r($vistor); exit;
    $this->Model->insertData('vistors',$vistor);
}else{
    $vistor['product_id'] = $table[0]['ID'];
    $vistor['product_category_id'] = $table[0]['product_category_id'];
    $vistor['sub_category_id'] = $table[0]['sub_category_id'];
    $vistor['category_id'] = $table[0]['category_id'];
    $vistor['sub_category_name'] = $table[0]['sub_category_name'];
    $vistor['Product_Name'] = $table[0]['Product_Name'];
    $vistor['Original_Prices'] = $table[0]['Original_Prices'];
    $vistor['Prices'] = $table[0]['Prices'];
    $vistor['GST_Persentage'] = $table[0]['GST_Persentage'];
    $vistor['Shipping_Charges'] = $table[0]['Shipping_Charges'];
    $vistor['SKU'] = $table[0]['SKU'];
    $vistor['Vistor_month'] = date('m');
    $vistor['Vistor_year'] = date('Y');
    $vistor['Vistor_day'] = date('d');
    $vistor['Vistor_year_month'] = date('Y-m');
    $vistor['Vistor_year_month_data'] = date('Y-m-d');
    $vistor['Vistor_year_month_data_time'] = date('Y-m-d H:i:s');
// echo '<pre>'; print_r($vistor); exit;
    $this->Model->insertData('vistors',$vistor);

}

$data['multiple_picture'] = $this->Model->getData('multiple_picture',array('Product_id'=>$ID));

$id =  $this->session->userdata('id'); 
$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
$data['reviews_ratings'] = $this->Model->getData('reviews_ratings',array('Product_id'=>$ID));

$data['total_row']= $this->Model->CountWhereRecord('reviews_ratings',array('Product_id'=>$ID));

$data['product_category_id']= $this->Model->getData('wellness',array('product_category_id'=>$product_category_id));

$data['sub_category_id'] = $this->Model->getDataOrderBy('wellness',array('sub_category_id'=>$sub_category_id),'Prices','DESC');
$data['category_id'] = $this->Model->getDataOrderBy('wellness',array('category_id'=>$category_id),'ID','DESC');


$this->load->view('add_to_cart',$data);
}
public function add_cart_page()
{
  $ID = $_GET['ID'];

  $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));	

  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('add_to_cart1',$data);
}
public function add_product()
{

  $id = $this->input->post('id');
  $produtname = $this->input->post('produtname');
  $price = $this->input->post('price');
  $picture = $this->input->post('picture');
  $original = $this->input->post('original');
  $offer = $this->input->post('offer');
  $size = $this->input->post('size');
  $qty='1';
		// $qty = $this->input->post('qty');
  $company_name = $this->input->post('company_name');
  $verified_status = $this->input->post('verified_status');

  $data = array(
    'id'      => $id,
    'qty'     => $qty,
    'price'   => $price,
    'name'    => $produtname,
    'picture' => $picture,
    'original' => $original,
    'size' => $size,
    'offer' => $offer,
    'company_name'=> $company_name,
    'verified_status'=> $verified_status
);

// echo "<pre>";print_r($data);exit;

  $data['cart'] = $this->cart->insert($data);

}
function Compare(){
  $this->load->helper('array');
  $id = $this->input->post('id');
  $produtname = $this->input->post('produtname');
  $price = $this->input->post('price');
  $picture = $this->input->post('picture');
  $original = $this->input->post('original');
  $offer = $this->input->post('offer');
  $company_name = $this->input->post('company_name');
  $verified_status = $this->input->post('verified_status');

  $data = array(
    'id'      => $id,
        // 'qty'     => '1',
    'price'   => $price,
    'name'    => $produtname,
    'picture' => $picture,
    'original' => $original,
    'offer' => $offer,
    'company_name'=> $company_name,
    'verified_status'=> $verified_status
);


}

function Notify(){
		// echo '<pre>'; print_r($_POST);
  $datas['Customer_id'] =  $this->session->userdata('id');
  $datas['Product_id']= $this->input->post('id');
  $datas['Product_Name'] = $this->input->post('produtname');
  $datas['Prices'] = $this->input->post('price');
		// $data['Product_picture'] = $this->input->post('picture');
  $datas['Original_Prices'] = $this->input->post('original');
  $data['offer'] = $this->input->post('offer');
  $datas['company_name'] = $this->input->post('company_name');
  $datas['verified_status'] = $this->input->post('verified_status');

       // $Product_info= $this->Model->getData('wellness',array('ID'=>$id));
  $id=$this->Model->insertData('notify',$datas);
  echo '<pre>'; print_r($datas); 
  echo '<pre>'; print_r($id); 


}
function whishlist(){
		// echo '<pre>'; print_r($_POST); exit;
  $datas['Customer_id'] =  $this->session->userdata('id');
  $datas['Product_id']= $this->input->post('id');
  $datas['Product_Name'] = $this->input->post('produtname');
  $datas['Prices'] = $this->input->post('price');
		// $data['Product_picture'] = $this->input->post('picture');
  $datas['Original_Prices'] = $this->input->post('original');
  $data['offer'] = $this->input->post('offer');
  $datas['company_name'] = $this->input->post('company_name');
  $data['verified_status'] = $this->input->post('verified_status');

       // $Product_info= $this->Model->getData('wellness',array('ID'=>$id));
  $this->Model->insertData('wishlist',$datas);
  echo '<pre>'; print_r($datas); 


}
public function Rating_review(){
		// echo '<pre>'; print_r($_POST);
  $Rating_review=$_POST;
        // echo '<pre>'; print_r($_POST);exit;

        // $this->Add_category_model->insertupend($_POST);
  $id = $this->Model->insertData('reviews_ratings',$Rating_review);
        // echo '<pre>'; print_r($id); exit;
}
public function Compare_page()
{	

		// $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

  $this->load->view('Compare_page',$data);
		// echo "<pre>";print_r($data);exit;
}

function show_cart(){ 
  $output = '';
  $no = 0;
  foreach ($this->cart->contents() as $items) {
     $no++;
     $output .='
     ';
 }
 $output .= '
 <ul style="line-height: 27px;">
 <li>
 <div class="row">
 <div class="col-sm-6"> Price </div>
 <div class="col-sm-6"><p>₹ '.'&nbsp;'.number_format($this->cart->total()).'</p></div>
 </div>
 </li>
 <li>
 <div class="row">
 <div class="col-sm-6">Delivery Charges</div>
 <div class="col-sm-6"><p> FREE</p></div>
 </div>
 </li>
 <hr>
 <li>
 <div class="row">
 <div class="col-sm-6">Amount Payable</div>
 <div class="col-sm-6"><p> ₹'.'&nbsp;'.number_format($this->cart->total()).'</p></div>
 </div>
 </li>
 <hr>
 </ul>
 <tr>
 <th colspan="3">Total</th>
 <th colspan="2">'.'Rp '.number_format($this->cart->total()).'</th>
 </tr>
 ';
 return $output;
}
function load_cart(){ 
  echo $this->show_cart();
}
function delete_cart(){ 
  $data = array(
     'rowid' => $this->input->post('row_id'), 
     'qty' => 0, 
 );
  $this->cart->update($data);
  redirect('home/cart_shopping');
}
function update_cart(){ 
		// echo '<pre>'; print_r($_POST); exit;
  $rowid = $this->input->post('rowid');
  $qty = $this->input->post('quantity');
  $i=0;
  foreach ($rowid as $key => $value) {
     $data = array(
       'rowid' => $value, 
       'qty' =>$qty[$i], 
   );
     $this->cart->update($data);
     $i++;
 }
		// echo '<pre>'; print_r($this->cart->contents()); exit;
 redirect('Home/cart_shopping');
}

function search_filter(){

  $val = $this->input->post('val');
  $data = $this->Cart_model->search($val);


}
function serach_fil(){

  $data['categories'] = $this->Text->get_categories();
  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));

  $this->load->view('wellnesshome',$data);

}
public function Upend_heading()
{

  $data['main_containt']='upend_heading';

  $this->load->view('containt',$data);
}
public function Enter_upend()
{
		// echo '<pre>'; print_r($_POST);exit;

  $this->Add_category_model->insertupend($_POST);
  $this->session->set_flashdata('msg',' Successfully your upend_heading Add');
  redirect('Home/Upend_heading');
}
public function upend_information()
{
  $data['upend_information'] = $this->Model->getAllData('upend_wrapper');
  $data['main_containt']='upend_information';

  $this->load->view('containt',$data);
}
public function sign_up()
{	
  $this->load->view('sign');	
}

function PlaceOrder_sgin_process(){


  $email_id = $_POST['email_id'];
  $password = md5($_POST['password']);
		// $ID = $_POST['ID'];
  $login = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'password'=>$password));
        // echo '<pre>'; print_r($login); exit;
  if(isset($login) && !empty($login)){

     $newdata = array(
        'id'=>$login[0]['id'],
        'user_id'=>$login[0]['email_id'],
        'user_name'=>$login[0]['user_name'],
        'user_role'=>$login[0]['contact_number'],
        'user_role'=>$login[0]['phone_number'],
        'user_role'=>$login[0]['shipping_address'],
        'user_role'=>$login[0]['billing_address'],
        'user_role'=>$login[0]['aadhar_number'],
        'user_role'=>$login[0]['pan_number'],
        'user_role'=>$login[0]['password'],
        'logged_in'=>TRUE
    );

     $this->session->set_userdata($newdata);
			// $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

     $user_ID =  $this->session->userdata('id'); 
     $login_information_id =  $this->session->userdata('id');
     $status['online']='1';
     $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
     $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
     $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
     $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
		  // echo '<pre>'; print_r($data['total_row_add']); exit;	
        // $data['categories'] = $this->Text->get_categories();
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('checkout_page',$data);
 }else{

     $this->session->set_flashdata('msg','login failed');
     redirect('Home');
 }
}
function Checkout_sgin_process(){


  $email_id = $_POST['email_id'];
  $password = md5($_POST['password']);
  $ID = $_POST['ID'];
  $login = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'password'=>$password));
        // echo '<pre>'; print_r($login); exit;
  if(isset($login) && !empty($login)){

     $newdata = array(
        'id'=>$login[0]['id'],
        'user_id'=>$login[0]['email_id'],
        'user_name'=>$login[0]['user_name'],
        'user_role'=>$login[0]['contact_number'],
        'user_role'=>$login[0]['phone_number'],
        'user_role'=>$login[0]['shipping_address'],
        'user_role'=>$login[0]['billing_address'],
        'user_role'=>$login[0]['aadhar_number'],
        'user_role'=>$login[0]['pan_number'],
        'user_role'=>$login[0]['password'],
        'logged_in'=>TRUE
    );

     $this->session->set_userdata($newdata);
     $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

     $user_ID =  $this->session->userdata('id'); 
     $login_information_id =  $this->session->userdata('id');
     $status['online']='1';
     $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
     $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
     $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
     $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
		  // echo '<pre>'; print_r($data['total_row_add']); exit;	
        // $data['categories'] = $this->Text->get_categories();
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('buy_now',$data);
 }else{

     $this->session->set_flashdata('msg','login failed');
     redirect('Home');
 }
}
public function Checkout_Manage_address_from(){

  $userData = array(
    'Customer_id' => $this->session->userdata('id'),
    'Name' => $this->input->post('Name'),
    'Phone_number' => $this->input->post('Phone_number'),
    'Pincode' => $this->input->post('Pincode'),
    'Locality' => $this->input->post('Locality'),
    'address' => $this->input->post('address'),
    'City' => $this->input->post('City'),
    'state' => $this->input->post('state'),
    'Landmark' => $this->input->post('Landmark'),
    'Alternate_Phone' => $this->input->post('Alternate_Phone'),
    'Address_type' => $this->input->post('Address_type')

);
		// echo '<pre>'; print_r($userData); exit;
		// $ID = $this->input->post('ID');
  $this->Model->insertData('manage_addresses',$userData);
		// $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

  $user_ID =  $this->session->userdata('id'); 
  $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
  $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
		    // $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
		  // echo '<pre>'; print_r($data['total_row_add']); exit;	
        // $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('checkout_page',$data);
}
public function Manage_address_from(){

  $userData = array(
    'Customer_id' => $this->session->userdata('id'),
    'Name' => $this->input->post('Name'),
    'Phone_number' => $this->input->post('Phone_number'),
    'Pincode' => $this->input->post('Pincode'),
    'Locality' => $this->input->post('Locality'),
    'address' => $this->input->post('address'),
    'City' => $this->input->post('City'),
    'state' => $this->input->post('state'),
    'Landmark' => $this->input->post('Landmark'),
    'Alternate_Phone' => $this->input->post('Alternate_Phone'),
    'Address_type' => $this->input->post('Address_type')

);
		// echo '<pre>'; print_r($userData); exit;
  $ID = $this->input->post('ID');
  $this->Model->insertData('manage_addresses',$userData);
  $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

  $user_ID =  $this->session->userdata('id'); 
  $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
  $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
  $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
		  // echo '<pre>'; print_r($data['total_row_add']); exit;	
        // $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('buy_now',$data);
}

public function epanelist_logindetail($username='',$password=''){
    if ((!empty($username) && !empty($password)) ) {
        $pwd=$password;
        $uname=base64_encode($username);
        $output=$this->api_calling($uname,$pwd);
        $val_data=json_decode($output,true);
        //echo "<pre>";print_r($val_data);die();
        $undefine='1';
        if($undefine){
            if($val_data['status']=='success'){
                $epanelist_login = array(
                    'user_id'=>$val_data['user_id'],
                    'username'=>$val_data['username'],
                    'name'=>$val_data['name'],
                    'account_type'=>$val_data['account_type'],
                    'email_verified'=>$val_data['email_verified'],
                    'employee_id'=>$val_data['employee_id'],
                    'employee_code'=>$val_data['employee_code'],
                    'profileImage'=>$val_data['profileImage'],
                    'entube_customer_logged_in'=>TRUE
                );
                $user_tracking = array(
                    'user_id' => $val_data['user_id'],
                    'employee_id' => $val_data['employee_id'], 
                    'user_ip' => $_SERVER['REMOTE_ADDR'],
                    // 'lat_long' => $_POST['user_latlong'],
                    'username' => $val_data['username'],
                    'date_1'=>date("Y-m-d H:i:s"),
                    'usertype' => 1
                );
                $this->Model->insertData('users_tracking',$user_tracking);
                $this->session->set_userdata($epanelist_login);
                //echo "<pre>";print_r($epanelist_login);die();
                //SET COOKIE AT LOGIN TIME FOR 6 MONTHS LIFETIME ADD BY MOHD ALAM 16/05/2020
                $cookie= array(
                   'name'   => 'epanelist_user',
                   'value'  => $epanelist_login['username'],
                   'expire' => time() + 60 * 60 * 24 * 180,
                );
                $this->input->set_cookie($cookie);

                $cookie_image= array(
                   'name'   => 'epanelist_image',
                   'value'  => $epanelist_login['profileImage'],
                   'expire' => time() + 60 * 60 * 24 * 180,
                );
                $this->input->set_cookie($cookie_image);

                $data['status'] = '2';
                $data['msg'] = '<strong>Well done!</strong> You have logged in successfully as E-Panelist User.';
                echo json_encode($data);
                exit;
            }
            else{
              $data['status'] = '3';
              $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
              echo json_encode($data);
              exit;
            }
        }
        else{
            $data['status'] = '4';
            $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
            echo json_encode($data);
            exit;
        }
    }
    else{
    $data['status'] = '5';
    $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
    echo json_encode($data);
    exit;
    }
}

public function sgin_process() {
    $jsonObj = $_POST['jsonObj']; 
    $array_data = json_decode($jsonObj,true); 
    $array_entity = $array_data['login'];
    //echo '<pre>'; print_r($array_entity);die();

    $user_id = htmlspecialchars($array_entity['user_id']);
    $password = $array_entity['password'];
    $userSubmit = $array_entity['userSubmit'];
    $email_id = $user_id;
   
    $date_time = date('Y-m-d H:i:s');
    $endTime = strtotime("-15 minutes", strtotime($date_time));
    $query = $this->db->query('SELECT * FROM ip_block WHERE ip="'.$_SERVER["REMOTE_ADDR"].'" and  date_time > (now() - interval 10 minute)');

    $attempts= $query->num_rows();

    if($attempts>="3"){
        $promo_codo['ip'] = "00000000";
        $promo_codo['date_time'] = date('Y-m-d H:i:s');
    }
    else{
        $promo_codo['ip'] = $_SERVER["REMOTE_ADDR"];
        $promo_codo['date_time'] = date('Y-m-d H:i:s');
    }    
    $email_information = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'status'=>'1'));

    if (!$email_information) {
        $data['value'] = $this->epanelist_logindetail($userSubmit,$password);
        $data['status'] = '6';
        $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
        $this->Model->insertData('ip_block',$promo_codo);
        echo json_encode($data);
        exit;
    }

    if($userSubmit){
        $password = md5($password);
        $login = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'password'=>$password,'status'=>'1'));
        //echo '<pre>'; print_r($login); exit;
        if(isset($login) && !empty($login)){
            $newdata = array(
                'id'=>$login[0]['id'],
                'user_id'=>$login[0]['email_id'],
                'user_name'=>$login[0]['user_name'],
                'last_name'=>$login[0]['last_name'],
                'user_role'=>$login[0]['contact_number'],
                'user_role'=>$login[0]['phone_number'],
                'user_role'=>$login[0]['shipping_address'],
                'user_role'=>$login[0]['billing_address'],
                'user_role'=>$login[0]['aadhar_number'],
                'user_role'=>$login[0]['pan_number'],
                'user_role'=>$login[0]['password'],
                'logged_in'=>TRUE
            );

            $user_tracking = array(
                'user_id' => $login[0]['id'],
                'employee_id' => $login[0]['id'], 
                'user_ip' => $_SERVER['REMOTE_ADDR'],
                // 'lat_long' => $array_entity['user_location'],
                'username' => $login[0]['user_name'],
                'date_1'=>date("Y-m-d H:i:s"),
                'usertype' => 0
            );
            $this->Model->insertData('users_tracking',$user_tracking);
            $this->session->set_userdata($newdata);
            //echo '<pre>'; print_r($newdata); exit;
            //SET COOKIE AT LOGIN TIME FOR 6 MONTHS LIFETIME ADD BY MOHD ALAM 16/05/2020
            $cookie= array(
               'name'   => 'guest_user',
               'value'  => $newdata['id'],
               'expire' => time() + 60 * 60 * 24 * 180,
            );
            $this->input->set_cookie($cookie);

            $login_information_id =  $this->session->userdata('id');
            $status['online']='1';

            $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
            $this->session->set_flashdata('msg','You have logged in successfully');
            $data['status'] = '1';
            $data['msg'] = '<strong>Well done!</strong> You have logged in successfully as Guest user.';
            echo json_encode($data);
        }
        else{
            // echo '<pre>'; print_r($password); 
            $status='1';
            $strSql = "SELECT * FROM custumer_login WHERE email_id='".$email_id."' AND Master_password='".$password."' AND status='".$status."'";
            $master =$this->Model->getSqlData($strSql);
            // echo '<pre>'; print_r($master); 
            if (isset($master) && !empty($master)) {
                $newdata = array(
                    'id'=>$master[0]['id'],
                    'user_id'=>$master[0]['email_id'],
                    'user_name'=>$master[0]['user_name'],
                    'user_role'=>$master[0]['contact_number'],
                    'user_role'=>$master[0]['phone_number'],
                    'user_role'=>$master[0]['shipping_address'],
                    'user_role'=>$master[0]['billing_address'],
                    'user_role'=>$master[0]['aadhar_number'],
                    'user_role'=>$master[0]['pan_number'],
                    'user_role'=>$master[0]['password'],
                    'logged_in'=>TRUE
                );
                $user_tracking = array(
                    'user_id' => $master[0]['id'],
                    'employee_id' => $master[0]['id'], 
                    'user_ip' => $_SERVER['REMOTE_ADDR'],
                    'lat_long' => $array_entity['user_location'],
                    'username' => $master[0]['user_name'],
                    'date_1'=>date("Y-m-d H:i:s"),
                    'usertype' => 0
                );

                $this->Model->insertData('users_tracking',$user_tracking);
                // echo '<pre>'; print_r($newdata); exit;
                $this->session->set_userdata($newdata);
                // echo '<pre>'; print_r($this->session->userdata('id')); exit;
                $login_information_id =  $this->session->userdata('id');
                // echo '<pre>'; print_r($login_information_id); exit;
                $statusss['online']='1';
                // echo '<pre>'; print_r($statusss); exit;
                $login_id = $this->Model->updateData('custumer_login',$statusss,array('id'=>$login_information_id));

                $data['status'] = '1';
                $data['msg'] = '<strong>Well done!</strong> You have logged in successfully.';
            }
            else{
                $data['status'] = '0';
                $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
                $this->Model->insertData('ip_block',$promo_codo);
            }
            echo json_encode($data);
            // 
        }
    }
    else{
        $data['status'] = '0';
        $this->Model->insertData('ip_block',$promo_codo);
        $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
        echo json_encode($data);
    }
}

public function send_otp_message($id,$contact_number,$otp_code){

  $user = "oxiinc";
  $password = "microlan@123";
  $senderId = "OXIINC";
  $channel = "Trans";
  $dcs = "0";
  $flashsms = "0";
  $route = "6";
  $mobile = $contact_number;
  $otp_code = $otp_code;
  $text_message = "Dear ". $mobile. ". This your otp".$otp_code.". We will process your Register at your chosen date and time.";
  $sms = urlencode($text_message);

  $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';
					    // echo '<pre>'; print_r($smsurl); exit;
  try  
  {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $smsurl);
    $data = curl_exec($ch);
    curl_close($ch);
    $response = $data;
}  
catch (Exception $e)  
{  
    $response = $e->getMessage();  
}


}
function validate_otp_confirmation(){
   	// echo '<pre>'; print_r($_POST); exit;
  $contact_number = $this->input->get_post('contact_number');
  $otp_code = $this->input->get_post('otp_code');
  $password = md5($this->input->get_post('password'));
		// echo '<pre>'; print_r($password); exit;
		// $password = md5($_POST['password']);
  if($contact_number!="" && $otp_code!=""){
     $user_data = $this->Model->getData('custumer_login',array('contact_number'=>$contact_number));
     $forget_data = $this->Model->getData('forgot_password',array('otp_code'=>$otp_code));
			// echo '<pre>'; print_r($forget_data); exit;
     if(isset($user_data) && !empty($user_data)){
				// echo '<pre>'; print_r($user_data); exit;
        if($forget_data[0]['otp_code']==$otp_code){
					// echo '<pre>'; print_r($forget_data); exit;
           $id = $user_data[0]['id'];
           $postData=array(

              'password' => $password,

          );

					// echo '<pre>'; print_r($postData); exit;

           $this->Model->updateData('custumer_login',$postData,array('id'=>$id)); 
					 // $data['msg'] = 'You have logged in successfully';
           $this->session->set_flashdata('msg' ,'Your password is reset successfully.');
           redirect('Home');
					// $this->model->updateData('user',array('is_mobile_verified'=>'1'),array('mobile_number'=>$mobile_number));
       }else{

					// $data['msg'] = 'Invalid OTP code is entered.';
           $this->session->set_flashdata('msg' ,'Invalid OTP code is entered.');
           redirect('Home');
       }
   }else{

      redirect('Home');
  }
}else{

   redirect('Home');
}

}



function logout(){
    $login_information_id =  $this->session->userdata('id');
    $status['online']='0';
    $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
    $this->session->set_userdata(array('logged_in' => FALSE));
    $this->session->sess_destroy();
    delete_cookie("epanelist_user");
    delete_cookie("epanelist_image");
    delete_cookie("guest_user");
    redirect(base_url());
}


public function varify()
{


   $postData=array(

      'status' =>1,

  );

					// echo '<pre>'; print_r($postData); exit;

   $this->Model->updateData('custumer_login',$postData,array('contact_number'=>$this->uri->segment(3))); 
   $this->session->set_flashdata('msg' ,'Your account has been varify successfully.');
   redirect('Home');
 	# code...
}

function send_register_confirmation_mail($user_name,$email_id,$contact_number){

	
  $user_name = $user_name;
  $user_names = $user_name;
  $to_email_address = $email_id;
  $subject = 'Thankyou For Register With as, Oxiinc Group';
  $emailer = 'emailer/welcome.html';
  $mail_content = file_get_contents($emailer);
  $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);
  $mail_content = str_replace('@_users_names_@', $user_names, $mail_content);
  $mail_content = str_replace('@_email_id_@', $email_id, $mail_content);
  $mail_content = str_replace('@_contact_number_@', $contact_number, $mail_content);



  $headers = "From:noreply@entube.in\r\n" .
  'Reply-To: myorder@oxiinc.in' . "\r\n" .
  "MIME-Version: 1.0\r\n".
  "Content-Type: text/html; charset=ISO-8859-1\r\n";
  'X-Mailer: PHP/';


  if(mail($to_email_address, $subject, $mail_content, $headers))
  {

  }
}

function checkout(){


  $ID = $this->session->userdata('id');

  $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
		  // echo '<pre>'; print_r($data['table']); exit;	


  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
  if ($this->session->userdata('in_logged_in')) {
    $this->load->view('get_epanelist_adddress',$data);
}else{
 $this->load->view('checkout_page',$data);
}
}

function buy_now(){
		// echo '<pre>'; print_r($_POST); exit;
  if (empty($_POST['ID'])) {
    redirect('Home');
}

$ID = $_POST['ID'];

$data['size'] =  $_POST['size'];
        // echo '<pre>'; print_r($data['size']); exit;

$data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

$user_ID =  $this->session->userdata('id'); 
$data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));

$data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
		  // echo '<pre>'; print_r($data['table']); exit;	
        // $data['categories'] = $this->Text->get_categories();
$id =  $this->session->userdata('id'); 
$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
$this->load->view('buy_now',$data);

}
function search(){
// 	 echo "SELECT * FROM add_video
// WHERE  Video_Name LIKE '%".$_POST['search']."%' LIMIT 0,8";
   $query = $this->db->query("SELECT * FROM add_video
      WHERE status='1' AND  (UPPER(Video_Name) LIKE UPPER('%".filter_var($_POST['search'], FILTER_SANITIZE_STRING)."%')) OR (LOWER(Video_Name) LIKE LOWER('%".filter_var($_POST['search'], FILTER_SANITIZE_STRING)."%'))");

   $data['Category_videos']= $query->result_array();

// 		}
    //   echo '<pre>'; print_r($data); exit;

   $this->load->view('Search_entube',$data);

}

function search_loadmore(){

   $query = $this->db->query("SELECT * FROM add_video
      WHERE status='1' AND (UPPER(Video_Name) LIKE UPPER('%".$_POST['search']."%')) OR (LOWER(Video_Name) LIKE LOWER('%".$_POST['search']."%')) LIMIT 0,".$_POST['id']);

   $Category_videos= $query->result_array();
   $data['search']=$_POST['search'];



   ?>
   <?php
// echo '<pre>'; print_r($like); exit;
   if(isset($like) && !empty($like)) foreach ($like as $value) { 
                        // echo '<pre>'; print_r($value); exit;

     $row1 = $this->Model->getData('add_video',array('ID'=>$value['post_id']));
// echo '<pre>'; print_r($row1); 
     if(	$row1){
        $category_name_info_khan = $this->Model->getData('category',array('status'=>1,'category_id'=>$row1[0]['category_id']));

        ?>
        <div class="video-card video-card-list" id="div1">
          <div class="video-card-image">

             <a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['post_id']); ?>"><img class="img-fluid img-responsive" src="<?php echo base_url().'uploads/product/'.$row1[0]['picture'];?>" alt="<?php echo "#"."History  ".$row1[0]['Video_Title']; ?>"></a>
             <!--<div class="time">3:50</div>-->
         </div>
         <div class="video-card-body">
             <div class="btn-group float-right right-action">
                <a href="#" class="right-action-link text-gray" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                   <button style="background-color: transparent;
                   border: none;" id="avinash">  <i class="fa fa-times" ></i></button>
               </a>


               <script>
                $(document).ready(function(){
                  $("#avinash").click(function(){
                    $("#div1").remove();

                                                     // alert("avinash");
                                                 });
              });
          </script>

          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


      </div>
      <div class="video-title">
          <a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['post_id']); ?>" style="    font-size: 15px;color:black !important; " ><?php echo $row1[0]['Video_Title']; ?></a>
      </div>
      <div class="video-page text-success">
          <?php echo $category_name_info_khan[0]['seo_category_name']; ?>   <a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>
      </div>
      <div class="video-view" style="    font-size: 15px;color:black">
       <?php 
       $watch_most = $this->Model->getData('watched_user',array('post_id'=>$row1[0]['ID']));
       echo $watch_most[0]['view'];




       ?>  views &nbsp;<i class="fas fa-calendar-alt"></i> 
       <?php 
       $FromDate = new DateTime(date("Y-m-d H:i:s"));
       $ToDate   = new DateTime($row1[0]['datatime']);
       $Interval = $FromDate->diff($ToDate);

       $Difference["Hours"] = $Interval->h;

       $Difference["Weeks"] = floor($Interval->d/7);
       $Difference["Days"] = $Interval->d % 7;
       $Difference["Months"] = $Interval->m;
       $Difference["minute"] = $Interval->i;
       $Difference["second"] = $Interval->s;
       $Difference["Year"] = $Interval->y;



       if($Difference["Year"]){
         echo $Difference["Year"]." "."Year";
     }else
     if($Difference["Months"]){
      echo $Difference["Months"]." "."Months";
  }else
  if($Difference["Weeks"]){
   echo $Difference["Weeks"]." "."Weeks";
}else
if($Difference["Days"]){
   echo $Difference["Days"]." "."Days";
}else
if($Difference["Hours"]){
   echo $Difference["Hours"]." "."Hours";
}else
if($Difference["minute"]){
    echo $Difference["minute"]." "."Minute";
}else
if($Difference["second"]){
 echo $Difference["second"]." "."Second";
} 
echo " "."ago";


?>
</div>
</div>
</div>



<?php }}else{ ?> 
	<center><img class="img-responsive" src="<?php echo base_url('black/img/GAGAN.gif'); ?>" alt="Smiley face" style="width: 100%;
  height: auto;"></center>
<?php } ?>

<?php
// 		$this->load->view('Search_entube',$data);

}
public function rangeslider(){
	
		// echo '<pre>'; print_r($_POST); exit;
  $sub_category_id = $this->input->get_post('sub_category_id');
  $data['sub_category_id'] = $sub_category_id;
  $price_max = $this->input->get_post('price-max');
  $price_min = $this->input->get_post('price-min');

  $data['banner'] = $this->Model->getData('banner',array('sub_category_id'=>$sub_category_id));

  $data['SUB_cat'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $data['Multiple_image'] = $this->Text->Rangeslider($sub_category_id,$price_max,$price_min);
		 // echo '<pre>'; print_r($data['Rangeslider']); exit;
  $this->load->view('Rangeslider',$data);
}
public function Second_Rangeslider(){
	
		// echo '<pre>'; print_r($_POST); exit;
  $sub_category_id = $this->input->get_post('sub_category_id');
  $data['sub_category_id'] = $sub_category_id;
  $price_max = $this->input->get_post('price-max');
  $price_min = $this->input->get_post('price-min');
  $verified_status = $this->input->get_post('verified_status');
  $data['banner'] = $this->Model->getData('banner',array('sub_category_id'=>$sub_category_id));

  $data['SUB_cat'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  if($sub_category_id!='' && $price_max!='' && $price_min!='' && $verified_status!=''){
     $data['Multiple_image'] = $this->Text->Second_Rangeslider($sub_category_id,$price_max,$price_min,$verified_status);
		 // echo '<pre>'; print_r($data['Multiple_image']); exit;
 }else{
  $data['Multiple_image'] = $this->Text->three_Rangeslider($sub_category_id,$price_max,$price_min);
}
		 // echo '<pre>'; print_r($data['Multiple_image']); exit;
$this->load->view('Second_Rangeslider',$data);
}
public function Price_ranger(){
  echo '<pre>'; print_r($_POST); 
  $sub_category_id = $this->input->post('sub_category_id');
    		// echo '<pre>'; print_r($sub_category_id); 
  $price_max = $this->input->post('price_max');
  $price_min = $this->input->post('price_min');
  $data['Multiple_image'] = $this->Text->three_Rangeslider($sub_category_id,$price_max,$price_min);
		// echo '<pre>'; print_r($data['Multiple_image']); exit;
  $this->load->view('Second_Rangeslider',$data);

}

public function Pro_Second_Rangeslider(){
	
		// echo '<pre>'; print_r($_POST); exit;
  $product_category_id = $this->input->get_post('product_category_id');
  $data['product_category_id'] = $product_category_id;
  $price_max = $this->input->get_post('price-max');
  $price_min = $this->input->get_post('price-min');
  $verified_status = $this->input->get_post('verified_status');
  $data['SUB_pro_cat'] = $this->Model->getData('product_category',array('product_category_id'=>$product_category_id));

  $data['Pro_banner'] = $this->Model->getData('pro_banner',array('product_category_id'=>$product_category_id));
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  if($product_category_id!='' && $price_max!='' && $price_min!='' && $verified_status!=''){
     $data['Pro_Multiple_image'] = $this->Text->Pro_Second_Rangeslider($product_category_id,$price_max,$price_min,$verified_status);
		 // echo '<pre>'; print_r($data['Multiple_image']); exit;
 }else{
  $data['Pro_Multiple_image'] = $this->Text->Pro_three_Rangeslider($product_category_id,$price_max,$price_min);
}
		 // echo '<pre>'; print_r($data['Multiple_image']); exit;
$this->load->view('Pro_Second_Rangeslider',$data);
}
public function Pro_Rangeslider(){
	
		// echo '<pre>'; print_r($_POST); exit;
  $product_category_id = $this->input->get_post('product_category_id');
  $data['product_category_id'] = $product_category_id;
  $price_max = $this->input->get_post('price-max');
  $price_min = $this->input->get_post('price-min');
  $data['SUB_pro_cat'] = $this->Model->getData('product_category',array('product_category_id'=>$product_category_id));

  $data['Pro_banner'] = $this->Model->getData('pro_banner',array('product_category_id'=>$product_category_id));
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		 // $data['Multiple_image'] = $this->Text->Rangeslider($sub_category_id,$price_max,$price_min);
  $data['Pro_Multiple_image'] = $this->Text->Pro_Rangeslider($product_category_id,$price_max,$price_min);
		 // echo '<pre>'; print_r($data['Pro_Multiple_image']); exit;
  $this->load->view('Pro_Rangeslider',$data);
}
function view_all(){
  $upend_id = $_GET['upend_id'];
  $data['upend_info'] = $this->Model->getData('wrapper_wellness',array('upend_id'=>$upend_id));
  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('view_all',$data);

}
public function view_add_to_cart()
{

  $ID = $_GET['ID'];

  $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
		// $data['SUB_cat'] = $this->model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
		// $data['categories'] = $this->text->get_categories();
  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('view_add_to_cart',$data);
}
public function view_product()
{

  $ID = $_GET['ID'];

  $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
		// $data['SUB_cat'] = $this->model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
		// $data['categories'] = $this->text->get_categories();
  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('view_add_to_cart',$data);
}
function View_buy_now(){
  $ID = $_GET['ID'];

  $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));

  $user_ID =  $this->session->userdata('id'); 
  $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));


		  // echo '<pre>'; print_r($data['table']); exit;	
  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('View_buy_now',$data);

}

function view_all_url(){
  $url_id = $_GET['url_id'];
  $data['url_append_heading'] = $this->Model->getData('url_append_heading',array('url_id'=>$url_id));
		// echo '<pre>'; print_r($data['url_append_heading']); exit;
  $data['url_append_info'] = $this->Model->getData('url_append_info',array('url_id'=>$url_id));
  $total_row = $this->Model->CountWhereRecord('url_append_info',array('url_id'=>$url_id));
  $data['total_row']= $total_row;
  $data['categories'] = $this->Text->get_categories();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('view_all_url',$data);

}
function about_us(){
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('about-us',$data);
}

function oxiinc_stories(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('oxiinc-stories',$data);
}


function cancellation_policy(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('cancellation-return-policy',$data);
}

function success_stories(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('success-stories',$data);
}
function payment_policy(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('payment-policy',$data);
}

function shipping_policy(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('shipping-policy',$data);
}

function report_infringement(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('report-infringement',$data);
}

function term_of_use(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('term-of-use',$data);
}
function securities(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('securities',$data);
}

function privacy_policy(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('privacy-policy',$data);
}

function faq(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('FAQ',$data);
}

function sitemap(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('sitemap',$data);
}

function press_release(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('press-release',$data);
}

function help(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('help',$data);
}

function payment(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('help',$data);
}
function Sale_On_Oxiinc(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('sell-on-oxiinc',$data);
}
function Affiliate(){
   $id =  $this->session->userdata('id'); 
   $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
   $this->load->view('affiliates',$data);
}

function text_message()
{
	$user_name = 'Mr.gagan';
	$to_email_address = 'gaganbansode@gmail.com';
  $subject = 'Your DirectFarm.in Order #'.$order_number;
  $emailer = 'emailer/templat.html';
  $mail_content = file_get_contents($emailer);
  $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);



  $headers = "From:no-reply@oxiinc.in\r\n" .
  'Reply-To: myorder@oxiinc.in' . "\r\n" .
  "MIME-Version: 1.0\r\n".
  "Content-Type: text/html; charset=ISO-8859-1\r\n";
  'X-Mailer: PHP/';


  if(mail($to_email_address, $subject, $mail_content, $headers))
  {
    echo"<h1>success</h1>";
}
}

function FamilyNutrition1(){
	$sub_category_id = '1';
		// $data['sub_category_id'] = str_split($sub_category_id[0]);
  $data['sub_category_id'] = $sub_category_id;
  $this->load->library('pagination');
  $this->load->library('Ajax_pagination');

  $total_row= $this->Model->CountWhereRecord('wellness',array('sub_category_id'=>$sub_category_id));
  $limit = 20;
  $config['uri_segment'] = 3;
  $totalRec = $total_row;

  $config['target']      = '#collegespaging';
  $config['base_url']    = base_url('Home/wellness').'?sub_category_id='.$sub_category_id;

  $config['total_rows']  = $totalRec;
  $config['per_page']    = $limit;
  $this->ajax_pagination->initialize($config);
  $page= ($this->uri->segment(3)) ? $this->uri->segment(3):0;

        // $data['Multiple_image'] = $this->Text->Multiple_image($sub_category_id,$config["per_page"],$page);

  $data['Multiple_image'] = $this->Text->Multiple_image($sub_category_id);
  $data['banner'] = $this->Model->getData('banner',array('sub_category_id'=>$sub_category_id));

  $data['SUB_cat'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));


		// $data['categories'] = $this->Text->get_categories();
		// $id =  $this->session->userdata('id'); 
		// $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $data['pagination'] = $this->ajax_pagination->create_links();
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		    // echo '<pre>'; print_r($data); exit;
  $this->load->view('family-nutrition1',$data);
}
function validate_offer_code(){


  $offer_code = $this->input->get_post('offer_code');
  $total_amount = $this->input->get_post('total_amount');
  if($offer_code!='' && $total_amount!='' ){

     $strSql = "SELECT * FROM promo_codo WHERE Promo_code='".$offer_code."' AND Active_states='1'AND expiry_date>='".date('Y-m-d')."'";
     $offer_data =$this->Model->getSqlData($strSql);
	            // echo '<pre>'; print_r($offer_data); exit;
     if(isset($offer_data) && !empty($offer_data)){
        $Promo_code = $offer_data[0]['Promo_code'];
        $ID = $offer_data[0]['ID'];
        $customer_id = $offer_data[0]['customer_id'];
        $Promo_amount = $offer_data[0]['Promo_Percentage'];
        $Minimum_Amount = $offer_data[0]['Minimum_Amount'];

        if($this->session->userdata('id') == $customer_id ){
          if ($total_amount>$Promo_amount) {

             $data['discount_amount'] = $total_amount - $Promo_amount;
             $data['Promo_amount'] = $Promo_amount;
             $data['promo_id'] = $ID;
             $ID = $this->session->userdata('id');
             $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
             $id =  $this->session->userdata('id'); 
             $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
             $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));

             $this->load->view('checkout_page',$data);

         }else{
          $this->session->set_flashdata('msg','Minimum billed amount should be Rs. '.$Minimum_Amount.", Your  total is Rs. ".$total_amount."");
          redirect('Home');
      }

  }else{
     $this->session->set_flashdata('msg','This Promo Code is Not Applicable For You.');
     redirect('Home');


 }
}else{
   $this->session->set_flashdata('msg','Invalid offer code is entered.');
   redirect('Home');

}

}else{
   $this->session->set_flashdata('msg','Required parameters are missing.');
   redirect('Home');
}
}
function logout_buy_now(){

  $login_information_id =  $this->session->userdata('id');
  $status['online']='0';
  $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
  $this->session->unset_userdata('logged_in');


  redirect(base_url("home/buy_now"));

}
function logout_checkout(){
		// $this->session->set_userdata(array('logged_in' => FALSE));
  $login_information_id =  $this->session->userdata('id');
  $status['online']='0';
  $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
  $this->session->unset_userdata('logged_in');

  redirect(base_url("home/checkout"));

}
function Summary_ticket(){
  $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
  $this->load->view('Summary_ticket',$data);
}
function validate_login(){
  $jsonObj = $_POST['jsonObj']; 
  $array_data = json_decode($jsonObj,true); 
  $array_entity = $array_data['login'];

  $user_id = $array_entity['user_id'];
  $password = $array_entity['password'];

  $user_data=$this->Model->getData('custumer_login',array('email_id' => $user_id,'password' => md5($password)));
		// echo '<pre>'; print_r($user_data); exit;
  if(isset($user_data) && !empty($user_data)){

     $newdata = array(
        'id'=>$user_data[0]['id'],
        'user_id'=>$user_data[0]['email_id'],
        'user_name'=>$user_data[0]['user_name'],
        'user_role'=>$user_data[0]['contact_number'],
        'user_role'=>$user_data[0]['phone_number'],
        'user_role'=>$user_data[0]['shipping_address'],
        'user_role'=>$user_data[0]['billing_address'],
        'user_role'=>$user_data[0]['aadhar_number'],
        'user_role'=>$user_data[0]['pan_number'],
        'user_role'=>$user_data[0]['password'],
        'logged_in'=>TRUE
    );

     $this->session->set_userdata($newdata);

     $data['status'] = '1';
     $data['msg'] = '<strong>Well done!</strong> You have logged in successfully. Please wait while we are redirecting you on dashboard.';

 }
 else{
     $data['status'] = '0';
     $data['msg'] = '<strong>Oh snap!</strong> The email address or password you entered is incorrect. Please try again.';
 }
 echo json_encode($data);
}
function test(){
  $this->load->view('test');
} 

function apitext_fail(){
  $this->session->set_flashdata('msg','login failed.');
  redirect('Home');
}
function subscription_code_epanelist(){
		// echo '<pre>'; print_r($_POST); exit;
  $data['user_id'] = $this->input->post('id');
		// $data['sr_no'] = $this->input->post('order_code');
  $data['pin'] = $this->input->post('order_code');
  $data['type'] = $this->input->post('project_name');
  $data['subscription_type'] = $this->input->post('subscription_type');
  $data['amount'] = $this->input->post('amount_after_tax');

  $this->load->view('epanelist_promo_code',$data);
}
function E_panelist_personal_information(){
  $data['pan_no'] = $this->input->post('pan_no');
  $data['adhaar_no'] = $this->input->post('adhaar_no');
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('E_panelist_personal_information',$data);
}
function  epanelist_digital_wallet(){


  if (empty($_POST['Withdrawl_balance'])) {
    redirect('Home');
}
        // echo '<pre>'; print_r($_POST); exit;
$data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
$data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
        // echo '<pre>'; print_r($data); exit;
$this->load->view('epanelist_digital_wallet',$data);
}
function epanelist_digital_shopping_wallet(){
		// echo '<pre>'; print_r($_POST); 
  if (empty($_POST['Shopping_balannce'])) {
    redirect('Home');
}
$data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
$data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
        // echo '<pre>'; print_r($data); exit;
$this->load->view('epanelist_digital_shopping_wallet',$data);
}
function epanelist_personal_information(){
		// echo '<pre>'; print_r($_POST); exit;
  $data['id'] = $this->input->post('id');
  $data['first_name'] = $this->input->post('first_name');
  $data['middle_name'] = $this->input->post('middle_name');
  $data['surname'] = $this->input->post('surname');
  $data['gender'] = $this->input->post('gender');
  $data['company_name'] = $this->input->post('company_name');
  $data['primary_email'] = $this->input->post('primary_email');
  $data['secondary_email'] = $this->input->post('secondary_email');
  $data['contact_1'] = $this->input->post('contact_1');
  $data['contact_2'] = $this->input->post('contact_2');
  $data['dob'] = $this->input->post('dob');
  $data['joining_date'] = $this->input->post('joining_date');
  $data['blood_group'] = $this->input->post('blood_group');
  $data['emp_code'] = $this->input->post('emp_code');
  $this->load->view('epanelist_personal_information',$data);

}
function epanelist_Manage_Addresses(){
		// echo '<pre>'; print_r($_POST); exit;
  $data['id'] = $this->input->post('id');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['type'] = $this->input->post('type');
  $data['pincode'] = $this->input->post('pincode');
  $this->load->view('epanelist_Manage_Addresses',$data);
}
function epanelist_checkout(){
		// echo '<pre>'; print_r($_POST); exit;
  $employee_id = $this->session->userdata('employee_id');
  $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('employee_id'=>$employee_id));
  $data['id'] = $this->input->post('id');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['type'] = $this->input->post('type');
  $data['pincode'] = $this->input->post('pincode');
  $data['areas'] = $this->input->post('areas');
  $data['cities'] = $this->input->post('cities');
  $data['states'] = $this->input->post('states');
  $data['countries'] = $this->input->post('countries');
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('epanelist_checkout',$data);
}
public function E_Panelist_Manage_Address(){
		// print_r($_POST);
  $userData = array(
    'user_id' => $this->input->post('user_id'),
    'employee_id' => $this->input->post('employee_id'),
    'Name' => $this->input->post('Name'),
    'Phone_number' => $this->input->post('Phone_number'),
    'Pincode' => $this->input->post('Pincode'),
    'Locality' => $this->input->post('Locality'),
    'address' => $this->input->post('address'),
    'City' => $this->input->post('City'),
    'state' => $this->input->post('state'),
    'Landmark' => $this->input->post('Landmark'),
    'Alternate_Phone' => $this->input->post('Alternate_Phone'),
    'Address_type' => $this->input->post('Address_type')

);
  $id = $this->Model->insertData('epanelist_manage_addresses',$userData);
	// print_r($id);
}
function Payment_process(){
		// echo '<pre>'; print_r($_POST); exit;
  $data['Shipping_address'] = $this->input->post('Shipping_address');
  $data['promo_id'] = $this->input->post('promo_id');
  $data['Promo_amount'] = $this->input->post('Promo_amount');
  $data['discount_amount'] = $this->input->post('discount_amount');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['pincode'] = $this->input->post('pincode');
  $data['areas'] = $this->input->post('areas');
  $data['cities'] = $this->input->post('cities');
  $data['states'] = $this->input->post('states');
		// $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('Payment_process',$data);
}
function Epanelist_Checkout_process(){
	// echo '<pre>'; print_r($_POST); exit;
	$data['Shipping_address'] = $this->input->post('Shipping_address');

  $data['total_price'] = $this->input->post('total_price');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['pincode'] = $this->input->post('pincode');
  $data['areas'] = $this->input->post('areas');
  $data['cities'] = $this->input->post('cities');
  $data['states'] = $this->input->post('states');
  $this->load->view('Epanelist_Checkout_process',$data);
}
function Apply_coupons(){
  $this->load->view('get_Epanelist_Apply_coupons');
}
function Epanelist_payment_process(){
		// echo '<pre>'; print_r($_POST); exit;
  $Shipping_address = $this->input->post('Shipping_address');
  $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));
  $data['promo_id'] = $this->input->post('promo_id');
  $data['Promo_amount'] = $this->input->post('Promo_amount');
  $data['discount_amount'] = $this->input->post('discount_amount');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['pincode'] = $this->input->post('pincode');
  $data['areas'] = $this->input->post('areas');
  $data['cities'] = $this->input->post('cities');
  $data['states'] = $this->input->post('states');
  $data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
  $data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('Epanelist_payment_process',$data);
}
function Epanelist_process_payment(){
  $Shipping_address = $this->input->post('Shipping_address');
  $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));

  $data['shopping_prices_total'] = $this->input->post('shopping_prices_total');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['pincode'] = $this->input->post('pincode');
  $data['areas'] = $this->input->post('areas');
  $data['cities'] = $this->input->post('cities');
  $data['states'] = $this->input->post('states');
  $data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
  $data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('Epanelist_process_payment',$data);
}


function Epanelist_Apply_coupons(){
	// echo '<pre>'; print_r($_POST); exit;



	$data['Panel_id'] = $this->input->post('Panel_id');
	 // $data['Panel_id'] = array("1", "2", "4");;
   $data['Panel_project_name'] = $this->input->post('Panel_project_name');
   $data['Panel_order_code'] = $this->input->post('Panel_order_code');
   $data['Panel_amount_after_tax'] = $this->input->post('Panel_amount_after_tax');


   $data['subpanel_id'] = $this->input->post('subpanel_id');
   $data['subpanel_project_name'] = $this->input->post('subpanel_project_name');
   $data['subpanel_order_code'] = $this->input->post('subpanel_order_code');
   $data['subpanel_amount_after_tax'] = $this->input->post('subpanel_amount_after_tax');

   $this->load->view('Apply_coupons',$data);
}
function Apply_epanelist_coupens(){
	$promo_id = $this->uri->segment(3);
	$Promo_amount = $this->uri->segment(4);
	// echo '<pre>'; print_r($promo_id); 
	// echo '<pre>'; print_r($Promo_amount); 

	
  $org_price= 0; $delivery_char=0; $total_sum=0; foreach ($this->cart->contents() as $items){
     // $qtys = $items['qty'];
    $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
    $GST_Persentage =  $data[0]['GST_Persentage'];


    if($GST_Persentage >0 ){
      $gst_value = $GST_Persentage/100; 
      $gst_prices = $gst_value*$items['price'];
      $gst_price = $gst_prices*$items['qty'];
                 // $total_price = $items['price']+$gst_price;
  }else{
      $gst_price = 0;
  }




  $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
  $Shipping_Charges =  $data[0]['Shipping_Charges'];

  if ($Shipping_Charges >0) {
      $Shipping_Charges = $Shipping_Charges*$items['qty'] ;
  }else{
   $Shipping_Charges = 0 ;

}

$original_price =  $items['original']*$items['qty'];
$order_data = array(

    'product_id'=>$items['id'],
    'Product_Name'=>$items['name'],
    'Product_Picture'=>$items['picture'],
    'size'=>$items['size'],
    'Prices' => $items['subtotal'],
    'product_qty' => $items['qty'],
    'Original_Prices'=>$items['original'],
);
$total_sum+=$gst_price;

$delivery_char+=$Shipping_Charges;  

$org_price+=$original_price;  

}
$total_amount = $delivery_char+$total_sum+$this->cart->total();
	// echo '<pre>'; print_r($total_amount); exit;











// echo '<pre>'; print_r($total_amount); 


if($promo_id!='' && $Promo_amount!='' ){
  if ($total_amount>$Promo_amount) {
                  	// echo '<pre>'; print_r($total_amount); exit;
     $data['discount_amount'] = $total_amount - $Promo_amount;
     $data['Promo_amount'] = $Promo_amount;
     $data['promo_id'] = $promo_id;


// echo '<pre>'; print_r($data['discount_amount']); exit;
     $this->load->view('discount_promo_amounts',$data);
                  	// echo '<pre>'; print_r($data['discount_amount']); exit;

 }else{
  $this->session->set_flashdata('msg','Minimum billed amount should be Rs. '.$Promo_amount.", Your  total is Rs. ".$total_amount."");
  redirect('Home');
}
}else{
   $this->session->set_flashdata('msg','Required parameters are missing.');
   redirect('Home');
}

}
function epanelist_promo_checkout(){
	// echo '<pre>'; print_r($_POST); exit;

  $data['discount_amount'] = $this->input->post('discount_amount');
  $data['Promo_amount'] = $this->input->post('Promo_amount');
  $data['promo_id'] = $this->input->post('promo_id');

  $employee_id = $this->session->userdata('employee_id');
  $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('employee_id'=>$employee_id));
  $data['id'] = $this->input->post('id');
  $data['address_1'] = $this->input->post('address_1');
  $data['address_2'] = $this->input->post('address_2');
  $data['site_name'] = $this->input->post('site_name');
  $data['type'] = $this->input->post('type');
  $data['pincode'] = $this->input->post('pincode');
  $data['areas'] = $this->input->post('areas');
  $data['cities'] = $this->input->post('cities');
  $data['states'] = $this->input->post('states');
  $data['countries'] = $this->input->post('countries');
		// echo '<pre>'; print_r($data); exit;
  $this->load->view('epanelist_promo_checkout',$data);
  /*$this->load->view('Apply_coupons');*/
}
function Epanelist_payment_process_complete(){
	// echo '<pre>'; print_r($_POST); exit;
	$data['user_id']= $_POST['user_id'];
	$data['total_shipping']= $_POST['total_shipping'];
	$data['total_gst']= $_POST['total_gst'];
	$data['payment_method']= $_POST['payment_method'];
	$data['Promo_amount']= $_POST['Promo_amount'];
	$data['promo_id']= $_POST['promo_id'];
	$data['Order_Date']= $_POST['Order_Date'];
	$shipping_address= $_POST['shipping_address'];
	$data['epanelist_Shipping_address']= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$shipping_address));
	$data['total_price']= $_POST['total_price'];
	$data['total_cart']= $_POST['total_cart'];
	$data['txnid']= $_POST['txnid'];
	$this->load->view('Epanelist_payment_process_complete',$data);
}
function Epanelist_process_payment_complete(){
  $data['user_id']= $_POST['user_id'];
  $data['total_shipping']= $_POST['total_shipping'];
  $data['total_gst']= $_POST['total_gst'];
  $data['payment_method']= $_POST['payment_method'];

  $data['Order_Date']= $_POST['Order_Date'];
  $shipping_address= $_POST['shipping_address'];
  $data['epanelist_Shipping_address']= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$shipping_address));
  $data['total_price']= $_POST['total_price'];
  $data['total_cart']= $_POST['total_cart'];
  $data['txnid']= $_POST['txnid'];
  $this->load->view('Epanelist_process_payment_complete',$data);
}
public function edit_user()
{
	# code...
   $postData = $_POST;
   if(!empty($_FILES['photo'])){
     $cat=rand()."entube_gagan.png";
     $uploaddir = './uploads/Customer_pan/';
     $uploadfile = $uploaddir . $cat;

     if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
        $postData['photo'] = $cat;
    }
}
// echo "<pre>";print_r($postData['photo']);exit();
$this->Model->updateData('custumer_login',$postData,array('id'=>$this->session->userdata('id')));
redirect('home/my_profile_user');
}

function my_profile_user(){


   $login = $this->Model->getData('custumer_login',array('id'=>$this->session->userdata('id'),'status'=>'1'));
   $data['customers']=$login;
// 	echo '<pre>'; print_r($data); exit;
   $this->load->view('my_profile_user',$data);
}

function channel(){


  $this->load->view('channel');
}
function video(){


  $this->load->view('video');
}
function playlist(){


  $this->load->view('playlist');
}
function sub_channel(){


  $this->load->view('sub_channel');
}
function about_channel(){


  $this->load->view('about_channel');
}
function playlist_video(){

	$ID = $this->uri->segment(4);
	$ip = $this->input->ip_address();
   $user_id=$this->session->userdata('username');
   if (!empty($user_id)) {
     	# code...
      $vistor['post_id'] = $this->uri->segment(4);
      $vistor['ip'] = "1";
      $vistor['user_id'] = $this->session->userdata('username');
      $this->Model->insertData('views',$vistor);
  } elseif($this->session->userdata('logged_in')){


      $vistor['post_id'] = $this->uri->segment(4);
      $vistor['ip'] = "1";
      $vistor['user_id'] = $this->session->userdata('id');
      $this->Model->insertData('views',$vistor);
  }else{

      $vistor['post_id'] = $this->uri->segment(4);
      $vistor['ip'] = $ip;

      $this->Model->insertData('views',$vistor);


  }
  $query = $this->db->query('SELECT count( DISTINCT(ip) ) FROM views WHERE post_id='.$ID);

  $row= $query->result_array();
  $query1 = $this->db->query('SELECT count(DISTINCT(user_id)) FROM views WHERE post_id='.$ID);

  $row1= $query1->result_array();
  $one=$row[0]['count( DISTINCT(ip) )'];
  $two=$row1[0]['count(DISTINCT(user_id))'];
  $data['views'] = $one+$two;


  $watch = $this->Model->getData('add_video',array('status'=>'1','ID'=>$this->uri->segment(4)));
  $data['watch'] = $watch;
  $category_id = $watch[0]['category_id'];
  $this->load->view('playlist_video',$data);
}
function api_calling($uname,$pwd){
	$key=substr(str_shuffle(STRING_KEY), 0, 10);
	$enc_pwd=base64_encode($pwd);
	$salt=SALT;
	$password=$key.$salt.$enc_pwd;
	$data = array("pd" => $password,"un" => $uname); 
	$data=http_build_query($data);//die;  
	$url = "https://www.oxiinc.com/login/login_api?".$data;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}

function e_panelist_login(){
    // if($_SERVER['REMOTE_ADDR']=="49.248.217.110"){
    //     echo "<pre>";print_r($_POST);exit();
    // }
   if ((!empty($_POST['username']) && !empty($_POST['password'])) ) {
      $pwd=$_POST['password'];
      $uname=base64_encode($_POST['username']);
      $output=$this->api_calling($uname,$pwd);
      $val_data=json_decode($output,true);
      if(!empty($_POST['g-recaptcha-response'])){
        if($val_data['status']=='success'){
           $epanelist_login = array(
              'user_id'=>$val_data['user_id'],
              'username'=>$val_data['username'],
              'name'=>$val_data['name'],
              'account_type'=>$val_data['account_type'],
              'email_verified'=>$val_data['email_verified'],
              'employee_id'=>$val_data['employee_id'],
              'employee_code'=>$val_data['employee_code'],
              'profileImage'=>$val_data['profileImage'],
              'entube_customer_logged_in'=>TRUE
          );
           $user_tracking=array('user_id' => $val_data['user_id'],
              'employee_id' => $val_data['employee_id'], 
              'user_ip' => $_SERVER['REMOTE_ADDR'],
              'lat_long' => $_POST['user_latlong'],
              'username' => $val_data['username'],
              'date_1'=>date("Y-m-d H:i:s"),
              'usertype' => 1);
           $this->Model->insertData('users_tracking',$user_tracking);
           $this->session->set_userdata($epanelist_login);
           $this->session->set_flashdata('msg','Login Successfully.');
           redirect('Home');
       }else{
           $this->session->set_flashdata('msg','Login Failed.');
           redirect('Home/E_panelist_page');
       }
   }
   $this->session->set_flashdata('msg','Fill the captcha.');
   redirect('Home/E_panelist_page');

}else{
  redirect('Home/E_panelist_page');
}

}
function forgot_test(){

   echo "Hi";
}

function forgot(){

// echo "<pre>";print_r($_POST['number']);
// $this->load->view('channel');

  $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$_POST['number']));
  if($mobile_info){
		// echo '<pre>'; print_r($mobile_info); 
    $otp_code = mt_rand(10000,999999);
    $user = "OXIINCHEALTH";
    $password = "OXIINC@185";
    $senderId = "ENTUBE";
    $channel = "Trans";
    $dcs = "0";
    $flashsms = "0";
    $route = "6";
    $mobile = $_POST['number'];

    $text_message =$otp_code." is your EnTube Reset Password verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
                        // echo '<pre>'; print_r($text_message);
    $sms = urlencode($text_message);

                        // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

    $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

    try  
    {
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_HEADER, 0);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_URL, $smsurl);
      $data = curl_exec($ch);
      curl_close($ch);
      $response = $data;
  }  
  catch (Exception $e)  
  {  
      $response = $e->getMessage();  
  }


  $array_data=array(

      'mobile'=>$_POST['number'],
				// 		'email'=>$mobile_info[0]['email_id'],
      'otp'=>$otp_code,
      'created'=>date("Y-m-d H:i:s"),
      'modified'=>date("Y-m-d H:i:s"),

  );
  $this->Model->updateData('otp',$array_data,array('mobile'=>$_POST['number']));


        // 		insertData('otp',array_map('strtoupper', $array_data));
        // 		$data['contact_number1']=$_POST['number'];
  $data1=$_POST['number'];

  $data=$data1;
        //  print_r ($data); exit;
        		// $data['email'] = $mobile_info[0]['email_id'];
        // 		$data['otp']=$otp_code;

        // 		$this->load->view('forgot_password',$data);
  echo '<div class="icon1">
  <span class="fa fa-lock"></span>
  <input type="hidden" id="user_mobile" name="contact_number" value="'.$data1.'" placeholder="Enter your otp" required=""/>
  <input type="number" id="user_otp" name="otp" style="outline: none;
  font-size: 15px;
  color: #222;
  border: none;
  width: 90%;
  display: inline-block;
  background: transparent;
  letter-spacing: 1px;" placeholder="Enter your otp" required=""/>
  </div>

  <div class="bottom">

  <button type="button" id="submit_otp" onclick="validotp()" class="btn">Send</button>

  </div>
  ';
}else{
    echo 'Please check your mobile number';
}
}
function forgot_password(){
    // print_r($_POST);exit();

  $mobile_info=$this->Model->getData('otp',array('mobile'=>$_POST['contact_number'],'otp'=>$_POST['otp']));
  $date1=date("Y-m-d H:i:s");
  $difference = strtotime($date1) - strtotime($mobile_info[0]['created']);

// getting the difference in minutes
  $difference_in_minutes = $difference / 60;

  if ($difference_in_minutes<="10") {
// 		$var['password'] = md5($_POST['password']);
//  $this->Model->updateData('custumer_login',$var,array('contact_number'=>$_POST['contact_number']));
    
    $URL=base_url('Home/reset_password');
    echo '
    <form action="'.$URL.'" method="post">
    <div class="icon1">
    <span class="fa fa-lock"></span>
    <input type="hidden" id="user_mobile" name="contact_number" value="'.$_POST['contact_number'].'" placeholder="Enter your otp" required=""/>
    <input type="text" id="new_password" name="password" placeholder="Enter your new password" style="outline: none;
    font-size: 15px;
    color: #222;
    border: none;
    width: 90%;
    display: inline-block;
    background: transparent;
    letter-spacing: 1px;" placeholder="Enter your otp" required=""/>
    </div>

    <div class="bottom">

    <button type="submit"  class="btn">Send</button>

    </div>
    </form>
    ';


}else{
 echo 'Please check your otp';
	   // $this->session->set_flashdata('msg','Please check your otp');
	   // redirect("Home");
}



}
function reset_password(){
  $var['password'] = md5($_POST['password']);
  $password= md5($_POST['password']);
  $this->Model->updateData('custumer_login',$var,array('contact_number'=>$_POST['contact_number']));
  $login = $this->Model->getData('custumer_login',array('contact_number'=>$_POST['contact_number'],'password'=>$password,'status'=>'1'));
  if(isset($login) && !empty($login)){
// echo '<pre>'; print_r(); exit;
     $newdata = array(
        'id'=>$login[0]['id'],
        'user_id'=>$login[0]['email_id'],
        'user_name'=>$login[0]['user_name'],
        'last_name'=>$login[0]['last_name'],
        'user_role'=>$login[0]['contact_number'],
        'user_role'=>$login[0]['phone_number'],
        'user_role'=>$login[0]['shipping_address'],
        'user_role'=>$login[0]['billing_address'],
        'user_role'=>$login[0]['aadhar_number'],
        'user_role'=>$login[0]['pan_number'],
        'user_role'=>$login[0]['password'],
        'logged_in'=>TRUE
    );

     $this->session->set_userdata($newdata);
     $login_information_id =  $this->session->userdata('id');
     $status['online']='1';
     $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));


 }
 $this->session->set_flashdata('msg','Successfully login');
 redirect("Home");
}
function load_comment(){

  $query = $this->db->query("select * from comment_section where v_id=
    ".$_POST['v_id']." order by id  DESC limit 2");

  $row= $query->result_array();
// echo "<pre>";print_r($row)
  if(!empty($row)) foreach ($row as $gagan){
    ?>

    <div class="col-sm-1">
      <div class="single-video-author ">
         <img class="img-fluid img-responsive" src="<?php echo $gagan['photo'] ?>" alt="">
     </div>
 </div>

 <div class="col-sm-11">

    <div class="single-video-author ">

       <p><a href="#" style="color:black"><strong><?php echo $gagan['user_id'] ?></strong></a></p>


       <p style="font-size: 14px;color: gray"><?php echo $gagan['comment']; ?></p>
       <br>

       <div class="comment-title">


          <div class="row">
            <div class="col-sm-12">

              <div class="comment-title">
                <?php 

                $like1= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1'));
                $dislike= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1'));
                ?>
                <?php if ($this->session->userdata('logged_in')) {?>

                   <?php 
                   $like1_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
                   ?>
                   <?php 
                   if ($like1_khan) {
                      ?>

                      <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-up" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button> 
                  <?php }else{?>
                   <button  style="background-color: transparent;border: none;" onclick="like_comment(<?php echo  $gagan['id']; ?>);"><i class="fa fa-thumbs-up" style="color: black!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button>
               <?php }?>
               <?php 
               $dislike_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
                         // echo '<pre>'; print_r($dislike); 
               ?>
               <?php 
               if ($dislike_khan) {
                ?>


                <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>   

            <?php }else{?>
                <button  onclick="dilike_copmment(<?php echo  $gagan['id']; ?>);" style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: black!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>
            <?php }?>
            <?php 

            $comment_reply_khan= $this->Model->CountWhereRecord('comment_reply',array('comment_id'=>$gagan['id'],'video_id'=>$this->uri->segment(3)));

            ?>


            <button class="reply_btn" style="background-color: transparent;border: none;"><i class="fa fa-reply" aria-hidden="true"></i> Reply</button>

        <?php }else{?>
          <button  class="ashfakkhan" style="background-color: transparent;border: none;" ><i class="fa fa-thumbs-up " style="color: black!important"></i> &nbsp;&nbsp;<?php echo  $like1; ?> </button>
          <button  class="ashfakkhan"  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down " style="color: black!important"></i> &nbsp;&nbsp;<?php echo  $dislike; ?> </button>
          <button class="ashfakkhan" style="background-color: transparent;border: none;"><i class="fa fa-reply " aria-hidden="true"></i> Reply</button>
      <?php } ?>


  </div>

  <form method="POST" action="/org/post/{comment_id}" class="reply-form">

    <div class="form-group">
      <div class="group">
        <input type="text" required>
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Add a public comment here </label>
    </div>

</div>
<div class="button-group" style="float: right;    margin-top: -30px;">
  <button type="submit" value="Post Comment">Post comment</button>
  <button type="button" class="cancel_btn" value="Cancel">Cancel</button>
</div>
</form>

<style>
    .reply-form {
      display: none
  }
</style>

<script>
    $(function() {
      $(".reply_btn").click(function() {
        $(this).parent().parent().children('.reply-form').show();
    });
      $(".cancel_btn").click(function() {
        $(this).parent().parent().hide();
    });
  });
</script>

</div>

</div>

</div>

</div>
</div>
<?php
}
}
public function all_customer_info($value='')
{
  $user_id="oxiinctop";
  $user_info=$_SESSION['customer_table'][$user_id];
  echo '<pre>'; print_r($user_info); exit;

}
public function mydigital_api()
{
   $url = "https://www.oxiinc.com/api/customers_information";
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_HEADER, 0);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_URL, $url);
   curl_setopt($ch, CURLOPT_POST, true);
   $output = curl_exec($ch);
   curl_close($ch);

   return $output;

}
function new_login($value=''){
  $this->load->view('new_login');
}
public function server_remote($value='')
{
  echo '<pre>'; print_r($_SESSION); exit;
}

}
?>