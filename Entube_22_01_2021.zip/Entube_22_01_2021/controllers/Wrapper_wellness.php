<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Wrapper_wellness extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Wrapper_wellness_add');
        
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function Add(){
        if($this->input->post('userSubmit')){
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['Product_Picture']['name'])){
                $config['upload_path'] = 'uploads/wrapper/wellness/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['Product_Picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('Product_Picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'Product_Name' => $this->input->post('Product_Name'),
                'upend_id' => $this->input->post('upend_id'),
                // 'sub_category_name' => $this->input->post('sub_category_name'),
                'Short_Description' => $this->input->post('Short_Description'),
                'original_price' => $this->input->post('original_price'),
                'Prices' => $this->input->post('Prices'),
                'terms_conditions' => $this->input->post('terms_conditions'),
                'product_type' => $this->input->post('product_type'),
                'company_name' => $this->input->post('company_name'),
                'pack_of' => $this->input->post('pack_of'),
                'unit' => $this->input->post('unit'),
                'hsn_code' => $this->input->post('hsn_code'),
                'Offers' => $this->input->post('Offers'),
                'stock_status' => $this->input->post('stock_status'),
                'large_Description' => $this->input->post('large_Description'),
                'verified_status' => $this->input->post('verified_status'),
                'highlight_label_1' => $this->input->post('highlight_label_1'),
                'highlight_label_2' => $this->input->post('highlight_label_2'),
                'Warranty' => $this->input->post('Warranty'),
                'Return_Policy' => $this->input->post('Return_Policy'),
                'Product_Picture' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->Wrapper_wellness_add->insert($userData);
            $this->session->set_flashdata('msg','successfully your Product image uploaded');
            redirect('wrapper/wellness');
            
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}