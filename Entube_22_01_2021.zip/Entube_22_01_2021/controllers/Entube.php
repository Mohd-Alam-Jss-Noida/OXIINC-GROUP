<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');

class Entube extends CI_Controller {
    function __construct() {
        parent::__construct();

        $this->load->model('Model');
        $this->load->model('Entube_model');
        $this->load->model('Text');
        $this->load->model('Files');
        $this->load->model('Cart_model');
        $this->load->model('Add_category_model');
        $this->load->helper('cookie');
        $this->load->helper('text');
        date_default_timezone_set("Asia/Calcutta");
    }

    public function index(){
        //BANNER SECTION
        $data['banner'] = $this->Entube_model->get_banner_data($limit = 4);
        
        //RECOMMENDED VIDEOS
        $data['recommended'] = $this->Entube_model->recommended_recently_uploaded_videos($recommended = 1, $priority = '', $most_viewed = '', $limit = 10);

        //RECENTLY UPLOADED VIDEOS
        $data['recently_uploaded'] = $this->Entube_model->recommended_recently_uploaded_videos($recommended = '', $priority = 1, $most_viewed = '', $limit= 10);

        //MOST VIEWED
        $data['most_viewed'] = $this->Entube_model->recommended_recently_uploaded_videos($recommended = '', $priority = '', $most_viewed = 1, $limit = 10);

        //YOU MAY LIKE
        if ($this->session->userdata('entube_customer_logged_in')){
            $column_name = 'user_id';
            $user_like = $this->session->userdata('username');
        }elseif($this->session->userdata('logged_in')){
            $column_name = 'user_id';
            $user_like = $this->session->userdata('id');
        }else{
            $column_name = 'ip';
            $user_like = $this->input->ip_address();
        }

        $data['ip_recommended'] = $this->Entube_model->get_ip_recommended_videos($column_name, $user_like, $limit = 10);

        //echo "<pre>";print_r($data['ip_recommended']);die();
        $this->load->view('new_user/index',$data);
    }

    public function sgin_process() {
        $jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['login'];

        $user_id = htmlspecialchars($array_entity['user_id']);
        $password = $array_entity['password'];
        $userSubmit = $array_entity['userSubmit'];
        $email_id = $user_id;

        $date_time = date('Y-m-d H:i:s');
        $endTime = strtotime("-15 minutes", strtotime($date_time));
        $query = $this->db->query('SELECT * FROM ip_block WHERE ip="'.$_SERVER["REMOTE_ADDR"].'" and  date_time > (now() - interval 10 minute)');

        $attempts= $query->num_rows();

        if($attempts>="3"){
            $promo_codo['ip'] = "00000000";
            $promo_codo['date_time'] = date('Y-m-d H:i:s');
        }
        else{
            $promo_codo['ip'] = $_SERVER["REMOTE_ADDR"];
            $promo_codo['date_time'] = date('Y-m-d H:i:s');
        }    
        $email_information = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'status'=>'1'));

        if (!$email_information) {
            $data['value'] = $this->epanelist_logindetail($userSubmit,$password);
            $data['status'] = '6';
            $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
            $this->Model->insertData('ip_block',$promo_codo);
            echo json_encode($data);
            exit;
        }

        if($userSubmit){
            $password = md5($password);
            $login = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'password'=>$password,'status'=>'1'));
            if(isset($login) && !empty($login)){
                $newdata = array(
                    'id'=>$login[0]['id'],
                    'user_id'=>$login[0]['email_id'],
                    'user_name'=>$login[0]['user_name'],
                    'last_name'=>$login[0]['last_name'],
                    'user_role'=>$login[0]['contact_number'],
                    'user_role'=>$login[0]['phone_number'],
                    'user_role'=>$login[0]['shipping_address'],
                    'user_role'=>$login[0]['billing_address'],
                    'user_role'=>$login[0]['aadhar_number'],
                    'user_role'=>$login[0]['pan_number'],
                    'user_role'=>$login[0]['password'],
                    'logged_in'=>TRUE
                );

                /*$user_tracking = array(
                    'user_id' => $login[0]['id'],
                    'employee_id' => $login[0]['id'], 
                    'user_ip' => $_SERVER['REMOTE_ADDR'],
                    // 'lat_long' => $array_entity['user_location'],
                    'username' => $login[0]['user_name'],
                    'date_1'=>date("Y-m-d H:i:s"),
                    'usertype' => 0
                );
                $this->Model->insertData('users_tracking',$user_tracking);*/
                $this->session->set_userdata($newdata);
                //echo '<pre>'; print_r($newdata); exit;

                //SET COOKIE AT LOGIN TIME FOR 6 MONTHS LIFETIME ADD BY MOHD ALAM 16/05/2020
                $cookie= array(
                    'name'   => 'guest_user',
                    'value'  => $newdata['id'],
                    'expire' => time() + 60 * 60 * 24 * 180,
                );
                $this->input->set_cookie($cookie);

                $login_information_id =  $this->session->userdata('id');
                $status['online']='1';

                $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
                $this->session->set_flashdata('msg','You have logged in successfully');
                $data['status'] = '1';
                $data['msg'] = '<strong>Well done!</strong> You have logged in successfully as Guest user.';
                echo json_encode($data);
            }
            else{
                $status='1';
                $strSql = "SELECT * FROM custumer_login WHERE email_id='".$email_id."' AND Master_password='".$password."' AND status='".$status."'";
                $master =$this->Model->getSqlData($strSql);
                if (isset($master) && !empty($master)) {
                    $newdata = array(
                        'id'=>$master[0]['id'],
                        'user_id'=>$master[0]['email_id'],
                        'user_name'=>$master[0]['user_name'],
                        'user_role'=>$master[0]['contact_number'],
                        'user_role'=>$master[0]['phone_number'],
                        'user_role'=>$master[0]['shipping_address'],
                        'user_role'=>$master[0]['billing_address'],
                        'user_role'=>$master[0]['aadhar_number'],
                        'user_role'=>$master[0]['pan_number'],
                        'user_role'=>$master[0]['password'],
                        'logged_in'=>TRUE
                    );
                    /*$user_tracking = array(
                        'user_id' => $master[0]['id'],
                        'employee_id' => $master[0]['id'], 
                        'user_ip' => $_SERVER['REMOTE_ADDR'],
                        'lat_long' => $array_entity['user_location'],
                        'username' => $master[0]['user_name'],
                        'date_1'=>date("Y-m-d H:i:s"),
                        'usertype' => 0
                    );

                    $this->Model->insertData('users_tracking',$user_tracking);*/
                    $this->session->set_userdata($newdata);
                    $login_information_id =  $this->session->userdata('id');
                    $statusss['online']='1';
                    $login_id = $this->Model->updateData('custumer_login',$statusss,array('id'=>$login_information_id));

                    $data['status'] = '1';
                    $data['msg'] = '<strong>Well done!</strong> You have logged in successfully.';
                }
                else{
                    $data['status'] = '0';
                    $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
                    $this->Model->insertData('ip_block',$promo_codo);
                }
                echo json_encode($data);
            }
        }
        else{
            $data['status'] = '0';
            $this->Model->insertData('ip_block',$promo_codo);
            $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
            echo json_encode($data);
        }
    }

    public function epanelist_logindetail($username='',$password=''){
        if ((!empty($username) && !empty($password))){
            $pwd=$password;
            $uname=base64_encode($username);
            $output=$this->api_calling($uname,$pwd);
            $val_data=json_decode($output,true);
            //echo "<pre>";print_r($val_data);die();
            $undefine='1';
            if($undefine){
                if($val_data['status']=='success'){
                    $epanelist_login = array(
                        'user_id'=>$val_data['user_id'],
                        'username'=>$val_data['username'],
                        'name'=>$val_data['name'],
                        'account_type'=>$val_data['account_type'],
                        'email_verified'=>$val_data['email_verified'],
                        'employee_id'=>$val_data['employee_id'],
                        'employee_code'=>$val_data['employee_code'],
                        'profileImage'=>$val_data['profileImage'],
                        'entube_customer_logged_in'=>TRUE
                    );
                    /*$user_tracking = array(
                        'user_id' => $val_data['user_id'],
                        'employee_id' => $val_data['employee_id'], 
                        'user_ip' => $_SERVER['REMOTE_ADDR'],
                        // 'lat_long' => $_POST['user_latlong'],
                        'username' => $val_data['username'],
                        'date_1'=>date("Y-m-d H:i:s"),
                        'usertype' => 1
                    );
                    $this->Model->insertData('users_tracking',$user_tracking);*/
                    $this->session->set_userdata($epanelist_login);
                    //echo "<pre>";print_r($epanelist_login);die();

                    //SET COOKIE AT LOGIN TIME FOR 6 MONTHS LIFETIME ADD BY MOHD ALAM 16/05/2020
                    $cookie_username = array(
                        'name'   => 'epanelist_username',
                        'value'  => $epanelist_login['username'],
                        'expire' => time() + 60 * 60 * 24 * 180,
                    );
                    $this->input->set_cookie($cookie_username);

                    $cookie_name = array(
                        'name'   => 'epanelist_name',
                        'value'  => $epanelist_login['name'],
                        'expire' => time() + 60 * 60 * 24 * 180,
                    );
                    $this->input->set_cookie($cookie_name);

                    $cookie_profileImage = array(
                        'name'   => 'epanelist_profileImage',
                        'value'  => $epanelist_login['profileImage'],
                        'expire' => time() + 60 * 60 * 24 * 180,
                    );
                    $this->input->set_cookie($cookie_profileImage);

                    $data['status'] = '2';
                    $data['msg'] = '<strong>Well done!</strong> You have logged in successfully as E-Panelist User.';
                    echo json_encode($data);
                    exit;
                }
                else{
                    $data['status'] = '3';
                    $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
                    echo json_encode($data);
                    exit;
                }
            }
            else{
                $data['status'] = '4';
                $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
                echo json_encode($data);
                exit;
            }
        }
        else{
            $data['status'] = '5';
            $data['msg'] = '<strong>Oh snap!</strong> The Username or password you are entered is incorrect. Please try again.';
            echo json_encode($data);
            exit;
        }
    }

    public function register_process() {
        $jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true);
        $array_entity = $array_data['login'];
        $username = $array_entity['username'];
        $email = $array_entity['email'];
        $phone = $array_entity['phone'];
        $password = $array_entity['password'];
        $passwordconfirm = $array_entity['passwordconfirm'];
        $userSubmit = $array_entity['userSubmit'];
        if (!$username) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> please enter Your User Name';    
            echo json_encode($data);
            exit;
        }
        if (!$email) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> please enter Your Email Address';    
            echo json_encode($data);
            exit;
        }
        if (!$phone) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> please enter Your phone No'; 
            echo json_encode($data);
            exit;
        }
        if (!$password) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> please enter Your password'; 
            echo json_encode($data);
            exit;
        }
        if (!$passwordconfirm) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> please enter Confirm Password';  
            echo json_encode($data);
            exit;
        }
        if ($password!=$passwordconfirm) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> Your Password And Confirm Password Is Not Same'; 
            echo json_encode($data);
            exit;
        }

        $email_info = $this->Model->getData('custumer_login',array('email_id'=>$email));

        if ($email_info) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> This Email Address already registered with as';  
            echo json_encode($data);
            exit;
        }

        $phone_info = $this->Model->getData('custumer_login',array('contact_number'=>$phone));

        if ($phone_info) {
            $data['status'] = '0';
            $data['msg'] = '<strong>Sorry!</strong> This Phone Number already registered with as';   
            echo json_encode($data);
            exit;
        }

        if (isset($email_info) && empty($email_info)) {
            if (isset($phone_info) && empty($phone_info)) {
                $array_data=array(
                    'user_name'=>$username,
                    'email_id'=>$email,
                    'password'=>md5($password),
                    'contact_number'=>$phone,
                    'countries'=> $array_entity['countries'],
                    'states'=> $array_entity['states'],
                    'cities'=> $array_entity['cities'],
                    'isd'=> $array_entity['isd'],
                    'resigtation_month'=> date('m'),
                    'resigtation_year'=> date('Y'),
                    'resigtation_day'=> date('d'),
                    'resigtation_year_month'=> date('Y-m'),
                    'resigtation_year_month_data' =>date('Y-m-d'),
                    'resigtation_year_month_data_time'=> date('Y-m-d H:i:s'),
                );
                $user_inserted_id = $this->Model->insertData('custumer_login',array_map('strtoupper', $array_data));

                if ($user_inserted_id) {
                    $channel_array = array(
                        'user_id' => $user_inserted_id,
                        'channel_name' => $username,
                    );
                    $channel_inserted_id = $this->Model->insertData('custumer_channel', $this->security->xss_clean($channel_array));
                }

                $mobile_info = $this->Model->getData('custumer_login',array('contact_number'=>$phone));

                // INSERT DATA IN OTP TABLE AND SEND SMS
                $otp_code = mt_rand(10000,999999);
                $array_otp_data=array(
                    'mobile'=>$mobile_info[0]['contact_number'],
                    'email'=>$mobile_info[0]['email_id'],
                    'otp'=>$otp_code,
                    'created'=>date("Y-m-d H:i:s"),
                    'modified'=>date("Y-m-d H:i:s"),
                );
                $otp_inserted = $this->Model->insertData('otp',array_map('strtoupper', $array_otp_data));

                // SEND SMS CODE BY MOHD ALAM 14/05/2020
                $user = "OXIINCHEALTH";
                $password = "OXIINC@185";
                $senderId = "ENTUBE";
                $channel = "Trans";
                $dcs = "0";
                $flashsms = "0";
                $route = "6";
                $mobile = $mobile_info[0]['contact_number'];

                $text_message = $otp_code." is your EnTube Registration verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
                // echo '<pre>'; print_r($text_message);
                $sms = urlencode($text_message);

                // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

                $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=ENTUBE&accusage=1';

                try {
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_HEADER, 0);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_URL, $smsurl);
                    $data = curl_exec($ch);
                    curl_close($ch);
                    $response = $data;
                }  
                catch (Exception $e) {  
                    $response = $e->getMessage();  
                }
                // echo '<pre>'; print_r($response);

                // SEND MAIL CODE COMMENT BY MOHD ALAM 14/05/2020
                /*$user_name = $mobile_info[0]['user_name'];
                $user_names = $mobile_info[0]['user_name'];
                $to_email_address =$mobile_info[0]['email_id'];
                $subject = 'Thankyou For Register With as, Oxiinc Group';
                $emailer = 'emailer/OTP.html';
                $mail_content = file_get_contents($emailer);

                $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);
                $mail_content = str_replace('@_users_names_@', $user_names, $mail_content);
                $mail_content = str_replace('@_email_id_@', $mobile_info[0]['email_id'], $mail_content);
                $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                $mail_content = str_replace('@_otp_@', $otp_code, $mail_content);

                $headers = "From:no-reply@oxiinc.in\r\n" .
                'Reply-To: myorder@oxiinc.in' . "\r\n" .
                "MIME-Version: 1.0\r\n".
                "Content-Type: text/html; charset=ISO-8859-1\r\n";
                'X-Mailer: PHP/';

                $this->load->library('email');
                $config = Array(
                    'protocol'  => 'mail',
                    'smtp_host' => 'mail.oxiinc.in',
                    'smtp_port' => 25,
                    'smtp_user' => 'noreply@oxiinc.com',
                    'smtp_pass' => '@@noreply@@',
                    'mailtype'  => 'html',
                    'charset'   => 'iso-8859-1'
                ); 
                $this->email->initialize($config);

                $this->email->from('noreply@oxiinc.com', 'Thankyou For Register With as, Oxiinc Group');
                $this->email->to($to_email_address);
                $this->email->subject($subject); 
                $this->email->message($mail_content);

                if($this->email->send()){
                }
                else{
                }*/
                $data = [];
                if(!empty($user_inserted_id) && !empty($channel_inserted_id) && !empty($otp_inserted)){
                    $data['status'] = '1';
                    $data['phone'] = $phone;
                    $data['email'] = $email;
                    $data['msg'] = '<strong>Well done!</strong> Registration Is Complete .Plz Verify it through OTP sent on you email id and phone number.';
                    echo json_encode($data);
                    exit;
                }
                else{
                    $data['status'] = '0';
                    $data['msg'] = '<strong>Sorry!</strong> Registration failed.';    
                    echo json_encode($data);
                    exit;
                }
            }
        }
    }

    public function resend_otp(){
        $jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true);
        $array_entity = $array_data['login'];
        $phone = $array_entity['phone'];

        $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$phone));
        //echo '<pre>'; var_dump($mobile_info); exit();
        $data = [];

        if ($mobile_info) {
            $mobile = $mobile_info[0]['contact_number'];
            $email = $mobile_info[0]['email_id'];
            $count_info=$this->Model->getData('otp',array('mobile'=>$mobile,'email'=>$email));
            //echo "<pre>";print_r($count_info);die();
            $otp_count = $count_info[0]["otp_count"];
            if ($otp_count < 3) {
                $data = [];
                $otp_code = mt_rand(10000,999999);
                $user = "OXIINCHEALTH";
                $password = "OXIINC@185";
                $senderId = "ENTUBE";
                $channel = "Trans";
                $dcs = "0";
                $flashsms = "0";
                $route = "6";
                $mobile = $mobile_info[0]['contact_number'];

                $text_message = $otp_code." is your EnTube Registration verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
                // echo '<pre>'; print_r($text_message);
                $sms = urlencode($text_message);

                // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

                $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=ENTUBE&accusage=1';

                try {
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_HEADER, 0);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_URL, $smsurl);
                    $data = curl_exec($ch);
                    curl_close($ch);
                    $response = $data;
                }  
                catch (Exception $e) {  
                    $response = $e->getMessage();  
                }
                // echo '<pre>'; print_r($response);

                // SEND MAIL CODE COMMENT BY MOHD ALAM 14/05/2020
                /*$user_name = $mobile_info[0]['user_name'];
                $user_names = $mobile_info[0]['user_name'];
                $to_email_address =$mobile_info[0]['email_id'];
                $subject = 'Thankyou For Register With as, Oxiinc Group';
                $emailer = 'emailer/OTP.html';
                $mail_content = file_get_contents($emailer);
                // echo '<pre>'; print_r($mail_content); exit;

                $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);
                $mail_content = str_replace('@_users_names_@', $user_names, $mail_content);
                $mail_content = str_replace('@_email_id_@', $mobile_info[0]['email_id'], $mail_content);
                $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                $mail_content = str_replace('@_otp_@', $otp_code, $mail_content);
                //echo '<pre>'; print_r($mail_content); exit;

                $headers = "From:no-reply@oxiinc.in\r\n" .
                'Reply-To: myorder@oxiinc.in' . "\r\n" .
                "MIME-Version: 1.0\r\n".
                "Content-Type: text/html; charset=ISO-8859-1\r\n";
                'X-Mailer: PHP/';

                $this->load->library('email');

                $config = Array(
                    'protocol'  => 'mail',
                    'smtp_host' => 'mail.oxiinc.in',
                    'smtp_port' => 25,
                    'smtp_user' => 'noreply@oxiinc.com',
                    'smtp_pass' => '@@noreply@@',
                    'mailtype'  => 'html',
                    'charset'   => 'iso-8859-1'
                ); 

                $this->email->initialize($config);

                $this->email->from('noreply@oxiinc.com', 'Thankyou For Register With as, Oxiinc Group');
                $this->email->to($to_email_address);
                $this->email->subject($subject); 
                $this->email->message($mail_content);

                if($this->email->send()){
                }
                else{
                }*/

                if ($count_info) {
                    $array_data=array(
                        'otp'=>$otp_code,
                        'otp_count'=>++$otp_count,
                        'modified'=>date("Y-m-d H:i:s")
                    );
                    $otp_update_insert = $this->Model->updateData('otp', $array_data, array('mobile'=>$mobile,'email'=>$email));
                }
                else{
                    $array_data=array(
                        'mobile'=>$mobile_info[0]['contact_number'],
                        'email'=>$mobile_info[0]['email_id'],
                        'otp'=>$otp_code,
                        'created'=>date("Y-m-d H:i:s"),
                        'modified'=>date("Y-m-d H:i:s")
                    );
                    $otp_update_insert = $this->Model->insertData('otp',array_map('strtoupper', $array_data));
                }
                $data = [];
                if ($otp_update_insert) {
                    $data["status"] = "1";
                    $data['msg'] = '<strong>Well done!</strong> OTP Resent on your phone number.';
                    echo json_encode($data);
                    exit;
                }
                else{
                    $data["status"] = "0";
                    $data['msg'] = '<strong>Sorry!</strong> Resend OTP failed.';    
                    echo json_encode($data);
                    exit;
                }
            }
            else{
                $data["status"] = "0";
                $data['msg'] = '<strong>Sorry!</strong> Resend OTP send only three times.';    
                echo json_encode($data);
                exit;
            }
        }
        else{
            $data["status"] = "0";
            $data['msg'] = '<strong>Sorry!</strong> Resend OTP failed? Becouse Mobile number not valid.';    
            echo json_encode($data);
            exit;
        }
    }

    public function verfication_otp(){
        $jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['login'];

        $phone = $array_entity['phone'];
        $email = $array_entity['email'];
        $otp = $array_entity['otp'];

        $mobile_info=$this->Model->getData('otp',array('mobile'=>$phone,'email'=>$email,'otp'=>$otp));

        if ($mobile_info) {
            $var['status'] = '1';

            $this->Model->updateData('custumer_login',$var,array('contact_number'=>$phone,'email_id'=>$email));

            $login = $this->Model->getData('custumer_login',array('contact_number'=>$phone,'email_id'=>$email));
            $newdata = array(
                'id'=>$login[0]['id'],
                'user_id'=>$login[0]['email_id'],
                'user_name'=>$login[0]['user_name'],
                'user_role'=>$login[0]['contact_number'],
                'user_role'=>$login[0]['phone_number'],
                'user_role'=>$login[0]['shipping_address'],
                'user_role'=>$login[0]['billing_address'],
                'user_role'=>$login[0]['aadhar_number'],
                'user_role'=>$login[0]['pan_number'],
                'user_role'=>$login[0]['password'],
                'logged_in'=>TRUE
            );

            $this->session->set_userdata($newdata);
            $this->session->set_flashdata('msg','You have logged in successfully');
            $data['status'] = '1';
            $data['msg']= '<strong>Well done!</strong> Your Verfication Is done. Please wait while we are redirecting you on Home Page';
            echo json_encode($data);
            exit;
        }
        else {
            $data['status'] = '0';
            $data['msg'] = $array_entity['otp'];  
            echo json_encode($data);
            exit;
        }
    }

    public function watch() {
        if ($this->uri->segment(2) == 'search') {
            $video_title = $this->security->xss_clean($this->uri->segment(3));
            $query = $this->db->select('ID')->from('add_video')->where('LOWER(Video_Title)', strtolower($video_title))->where('status', 1)->where('is_deleted', 0)->get();
            $result_id = ($query->num_rows() > 0) ? $query->result_array() : FALSE;
            $video_id = $result_id[0]['ID'];
        }
        else{
            $video_id = filter_var($this->uri->segment(3), FILTER_SANITIZE_NUMBER_INT);
        }
        
        $ip = $this->input->ip_address();
        if ($this->session->userdata('entube_customer_logged_in')) {
            $vistor['post_id'] = $video_id;
            $vistor['ip'] = "1";
            $vistor['user_id'] = $this->session->userdata('username');
            $watched = $this->Model->getData('views',array('post_id'=>$video_id,'user_id'=>$vistor['user_id']));
            if(!$watched){
                $this->Model->insertData('views',$vistor);
                $watched_user = $this->Model->getData('watched_user',array('post_id'=>$video_id));
                if(!$watched_user){
                    $this->Model->insertData('watched_user',array('post_id'=>$video_id,'view'=>'1'));
                }
                else {
                    $strSqldwre123yyy="UPDATE watched_user SET view = view + 1 WHERE post_id ='".$video_id."'";
                    $this->db->query($strSqldwre123yyy);
                }
            }
        }
        elseif($this->session->userdata('logged_in')) {
            $vistor['post_id'] = $video_id;
            $vistor['ip'] = "1";
            $vistor['user_id'] = $this->session->userdata('id');
            $watched = $this->Model->getData('views',array('post_id'=>$video_id,'user_id'=>$vistor['user_id']));
            if(!$watched){
                $this->Model->insertData('views',$vistor);
                $watched_user = $this->Model->getData('watched_user',array('post_id'=>$video_id));
                if(!$watched_user){
                    $this->Model->insertData('watched_user',array('post_id'=>$video_id,'view'=>'1'));
                }
                else{
                    $strSqldwre123="UPDATE watched_user SET view = view + 1 WHERE post_id ='".$video_id."'";
                    $this->db->query($strSqldwre123);
                }
            }
        }
        else {
            $vistor['post_id'] = $video_id;
            $vistor['ip'] = $ip;
            $watched = $this->Model->getData('views',array('post_id'=>$video_id,'ip'=>$ip));
            if(!$watched){
                $this->Model->insertData('views',$vistor);
                $watched_user = $this->Model->getData('watched_user',array('post_id'=>$video_id));
                if(!$watched_user){
                    $this->Model->insertData('watched_user',array('post_id'=>$video_id,'view'=>'1'));
                }
                else{
                    $strSqldwre="UPDATE watched_user SET view = view + 1 WHERE post_id ='".$video_id."'";
                    $this->db->query($strSqldwre);
                }
            }
        }

        $data['watch'] = $this->Entube_model->watch_video($video_id);
        $next_video = $this->Entube_model->watch_next_video($data['watch'][0]['category_id'], $video_id);
        shuffle($next_video);
        $data['watch_next'] = $next_video[0];

        //echo "<pre>";print_r($data['watch_next']);die();
        $data['main_containt']='new_user/watch_video';
        $this->load->view('new_user/containt', $data);
    }

    public function watch_more_videos_on_page_load(){
        //echo "<pre>";print_r($_POST);die();
        $load_more_video = $this->Entube_model->watch_more_videos_on_page_load($_POST['next_video_id'], $_POST['video_limit']);
        if(isset($load_more_video) && !empty($load_more_video)) foreach ($load_more_video as $key => $value){
            if($value['channel_name']) {
                $channel_name = $value['channel_name'];
            } elseif ($value['user_id']) {
                $channel_name = $value['user_id'];
            } else{
                $channel_name = OXIINC_CHANNEL;
            }

            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');
            ?>
            <div class="video-card">
                <div class="video-card-img">
                    <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>">
                        <img src="<?php echo $video_image;?>" class="trending-mp-video-img" alt="" />
                        <i class="fas fa-play-circle"></i>
                        <div class="video-overlay"></div>
                    </a>
                </div>
                <div class="video-card-info">
                    <span class="title">
                        <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>"><?php echo $value['Video_Title']; ?></a>
                    </span>
                    <span class="channel-title">
                        <a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name ;?> <i class="far fa-check-circle"></i></a>
                    </span>
                    <span>
                        <i class="far fa-eye"></i> <?php echo ($value['view'] > 0) ? $value['view']." views" : " 0 view"; ?>
                        <i class="far fa-calendar-alt" style="margin-left: 30px;"></i>
                        <?php
                        $FromDate = new DateTime(date("Y-m-d H:i:s"));
                        $ToDate   = new DateTime($value['datatime']);
                        $Interval = $FromDate->diff($ToDate);

                        $Difference["Hours"] = $Interval->h;

                        $Difference["Weeks"] = floor($Interval->d/7);
                        $Difference["Days"] = $Interval->d % 7;
                        $Difference["Months"] = $Interval->m;
                        $Difference["minute"] = $Interval->i;
                        $Difference["second"] = $Interval->s;
                        $Difference["Year"] = $Interval->y;

                        if($Difference["Year"]){
                            echo $Difference["Year"]." "."Year";
                        }else
                        if($Difference["Months"]){
                            echo $Difference["Months"]." "."Months";
                        }else
                        if($Difference["Weeks"]){
                            echo $Difference["Weeks"]." "."Weeks";
                        }else
                        if($Difference["Days"]){
                            echo $Difference["Days"]." "."Days";
                        }else
                        if($Difference["Hours"]){
                            echo $Difference["Hours"]." "."Hours";
                        }else
                        if($Difference["minute"]){
                            echo $Difference["minute"]." "."Minute";
                        }else
                        if($Difference["second"]){
                            echo $Difference["second"]." "."Second";
                        } 
                        echo " "."ago";
                        ?>
                    </span>
                </div>
                <span class="dropdown video-login-popup video-login-popup2">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
                        <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
                        <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
                    </ul>
                </span>
            </div>
            <?php 
        }
    }

    public function page_load_comment() {
        $query = $this->db->query("SELECT * FROM comment_section WHERE v_id=".$_POST['v_id']." AND status = 1 order by id  DESC LIMIT ".$_POST['comment_limit']);
        $row= $query->result_array();
            //echo "<pre>";print_r($row);die();
        if(!empty($row)) foreach ($row as $gagan){ ?>
            <div class="col-left space-left user-comment-col">
                <a href="<?php echo base_url("Entube/channel/".$this->session->userdata('user_id')); ?>"><img src="<?php echo $gagan['photo'] ?>" alt="" class="channel-logo" width="40px" height="40px" style="border-radius: 50%;"></a>
                <span class="title-05 fwd"><?php echo $gagan['user_id']; ?></span>
                <span class="title-06 fwd"><?php echo $gagan['comment']; ?></span>
                <?php
                $like1=$this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1'));
                $dislike= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1'));
                if ($this->session->userdata('logged_in')) {
                    $like1_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
                                    //echo "<pre>";print_r($like1_khan);die();
                    if ($like1_khan) { ?>
                        <span class="user-likes-video"><i class="far fa-thumbs-up" style="color: blue!important"></i> <?php echo  $like1; ?></span>
                    <?php }
                    else{ ?>
                        <span class="user-likes-video" onclick="like_comment(<?php echo  $gagan['id']; ?>);"><i class="far fa-thumbs-up"></i> <?php echo  $like1; ?></span>
                    <?php }
                    $dislike_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
                    if ($dislike_khan) { ?>
                        <span class="user-likes-video"><i class="far fa-thumbs-down" style="color: blue!important"></i> <?php echo  $dislike; ?></span>
                    <?php }
                    else{ ?>
                        <span class="user-likes-video" onclick="dilike_copmment(<?php echo  $gagan['id']; ?>);"><i class="far fa-thumbs-down"></i> <?php echo  $dislike; ?></span>
                    <?php }
                    $comment_reply_khan= $this->Model->CountWhereRecord('comment_reply',array('comment_id'=>$gagan['id'],'video_id'=>$this->uri->segment(3)));
                }
                else if($this->session->userdata('entube_customer_logged_in')) {
                    $like1_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('employee_id')));
                                    //echo "<pre>";print_r($like1_khan);die();
                    if ($like1_khan) { ?>
                        <span class="user-likes-video" style="color: blue!important"><i class="far fa-thumbs-up"></i> <?php echo  $like1; ?></span>
                    <?php } else{ ?>
                        <span class="user-likes-video" onclick="like_comment1(<?php echo $gagan['id']; ?>);"><i class="far fa-thumbs-up"></i> <?php echo  $like1; ?></span>
                    <?php }
                    $dislike_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('employee_id')));
                    if ($dislike_khan) { ?>
                        <span class="user-likes-video" style="color: blue!important"><i class="far fa-thumbs-down"></i> <?php echo  $dislike; ?></span>
                    <?php }else{ ?>
                        <span class="user-likes-video" onclick="dilike_copmment1(<?php echo $gagan['id']; ?>);"><i class="far fa-thumbs-down"></i> <?php echo  $dislike; ?></span>
                    <?php }
                    $comment_reply_khan= $this->Model->CountWhereRecord('comment_reply',array('comment_id'=>$gagan['id'],'video_id'=>$this->uri->segment(3)));
                }
                else { ?>
                    <span class="user-likes-video" data-toggle="modal" data-target="#EPanelistloginModal"><i class="far fa-thumbs-up"></i> <?php echo  $like1; ?></span>
                    <span class="user-likes-video" data-toggle="modal" data-target="#EPanelistloginModal"><i class="far fa-thumbs-down"></i> <?php echo  $dislike; ?></span>
                <?php } ?>
                <div class="reply-form">
                    <form method="POST" action="/org/post/{comment_id}" >
                        <div class="form-group">
                            <div class="group">
                                <input type="text" required>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                            </div>
                        </div>
                        <div class="button-group" style="float: right; margin-top: -30px;">
                            <button type="submit" value="Post Comment">Post comment</button>
                            <button type="button" class="cancel_btn" value="Cancel">Cancel</button>
                        </div>
                    </form>
                </div>
                <style>
                    .reply-form {
                        display: none
                    }
                </style>
                <script>
                    $(function() {
                        $(".reply_btn").click(function() {
                            $(this).parent().parent().children('.reply-form').show();
                        });
                        $(".cancel_btn").click(function() {
                            $(this).parent().parent().hide();
                        });
                    });
                </script>
            </div>
            <?php
        }
    }

    public function trending(){
        $limit_val = 10; $offset_val = 0;
        $data['most_viewed'] = $this->Entube_model->get_videos_orderby_view_desc($limit_val, $offset_val);
        $data['Recently_uploaded'] = $this->Entube_model->get_videos_orderby_id_desc($limit_val, $offset_val);
        //echo "<pre>";print_r($data['most_viewed']);die();
        $data['main_containt'] = 'new_user/trending';
        $this->load->view('new_user/containt', $data);
    }

    public function trending_videos_on_page_scroll() {
        $most_viewed = $this->Entube_model->get_videos_orderby_view_desc($_POST['data_limit'], $_POST['data_offset']);
        if(isset($most_viewed) && !empty($most_viewed)) foreach ($most_viewed as $key => $value) {
            if($value['channel_name']) {
                $channel_name = $value['channel_name'];
            } elseif ($value['user_id']) {
                $channel_name = $value['user_id'];
            } else{
                $channel_name = OXIINC_CHANNEL;
            }

            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

            if($value['channel_logo']) {
                $channel_logo = $value['channel_logo'];
            } elseif ($channel_name == OXIINC_CHANNEL) {
                $channel_logo = 'oxiinc-digital-icon.png';
            } else{
                $channel_logo = 'channel-logo.jpg';
            }
            ?>
            <div class="item equal-height-col">
                <div class="item-containt-col">
                    <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
                        <img src="<?php echo $video_image ;?>" class="trending-video-item-img" alt="" />
                        <i class="fas fa-play-circle"></i>
                        <div class="video-overlay"></div>
                    </a>
                    <div class="video-containt-col">
                        <div class="chanel-img-col">
                            <a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
                                <img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
                            </a>
                        </div>
                        <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo $value['Video_Title']; ?></a>
                        <a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>" class="video-channel" style="color:#fff;"><?php echo $channel_name; ?> <i class="fas fa-check-circle"></i></a>
                        <div class="video-views">
                            <span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
                            <span><i class="far fa-calendar-alt"></i>
                                <?php
                                $FromDate = new DateTime(date("Y-m-d H:i:s"));
                                $ToDate   = new DateTime($value['datatime']);
                                $Interval = $FromDate->diff($ToDate);
                                $Difference["Hours"] = $Interval->h;
                                $Difference["Weeks"] = floor($Interval->d/7);
                                $Difference["Days"] = $Interval->d % 7;
                                $Difference["Months"] = $Interval->m;
                                $Difference["minute"] = $Interval->i;
                                $Difference["second"] = $Interval->s;
                                $Difference["Year"] = $Interval->y;
                                if($Difference["Year"]){
                                    echo $Difference["Year"]." "."Year";
                                }else
                                if($Difference["Months"]){
                                    echo $Difference["Months"]." "."Months";
                                }else
                                if($Difference["Weeks"]){
                                    echo $Difference["Weeks"]." "."Weeks";
                                }else
                                if($Difference["Days"]){
                                    echo $Difference["Days"]." "."Days";
                                }else
                                if($Difference["Hours"]){
                                    echo $Difference["Hours"]." "."Hours";
                                }else
                                if($Difference["minute"]){
                                    echo $Difference["minute"]." "."Minute";
                                }else
                                if($Difference["second"]){
                                    echo $Difference["second"]." "."Second";
                                }
                                echo " "."ago";
                                ?>
                            </span>
                        </div>
                    </div>
                    <span class="dropdown video-login-popup video-login-popup2">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
                            <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
                        </ul>
                    </span>
                </div>
            </div>
            <?php
        }
    }

    public function recently_videos_on_page_scroll() {
        $Recently_uploaded = $this->Entube_model->get_videos_orderby_id_desc($_POST['data_limit'], $_POST['data_offset']);
        if(isset($Recently_uploaded) && !empty($Recently_uploaded)) foreach ($Recently_uploaded as $key => $value) {
            if($value['channel_name']) {
                $channel_name = $value['channel_name'];
            } elseif ($value['user_id']) {
                $channel_name = $value['user_id'];
            } else{
                $channel_name = OXIINC_CHANNEL;
            }

            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');
            ?>
            <div class="video-card">
                <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-card-img">
                    <img src="<?php echo $video_image ;?>" class="trending-mp-video-img" alt=""/>
                    <i class="fas fa-play-circle"></i>
                    <div class="video-overlay"></div>
                </a>
                <div class="video-card-info">
                    <span class="title"><a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>"><?php echo $value['Video_Title']; ?></a></span>
                    <span class="channel-title"><a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name; ?> <i class="far fa-check-circle"></i></a></span>
                    <span class="views_and_date">
                        <i class="far fa-eye"></i> <?php echo ($value['view'] > 0) ? $value['view']." views" : " 0 view"; ?>
                        <i class="far fa-calendar-alt" style="margin-left: 30px;"></i>
                        <?php
                        $FromDate = new DateTime(date("Y-m-d H:i:s"));
                        $ToDate   = new DateTime($value['datatime']);
                        $Interval = $FromDate->diff($ToDate);
                        $Difference["Hours"] = $Interval->h;
                        $Difference["Weeks"] = floor($Interval->d/7);
                        $Difference["Days"] = $Interval->d % 7;
                        $Difference["Months"] = $Interval->m;
                        $Difference["minute"] = $Interval->i;
                        $Difference["second"] = $Interval->s;
                        $Difference["Year"] = $Interval->y;

                        if($Difference["Year"]){
                            echo $Difference["Year"]." "."Year";
                        }else
                        if($Difference["Months"]){
                            echo $Difference["Months"]." "."Months";
                        }else
                        if($Difference["Weeks"]){
                            echo $Difference["Weeks"]." "."Weeks";
                        }else
                        if($Difference["Days"]){
                            echo $Difference["Days"]." "."Days";
                        }else
                        if($Difference["Hours"]){
                            echo $Difference["Hours"]." "."Hours";
                        }else
                        if($Difference["minute"]){
                            echo $Difference["minute"]." "."Minute";
                        }else
                        if($Difference["second"]){
                            echo $Difference["second"]." "."Second";
                        } 
                        echo " "."ago";
                        ?>
                    </span>
                </div>
                <span class="dropdown video-login-popup video-login-popup2">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
                        <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
                        <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
                    </ul>
                </span>
            </div>
            <?php
        }
    }

    public function autocomplete_search() {
        $search_array = $this->Entube_model->autocomplete_search($_GET['search_data']);
        echo json_encode($search_array);
    }

    public function search(){
        $data = array();
        $limit_val = 10; $offset_val = 0;
        if(isset($_POST['auto_search']) && !empty($_POST['auto_search'])){
            $video_title = $this->security->xss_clean(trim($_POST['auto_search']));
            $data['search_result'] = $this->Entube_model->search($video_title, $limit_val, $offset_val);
            $data['video_title'] = $video_title;
        } elseif(!empty($this->uri->segment(3))){
            $video_title = $this->security->xss_clean(lcfirst(trim($this->uri->segment(3))));
            $video_title = preg_split('/(?=[A-Z])/', $video_title);
            $video_title = implode(" ",$video_title);
            $data['search_result'] = $this->Entube_model->search($video_title, $limit_val, $offset_val);
            $data['video_title'] = $video_title;
        }
        //echo "<pre>";print_r($_POST);die();
        $data['main_containt']='new_user/search';
        $this->load->view('new_user/containt', $data);
    }

    public function search_videos_on_page_scroll(){
        $search_result = $this->Entube_model->search($_POST['video_title'], $_POST['data_limit'], $_POST['data_offset']);
        if(isset($search_result) && !empty($search_result)) foreach ($search_result as $key => $value) {
            if($value['channel_name']) {
                $channel_name = $value['channel_name'];
            } elseif ($value['user_id']) {
                $channel_name = $value['user_id'];
            } else{
                $channel_name = OXIINC_CHANNEL;
            }

            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

            if($value['channel_logo']) {
                $channel_logo = $value['channel_logo'];
            } elseif ($channel_name == OXIINC_CHANNEL) {
                $channel_logo = 'oxiinc-digital-icon.png';
            } else{
                $channel_logo = 'channel-logo.jpg';
            }
            ?>
            <div class="item equal-height-col">
                <div class="item-containt-col">
                    <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
                        <img src="<?php echo $video_image ;?>" class="trending-video-item-img" alt="" />
                        <i class="fas fa-play-circle"></i>
                        <div class="video-overlay"></div>
                    </a>
                    <div class="video-containt-col">
                        <div class="chanel-img-col">
                            <a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
                                <img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
                            </a>
                        </div>
                        <a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo $value['Video_Title']; ?></a>
                        <a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>" class="video-channel" style="color:#fff;"><?php echo $channel_name; ?> <i class="fas fa-check-circle"></i></a>
                        <div class="video-views">
                            <span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
                            <span><i class="far fa-calendar-alt"></i>
                                <?php
                                $FromDate = new DateTime(date("Y-m-d H:i:s"));
                                $ToDate   = new DateTime($value['datatime']);
                                $Interval = $FromDate->diff($ToDate);
                                $Difference["Hours"] = $Interval->h;
                                $Difference["Weeks"] = floor($Interval->d/7);
                                $Difference["Days"] = $Interval->d % 7;
                                $Difference["Months"] = $Interval->m;
                                $Difference["minute"] = $Interval->i;
                                $Difference["second"] = $Interval->s;
                                $Difference["Year"] = $Interval->y;
                                if($Difference["Year"]){
                                    echo $Difference["Year"]." "."Year";
                                }else
                                if($Difference["Months"]){
                                    echo $Difference["Months"]." "."Months";
                                }else
                                if($Difference["Weeks"]){
                                    echo $Difference["Weeks"]." "."Weeks";
                                }else
                                if($Difference["Days"]){
                                    echo $Difference["Days"]." "."Days";
                                }else
                                if($Difference["Hours"]){
                                    echo $Difference["Hours"]." "."Hours";
                                }else
                                if($Difference["minute"]){
                                    echo $Difference["minute"]." "."Minute";
                                }else
                                if($Difference["second"]){
                                    echo $Difference["second"]." "."Second";
                                }
                                echo " "."ago";
                                ?>
                            </span>
                        </div>
                    </div>
                    <span class="dropdown video-login-popup video-login-popup2">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
                            <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
                        </ul>
                    </span>
                </div>
            </div>
            <?php
        }
    }

    public function history(){
        /*if($this->session->userdata('entube_customer_logged_in')){
            $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('username').'" LIMIT 0,16');
        }elseif($this->session->userdata('logged_in')){
            $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('id').'" LIMIT 0,16'); 
        }else{
            $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  ip="'.$this->input->ip_address().'" LIMIT 0,16'); 
        }
        $row['like']= $query->result_array();
        $this->load->view('watch_history',$row);*/

        if($this->session->userdata('entube_customer_logged_in')){
            $user_id = $this->session->userdata('username');
        }elseif($this->session->userdata('logged_in')){
            $user_id = $this->session->userdata('id');
        }else{
            redirect(base_url('Entube/logout'));
        }
        $limit_val = 10; $offset_val = 0;
        $data['Watch_history'] = $this->Entube_model->get_Watch_history($limit_val, $offset_val, $user_id);

        //echo "<pre>";print_r($data['Watch_history']);die();
        $data['main_containt'] = 'new_user/history';
        $this->load->view('new_user/containt', $data);
    }

    public function comment_section(){
        $data = $this->security->xss_clean($_POST);
        // echo "<pre>";print_r($data);exit();
        $this->Model->insertData('comment_section',$data);
        redirect($_POST['url']);
    }

    public function watch_later(){
        // echo "<pre>";print_r()
        $this->Model->insertData('watch_later',$_POST);
    }

    public function comment_update(){
        $order_data = array(
            'comment'=>$_POST['comment'],
            // 'sub_option' => $sub_option[$i],
        );
        $this->Model->updateData('comment_section',$order_data,array('id'=>$_POST['id']));
        redirect($_POST['url']);
    }

    public function Category_videos() {
        $ID = $this->uri->segment(3);
        $data['category_name_'] = $this->uri->segment(2);
        $query = $this->db->query("select * from  add_video where category_id=$ID and status=1 order by id desc limit 0,16");
        $data['Category_videos']= $query->result_array();
        $query_type = $this->db->query("select * from  category where category_id=$ID");
        $category_type= $query_type->result_array();
        $data['category_type']= $category_type[0]['category_name'];
        $this->load->view('Category_videos12',$data);
    }

    public function Epanelist_login(){
        $user_id = $this->input->post('user_id');
        $username = $this->input->post('username');
        $name = $this->input->post('name');
        $account_type = $this->input->post('account_type');
        $email_verified = $this->input->post('email_verified');
        $employee_id = $this->input->post('employee_id');
        $employee_code = $this->input->post('employee_code');
        $profileImage = $this->input->post('profileImage');

        $epanelist_login = array(
            'user_id'=>$user_id,
            'username'=>$username,
            'name'=>$name,
            'account_type'=>$account_type,
            'email_verified'=>$email_verified,
            'employee_id'=>$employee_id,
            'employee_code'=>$employee_code,
            'profileImage'=>$profileImage,
            'entube_customer_logged_in'=>TRUE
        );

        $this->session->set_userdata($epanelist_login);
        $login_information_id =  $this->session->userdata('employee_id');
                // echo '<pre>'; print_r($login_information_id); exit;
        $this->session->set_flashdata('msg','login Successfully.');
        redirect('Entube');
    }

    public function cart_shopping() {
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('add_to_cart1',$data);
        // echo "<pre>";print_r($data);exit;
    }

    public function liked_video(){
        if($this->session->userdata('entube_customer_logged_in')){
            $query = $this->db->query('SELECT * FROM like_dislike WHERE like1=1  AND  user_id="'.$this->session->userdata('username').'" ORDER BY id DESC');
        }elseif($this->session->userdata('logged_in')){
            $query = $this->db->query('SELECT * FROM like_dislike WHERE like1=1  AND  user_id="'.$this->session->userdata('id').'" ORDER BY id DESC'); 
        }
        $row['like']= $query->result_array();
        $this->load->view('liked_video',$row);
    }

    public function watch_later_video(){
        if($this->session->userdata('entube_customer_logged_in')){
           $query = $this->db->query('SELECT DISTINCT v_id FROM watch_later WHERE status=1  AND  user_id="'.$this->session->userdata('username').'" ');
        }elseif($this->session->userdata('logged_in')){
            $query = $this->db->query('SELECT DISTINCT v_id FROM watch_later WHERE status=1  AND  user_id="'.$this->session->userdata('id').'" ');
        }
        $row['like']= $query->result_array();
        $this->load->view('watch_later_video_khan',$row);
    }

    public function watch_history_loadmore(){
        if($this->session->userdata('entube_customer_logged_in')){
            $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('username').'" LIMIT 0,'.$_POST['id']);
        }elseif($this->session->userdata('logged_in')){
            $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  user_id="'.$this->session->userdata('id').'" LIMIT 0,'.$_POST['id']); 
        }else{
            $query = $this->db->query('SELECT DISTINCT(post_id) FROM views WHERE  ip="'.$this->input->ip_address().'" LIMIT 0,'.$_POST['id']); 
        }
        $like= $query->result_array();
        if(isset($like) && !empty($like)) foreach ($like as $value) {
            $row1 = $this->Model->getData('add_video',array('ID'=>$value['post_id']));
            if($row1){
                $category_name_info_khan = $this->Model->getData('category',array('status'=>1,'category_id'=>$row1[0]['category_id']));
                ?>
                <div class="video-card video-card-list" id="div1">
                    <div class="video-card-image">
                        <a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['post_id']); ?>"><img class="img-fluid img-responsive" src="<?php echo base_url().'uploads/product/'.$row1[0]['picture'];?>" alt="<?php echo "#"."History  ".$row1[0]['Video_Title']; ?>"></a>
                    </div>
                    <div class="video-card-body">
                        <div class="btn-group float-right right-action">
                            <a href="#" class="right-action-link text-gray" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <button style="background-color: transparent; border: none;" id="avinash">  <i class="fa fa-times" ></i></button>
                            </a>
                            <script>
                                $(document).ready(function(){
                                    $("#avinash").click(function(){
                                        $("#div1").remove();
                                                 // alert("avinash");
                                             });
                                });
                            </script>
                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                        </div>
                        <div class="video-title">
                            <a href="<?php echo base_url("watch/".$category_name_info_khan[0]['seo_category_name']."/".$value['post_id']); ?>" style="font-size: 15px;color:black !important; " ><?php echo $row1[0]['Video_Title']; ?></a>
                        </div>
                        <div class="video-page text-success">
                            <?php echo $category_name_info_khan[0]['seo_category_name']; ?><a title="" data-placement="top" data-toggle="tooltip" href="#" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>
                        </div>
                        <div class="video-view" style="font-size: 15px;color:black">
                            <?php 
                            $watch_most = $this->Model->getData('watched_user',array('post_id'=>$row1[0]['ID']));
                            echo $watch_most[0]['view'];
                            ?> views &nbsp;<i class="fas fa-calendar-alt"></i> 
                            <?php 
                            $FromDate = new DateTime(date("Y-m-d H:i:s"));
                            $ToDate   = new DateTime($row1[0]['datatime']);
                            $Interval = $FromDate->diff($ToDate);
                            $Difference["Hours"] = $Interval->h;
                            $Difference["Weeks"] = floor($Interval->d/7);
                            $Difference["Days"] = $Interval->d % 7;
                            $Difference["Months"] = $Interval->m;
                            $Difference["minute"] = $Interval->i;
                            $Difference["second"] = $Interval->s;
                            $Difference["Year"] = $Interval->y;

                            if($Difference["Year"]){
                                echo $Difference["Year"]." "."Year";
                            }else
                            if($Difference["Months"]){
                                echo $Difference["Months"]." "."Months";
                            }else
                            if($Difference["Weeks"]){
                                echo $Difference["Weeks"]." "."Weeks";
                            }else
                            if($Difference["Days"]){
                                echo $Difference["Days"]." "."Days";
                            }else
                            if($Difference["Hours"]){
                                echo $Difference["Hours"]." "."Hours";
                            }else
                            if($Difference["minute"]){
                                echo $Difference["minute"]." "."Minute";
                            }else
                            if($Difference["second"]){
                                echo $Difference["second"]." "."Second";
                            } 
                            echo " "."ago";
                            ?>
                        </div>
                    </div>
                </div>
                <?php
            }
        }
    }

    public function add(){
        $this->load->model('Cart_model');
        $insert_room = array(
            'id' => $this->input->post('ID'),
            'name' => $this->input->post('Product_Name'),
            'price' => $this->input->post('Prices'),
            'qty' => 1
        );
        $this->cart->insert($insert_room);
        redirect('Entube/cart_shopping');
    }   

    public function like_dislike() {
        if($this->session->userdata('entube_customer_logged_in')){
            $query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$_POST['v_id'].'  AND  user_id="'.$this->session->userdata('username').'"');
        } elseif($this->session->userdata('logged_in')){
            $query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$_POST['v_id'].'  AND  user_id="'.$this->session->userdata('id').'"');
        }
        $row= $query->result_array();
        $num=$query->num_rows();
        if ($num) {
                    # code...
            $this->Model->updateData('like_dislike',$_POST,array('id'=>$row[0]['id']));
        }else{
            $this->Model->insertData('like_dislike',$_POST);
                    // echo "<pre>";print_r($_POST);exit;
        }
    }

    public function get_limit(){
        $limit = 5;
        return $limit;
    }

    public function get_offer(){
        $offset = $this->url->segment(4);
        if(!is_numberic($offset)){
            $offset=0;
        }
        return $offset;
    }

    public function get_setting_public_bootstrap(){
        $settings['num_links'] = 10;

        $settings['full_tag_open']='<nav aria-label="Page navigation"><ul class="pagination">';
        $settings['full_tag_close']='</ul>';

        $settings['cur_tag_open']='<li class="disabled"><a href="#"';
        $settings['cur_tag_close']='</a></li>';

        $settings['num_tag_open']='<li>';
        $settings['num_tag_close']='</li>';

        $settings['first_link']='First';
        $settings['first_tag_open']='<li>';
        $settings['first_tag_close']='</li>';

        $settings['last_link']='Last';
        $settings['last_tag_open']='<li>';
        $settings['last_tag_close']='</li>';

        $settings['prev_link']='<span aria-hidden="true">&laquo;</span>';
        $settings['prev_tag_open']='<li>';
        $settings['prev_tag_close']='</li>';

        $settings['next_link']='<span aria-hidden="true">&raquo;</span>';
        $settings['next_tag_open']='<li>';
        $settings['next_tag_close']='</li>';
        return $settings;
    }

    public function add_to_cart(){
        $ID = $_GET['ID'];
                    // echo '<pre>'; print_r($ID); exit;
        $table = $this->Model->getData('wellness',array('ID'=>$ID));
                    // echo '<pre>'; print_r($table); exit;
        $data['table']=$table;
        $product_category_id = $table[0]['product_category_id'];
        $sub_category_id = $table[0]['sub_category_id'];
        $category_id = $table[0]['category_id'];

        if ($this->session->userdata('logged_in')) {
            $id =  $this->session->userdata('id'); 
            $custumer_login = $this->Model->getData('custumer_login',array('id'=>$id));
            $vistor['user_name'] = $custumer_login[0]['user_name'];
            $vistor['email_id'] = $custumer_login[0]['email_id'];
            $vistor['contact_number'] = $custumer_login[0]['contact_number'];
            $vistor['customer_id'] = $custumer_login[0]['id'];
            $vistor['product_id'] = $table[0]['ID'];
            $vistor['product_category_id'] = $table[0]['product_category_id'];
            $vistor['sub_category_id'] = $table[0]['sub_category_id'];
            $vistor['category_id'] = $table[0]['category_id'];
            $vistor['sub_category_name'] = $table[0]['sub_category_name'];
            $vistor['Product_Name'] = $table[0]['Product_Name'];
            $vistor['Original_Prices'] = $table[0]['Original_Prices'];
            $vistor['Prices'] = $table[0]['Prices'];
            $vistor['GST_Persentage'] = $table[0]['GST_Persentage'];
            $vistor['Shipping_Charges'] = $table[0]['Shipping_Charges'];
            $vistor['SKU'] = $table[0]['SKU'];
            $vistor['Vistor_month'] = date('m');
            $vistor['Vistor_year'] = date('Y');
            $vistor['Vistor_day'] = date('d');
            $vistor['Vistor_year_month'] = date('Y-m');
            $vistor['Vistor_year_month_data'] = date('Y-m-d');
            $vistor['Vistor_year_month_data_time'] = date('Y-m-d H:i:s');
                        // echo '<pre>'; print_r($vistor); exit;
            $this->Model->insertData('vistors',$vistor);
        }else{
            $vistor['product_id'] = $table[0]['ID'];
            $vistor['product_category_id'] = $table[0]['product_category_id'];
            $vistor['sub_category_id'] = $table[0]['sub_category_id'];
            $vistor['category_id'] = $table[0]['category_id'];
            $vistor['sub_category_name'] = $table[0]['sub_category_name'];
            $vistor['Product_Name'] = $table[0]['Product_Name'];
            $vistor['Original_Prices'] = $table[0]['Original_Prices'];
            $vistor['Prices'] = $table[0]['Prices'];
            $vistor['GST_Persentage'] = $table[0]['GST_Persentage'];
            $vistor['Shipping_Charges'] = $table[0]['Shipping_Charges'];
            $vistor['SKU'] = $table[0]['SKU'];
            $vistor['Vistor_month'] = date('m');
            $vistor['Vistor_year'] = date('Y');
            $vistor['Vistor_day'] = date('d');
            $vistor['Vistor_year_month'] = date('Y-m');
            $vistor['Vistor_year_month_data'] = date('Y-m-d');
            $vistor['Vistor_year_month_data_time'] = date('Y-m-d H:i:s');
                        // echo '<pre>'; print_r($vistor); exit;
            $this->Model->insertData('vistors',$vistor);
        }
        $data['multiple_picture'] = $this->Model->getData('multiple_picture',array('Product_id'=>$ID));

        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $data['reviews_ratings'] = $this->Model->getData('reviews_ratings',array('Product_id'=>$ID));

        $data['total_row']= $this->Model->CountWhereRecord('reviews_ratings',array('Product_id'=>$ID));

        $data['product_category_id']= $this->Model->getData('wellness',array('product_category_id'=>$product_category_id));

        $data['sub_category_id'] = $this->Model->getDataOrderBy('wellness',array('sub_category_id'=>$sub_category_id),'Prices','DESC');
        $data['category_id'] = $this->Model->getDataOrderBy('wellness',array('category_id'=>$category_id),'ID','DESC');
        $this->load->view('add_to_cart',$data);
    }

    public function add_cart_page() {
        $ID = $_GET['ID'];
        $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('add_to_cart1',$data);
    }

    public function add_product() {
        $id = $this->input->post('id');
        $produtname = $this->input->post('produtname');
        $price = $this->input->post('price');
        $picture = $this->input->post('picture');
        $original = $this->input->post('original');
        $offer = $this->input->post('offer');
        $size = $this->input->post('size');
        $qty='1';
                    // $qty = $this->input->post('qty');
        $company_name = $this->input->post('company_name');
        $verified_status = $this->input->post('verified_status');

        $data = array(
            'id'      => $id,
            'qty'     => $qty,
            'price'   => $price,
            'name'    => $produtname,
            'picture' => $picture,
            'original' => $original,
            'size' => $size,
            'offer' => $offer,
            'company_name'=> $company_name,
            'verified_status'=> $verified_status
        );
        $data['cart'] = $this->cart->insert($data);
    }

    public function Compare(){
        $this->load->helper('array');
        $id = $this->input->post('id');
        $produtname = $this->input->post('produtname');
        $price = $this->input->post('price');
        $picture = $this->input->post('picture');
        $original = $this->input->post('original');
        $offer = $this->input->post('offer');
        $company_name = $this->input->post('company_name');
        $verified_status = $this->input->post('verified_status');

        $data = array(
            'id'      => $id,
                                // 'qty'     => '1',
            'price'   => $price,
            'name'    => $produtname,
            'picture' => $picture,
            'original' => $original,
            'offer' => $offer,
            'company_name'=> $company_name,
            'verified_status'=> $verified_status
        );
    }

    public function Notify(){
        $datas['Customer_id'] =  $this->session->userdata('id');
        $datas['Product_id']= $this->input->post('id');
        $datas['Product_Name'] = $this->input->post('produtname');
        $datas['Prices'] = $this->input->post('price');
                        // $data['Product_picture'] = $this->input->post('picture');
        $datas['Original_Prices'] = $this->input->post('original');
        $data['offer'] = $this->input->post('offer');
        $datas['company_name'] = $this->input->post('company_name');
        $datas['verified_status'] = $this->input->post('verified_status');

                             // $Product_info= $this->Model->getData('wellness',array('ID'=>$id));
        $id=$this->Model->insertData('notify',$datas);
        echo '<pre>'; print_r($datas); 
        echo '<pre>'; print_r($id); 
    }

    public function whishlist(){
        $datas['Customer_id'] =  $this->session->userdata('id');
        $datas['Product_id']= $this->input->post('id');
        $datas['Product_Name'] = $this->input->post('produtname');
        $datas['Prices'] = $this->input->post('price');
                        // $data['Product_picture'] = $this->input->post('picture');
        $datas['Original_Prices'] = $this->input->post('original');
        $data['offer'] = $this->input->post('offer');
        $datas['company_name'] = $this->input->post('company_name');
        $data['verified_status'] = $this->input->post('verified_status');
        $this->Model->insertData('wishlist',$datas);
        echo '<pre>'; print_r($datas);
    }

    public function Rating_review(){
        $Rating_review=$_POST;
        $id = $this->Model->insertData('reviews_ratings',$Rating_review);
    }

    public function Compare_page(){
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('Compare_page',$data);
    }

    public function show_cart(){
        $output = '';
        $no = 0;
        foreach ($this->cart->contents() as $items) {
            $no++;
            $output .='';
        }
        $output .= '
        <ul style="line-height: 27px;">
        <li>
        <div class="row">
        <div class="col-sm-6"> Price </div>
        <div class="col-sm-6"><p>₹ '.'&nbsp;'.number_format($this->cart->total()).'</p></div>
        </div>
        </li>
        <li>
        <div class="row">
        <div class="col-sm-6">Delivery Charges</div>
        <div class="col-sm-6"><p> FREE</p></div>
        </div>
        </li>
        <hr>
        <li>
        <div class="row">
        <div class="col-sm-6">Amount Payable</div>
        <div class="col-sm-6"><p> ₹'.'&nbsp;'.number_format($this->cart->total()).'</p></div>
        </div>
        </li>
        <hr>
        </ul>
        <tr>
        <th colspan="3">Total</th>
        <th colspan="2">'.'Rp '.number_format($this->cart->total()).'</th>
        </tr>
        ';
        return $output;
    }

    public function load_cart(){ 
        echo $this->show_cart();
    }

    public function delete_cart(){ 
        $data = array(
            'rowid' => $this->input->post('row_id'), 
            'qty' => 0, 
        );
        $this->cart->update($data);
        redirect('Entube/cart_shopping');
    }

    public function update_cart(){
        $rowid = $this->input->post('rowid');
        $qty = $this->input->post('quantity');
        $i=0;
        foreach ($rowid as $key => $value) {
            $data = array(
             'rowid' => $value, 
             'qty' =>$qty[$i], 
         );
            $this->cart->update($data);
            $i++;
        }
        redirect('Entube/cart_shopping');
    }

    public function search_filter(){
        $val = $this->input->post('val');
        $data = $this->Cart_model->search($val);
    }

    public function serach_fil(){
        $data['categories'] = $this->Text->get_categories();
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('wellnessEntube',$data);
    }

    public function Upend_heading(){
        $data['main_containt']='upend_heading';
        $this->load->view('containt',$data);
    }

    public function Enter_upend(){
        $this->Add_category_model->insertupend($_POST);
        $this->session->set_flashdata('msg',' Successfully your upend_heading Add');
        redirect('Entube/Upend_heading');
    }

    public function upend_information(){
        $data['upend_information'] = $this->Model->getAllData('upend_wrapper');
        $data['main_containt']='upend_information';
        $this->load->view('containt',$data);
    }

    public function sign_up() {   
        $this->load->view('sign');  
    }

    public function PlaceOrder_sgin_process(){
        $email_id = $_POST['email_id'];
        $password = md5($_POST['password']);
        $login = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'password'=>$password));
        if(isset($login) && !empty($login)){
         $newdata = array(
            'id'=>$login[0]['id'],
            'user_id'=>$login[0]['email_id'],
            'user_name'=>$login[0]['user_name'],
            'user_role'=>$login[0]['contact_number'],
            'user_role'=>$login[0]['phone_number'],
            'user_role'=>$login[0]['shipping_address'],
            'user_role'=>$login[0]['billing_address'],
            'user_role'=>$login[0]['aadhar_number'],
            'user_role'=>$login[0]['pan_number'],
            'user_role'=>$login[0]['password'],
            'logged_in'=>TRUE
        );

         $this->session->set_userdata($newdata);

         $user_ID =  $this->session->userdata('id'); 
         $login_information_id =  $this->session->userdata('id');
         $status['online']='1';
         $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
         $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
         $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
         $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
         $id =  $this->session->userdata('id'); 
         $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
         $this->load->view('checkout_page',$data);
     }else{

        $this->session->set_flashdata('msg','login failed');
        redirect('Entube');
    }
    }

    public function Checkout_sgin_process(){
        $email_id = $_POST['email_id'];
        $password = md5($_POST['password']);
        $ID = $_POST['ID'];
        $login = $this->Model->getData('custumer_login',array('email_id'=>$email_id,'password'=>$password));
        if(isset($login) && !empty($login)){

         $newdata = array(
            'id'=>$login[0]['id'],
            'user_id'=>$login[0]['email_id'],
            'user_name'=>$login[0]['user_name'],
            'user_role'=>$login[0]['contact_number'],
            'user_role'=>$login[0]['phone_number'],
            'user_role'=>$login[0]['shipping_address'],
            'user_role'=>$login[0]['billing_address'],
            'user_role'=>$login[0]['aadhar_number'],
            'user_role'=>$login[0]['pan_number'],
            'user_role'=>$login[0]['password'],
            'logged_in'=>TRUE
        );

         $this->session->set_userdata($newdata);
         $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

         $user_ID =  $this->session->userdata('id'); 
         $login_information_id =  $this->session->userdata('id');
         $status['online']='1';
         $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
         $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
         $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
         $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
                    // echo '<pre>'; print_r($data['total_row_add']); exit; 
                    // $data['categories'] = $this->Text->get_categories();
         $id =  $this->session->userdata('id'); 
         $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
         $this->load->view('buy_now',$data);
     }else{

        $this->session->set_flashdata('msg','login failed');
        redirect('Entube');
    }
    }

    public function Checkout_Manage_address_from(){
        $userData = array(
            'Customer_id' => $this->session->userdata('id'),
            'Name' => $this->input->post('Name'),
            'Phone_number' => $this->input->post('Phone_number'),
            'Pincode' => $this->input->post('Pincode'),
            'Locality' => $this->input->post('Locality'),
            'address' => $this->input->post('address'),
            'City' => $this->input->post('City'),
            'state' => $this->input->post('state'),
            'Landmark' => $this->input->post('Landmark'),
            'Alternate_Phone' => $this->input->post('Alternate_Phone'),
            'Address_type' => $this->input->post('Address_type')

        );

        $this->Model->insertData('manage_addresses',$userData);

        $user_ID =  $this->session->userdata('id'); 
        $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
        $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('checkout_page',$data);
    }

    public function Manage_address_from(){
        $userData = array(
            'Customer_id' => $this->session->userdata('id'),
            'Name' => $this->input->post('Name'),
            'Phone_number' => $this->input->post('Phone_number'),
            'Pincode' => $this->input->post('Pincode'),
            'Locality' => $this->input->post('Locality'),
            'address' => $this->input->post('address'),
            'City' => $this->input->post('City'),
            'state' => $this->input->post('state'),
            'Landmark' => $this->input->post('Landmark'),
            'Alternate_Phone' => $this->input->post('Alternate_Phone'),
            'Address_type' => $this->input->post('Address_type')

        );

        $ID = $this->input->post('ID');
        $this->Model->insertData('manage_addresses',$userData);
        $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

        $user_ID =  $this->session->userdata('id'); 
        $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));
        $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
        $data['total_row_add'] = $this->Model->CountWhereRecord('manage_addresses',array('Customer_id'=>$user_ID));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('buy_now',$data);
    }

        public function send_otp_message($id,$contact_number,$otp_code){
            $user = "oxiinc";
            $password = "microlan@123";
            $senderId = "OXIINC";
            $channel = "Trans";
            $dcs = "0";
            $flashsms = "0";
            $route = "6";
            $mobile = $contact_number;
            $otp_code = $otp_code;
            $text_message = "Dear ". $mobile. ". This your otp".$otp_code.". We will process your Register at your chosen date and time.";
            $sms = urlencode($text_message);

            $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';
            // echo '<pre>'; print_r($smsurl); exit;
            try  
            {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_URL, $smsurl);
                $data = curl_exec($ch);
                curl_close($ch);
                $response = $data;
            }  
            catch (Exception $e)  
            {  
                $response = $e->getMessage();  
            }
        }

        public function validate_otp_confirmation(){
            // echo '<pre>'; print_r($_POST); exit;
            $contact_number = $this->input->get_post('contact_number');
            $otp_code = $this->input->get_post('otp_code');
            $password = md5($this->input->get_post('password'));
            // echo '<pre>'; print_r($password); exit;
            // $password = md5($_POST['password']);
            if($contact_number!="" && $otp_code!=""){
             $user_data = $this->Model->getData('custumer_login',array('contact_number'=>$contact_number));
             $forget_data = $this->Model->getData('forgot_password',array('otp_code'=>$otp_code));
                // echo '<pre>'; print_r($forget_data); exit;
             if(isset($user_data) && !empty($user_data)){
                    // echo '<pre>'; print_r($user_data); exit;
                if($forget_data[0]['otp_code']==$otp_code){
                        // echo '<pre>'; print_r($forget_data); exit;
                 $id = $user_data[0]['id'];
                 $postData=array(
                    'password' => $password,

                );

                 $this->Model->updateData('custumer_login',$postData,array('id'=>$id));
                        // $data['msg'] = 'You have logged in successfully';
                 $this->session->set_flashdata('msg' ,'Your password is reset successfully.');
                 redirect('Entube');
                        // $this->model->updateData('user',array('is_mobile_verified'=>'1'),array('mobile_number'=>$mobile_number));
             }else{

                                // $data['msg'] = 'Invalid OTP code is entered.';
                 $this->session->set_flashdata('msg' ,'Invalid OTP code is entered.');
                 redirect('Entube');
             }
         }else{
            redirect('Entube');
        }
    }else{
        redirect('Entube');
    }
    }

    public function logout(){
        $login_information_id =  $this->session->userdata('id');
        $status['online']='0';
        $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
        $this->session->set_userdata(array('logged_in' => FALSE));
        $this->session->sess_destroy();
        delete_cookie("epanelist_username");
        delete_cookie("epanelist_name");
        delete_cookie("epanelist_profileImage");
        delete_cookie("guest_user");
        redirect(base_url());
    }

    public function varify() {
     $postData=array(
        'status' =>1,
    );
     $this->Model->updateData('custumer_login',$postData,array('contact_number'=>$this->uri->segment(3))); 
     $this->session->set_flashdata('msg' ,'Your account has been varify successfully.');
     redirect('Entube');
    }

    public function send_register_confirmation_mail($user_name,$email_id,$contact_number){
        $user_name = $user_name;
        $user_names = $user_name;
        $to_email_address = $email_id;
        $subject = 'Thankyou For Register With as, Oxiinc Group';
        $emailer = 'emailer/welcome.html';
        $mail_content = file_get_contents($emailer);
        $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);
        $mail_content = str_replace('@_users_names_@', $user_names, $mail_content);
        $mail_content = str_replace('@_email_id_@', $email_id, $mail_content);
        $mail_content = str_replace('@_contact_number_@', $contact_number, $mail_content);

        $headers = "From:noreply@entube.in\r\n" .
        'Reply-To: myorder@oxiinc.in' . "\r\n" .
        "MIME-Version: 1.0\r\n".
        "Content-Type: text/html; charset=ISO-8859-1\r\n";
        'X-Mailer: PHP/';

        if(mail($to_email_address, $subject, $mail_content, $headers))
        {

        }
    }

    public function checkout(){
        $ID = $this->session->userdata('id');
        $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
        if ($this->session->userdata('in_logged_in')) {
            $this->load->view('get_epanelist_adddress',$data);
        }else{
         $this->load->view('checkout_page',$data);
     }
    }

    function buy_now(){
            // echo '<pre>'; print_r($_POST); exit;
        if (empty($_POST['ID'])) {
            redirect('Entube');
        }

        $ID = $_POST['ID'];

        $data['size'] =  $_POST['size'];
                    // echo '<pre>'; print_r($data['size']); exit;

        $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));

        $user_ID =  $this->session->userdata('id'); 
        $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));

        $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$user_ID));
                // echo '<pre>'; print_r($data['table']); exit; 
                    // $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('buy_now',$data);

    }


    public function rangeslider(){

            // echo '<pre>'; print_r($_POST); exit;
        $sub_category_id = $this->input->get_post('sub_category_id');
        $data['sub_category_id'] = $sub_category_id;
        $price_max = $this->input->get_post('price-max');
        $price_min = $this->input->get_post('price-min');

        $data['banner'] = $this->Model->getData('banner',array('sub_category_id'=>$sub_category_id));

        $data['SUB_cat'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $data['Multiple_image'] = $this->Text->Rangeslider($sub_category_id,$price_max,$price_min);
             // echo '<pre>'; print_r($data['Rangeslider']); exit;
        $this->load->view('Rangeslider',$data);
    }
    public function Second_Rangeslider(){

            // echo '<pre>'; print_r($_POST); exit;
        $sub_category_id = $this->input->get_post('sub_category_id');
        $data['sub_category_id'] = $sub_category_id;
        $price_max = $this->input->get_post('price-max');
        $price_min = $this->input->get_post('price-min');
        $verified_status = $this->input->get_post('verified_status');
        $data['banner'] = $this->Model->getData('banner',array('sub_category_id'=>$sub_category_id));

        $data['SUB_cat'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        if($sub_category_id!='' && $price_max!='' && $price_min!='' && $verified_status!=''){
         $data['Multiple_image'] = $this->Text->Second_Rangeslider($sub_category_id,$price_max,$price_min,$verified_status);
             // echo '<pre>'; print_r($data['Multiple_image']); exit;
     }else{
        $data['Multiple_image'] = $this->Text->three_Rangeslider($sub_category_id,$price_max,$price_min);
    }
             // echo '<pre>'; print_r($data['Multiple_image']); exit;
    $this->load->view('Second_Rangeslider',$data);
    }
    public function Price_ranger(){
        echo '<pre>'; print_r($_POST); 
        $sub_category_id = $this->input->post('sub_category_id');
                    // echo '<pre>'; print_r($sub_category_id); 
        $price_max = $this->input->post('price_max');
        $price_min = $this->input->post('price_min');
        $data['Multiple_image'] = $this->Text->three_Rangeslider($sub_category_id,$price_max,$price_min);
            // echo '<pre>'; print_r($data['Multiple_image']); exit;
        $this->load->view('Second_Rangeslider',$data);

    }

    public function Pro_Second_Rangeslider(){

            // echo '<pre>'; print_r($_POST); exit;
        $product_category_id = $this->input->get_post('product_category_id');
        $data['product_category_id'] = $product_category_id;
        $price_max = $this->input->get_post('price-max');
        $price_min = $this->input->get_post('price-min');
        $verified_status = $this->input->get_post('verified_status');
        $data['SUB_pro_cat'] = $this->Model->getData('product_category',array('product_category_id'=>$product_category_id));

        $data['Pro_banner'] = $this->Model->getData('pro_banner',array('product_category_id'=>$product_category_id));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        if($product_category_id!='' && $price_max!='' && $price_min!='' && $verified_status!=''){
         $data['Pro_Multiple_image'] = $this->Text->Pro_Second_Rangeslider($product_category_id,$price_max,$price_min,$verified_status);
             // echo '<pre>'; print_r($data['Multiple_image']); exit;
     }else{
        $data['Pro_Multiple_image'] = $this->Text->Pro_three_Rangeslider($product_category_id,$price_max,$price_min);
    }
             // echo '<pre>'; print_r($data['Multiple_image']); exit;
    $this->load->view('Pro_Second_Rangeslider',$data);
    }
    public function Pro_Rangeslider(){

            // echo '<pre>'; print_r($_POST); exit;
        $product_category_id = $this->input->get_post('product_category_id');
        $data['product_category_id'] = $product_category_id;
        $price_max = $this->input->get_post('price-max');
        $price_min = $this->input->get_post('price-min');
        $data['SUB_pro_cat'] = $this->Model->getData('product_category',array('product_category_id'=>$product_category_id));

        $data['Pro_banner'] = $this->Model->getData('pro_banner',array('product_category_id'=>$product_category_id));
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
             // $data['Multiple_image'] = $this->Text->Rangeslider($sub_category_id,$price_max,$price_min);
        $data['Pro_Multiple_image'] = $this->Text->Pro_Rangeslider($product_category_id,$price_max,$price_min);
             // echo '<pre>'; print_r($data['Pro_Multiple_image']); exit;
        $this->load->view('Pro_Rangeslider',$data);
    }
    function view_all(){
        $upend_id = $_GET['upend_id'];
        $data['upend_info'] = $this->Model->getData('wrapper_wellness',array('upend_id'=>$upend_id));
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('view_all',$data);

    }
    public function view_add_to_cart()
    {

        $ID = $_GET['ID'];

        $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
            // $data['SUB_cat'] = $this->model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
            // $data['categories'] = $this->text->get_categories();
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('view_add_to_cart',$data);
    }
    public function view_product()
    {

        $ID = $_GET['ID'];

        $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
            // $data['SUB_cat'] = $this->model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
            // $data['categories'] = $this->text->get_categories();
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('view_add_to_cart',$data);
    }
    function View_buy_now(){
        $ID = $_GET['ID'];

        $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));

        $user_ID =  $this->session->userdata('id'); 
        $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$user_ID));


                // echo '<pre>'; print_r($data['table']); exit; 
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('View_buy_now',$data);

    }

    function view_all_url(){
        $url_id = $_GET['url_id'];
        $data['url_append_heading'] = $this->Model->getData('url_append_heading',array('url_id'=>$url_id));
            // echo '<pre>'; print_r($data['url_append_heading']); exit;
        $data['url_append_info'] = $this->Model->getData('url_append_info',array('url_id'=>$url_id));
        $total_row = $this->Model->CountWhereRecord('url_append_info',array('url_id'=>$url_id));
        $data['total_row']= $total_row;
        $data['categories'] = $this->Text->get_categories();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('view_all_url',$data);

    }
    function about_us(){
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('about-us',$data);
    }

    function oxiinc_stories(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('oxiinc-stories',$data);
    }


    function cancellation_policy(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('cancellation-return-policy',$data);
    }

    function success_stories(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('success-stories',$data);
    }
    function payment_policy(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('payment-policy',$data);
    }

    function shipping_policy(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('shipping-policy',$data);
    }

    function report_infringement(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('report-infringement',$data);
    }

    function term_of_use(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('term-of-use',$data);
    }
    function securities(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('securities',$data);
    }

    function privacy_policy(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('privacy-policy',$data);
    }

    function faq(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('FAQ',$data);
    }

    function sitemap(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('sitemap',$data);
    }

    function press_release(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('press-release',$data);
    }

    function help(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('help',$data);
    }

    function payment(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('help',$data);
    }
    function Sale_On_Oxiinc(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('sell-on-oxiinc',$data);
    }
    function Affiliate(){
     $id =  $this->session->userdata('id'); 
     $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
     $this->load->view('affiliates',$data);
    }

    function text_message()
    {
        $user_name = 'Mr.gagan';
        $to_email_address = 'gaganbansode@gmail.com';
        $subject = 'Your DirectFarm.in Order #'.$order_number;
        $emailer = 'emailer/templat.html';
        $mail_content = file_get_contents($emailer);
        $mail_content = str_replace('@_user_name_@', $user_name, $mail_content);



        $headers = "From:no-reply@oxiinc.in\r\n" .
        'Reply-To: myorder@oxiinc.in' . "\r\n" .
        "MIME-Version: 1.0\r\n".
        "Content-Type: text/html; charset=ISO-8859-1\r\n";
        'X-Mailer: PHP/';


        if(mail($to_email_address, $subject, $mail_content, $headers))
        {
            echo"<h1>success</h1>";
        }
    }

    function FamilyNutrition1(){
        $sub_category_id = '1';
            // $data['sub_category_id'] = str_split($sub_category_id[0]);
        $data['sub_category_id'] = $sub_category_id;
        $this->load->library('pagination');
        $this->load->library('Ajax_pagination');

        $total_row= $this->Model->CountWhereRecord('wellness',array('sub_category_id'=>$sub_category_id));
        $limit = 20;
        $config['uri_segment'] = 3;
        $totalRec = $total_row;

        $config['target']      = '#collegespaging';
        $config['base_url']    = base_url('Entube/wellness').'?sub_category_id='.$sub_category_id;

        $config['total_rows']  = $totalRec;
        $config['per_page']    = $limit;
        $this->ajax_pagination->initialize($config);
        $page= ($this->uri->segment(3)) ? $this->uri->segment(3):0;

                    // $data['Multiple_image'] = $this->Text->Multiple_image($sub_category_id,$config["per_page"],$page);

        $data['Multiple_image'] = $this->Text->Multiple_image($sub_category_id);
        $data['banner'] = $this->Model->getData('banner',array('sub_category_id'=>$sub_category_id));

        $data['SUB_cat'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));


            // $data['categories'] = $this->Text->get_categories();
            // $id =  $this->session->userdata('id'); 
            // $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $data['pagination'] = $this->ajax_pagination->create_links();
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
                    // echo '<pre>'; print_r($data); exit;
        $this->load->view('family-nutrition1',$data);
    }
    function validate_offer_code(){


        $offer_code = $this->input->get_post('offer_code');
        $total_amount = $this->input->get_post('total_amount');
        if($offer_code!='' && $total_amount!='' ){

         $strSql = "SELECT * FROM promo_codo WHERE Promo_code='".$offer_code."' AND Active_states='1'AND expiry_date>='".date('Y-m-d')."'";
         $offer_data =$this->Model->getSqlData($strSql);
                                // echo '<pre>'; print_r($offer_data); exit;
         if(isset($offer_data) && !empty($offer_data)){
            $Promo_code = $offer_data[0]['Promo_code'];
            $ID = $offer_data[0]['ID'];
            $customer_id = $offer_data[0]['customer_id'];
            $Promo_amount = $offer_data[0]['Promo_Percentage'];
            $Minimum_Amount = $offer_data[0]['Minimum_Amount'];

            if($this->session->userdata('id') == $customer_id ){
                if ($total_amount>$Promo_amount) {

                 $data['discount_amount'] = $total_amount - $Promo_amount;
                 $data['Promo_amount'] = $Promo_amount;
                 $data['promo_id'] = $ID;
                 $ID = $this->session->userdata('id');
                 $data['customer_info'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
                 $id =  $this->session->userdata('id'); 
                 $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
                 $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));

                 $this->load->view('checkout_page',$data);

             }else{
                $this->session->set_flashdata('msg','Minimum billed amount should be Rs. '.$Minimum_Amount.", Your  total is Rs. ".$total_amount."");
                redirect('Entube');
            }

        }else{
         $this->session->set_flashdata('msg','This Promo Code is Not Applicable For You.');
         redirect('Entube');


     }
    }else{
     $this->session->set_flashdata('msg','Invalid offer code is entered.');
     redirect('Entube');

    }

    }else{
     $this->session->set_flashdata('msg','Required parameters are missing.');
     redirect('Entube');
    }
    }
    function logout_buy_now(){

        $login_information_id =  $this->session->userdata('id');
        $status['online']='0';
        $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
        $this->session->unset_userdata('logged_in');


        redirect(base_url("Entube/buy_now"));

    }
    function logout_checkout(){
            // $this->session->set_userdata(array('logged_in' => FALSE));
        $login_information_id =  $this->session->userdata('id');
        $status['online']='0';
        $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));
        $this->session->unset_userdata('logged_in');

        redirect(base_url("Entube/checkout"));

    }
    function Summary_ticket(){
        $id =  $this->session->userdata('id'); 
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        $this->load->view('Summary_ticket',$data);
    }
    function validate_login(){
        $jsonObj = $_POST['jsonObj']; 
        $array_data = json_decode($jsonObj,true); 
        $array_entity = $array_data['login'];

        $user_id = $array_entity['user_id'];
        $password = $array_entity['password'];

        $user_data=$this->Model->getData('custumer_login',array('email_id' => $user_id,'password' => md5($password)));
            // echo '<pre>'; print_r($user_data); exit;
        if(isset($user_data) && !empty($user_data)){

         $newdata = array(
            'id'=>$user_data[0]['id'],
            'user_id'=>$user_data[0]['email_id'],
            'user_name'=>$user_data[0]['user_name'],
            'user_role'=>$user_data[0]['contact_number'],
            'user_role'=>$user_data[0]['phone_number'],
            'user_role'=>$user_data[0]['shipping_address'],
            'user_role'=>$user_data[0]['billing_address'],
            'user_role'=>$user_data[0]['aadhar_number'],
            'user_role'=>$user_data[0]['pan_number'],
            'user_role'=>$user_data[0]['password'],
            'logged_in'=>TRUE
        );

         $this->session->set_userdata($newdata);

         $data['status'] = '1';
         $data['msg'] = '<strong>Well done!</strong> You have logged in successfully. Please wait while we are redirecting you on dashboard.';

     }
     else{
         $data['status'] = '0';
         $data['msg'] = '<strong>Oh snap!</strong> The email address or password you entered is incorrect. Please try again.';
     }
     echo json_encode($data);
    }
    function test(){
        $this->load->view('test');
    } 

    function apitext_fail(){
        $this->session->set_flashdata('msg','login failed.');
        redirect('Entube');
    }
    function subscription_code_epanelist(){
            // echo '<pre>'; print_r($_POST); exit;
        $data['user_id'] = $this->input->post('id');
            // $data['sr_no'] = $this->input->post('order_code');
        $data['pin'] = $this->input->post('order_code');
        $data['type'] = $this->input->post('project_name');
        $data['subscription_type'] = $this->input->post('subscription_type');
        $data['amount'] = $this->input->post('amount_after_tax');

        $this->load->view('epanelist_promo_code',$data);
    }
    function E_panelist_personal_information(){
        $data['pan_no'] = $this->input->post('pan_no');
        $data['adhaar_no'] = $this->input->post('adhaar_no');
            // echo '<pre>'; print_r($data); exit;
        $this->load->view('E_panelist_personal_information',$data);
    }
    function  epanelist_digital_wallet(){


        if (empty($_POST['Withdrawl_balance'])) {
            redirect('Entube');
        }
                    // echo '<pre>'; print_r($_POST); exit;
        $data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
        $data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
                    // echo '<pre>'; print_r($data); exit;
        $this->load->view('epanelist_digital_wallet',$data);
    }
    function epanelist_digital_shopping_wallet(){
            // echo '<pre>'; print_r($_POST); 
        if (empty($_POST['Shopping_balannce'])) {
            redirect('Entube');
        }
        $data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
        $data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
                    // echo '<pre>'; print_r($data); exit;
        $this->load->view('epanelist_digital_shopping_wallet',$data);
    }
    function epanelist_personal_information(){
            // echo '<pre>'; print_r($_POST); exit;
        $data['id'] = $this->input->post('id');
        $data['first_name'] = $this->input->post('first_name');
        $data['middle_name'] = $this->input->post('middle_name');
        $data['surname'] = $this->input->post('surname');
        $data['gender'] = $this->input->post('gender');
        $data['company_name'] = $this->input->post('company_name');
        $data['primary_email'] = $this->input->post('primary_email');
        $data['secondary_email'] = $this->input->post('secondary_email');
        $data['contact_1'] = $this->input->post('contact_1');
        $data['contact_2'] = $this->input->post('contact_2');
        $data['dob'] = $this->input->post('dob');
        $data['joining_date'] = $this->input->post('joining_date');
        $data['blood_group'] = $this->input->post('blood_group');
        $data['emp_code'] = $this->input->post('emp_code');
        $this->load->view('epanelist_personal_information',$data);

    }
    function epanelist_Manage_Addresses(){
            // echo '<pre>'; print_r($_POST); exit;
        $data['id'] = $this->input->post('id');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['type'] = $this->input->post('type');
        $data['pincode'] = $this->input->post('pincode');
        $this->load->view('epanelist_Manage_Addresses',$data);
    }
    function epanelist_checkout(){
            // echo '<pre>'; print_r($_POST); exit;
        $employee_id = $this->session->userdata('employee_id');
        $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('employee_id'=>$employee_id));
        $data['id'] = $this->input->post('id');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['type'] = $this->input->post('type');
        $data['pincode'] = $this->input->post('pincode');
        $data['areas'] = $this->input->post('areas');
        $data['cities'] = $this->input->post('cities');
        $data['states'] = $this->input->post('states');
        $data['countries'] = $this->input->post('countries');
            // echo '<pre>'; print_r($data); exit;
        $this->load->view('epanelist_checkout',$data);
    }
    public function E_Panelist_Manage_Address(){
            // print_r($_POST);
        $userData = array(
            'user_id' => $this->input->post('user_id'),
            'employee_id' => $this->input->post('employee_id'),
            'Name' => $this->input->post('Name'),
            'Phone_number' => $this->input->post('Phone_number'),
            'Pincode' => $this->input->post('Pincode'),
            'Locality' => $this->input->post('Locality'),
            'address' => $this->input->post('address'),
            'City' => $this->input->post('City'),
            'state' => $this->input->post('state'),
            'Landmark' => $this->input->post('Landmark'),
            'Alternate_Phone' => $this->input->post('Alternate_Phone'),
            'Address_type' => $this->input->post('Address_type')

        );
        $id = $this->Model->insertData('epanelist_manage_addresses',$userData);
        // print_r($id);
    }
    function Payment_process(){
            // echo '<pre>'; print_r($_POST); exit;
        $data['Shipping_address'] = $this->input->post('Shipping_address');
        $data['promo_id'] = $this->input->post('promo_id');
        $data['Promo_amount'] = $this->input->post('Promo_amount');
        $data['discount_amount'] = $this->input->post('discount_amount');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['pincode'] = $this->input->post('pincode');
        $data['areas'] = $this->input->post('areas');
        $data['cities'] = $this->input->post('cities');
        $data['states'] = $this->input->post('states');
            // $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));
            // echo '<pre>'; print_r($data); exit;
        $this->load->view('Payment_process',$data);
    }
    function Epanelist_Checkout_process(){
        // echo '<pre>'; print_r($_POST); exit;
        $data['Shipping_address'] = $this->input->post('Shipping_address');

        $data['total_price'] = $this->input->post('total_price');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['pincode'] = $this->input->post('pincode');
        $data['areas'] = $this->input->post('areas');
        $data['cities'] = $this->input->post('cities');
        $data['states'] = $this->input->post('states');
        $this->load->view('Epanelist_Checkout_process',$data);
    }
    function Apply_coupons(){
        $this->load->view('get_Epanelist_Apply_coupons');
    }
    function Epanelist_payment_process(){
            // echo '<pre>'; print_r($_POST); exit;
        $Shipping_address = $this->input->post('Shipping_address');
        $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));
        $data['promo_id'] = $this->input->post('promo_id');
        $data['Promo_amount'] = $this->input->post('Promo_amount');
        $data['discount_amount'] = $this->input->post('discount_amount');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['pincode'] = $this->input->post('pincode');
        $data['areas'] = $this->input->post('areas');
        $data['cities'] = $this->input->post('cities');
        $data['states'] = $this->input->post('states');
        $data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
        $data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
            // echo '<pre>'; print_r($data); exit;
        $this->load->view('Epanelist_payment_process',$data);
    }
    function Epanelist_process_payment(){
        $Shipping_address = $this->input->post('Shipping_address');
        $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));

        $data['shopping_prices_total'] = $this->input->post('shopping_prices_total');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['pincode'] = $this->input->post('pincode');
        $data['areas'] = $this->input->post('areas');
        $data['cities'] = $this->input->post('cities');
        $data['states'] = $this->input->post('states');
        $data['Withdrawl_balance'] = $this->input->post('Withdrawl_balance');
        $data['Shopping_balannce'] = $this->input->post('Shopping_balannce');
            // echo '<pre>'; print_r($data); exit;
        $this->load->view('Epanelist_process_payment',$data);
    }


    function Epanelist_Apply_coupons(){
        // echo '<pre>'; print_r($_POST); exit;



        $data['Panel_id'] = $this->input->post('Panel_id');
         // $data['Panel_id'] = array("1", "2", "4");;
        $data['Panel_project_name'] = $this->input->post('Panel_project_name');
        $data['Panel_order_code'] = $this->input->post('Panel_order_code');
        $data['Panel_amount_after_tax'] = $this->input->post('Panel_amount_after_tax');


        $data['subpanel_id'] = $this->input->post('subpanel_id');
        $data['subpanel_project_name'] = $this->input->post('subpanel_project_name');
        $data['subpanel_order_code'] = $this->input->post('subpanel_order_code');
        $data['subpanel_amount_after_tax'] = $this->input->post('subpanel_amount_after_tax');

        $this->load->view('Apply_coupons',$data);
    }
    function Apply_epanelist_coupens(){
        $promo_id = $this->uri->segment(3);
        $Promo_amount = $this->uri->segment(4);
        // echo '<pre>'; print_r($promo_id); 
        // echo '<pre>'; print_r($Promo_amount); 

        
        $org_price= 0; $delivery_char=0; $total_sum=0; foreach ($this->cart->contents() as $items){
             // $qtys = $items['qty'];
            $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
            $GST_Persentage =  $data[0]['GST_Persentage'];


            if($GST_Persentage >0 ){
                $gst_value = $GST_Persentage/100; 
                $gst_prices = $gst_value*$items['price'];
                $gst_price = $gst_prices*$items['qty'];
                                     // $total_price = $items['price']+$gst_price;
            }else{
                $gst_price = 0;
            }




            $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
            $Shipping_Charges =  $data[0]['Shipping_Charges'];

            if ($Shipping_Charges >0) {
                $Shipping_Charges = $Shipping_Charges*$items['qty'] ;
            }else{
             $Shipping_Charges = 0 ;

         }

         $original_price =  $items['original']*$items['qty'];
         $order_data = array(

            'product_id'=>$items['id'],
            'Product_Name'=>$items['name'],
            'Product_Picture'=>$items['picture'],
            'size'=>$items['size'],
            'Prices' => $items['subtotal'],
            'product_qty' => $items['qty'],
            'Original_Prices'=>$items['original'],
        );
         $total_sum+=$gst_price;

         $delivery_char+=$Shipping_Charges;  

         $org_price+=$original_price;  

     }
     $total_amount = $delivery_char+$total_sum+$this->cart->total();
        // echo '<pre>'; print_r($total_amount); exit;











    // echo '<pre>'; print_r($total_amount); 


     if($promo_id!='' && $Promo_amount!='' ){
        if ($total_amount>$Promo_amount) {
                                            // echo '<pre>'; print_r($total_amount); exit;
         $data['discount_amount'] = $total_amount - $Promo_amount;
         $data['Promo_amount'] = $Promo_amount;
         $data['promo_id'] = $promo_id;


    // echo '<pre>'; print_r($data['discount_amount']); exit;
         $this->load->view('discount_promo_amounts',$data);
                                            // echo '<pre>'; print_r($data['discount_amount']); exit;

     }else{
        $this->session->set_flashdata('msg','Minimum billed amount should be Rs. '.$Promo_amount.", Your  total is Rs. ".$total_amount."");
        redirect('Entube');
    }
    }else{
     $this->session->set_flashdata('msg','Required parameters are missing.');
     redirect('Entube');
    }

    }
    function epanelist_promo_checkout(){
        // echo '<pre>'; print_r($_POST); exit;

        $data['discount_amount'] = $this->input->post('discount_amount');
        $data['Promo_amount'] = $this->input->post('Promo_amount');
        $data['promo_id'] = $this->input->post('promo_id');

        $employee_id = $this->session->userdata('employee_id');
        $data['epanelist_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('employee_id'=>$employee_id));
        $data['id'] = $this->input->post('id');
        $data['address_1'] = $this->input->post('address_1');
        $data['address_2'] = $this->input->post('address_2');
        $data['site_name'] = $this->input->post('site_name');
        $data['type'] = $this->input->post('type');
        $data['pincode'] = $this->input->post('pincode');
        $data['areas'] = $this->input->post('areas');
        $data['cities'] = $this->input->post('cities');
        $data['states'] = $this->input->post('states');
        $data['countries'] = $this->input->post('countries');
            // echo '<pre>'; print_r($data); exit;
        $this->load->view('epanelist_promo_checkout',$data);
        /*$this->load->view('Apply_coupons');*/
    }
    function Epanelist_payment_process_complete(){
        // echo '<pre>'; print_r($_POST); exit;
        $data['user_id']= $_POST['user_id'];
        $data['total_shipping']= $_POST['total_shipping'];
        $data['total_gst']= $_POST['total_gst'];
        $data['payment_method']= $_POST['payment_method'];
        $data['Promo_amount']= $_POST['Promo_amount'];
        $data['promo_id']= $_POST['promo_id'];
        $data['Order_Date']= $_POST['Order_Date'];
        $shipping_address= $_POST['shipping_address'];
        $data['epanelist_Shipping_address']= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$shipping_address));
        $data['total_price']= $_POST['total_price'];
        $data['total_cart']= $_POST['total_cart'];
        $data['txnid']= $_POST['txnid'];
        $this->load->view('Epanelist_payment_process_complete',$data);
    }
    function Epanelist_process_payment_complete(){
        $data['user_id']= $_POST['user_id'];
        $data['total_shipping']= $_POST['total_shipping'];
        $data['total_gst']= $_POST['total_gst'];
        $data['payment_method']= $_POST['payment_method'];

        $data['Order_Date']= $_POST['Order_Date'];
        $shipping_address= $_POST['shipping_address'];
        $data['epanelist_Shipping_address']= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$shipping_address));
        $data['total_price']= $_POST['total_price'];
        $data['total_cart']= $_POST['total_cart'];
        $data['txnid']= $_POST['txnid'];
        $this->load->view('Epanelist_process_payment_complete',$data);
    }
    public function edit_user()
    {
        # code...
     $postData = $_POST;
     if(!empty($_FILES['photo'])){
         $cat=rand()."entube_gagan.png";
         $uploaddir = './uploads/customer_channel_logo/';
         $uploadfile = $uploaddir . $cat;

         if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
                                // echo "File is valid, and was successfully uploaded.\n";
            $postData['photo'] = $cat;
        }
    }
    // echo "<pre>";print_r($postData['photo']);exit();
    $this->Model->updateData('custumer_login',$postData,array('id'=>$this->session->userdata('id')));
    redirect('Entube/my_profile_user');
    }

    function my_profile_user(){


     $login = $this->Model->getData('custumer_login',array('id'=>$this->session->userdata('id'),'status'=>'1'));
     $data['customers']=$login;
    //  echo '<pre>'; print_r($data); exit;
     $this->load->view('my_profile_user',$data);
    }

    function channel(){


        $this->load->view('channel');
    }
    function video(){


        $this->load->view('video');
    }
    function playlist(){


        $this->load->view('playlist');
    }
    function sub_channel(){


        $this->load->view('sub_channel');
    }
    function about_channel(){


        $this->load->view('about_channel');
    }
    function playlist_video(){
        $ip = $this->input->ip_address();
        if ($this->session->userdata('entube_customer_logged_in')) {
            $vistor['post_id'] = $this->uri->segment(4);
            $vistor['ip'] = "1";
            $vistor['user_id'] = $this->session->userdata('username');
            $this->Model->insertData('views',$vistor);
        } elseif($this->session->userdata('logged_in')){
            $vistor['post_id'] = $this->uri->segment(4);
            $vistor['ip'] = "1";
            $vistor['user_id'] = $this->session->userdata('id');
            $this->Model->insertData('views',$vistor);
        }else{
            $vistor['post_id'] = $this->uri->segment(4);
            $vistor['ip'] = $ip;
            $this->Model->insertData('views',$vistor);
        }

        //EDIT BY MOHD ALAM 11/07/2020
        $this->db->select('pn.ID AS pn_id, pn.playlistname, ad.ID, ad.category_id, ad.user_id, ad.datatime, ad.Video_Title, ad.video, ad.picture, ad.status, ad.Short_Description, cl.photo, cl.user_name, cl.last_name, cl.channel_name, cc.channel_name AS custumer_channel_name, wu.view');
        $this->db->from('playlist_names pn'); 
        $this->db->join('playlist_video_select pvs', 'pn.ID = pvs.playlistname_id', 'INNER');
        $this->db->join('add_video ad', 'pvs.video_id = ad.ID', 'INNER');
        $this->db->join('custumer_login cl', 'ad.user_id = cl.id', 'LEFT');
        $this->db->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT');
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->where('pn.ID', $this->uri->segment(3));
        $this->db->where('ad.ID', $this->uri->segment(4));
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        $query_video = $this->db->get();
        $data['playlist_video'] = $query_video->result_array();
        //echo "<pre>";print_r($data['playlist_video']);die();

        $this->db->select('pn.ID AS pn_id, pn.playlistname, ad.ID, ad.category_id, ad.user_id, ad.datatime, ad.Video_Title, ad.video, ad.picture, ad.status, ad.Short_Description, cl.photo, cl.user_name, cl.last_name, cl.channel_name, cc.channel_name AS custumer_channel_name, wu.view');
        $this->db->from('playlist_names pn'); 
        $this->db->join('playlist_video_select pvs', 'pn.ID = pvs.playlistname_id', 'INNER');
        $this->db->join('add_video ad', 'pvs.video_id = ad.ID', 'INNER');
        $this->db->join('custumer_login cl', 'ad.user_id = cl.id', 'LEFT');
        $this->db->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT');
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->where('pn.ID', $this->uri->segment(3));
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        $this->db->order_by('ad.ID', 'DESC');
        $query_watch = $this->db->get();
        $data['playlist_watch'] = $query_watch->result_array();
        //echo "<pre>";print_r($data['playlist_watch']);die();

        $this->db->select('pn.ID AS pn_id, ad.ID');
        $this->db->from('playlist_names pn'); 
        $this->db->join('playlist_video_select pvs', 'pn.ID = pvs.playlistname_id', 'INNER');
        $this->db->join('add_video ad', 'pvs.video_id = ad.ID', 'INNER');
        $this->db->where('pn.ID', $this->uri->segment(3));
        $this->db->where('ad.ID <', $this->uri->segment(4));
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        $this->db->order_by('ad.ID', 'DESC');
        $this->db->limit(1);
        $query_video_next = $this->db->get();
        $data['playlist_next'] = $query_video_next->result_array();
        //echo "<pre>";print_r($data['playlist_next']);die();

        $data['main_containt']='new_user/playlist_video';
        $this->load->view('new_user/containt', $data);
    }

    function api_calling($uname,$pwd){
        $key=substr(str_shuffle(STRING_KEY), 0, 10);
        $enc_pwd=base64_encode($pwd);
        $salt=SALT;
        $password=$key.$salt.$enc_pwd;
        $data = array("pd" => $password,"un" => $uname); 
        $data=http_build_query($data);//die;  
        $url = "https://www.oxiinc.com/login/login_api?".$data;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }

    function e_panelist_login(){
            // if($_SERVER['REMOTE_ADDR']=="49.248.217.110"){
            //     echo "<pre>";print_r($_POST);exit();
            // }
     if ((!empty($_POST['username']) && !empty($_POST['password'])) ) {
        $pwd=$_POST['password'];
        $uname=base64_encode($_POST['username']);
        $output=$this->api_calling($uname,$pwd);
        $val_data=json_decode($output,true);
        if(!empty($_POST['g-recaptcha-response'])){
            if($val_data['status']=='success'){
             $epanelist_login = array(
                'user_id'=>$val_data['user_id'],
                'username'=>$val_data['username'],
                'name'=>$val_data['name'],
                'account_type'=>$val_data['account_type'],
                'email_verified'=>$val_data['email_verified'],
                'employee_id'=>$val_data['employee_id'],
                'employee_code'=>$val_data['employee_code'],
                'profileImage'=>$val_data['profileImage'],
                'entube_customer_logged_in'=>TRUE
            );
             /*$user_tracking=array('user_id' => $val_data['user_id'],
                'employee_id' => $val_data['employee_id'], 
                'user_ip' => $_SERVER['REMOTE_ADDR'],
                'lat_long' => $_POST['user_latlong'],
                'username' => $val_data['username'],
                'date_1'=>date("Y-m-d H:i:s"),
                'usertype' => 1);
                $this->Model->insertData('users_tracking',$user_tracking);*/
                $this->session->set_userdata($epanelist_login);
                $this->session->set_flashdata('msg','Login Successfully.');
                redirect('E_Panelist_page/My_Digital');
            }else{
             $this->session->set_flashdata('msg','Login Failed.');
             redirect();
         }
     }
     $this->session->set_flashdata('msg','Fill the captcha.');
     redirect();

    }else{
        redirect();
    }

    }
    function forgot_test(){

     echo "Hi";
    }

    function forgot(){

    // echo "<pre>";print_r($_POST['number']);
    // $this->load->view('channel');

        $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$_POST['number']));
        if($mobile_info){
            // echo '<pre>'; print_r($mobile_info); 
            $otp_code = mt_rand(10000,999999);
            $user = "OXIINCHEALTH";
            $password = "OXIINC@185";
            $senderId = "ENTUBE";
            $channel = "Trans";
            $dcs = "0";
            $flashsms = "0";
            $route = "6";
            $mobile = $_POST['number'];

            $text_message =$otp_code." is your EnTube Reset Password verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
                                                    // echo '<pre>'; print_r($text_message);
            $sms = urlencode($text_message);

                                                    // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

            $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

            try  
            {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_URL, $smsurl);
                $data = curl_exec($ch);
                curl_close($ch);
                $response = $data;
            }  
            catch (Exception $e)  
            {  
                $response = $e->getMessage();  
            }


            $array_data=array(

                'mobile'=>$_POST['number'],
                    //      'email'=>$mobile_info[0]['email_id'],
                'otp'=>$otp_code,
                'created'=>date("Y-m-d H:i:s"),
                'modified'=>date("Y-m-d H:i:s"),

            );
            $this->Model->updateData('otp',$array_data,array('mobile'=>$_POST['number']));


                    //      insertData('otp',array_map('strtoupper', $array_data));
                    //      $data['contact_number1']=$_POST['number'];
            $data1=$_POST['number'];

            $data=$data1;
                    //  print_r ($data); exit;
                            // $data['email'] = $mobile_info[0]['email_id'];
                    //      $data['otp']=$otp_code;

                    //      $this->load->view('forgot_password',$data);
            echo '<div class="icon1">
            <span class="fa fa-lock"></span>
            <input type="hidden" id="user_mobile" name="contact_number" value="'.$data1.'" placeholder="Enter your otp" required=""/>
            <input type="number" id="user_otp" name="otp" style="outline: none;
            font-size: 15px;
            color: #222;
            border: none;
            width: 90%;
            display: inline-block;
            background: transparent;
            letter-spacing: 1px;" placeholder="Enter your otp" required=""/>
            </div>

            <div class="bottom">

            <button type="button" id="submit_otp" onclick="validotp()" class="btn">Send</button>

            </div>
            ';
        }else{
            echo 'Please check your mobile number';
        }
    }
    function forgot_password(){
            // print_r($_POST);exit();

        $mobile_info=$this->Model->getData('otp',array('mobile'=>$_POST['contact_number'],'otp'=>$_POST['otp']));
        $date1=date("Y-m-d H:i:s");
        $difference = strtotime($date1) - strtotime($mobile_info[0]['created']);

    // getting the difference in minutes
        $difference_in_minutes = $difference / 60;

        if ($difference_in_minutes<="10") {
    //      $var['password'] = md5($_POST['password']);
    //  $this->Model->updateData('custumer_login',$var,array('contact_number'=>$_POST['contact_number']));

            $URL=base_url('Entube/reset_password');
            echo '
            <form action="'.$URL.'" method="post">
            <div class="icon1">
            <span class="fa fa-lock"></span>
            <input type="hidden" id="user_mobile" name="contact_number" value="'.$_POST['contact_number'].'" placeholder="Enter your otp" required=""/>
            <input type="text" id="new_password" name="password" placeholder="Enter your new password" style="outline: none;
            font-size: 15px;
            color: #222;
            border: none;
            width: 90%;
            display: inline-block;
            background: transparent;
            letter-spacing: 1px;" placeholder="Enter your otp" required=""/>
            </div>

            <div class="bottom">

            <button type="submit"  class="btn">Send</button>

            </div>
            </form>
            ';


        }else{
         echo 'Please check your otp';
             // $this->session->set_flashdata('msg','Please check your otp');
             // redirect("Entube");
     }



    }
    function reset_password(){
        $var['password'] = md5($_POST['password']);
        $password= md5($_POST['password']);
        $this->Model->updateData('custumer_login',$var,array('contact_number'=>$_POST['contact_number']));
        $login = $this->Model->getData('custumer_login',array('contact_number'=>$_POST['contact_number'],'password'=>$password,'status'=>'1'));
        if(isset($login) && !empty($login)){
    // echo '<pre>'; print_r(); exit;
         $newdata = array(
            'id'=>$login[0]['id'],
            'user_id'=>$login[0]['email_id'],
            'user_name'=>$login[0]['user_name'],
            'last_name'=>$login[0]['last_name'],
            'user_role'=>$login[0]['contact_number'],
            'user_role'=>$login[0]['phone_number'],
            'user_role'=>$login[0]['shipping_address'],
            'user_role'=>$login[0]['billing_address'],
            'user_role'=>$login[0]['aadhar_number'],
            'user_role'=>$login[0]['pan_number'],
            'user_role'=>$login[0]['password'],
            'logged_in'=>TRUE
        );

         $this->session->set_userdata($newdata);
         $login_information_id =  $this->session->userdata('id');
         $status['online']='1';
         $login_id = $this->Model->updateData('custumer_login',$status,array('id'=>$login_information_id));


     }
     $this->session->set_flashdata('msg','Successfully login');
     redirect("Entube");
    }
    function load_comment(){

        $query = $this->db->query("select * from comment_section where v_id=
            ".$_POST['v_id']." order by id  DESC limit 2");

        $row= $query->result_array();
    // echo "<pre>";print_r($row)
        if(!empty($row)) foreach ($row as $gagan){
            ?>

            <div class="col-sm-1">
                <div class="single-video-author ">
                 <img class="img-fluid img-responsive" src="<?php echo $gagan['photo'] ?>" alt="">
             </div>
         </div>

         <div class="col-sm-11">

            <div class="single-video-author ">

             <p><a href="#" style="color:black"><strong><?php echo $gagan['user_id'] ?></strong></a></p>


             <p style="font-size: 14px;color: gray"><?php echo $gagan['comment']; ?></p>
             <br>

             <div class="comment-title">


                <div class="row">
                    <div class="col-sm-12">

                        <div class="comment-title">
                            <?php 

                            $like1= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1'));
                            $dislike= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1'));
                            ?>
                            <?php if ($this->session->userdata('logged_in')) {?>

                             <?php 
                             $like1_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'like1'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
                             ?>
                             <?php 
                             if ($like1_khan) {
                                ?>

                                <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-up" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button> 
                            <?php }else{?>
                             <button  style="background-color: transparent;border: none;" onclick="like_comment(<?php echo  $gagan['id']; ?>);"><i class="fa fa-thumbs-up" style="color: black!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $like1; ?> </a></button>
                         <?php }?>
                         <?php 
                         $dislike_khan= $this->Model->CountWhereRecord('like_dislike_comment',array('comment_id'=>$gagan['id'],'dislike'=>'1','video_id'=>$_POST['v_id'],'customer_id'=>$this->session->userdata('id')));
                                                     // echo '<pre>'; print_r($dislike); 
                         ?>
                         <?php 
                         if ($dislike_khan) {
                            ?>


                            <button  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: blue!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>   

                        <?php }else{?>
                            <button  onclick="dilike_copmment(<?php echo  $gagan['id']; ?>);" style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down" style="color: black!important"></i> &nbsp;&nbsp;<a href="#"><?php echo  $dislike; ?> </a></button>
                        <?php }?>
                        <?php 

                        $comment_reply_khan= $this->Model->CountWhereRecord('comment_reply',array('comment_id'=>$gagan['id'],'video_id'=>$this->uri->segment(3)));

                        ?>


                        <button class="reply_btn" style="background-color: transparent;border: none;"><i class="fa fa-reply" aria-hidden="true"></i> Reply</button>

                    <?php }else{?>
                        <button  class="ashfakkhan" style="background-color: transparent;border: none;" ><i class="fa fa-thumbs-up " style="color: black!important"></i> &nbsp;&nbsp;<?php echo  $like1; ?> </button>
                        <button  class="ashfakkhan"  style="background-color: transparent;border: none;"><i class="fa fa-thumbs-down " style="color: black!important"></i> &nbsp;&nbsp;<?php echo  $dislike; ?> </button>
                        <button class="ashfakkhan" style="background-color: transparent;border: none;"><i class="fa fa-reply " aria-hidden="true"></i> Reply</button>
                    <?php } ?>


                </div>

                <form method="POST" action="/org/post/{comment_id}" class="reply-form">

                    <div class="form-group">
                        <div class="group">
                            <input type="text" required>
                            <span class="highlight"></span>
                            <span class="bar"></span>
                            <label>Add a public comment here </label>
                        </div>

                    </div>
                    <div class="button-group" style="float: right;    margin-top: -30px;">
                        <button type="submit" value="Post Comment">Post comment</button>
                        <button type="button" class="cancel_btn" value="Cancel">Cancel</button>
                    </div>
                </form>

                <style>
                    .reply-form {
                        display: none
                    }
                </style>

                <script>
                    $(function() {
                        $(".reply_btn").click(function() {
                            $(this).parent().parent().children('.reply-form').show();
                        });
                        $(".cancel_btn").click(function() {
                            $(this).parent().parent().hide();
                        });
                    });
                </script>

            </div>

        </div>

    </div>

    </div>
    </div>
    <?php
    }
    }
    public function all_customer_info($value='')
    {
        $user_id="oxiinctop";
        $user_info=$_SESSION['customer_table'][$user_id];
        echo '<pre>'; print_r($user_info); exit;

    }
    public function mydigital_api()
    {
     $url = "https://www.oxiinc.com/api/customers_information";
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_HEADER, 0);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_URL, $url);
     curl_setopt($ch, CURLOPT_POST, true);
     $output = curl_exec($ch);
     curl_close($ch);

     return $output;

    }
    function new_login($value=''){
        $this->load->view('new_login');
    }
}
?>