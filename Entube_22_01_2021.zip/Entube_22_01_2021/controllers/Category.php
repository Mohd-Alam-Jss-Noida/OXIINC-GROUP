<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
         // $this->load->model('Text');
         // $this->load->model('textsecond');
         // $this->load->model('Orders_model');
         $this->load->model('Add_category_model');

         if(!$this->session->userdata('is_logged_in')){
         	redirect('Login');
         }
	}
	public function Add_Category()
	{

		$data['main_containt']='Add_Category';

        $this->load->view('containt',$data);
	}
	public function enter_category()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$this->Add_category_model->insertData($_POST);
		$this->session->set_flashdata('msg',' Successfully your Category Add');
		redirect('Category/Add_Category');
	}
	public function Category_List()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$category_list = $this->Model->getData('category');
		$data['category_list'] = $category_list;
		$data['main_containt']='Category_List';
        $this->load->view('containt',$data);
	}
	public function Category_eidt()
	{
        $category_id = $_GET['category_id'];
		
		$data['table'] = $this->Model->getData('category',array('category_id'=>$category_id));
		$data['main_containt']='Category_eidt';

        $this->load->view('containt',$data);
	}
	public function edit_Category_form()
	{

		$postData = $_POST;
		if(!empty($_FILES['photo'])){
			$cat=rand()."entube_gagan.png";
            $uploaddir = './uploads/banner/';
            $uploadfile = $uploaddir . $cat;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['photo'] = $cat;
            }
        }

		$this->Model->updateData('category',$postData,array('category_id'=>$_POST['category_id']));
        $this->session->set_flashdata('msg','Category Update Successfully ');
		redirect('Category/Category_List');
	}
	function Category_delete(){
        $category_id = $this->input->get_post('category_id');
        $this->Model->deleteData('category',array('category_id'=>$category_id));
        
        $this->session->set_flashdata('msg' ,'The Category has been deleted successfully.');

        redirect('Category/Category_List');
    }
    public function Add_sub_Category()
	{
        $data['category_data'] = $this->Model->getAllData('category');
		$data['main_containt']='Add_sub_Category';

        $this->load->view('containt',$data);
	}
	public function enter_sub_category()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$this->Add_category_model->insertsub($_POST);
		$this->session->set_flashdata('msg',' Successfully your SubCategory Add');
		redirect('Category/Add_sub_Category');
	}
	public function Sub_category_List()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$subcategory_list = $this->Model->getData('subcategory');
		$data['subcategory_list'] = $subcategory_list;
		$data['main_containt']='subcategory_list';
        $this->load->view('containt',$data);
	}
	public function sub_Category_eidt()
	{
        $sub_category_id = $_GET['sub_category_id'];
		
		$data['table'] = $this->Model->getData('subcategory',array('sub_category_id'=>$sub_category_id));
		$data['main_containt']='subcategory_eidt';

        $this->load->view('containt',$data);
	}
	public function edit_subCategory_form()
	{
       	$postData = $_POST;
       
       	if(!empty($_FILES['photo'])){
			$cat=rand()."entube_gagan.png";
            $uploaddir = './uploads/banner/';
            $uploadfile = $uploaddir . $cat;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['photo'] = $cat;
            }
        }
        
        
		$this->Model->updateData('subcategory',$postData,array('sub_category_id'=>$_POST['sub_category_id']));
        $this->session->set_flashdata('msg','SubCategory Update Successfully ');
		redirect('Category/Sub_category_List');
	}
	function sub_Category_delete(){
        $sub_category_id = $this->input->get_post('sub_category_id');
        $this->Model->deleteData('subcategory',array('sub_category_id'=>$sub_category_id));
        
        $this->session->set_flashdata('msg' ,'The SubCategory has been deleted successfully.');

        redirect('Category/Sub_category_List');
    }
    public function Add_product_sub_Category()
	{
        $data['Add_product_sub_data'] = $this->Model->getAllData('subcategory');
		$data['main_containt']='Add_product_sub';

        $this->load->view('containt',$data);
	}
	public function enter_product_category()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$this->Add_category_model->insertpro($_POST);
		$this->session->set_flashdata('msg',' Successfully your productCategory Add');
		redirect('Category/Add_product_sub_Category');
	}
	public function Orders_same()
	{

		$table = $this->Model->getData('orders');
		$data['h'] = $table;
		 $data['main_containt']='orderstable';
        
        $this->load->view('containt',$data);
	}
	public function Create_new_order()
	{
		 $data['main_containt']='createneworder';
        
        $this->load->view('containt',$data);
	}
	public function Create_new_orderss()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$this->Orders_model->insertData($_POST);
		// $data['main_containt']='orderstable';
		redirect('orders/orders_same');
	}
	public function View()
	{
		$id = $_GET['ID'];
		$table = $this->Model->getData('orders',array('id'=>$id));
		$data['view'] = $table;
		$data['main_containt']='view_order';
        
        $this->load->view('containt',$data);
	}
	public function Ordereidt()
	{

		$ID = $_GET['ID'];
		
		$data['table'] = $this->Model->getData('orders',array('ID'=>$ID));

		$data['main_containt']='ordereidt';
        
        $this->load->view('containt',$data);
	}
	public function Add_Product_Category()
	{
		 $data['category_data'] = $this->Model->getAllData('category');

		$data['main_containt']='Add_Product_Category';

        $this->load->view('containt',$data);
	}
	public function Add_product_category_form(){
		 $product_enter=$_POST;
		 $this->Model->insertData('product_category',$product_enter);
        $this->session->set_flashdata('msg',' Successfully your Product Category Add');
        redirect('Category/Add_Product_Category');
	}
	public function Product_Category_List()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$product_category = $this->Model->getData('product_category');
		$data['product_category'] = $product_category;
		$data['main_containt']='Product_Category_List';
        $this->load->view('containt',$data);
	}
	function product_category_delete(){
        $product_category_id = $this->input->get_post('product_category_id');
        $this->Model->deleteData('product_category',array('product_category_id'=>$product_category_id));
        
        $this->session->set_flashdata('msg' ,'The Product Category has been deleted successfully.');

        redirect('Category/Product_Category_List');
    }
    public function product_category_eidt()
	{
        $product_category_id = $_GET['product_category_id'];
		
		$data['table'] = $this->Model->getData('product_category',array('product_category_id'=>$product_category_id));
		$data['main_containt']='product_category_eidt';

        $this->load->view('containt',$data);
	}
	function Edit_product_category_form(){

		 $this->Model->updateData('product_category',$_POST,array('product_category_id'=>$_POST['product_category_id']));
         $this->session->set_flashdata('msg' ,'The Product Category has been updated successfully.');
         redirect('Category/Product_Category_List');
	}
	// public function wellness()
	// {

 //        $sub_category_id = $_GET['sub_category_id'];
		
	// 	$data['table'] = $this->model->getData('wellness',array('sub_category_id'=>$sub_category_id));
		
	// 	$data['categories'] = $this->text->get_categories();
        
 //        $this->load->view('wellnesshome',$data);
	// }
	// public function text()
	// {
 //   //       $table = $this->model->getData('category');
	// 	 // $data['h'] = $table;
	// 	 $return['categories'] = $this->text->get_categories();
		 
	// 	 // echo '<pre>'; print_r($return); exit;
 //         $this->load->view('textsecond',$return);
	// }
	// public function textsecond()
	// {

	// 	$wellness = $this->model->getData('category',array('category_id'=>'1','status'=>1));
	// 	$catELECTRONICS = $this->model->getData('category',array('category_id'=>'2'));
	// 	$homekitchen = $this->model->getData('category',array('category_id'=>'3'));
	// 	$WOMENS = $this->model->getData('category',array('category_id'=>'4'));
	// 	$MENS = $this->model->getData('category',array('category_id'=>'5'));
	// 	$BABY = $this->model->getData('category',array('category_id'=>'6'));
	// 	//
	// 	$babykids = $this->model->getData('subcategory',array('sub_category_id'=>'46'));
	// 	$girlfoot = $this->model->getData('subcategory',array('sub_category_id'=>'44'));
	// 	$boyfoot = $this->model->getData('subcategory',array('sub_category_id'=>'43'));
	// 	$girlcolth = $this->model->getData('subcategory',array('sub_category_id'=>'42'));
	// 	$boycolth = $this->model->getData('subcategory',array('sub_category_id'=>'41'));
	// 	$Innerwear = $this->model->getData('subcategory',array('sub_category_id'=>'40'));
	// 	$Acce = $this->model->getData('subcategory',array('sub_category_id'=>'39'));
	// 	$menwera = $this->model->getData('subcategory',array('sub_category_id'=>'38'));
	// 	$womensBags = $this->model->getData('subcategory',array('sub_category_id'=>'37'));
	// 	$Footwear = $this->model->getData('subcategory',array('sub_category_id'=>'36'));
	// 	$sportactive = $this->model->getData('subcategory',array('sub_category_id'=>'35'));
	// 	$Bottomwear = $this->model->getData('subcategory',array('sub_category_id'=>'34'));
	// 	$Topwear = $this->model->getData('subcategory',array('sub_category_id'=>'33'));
	// 	$Nightwear = $this->model->getData('subcategory',array('sub_category_id'=>'32'));
	// 	$Jewellery = $this->model->getData('subcategory',array('sub_category_id'=>'31'));
	// 	$Accessories = $this->model->getData('subcategory',array('sub_category_id'=>'30'));
	// 	$Footwear = $this->model->getData('subcategory',array('sub_category_id'=>'29'));
	// 	$Bags = $this->model->getData('subcategory',array('sub_category_id'=>'28'));
	// 	$sport = $this->model->getData('subcategory',array('sub_category_id'=>'27'));
	// 	$Western = $this->model->getData('subcategory',array('sub_category_id'=>'26'));
	// 	$fusion = $this->model->getData('subcategory',array('sub_category_id'=>'25'));
	// 	$Decor = $this->model->getData('subcategory',array('sub_category_id'=>'24'));
	// 	$hardware = $this->model->getData('subcategory',array('sub_category_id'=>'23'));
	// 	$bathroom = $this->model->getData('subcategory',array('sub_category_id'=>'22'));
	// 	$health = $this->model->getData('subcategory',array('sub_category_id'=>'21'));
	// 	$lighing = $this->model->getData('subcategory',array('sub_category_id'=>'20'));
	// 	$kitchen = $this->model->getData('subcategory',array('sub_category_id'=>'19'));
	// 	$homefaur = $this->model->getData('subcategory',array('sub_category_id'=>'18'));
	// 	$homeapplication = $this->model->getData('subcategory',array('sub_category_id'=>'17'));
	// 	$gaming = $this->model->getData('subcategory',array('sub_category_id'=>'16'));
	// 	$washing = $this->model->getData('subcategory',array('sub_category_id'=>'15'));
	// 	$ari = $this->model->getData('subcategory',array('sub_category_id'=>'14'));
	// 	$refri = $this->model->getData('subcategory',array('sub_category_id'=>'13','status'=>1));
	// 	$computer = $this->model->getData('subcategory',array('sub_category_id'=>'12','status'=>1));
	// 	$laptop = $this->model->getData('subcategory',array('sub_category_id'=>'11','status'=>1));
	// 	$mobile = $this->model->getData('subcategory',array('sub_category_id'=>'10','status'=>1));
	// 	$homeent = $this->model->getData('subcategory',array('sub_category_id'=>'9','status'=>1));
	// 	$agri = $this->model->getData('subcategory',array('sub_category_id'=>'8','status'=>1));
	// 	$baby = $this->model->getData('subcategory',array('sub_category_id'=>'7','status'=>1));
	// 	$gym = $this->model->getData('subcategory',array('sub_category_id'=>'6','status'=>1));
	// 	$home = $this->model->getData('subcategory',array('sub_category_id'=>'5','status'=>1));
	// 	$personal = $this->model->getData('subcategory',array('sub_category_id'=>'4','status'=>1));
	// 	$ELECTRONICS = $this->model->getData('subcategory',array('sub_category_id'=>'2','status'=>1));
	// 	$Beauty = $this->model->getData('subcategory',array('sub_category_id'=>'3','status'=>1));
	// 	$subwellness = $this->model->getData('subcategory',array('sub_category_id'=>'1','status'=>1));
	// 	//
	// 	$prowellness = $this->model->getData('product_category',array('sub_category_id'=>'1','status'=>1));
	// 	$proELECTRONICS = $this->model->getData('product_category',array('sub_category_id'=>'2','status'=>1));
	// 	$proBeauty = $this->model->getData('product_category',array('sub_category_id'=>'3','status'=>1));
	// 	$propersonal = $this->model->getData('product_category',array('sub_category_id'=>'4','status'=>1));
	// 	$prohome = $this->model->getData('product_category',array('sub_category_id'=>'5','status'=>1));
	// 	$progym = $this->model->getData('product_category',array('sub_category_id'=>'6','status'=>1));
	// 	$probaby = $this->model->getData('product_category',array('sub_category_id'=>'7','status'=>1));
	// 	$proagri = $this->model->getData('product_category',array('sub_category_id'=>'8','status'=>1));
	// 	$prohomeent = $this->model->getData('product_category',array('sub_category_id'=>'9','status'=>1));
	// 	$promobile = $this->model->getData('product_category',array('sub_category_id'=>'10','status'=>1));
	// 	$prolaptop = $this->model->getData('product_category',array('sub_category_id'=>'11','status'=>1));
	// 	$procomputer = $this->model->getData('product_category',array('sub_category_id'=>'12','status'=>1));
	// 	$prorefri = $this->model->getData('product_category',array('sub_category_id'=>'13','status'=>1));
	// 	$proari = $this->model->getData('product_category',array('sub_category_id'=>'14'));
	// 	$prowashing = $this->model->getData('product_category',array('sub_category_id'=>'15'));
	// 	$progaming = $this->model->getData('product_category',array('sub_category_id'=>'16'));
	// 	$prohomeapplication = $this->model->getData('product_category',array('sub_category_id'=>'17'));
	// 	$prohomefaur = $this->model->getData('product_category',array('sub_category_id'=>'18'));
	// 	$prokitchen = $this->model->getData('product_category',array('sub_category_id'=>'19'));
	// 	$prolighing = $this->model->getData('product_category',array('sub_category_id'=>'20'));
	// 	$prohealth = $this->model->getData('product_category',array('sub_category_id'=>'21'));
	// 	$probathroom = $this->model->getData('product_category',array('sub_category_id'=>'22'));
	// 	$prohardware = $this->model->getData('product_category',array('sub_category_id'=>'23'));
	// 	$proDecor = $this->model->getData('product_category',array('sub_category_id'=>'24'));
	// 	$profusion = $this->model->getData('product_category',array('sub_category_id'=>'25'));
	// 	$proWestern = $this->model->getData('product_category',array('sub_category_id'=>'26'));
	// 	$prosport = $this->model->getData('product_category',array('sub_category_id'=>'27'));
	// 	$proBags = $this->model->getData('product_category',array('sub_category_id'=>'28'));
	// 	$proFootwear = $this->model->getData('product_category',array('sub_category_id'=>'29'));
	// 	$proAccessories = $this->model->getData('product_category',array('sub_category_id'=>'30'));
	// 	$proJewellery = $this->model->getData('product_category',array('sub_category_id'=>'31'));
	// 	$proNightwear = $this->model->getData('product_category',array('sub_category_id'=>'32'));
	// 	$proTopwear = $this->model->getData('product_category',array('sub_category_id'=>'33'));
	// 	$proBottomwear = $this->model->getData('product_category',array('sub_category_id'=>'34'));
	// 	$prosportactive = $this->model->getData('product_category',array('sub_category_id'=>'35'));
	// 	$proFootwear = $this->model->getData('product_category',array('sub_category_id'=>'36'));
	// 	$prowomensBags = $this->model->getData('product_category',array('sub_category_id'=>'37'));
	// 	$promenwera = $this->model->getData('product_category',array('sub_category_id'=>'38'));
	// 	$proAcce = $this->model->getData('product_category',array('sub_category_id'=>'39'));
	// 	$proInnerwear = $this->model->getData('product_category',array('sub_category_id'=>'40'));
	// 	$proboycolth = $this->model->getData('product_category',array('sub_category_id'=>'41'));
	// 	$progirlcolth = $this->model->getData('product_category',array('sub_category_id'=>'42'));
	// 	$proboyfoot = $this->model->getData('product_category',array('sub_category_id'=>'43'));
	// 	$progirlfoot = $this->model->getData('product_category',array('sub_category_id'=>'44'));
	// 	$probabykids = $this->model->getData('product_category',array('sub_category_id'=>'46'));
	// 	$proBIGDEAL = $this->model->getData('product_category',array('sub_category_id'=>'47'));
	// 	//
	// 	$data['catname'] = $wellness;
	// 	$data['catELECTRONICS'] = $catELECTRONICS;
	// 	$data['homekitchen'] = $homekitchen;
	// 	$data['WOMENS'] = $WOMENS;
	// 	$data['MENS'] = $MENS;
	// 	$data['BABY'] = $BABY;
	// 	//
	// 	$data['babykids'] = $babykids;
	// 	$data['girlfoot'] = $girlfoot;
	// 	$data['boyfoot'] = $boyfoot;
	// 	$data['girlcolth'] = $girlcolth;
	// 	$data['boycolth'] = $boycolth;
	// 	$data['Innerwear'] = $Innerwear;
	// 	$data['Acce'] = $Acce;
	// 	$data['menwera'] = $menwera;
	// 	$data['womensBags'] = $womensBags;
	// 	$data['Footwear'] = $Footwear;
	// 	$data['sportactive'] = $sportactive;
	// 	$data['Bottomwear'] = $Bottomwear;
	// 	$data['Topwear'] = $Topwear;
	// 	$data['Nightwear'] = $Nightwear;
	// 	$data['Jewellery'] = $Jewellery;
	// 	$data['Accessories'] = $Accessories;
	// 	$data['Footwear'] = $Footwear;
	// 	$data['Bags'] = $Bags;
	// 	$data['sport'] = $sport;
	// 	$data['Western'] = $Western;
	// 	$data['fusion'] = $fusion;
	// 	$data['Decor'] = $Decor;
	// 	$data['hardware'] = $hardware;
	// 	$data['bathroom'] = $bathroom;
	// 	$data['health'] = $health;
	// 	$data['lighing'] = $lighing;
	// 	$data['kitchen'] = $kitchen;
	// 	$data['homefaur'] = $homefaur;
	// 	$data['homeapplication'] = $homeapplication;
	// 	$data['gaming'] = $gaming;
	// 	$data['washing'] = $washing;
	// 	$data['ari'] = $ari;
	// 	$data['refri'] = $refri;
	// 	$data['computer'] = $computer;
	// 	$data['laptop'] = $laptop;
	// 	$data['mobile'] = $mobile;
	// 	$data['homeent'] = $homeent;
	// 	$data['agri'] = $agri;
	// 	$data['baby'] = $baby;
	// 	$data['gym'] = $gym;
	// 	$data['home'] = $home;
	// 	$data['personal'] = $personal;
	// 	$data['Beauty'] = $Beauty;
	// 	$data['ELECTRONICS'] = $ELECTRONICS;
	// 	$data['subwellness'] = $subwellness;
	// 	//
	// 	$data['prowellness'] = $prowellness;
	// 	$data['proELECTRONICS'] = $proELECTRONICS;
	// 	$data['proBeauty'] = $proBeauty;
	// 	$data['propersonal'] = $propersonal;
	// 	$data['prohome'] = $prohome;
	// 	$data['progym'] = $progym;
	// 	$data['probaby'] = $probaby	;
	// 	$data['proagri'] = $proagri	;
	// 	$data['prohomeent'] = $prohomeent;
	// 	$data['promobile'] = $promobile;
	// 	$data['prolaptop'] = $prolaptop;
	// 	$data['procomputer'] = $procomputer;
	// 	$data['prorefri'] = $prorefri;
	// 	$data['proari'] = $proari;
	// 	$data['prowashing'] = $prowashing;
	// 	$data['progaming'] = $progaming;
	// 	$data['prohomeapplication'] = $prohomeapplication;
	// 	$data['prohomefaur'] = $prohomefaur;
	// 	$data['prokitchen'] = $prokitchen;
	// 	$data['prolighing'] = $prolighing;
	// 	$data['prohealth'] = $prohealth;
	// 	$data['probathroom'] = $probathroom;
	// 	$data['prohardware'] = $prohardware;
	// 	$data['proDecor'] = $proDecor;
	// 	$data['profusion'] = $profusion;
	// 	$data['proWestern'] = $proWestern;
	// 	$data['prosport'] = $prosport;
	// 	$data['proBags'] = $proBags;
	// 	$data['proFootwear'] = $proFootwear;
	// 	$data['proAccessories'] = $proAccessories;
	// 	$data['proJewellery'] = $proJewellery;
	// 	$data['proNightwear'] = $proNightwear;
	// 	$data['proTopwear'] = $proTopwear;
	// 	$data['proBottomwear'] = $proBottomwear;
	// 	$data['prosportactive'] = $prosportactive;
	// 	$data['proFootwear'] = $proFootwear;
	// 	$data['prowomensBags'] = $prowomensBags;
	// 	$data['promenwera'] = $promenwera;
	// 	$data['proAcce'] = $proAcce;
	// 	$data['proInnerwear'] = $proInnerwear;
	// 	$data['proboycolth'] = $proboycolth;
	// 	$data['progirlcolth'] = $progirlcolth;
	// 	$data['proboyfoot'] = $proboyfoot;
	// 	$data['progirlfoot'] = $progirlfoot;
	// 	$data['probabykids'] = $probabykids;
	// 	$data['proBIGDEAL'] = $proBIGDEAL;
	// 	//
 //         $this->load->view('textsecond',$data);
	// }
	
	// public function text()
	// {
	// 	$cat = $table = $this->model->getData('category');
	// 	$return[$cat->category_id] = $cat;
	// 	$sub_cat =$this->model->getData('subcategory',array('category_id'=>2,'status'=>1)); 
 //        $data['category'] = $cat;
 //        $data['sub'] = $sub_cat;
 //        $this->load->view('text',$data);

	// }

}
