<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class homewellness extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('model');
         $this->load->model('text');
         $this->load->model('orders_model');
    }
    public function FamilyNutrition()
	{
        
        // echo "hiii";
        $FamilyNutrition = $this->model->getData('wellness',array('Wellness_type'=>'FN','status'=>1));
        $data['categories'] = $this->text->get_categories();
        $data['FamilyNutrition'] = $FamilyNutrition;
		$this->load->view('FamilyNutrition',$data);
	}
	public function WeightLoss()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $weightloss = $this->model->getData('wellness',array('Wellness_type'=>'WL','status'=>1));
        $data['weightloss'] = $weightloss;
		$this->load->view('WeightLoss',$data);
	}
	public function BeautyCare()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $BeautyCare = $this->model->getData('wellness',array('Wellness_type'=>'BC','status'=>1));
        $data['BeautyCare'] = $BeautyCare;
		$this->load->view('BeautyCare',$data);
	}
	public function PersonalCare()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $PersonalCare = $this->model->getData('wellness',array('Wellness_type'=>'PC','status'=>1));
        $data['PersonalCare'] = $PersonalCare;
		$this->load->view('PersonalCare',$data);
	}
	public function HomeCare()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $HomeCare = $this->model->getData('wellness',array('Wellness_type'=>'HC','status'=>1));
        $data['HomeCare'] = $HomeCare;
		$this->load->view('HomeCare',$data);
	}
	public function GymCare()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $GymCare = $this->model->getData('wellness',array('Wellness_type'=>'GC','status'=>1));
        $data['GymCare'] = $GymCare;
		$this->load->view('GymCare',$data);
	}
	public function BabyCare()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $BabyCare = $this->model->getData('wellness',array('Wellness_type'=>'BA','status'=>1));
        $data['BabyCare'] = $BabyCare;
		$this->load->view('BabyCare',$data);
	}
	public function AgriProducts()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $AgriProducts = $this->model->getData('wellness',array('Wellness_type'=>'AP','status'=>1));
        $data['AgriProducts'] = $AgriProducts;
		$this->load->view('AgriProducts',$data);
	}
	public function HomeEntertainment()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $HomeEntertainment = $this->model->getData('electronics',array('Electronics_type'=>'HE','status'=>1));
        $data['HomeEntertainment'] = $HomeEntertainment;
		$this->load->view('HomeEntertainment',$data);
	}
	public function MobileAccessories()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $MobileAccessories = $this->model->getData('electronics',array('Electronics_type'=>'MA','status'=>1));
        $data['MobileAccessories'] = $MobileAccessories;
		$this->load->view('MobileAccessories',$data);
	}
	public function LaptopAccessories()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $LaptopAccessories = $this->model->getData('electronics',array('Electronics_type'=>'LA','status'=>1));
        $data['LaptopAccessories'] = $LaptopAccessories;
		$this->load->view('LaptopAccessories',$data);
	}
	public function ComputerAccessories()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $ComputerAccessories = $this->model->getData('electronics',array('Electronics_type'=>'CA','status'=>1));
        $data['ComputerAccessories'] = $ComputerAccessories;
		$this->load->view('ComputerAccessories',$data);
	}
	public function TVRefrigerators()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $TVRefrigerators = $this->model->getData('electronics',array('Electronics_type'=>'TR','status'=>1));
        $data['TVRefrigerators'] = $TVRefrigerators;
		$this->load->view('TVRefrigerators',$data);
	}
	public function AirConditioners()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $AirConditioners = $this->model->getData('electronics',array('Electronics_type'=>'AC','status'=>1));
        $data['AirConditioners'] = $AirConditioners;
		$this->load->view('AirConditioners',$data);
	}
	public function WashingMachine()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $WashingMachine = $this->model->getData('electronics',array('Electronics_type'=>'WM','status'=>1));
        $data['WashingMachine'] = $WashingMachine;
		$this->load->view('WashingMachine',$data);
	}
	public function GeysersGaming()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $GeysersGaming = $this->model->getData('electronics',array('Electronics_type'=>'GG','status'=>1));
        $data['GeysersGaming'] = $GeysersGaming;
		$this->load->view('GeysersGaming',$data);
	}
}
// homewellness/GeysersGaming