<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class E_Panelist_page_new extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
          $this->load->model('Text');
          // $this->load->model('Cart_model');
          //  $this->load->model('Add_category_model');
           // $this->load->model('customer');
          if(!$this->session->userdata('entube_customer_logged_in')){
         	redirect('Home');

         }

     }

function E_panelist_my_profile(){
	// $servername='172.19.2.230';
	// $username='membero_oxiinc';
	// $password='YD4{B@Cp;[wS';
	// $dbname = "membero_oxiinc";
	// $conn=mysqli_connect($servername,$username,$password,"$dbname");

	// $user_id = $this->session->userdata('employee_id');
	// $result=mysqli_query($conn,'select * from customers where id = '.$user_id.'');
	// $data['customers']=mysqli_fetch_assoc($result);
	// 	echo '<pre>'; print_r($data); exit;
	$this->load->view('epanelist_personal_information');
}

function E_panelist_Address(){
// $servername='172.19.2.230';
// $username='root';
// $password='';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");
$servername='172.19.2.230';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");


	$user_id = $this->session->userdata('employee_id');
	$result=mysqli_query($conn,'select * from address where user_id = '.$user_id.'');
$data['addresses']=mysqli_fetch_assoc($result);
// echo '<pre>'; print_r($data); exit;
$this->load->view('epanelist_Manage_Addresses',$data);
}
function  PAN_Card_Information(){
// 	$servername='localhost';
// $username='root';
// $password='';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");
$servername='172.19.2.230';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");


	$user_id = $this->session->userdata('employee_id');
	$result=mysqli_query($conn,'select * from customers where id = '.$user_id.'');
$data['customers']=mysqli_fetch_assoc($result);
// echo '<pre>'; print_r($data); exit;
$this->load->view('epanelist_PAN_Card_Information',$data);
}
 function My_Digital(){
 	      $data['employee_id'] = $this->session->userdata('employee_id');
		  $data['user_id'] = $this->session->userdata('user_id');
		if (!$this->session->userdata('api_customer_package_subpanel')=='1') {
			$message9=$this->customer_package_subpanel($data);
			$msg=json_decode($message9,true);
			$_SESSION['api_customer_package_subpanel']='1';
		    $_SESSION['package_id']=$msg['package_id'];
		    $_SESSION['subpanels']=$msg['subpanels'];
		    $_SESSION['free_trail']=$msg['free_trail'];
		}
     	//$this->load->view('My_digital');
     	$data['main_containt']='new_user/my_digital';
    	$this->load->view('new_user/containt', $data);
     }
 function My_Digital_New(){
     	$this->load->view('My_Digital_New');
     }
	function Withdrawl_balance_otp(){
		// echo '<pre>'; print_r('hi'); 
// 		  $servername='localhost';
// $username='root';
// $password='';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");
$servername='172.19.2.230';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");

$var = $this->session->userdata('employee_id');


$result=mysqli_query($conn,'select * from customers where id = '.$var.'');
$customer_information=mysqli_fetch_assoc($result);

$data['customer_information'] = $customer_information;
// echo '<pre>'; print_r($data['customer_information']); exit;

$email_id =  $customer_information['primary_email'];
		$user_name =  $customer_information['first_name'];
		$contact_number =  $customer_information['contact_1'];
		// echo '<pre>'; print_r($contact_number);
		$otp_code = mt_rand(10000,999999);
        		$array_data=array(
						
						'contact_number'=>$contact_number,
						'otp_code'=>$otp_code,
						'otp_date'=>date('Y-m-d'),
						
					);
        		$this->Model->insertData('epanelist_otp',array_map('strtoupper', $array_data));

        		// $this->send_otp_message($id,$contact_number,$otp_code); 
        		   	    $user = "oxiinc";
						$password = "microlan@123";
						$senderId = "OXIINC";
						$channel = "Trans";
						$dcs = "0";
						$flashsms = "0";
						$route = "6";
						// $mobile = $contact_number;
						$mobile = "7710929568";
						$otp_code = $otp_code;
			            $text_message = "Dear ". $mobile. ". This your otp".$otp_code.". We will process your Register at your chosen date and time.";
					    $sms = urlencode($text_message);

					    $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';
					    // echo '<pre>'; print_r($smsurl); exit;
					    try  
				        {
				            $ch = curl_init();
				            curl_setopt($ch, CURLOPT_HEADER, 0);
				            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				            curl_setopt($ch, CURLOPT_URL, $smsurl);
				            $data = curl_exec($ch);
				            curl_close($ch);
				            $response = $data;
				        }  
				        catch (Exception $e)  
				        {  
				            $response = $e->getMessage();  
				        }
	}
	function My_digital_money_panel(){
    
		if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username'])) && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    		$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

			if ($share_data) {
				redirect('E_Panelist_page_new/panel');
			}
	
			// echo '<pre>'; print_r($_POST); 
			$data['employee_id'] = $_POST['employee_id'];
			$data['user_id'] = $_POST['user_id'];
			$data['Link'] = $_POST['Link'];
			$data['Allow_id'] = $_POST['Allow_id'];
			$data['account_type'] = $_POST['account_type'];
			$data['username'] = $_POST['username'];
			$data['money'] = $_POST['money'];
			$data['serveice_charges'] = '5';
			$data['net_amount_credited'] = '95';
			$data['shopping_wallet_amount'] = '19';
			$data['digital_amount_credited'] = '76';
			$data['Panel_type'] = $_POST['Panel_type'];
			$data['caption'] = $_POST['caption'];
			$data['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
			// echo '<pre>'; print_r($data['Amount_Occurred_date']); exit;
			$data['insert_date_time']=date('Y-m-d H:i:s');
			$data['insert_month']= date('m');
		    $data['insert_year']= date('Y');
		    $data['insert_day']= date('d');
		    $data['insert_year_month']= date('Y-m');
		    $data['insert_year_month_data'] =date('Y-m-d');
		    $data['insert_year_month_data_time']= date('Y-m-d H:i:s');

			if ($_SESSION['package_id']) {
				if ($_SESSION['package_id']>='5') {
					$message=$this->mydigital_api($data);
					if ($message==1) {
						$this->Model->insertData('share_allow_data_inform',$data);
					}
					redirect('E_Panelist_page_new/panel');
				}
				else{
					if ($_SESSION['free_trail']) {
						$message_1=$this->mydigital_api($data);
					    if ($message_1==1) {
					        $this->Model->insertData('share_allow_data_inform',$data);
							redirect('E_Panelist_page_new/panel');
					    }else{
					       redirect('E_Panelist_page_new/panel'); 
					    }
					}
					else{
					    redirect('E_Panelist_page_new/panel');
					}
				}
			}
			else{
				redirect('E_Panelist_page_new/panel');
			}
		}
		redirect('E_Panelist_page_new/panel');
	}



function My_digital_money_sub_panel_1(){

	 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    
    		$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_1');
	}
	
	// echo '<pre>'; print_r($_POST); 
	$data1['employee_id'] = $_POST['employee_id'];
	$data1['user_id'] = $_POST['user_id'];
	$data1['Link'] = $_POST['Link'];
	$data1['Allow_id'] = $_POST['Allow_id'];
	$data1['account_type'] = $_POST['account_type'];
	$data1['username'] = $_POST['username'];
	$data1['money'] = $_POST['money'];
	$data1['serveice_charges'] = '5';
	$data1['net_amount_credited'] = '95';
	$data1['shopping_wallet_amount'] = '19';
	$data1['digital_amount_credited'] = '76';
	$data1['Panel_type'] = $_POST['Panel_type'];
	$data1['caption'] = $_POST['caption'];
	$data1['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data1['insert_date_time']=date('Y-m-d H:i:s');
	$data1['insert_month']= date('m');
    $data1['insert_year']= date('Y');
    $data1['insert_day']= date('d');
    $data1['insert_year_month']= date('Y-m');
    $data1['insert_year_month_data'] =date('Y-m-d');
    $data1['insert_year_month_data_time']= date('Y-m-d H:i:s');




if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='1') {
$message1=$this->mydigital_api($data1);
if ($message1==1) {
		$this->Model->insertData('share_allow_data_inform',$data1);
}
		redirect('E_Panelist_page_new/sub_panel_1');
	}else{
	    $this->Model->insertData('share_allow_data_inform',$data1);
		redirect('E_Panelist_page_new/sub_panel_1');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data1);
redirect('E_Panelist_page_new/sub_panel_1');
}
}




redirect('E_Panelist_page_new/sub_panel_1');

}


function My_digital_money_sub_panel_2(){
    
     if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    			$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_2');
	}
	
	// echo '<pre>'; print_r($_POST); 
	$data2['employee_id'] = $_POST['employee_id'];
	$data2['user_id'] = $_POST['user_id'];
	$data2['Link'] = $_POST['Link'];
	$data2['Allow_id'] = $_POST['Allow_id'];
	$data2['account_type'] = $_POST['account_type'];
	$data2['username'] = $_POST['username'];
	$data2['money'] = $_POST['money'];
	$data2['serveice_charges'] = '5';
	$data2['net_amount_credited'] = '95';
	$data2['shopping_wallet_amount'] = '19';
	$data2['digital_amount_credited'] = '76';
	$data2['Panel_type'] = $_POST['Panel_type'];
	$data2['caption'] = $_POST['caption'];
	$data2['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data2['insert_date_time']=date('Y-m-d H:i:s');
	$data2['insert_month']= date('m');
    $data2['insert_year']= date('Y');
    $data2['insert_day']= date('d');
    $data2['insert_year_month']= date('Y-m');
    $data2['insert_year_month_data'] =date('Y-m-d');
    $data2['insert_year_month_data_time']= date('Y-m-d H:i:s');





if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='2') {
$message2=$this->mydigital_api($data2);
if ($message2==1) {
		$this->Model->insertData('share_allow_data_inform',$data2);
}
		redirect('E_Panelist_page_new/sub_panel_2');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data2);
		redirect('E_Panelist_page_new/sub_panel_2');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data2);
redirect('E_Panelist_page_new/sub_panel_2');
}
}




redirect('E_Panelist_page_new/sub_panel_2');

}
function My_digital_money_sub_panel_3(){
    
     if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){


    				$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_3');
	}
	
	// echo '<pre>'; print_r($_POST); 
	$data3['employee_id'] = $_POST['employee_id'];
	$data3['user_id'] = $_POST['user_id'];
	$data3['Link'] = $_POST['Link'];
	$data3['Allow_id'] = $_POST['Allow_id'];
	$data3['account_type'] = $_POST['account_type'];
	$data3['username'] = $_POST['username'];
	$data3['money'] = $_POST['money'];
$data3['serveice_charges'] = '5';
	$data3['net_amount_credited'] = '95';
	$data3['shopping_wallet_amount'] = '19';
	$data3['digital_amount_credited'] = '76';
	$data3['Panel_type'] = $_POST['Panel_type'];
	$data3['caption'] = $_POST['caption'];
	$data3['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data3['insert_date_time']=date('Y-m-d H:i:s');
	$data3['insert_month']= date('m');
    $data3['insert_year']= date('Y');
    $data3['insert_day']= date('d');
    $data3['insert_year_month']= date('Y-m');
    $data3['insert_year_month_data'] =date('Y-m-d');
    $data3['insert_year_month_data_time']= date('Y-m-d H:i:s');
	


if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='3') {
$message3=$this->mydigital_api($data3);
if ($message3==1) {
			$this->Model->insertData('share_allow_data_inform',$data3);
		}
		redirect('E_Panelist_page_new/sub_panel_3');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data3);
		redirect('E_Panelist_page_new/sub_panel_3');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data3);
redirect('E_Panelist_page_new/sub_panel_3');
}
}




redirect('E_Panelist_page_new/sub_panel_3');

}
function My_digital_money_sub_panel_4(){

	 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    
    					$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_4');
	}
	
	// echo '<pre>'; print_r($_POST); 
	$data4['employee_id'] = $_POST['employee_id'];
	$data4['user_id'] = $_POST['user_id'];
	$data4['Link'] = $_POST['Link'];
	$data4['Allow_id'] = $_POST['Allow_id'];
	$data4['account_type'] = $_POST['account_type'];
	$data4['username'] = $_POST['username'];
	$data4['money'] = $_POST['money'];
	$data4['serveice_charges'] = '5';
	$data4['net_amount_credited'] = '95';
	$data4['shopping_wallet_amount'] = '19';
	$data4['digital_amount_credited'] = '76';
	$data4['Panel_type'] = $_POST['Panel_type'];
	$data4['caption'] = $_POST['caption'];
	$data4['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data4['insert_date_time']=date('Y-m-d H:i:s');
	$data4['insert_month']= date('m');
    $data4['insert_year']= date('Y');
    $data4['insert_day']= date('d');
    $data4['insert_year_month']= date('Y-m');
    $data4['insert_year_month_data'] =date('Y-m-d');
    $data4['insert_year_month_data_time']= date('Y-m-d H:i:s');





if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='4') {
$message4=$this->mydigital_api($data4);
if ($message4==1) {
	$this->Model->insertData('share_allow_data_inform',$data4);
}
		redirect('E_Panelist_page_new/sub_panel_4');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data4);
redirect('E_Panelist_page_new/sub_panel_4');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data4);
redirect('E_Panelist_page_new/sub_panel_4');
}
}


redirect('E_Panelist_page_new/sub_panel_4');



}

function My_digital_money_sub_panel_5(){

 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){


    
    						$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_5');
	}
	// echo '<pre>'; print_r($_POST); 
	$data5['employee_id'] = $_POST['employee_id'];
	$data5['user_id'] = $_POST['user_id'];
	$data5['Link'] = $_POST['Link'];
	$data5['Allow_id'] = $_POST['Allow_id'];
	$data5['account_type'] = $_POST['account_type'];
	$data5['username'] = $_POST['username'];
	$data5['money'] = $_POST['money'];
	$data5['serveice_charges'] = '5';
	$data5['net_amount_credited'] = '95';
	$data5['shopping_wallet_amount'] = '19';
	$data5['digital_amount_credited'] = '76';
	$data5['Panel_type'] = $_POST['Panel_type'];
	$data5['caption'] = $_POST['caption'];
	$data5['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data5['insert_date_time']=date('Y-m-d H:i:s');
	$data5['insert_month']= date('m');
    $data5['insert_year']= date('Y');
    $data5['insert_day']= date('d');
    $data5['insert_year_month']= date('Y-m');
    $data5['insert_year_month_data'] =date('Y-m-d');
    $data5['insert_year_month_data_time']= date('Y-m-d H:i:s');




if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='5') {
$message5=$this->mydigital_api($data5);
if ($message5==1) {
	$this->Model->insertData('share_allow_data_inform',$data5);
}
		redirect('E_Panelist_page_new/sub_panel_5');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data5);
redirect('E_Panelist_page_new/sub_panel_5');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data5);
redirect('E_Panelist_page_new/sub_panel_5');
}
}


redirect('E_Panelist_page_new/sub_panel_5');



}
function My_digital_money_sub_panel_6(){

	 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    
    $share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_6');
	}
	
	// echo '<pre>'; print_r($_POST); 
	$data6['employee_id'] = $_POST['employee_id'];
	$data6['user_id'] = $_POST['user_id'];
	$data6['Link'] = $_POST['Link'];
	$data6['Allow_id'] = $_POST['Allow_id'];
	$data6['account_type'] = $_POST['account_type'];
	$data6['username'] = $_POST['username'];
	$data6['money'] = $_POST['money'];
	$data6['serveice_charges'] = '5';
	$data6['net_amount_credited'] = '95';
	$data6['shopping_wallet_amount'] = '19';
	$data6['digital_amount_credited'] = '76';
	$data6['Panel_type'] = $_POST['Panel_type'];
	$data6['caption'] = $_POST['caption'];
	$data6['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data6['insert_date_time']=date('Y-m-d H:i:s');
	$data6['insert_month']= date('m');
    $data6['insert_year']= date('Y');
    $data6['insert_day']= date('d');
    $data6['insert_year_month']= date('Y-m');
    $data6['insert_year_month_data'] =date('Y-m-d');
    $data6['insert_year_month_data_time']= date('Y-m-d H:i:s');
	

if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='6') {
$message6=$this->mydigital_api($data6);
if ($message6==1) {
	$this->Model->insertData('share_allow_data_inform',$data6);
}
		redirect('E_Panelist_page_new/sub_panel_6');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data6);
redirect('E_Panelist_page_new/sub_panel_6');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data6);
redirect('E_Panelist_page_new/sub_panel_6');
}
}


redirect('E_Panelist_page_new/sub_panel_6');



}
function My_digital_money_sub_panel_7(){

	 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    
    	$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_7');
	}
	// echo '<pre>'; print_r($_POST); 
	$data7['employee_id'] = $_POST['employee_id'];
	$data7['user_id'] = $_POST['user_id'];
	$data7['Link'] = $_POST['Link'];
	$data7['Allow_id'] = $_POST['Allow_id'];
	$data7['account_type'] = $_POST['account_type'];
	$data7['username'] = $_POST['username'];
	$data7['money'] = $_POST['money'];
	$data7['serveice_charges'] = '5';
	$data7['net_amount_credited'] = '95';
	$data7['shopping_wallet_amount'] = '19';
	$data7['digital_amount_credited'] = '76';
	$data7['Panel_type'] = $_POST['Panel_type'];
	$data7['caption'] = $_POST['caption'];
	$data7['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data7['insert_date_time']=date('Y-m-d H:i:s');
	$data7['insert_month']= date('m');
    $data7['insert_year']= date('Y');
    $data7['insert_day']= date('d');
    $data7['insert_year_month']= date('Y-m');
    $data7['insert_year_month_data'] =date('Y-m-d');
    $data7['insert_year_month_data_time']= date('Y-m-d H:i:s');
	



if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='7') {
$message7=$this->mydigital_api($data7);
if ($message7==1) {
	$this->Model->insertData('share_allow_data_inform',$data7);
}
		redirect('E_Panelist_page_new/sub_panel_7');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data7);
redirect('E_Panelist_page_new/sub_panel_7');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data7);
redirect('E_Panelist_page_new/sub_panel_7');
}
}


redirect('E_Panelist_page_new/sub_panel_7');



}
function My_digital_money_sub_panel_8(){

	 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    
    		$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_8');
	}
	// echo '<pre>'; print_r($_POST); 
	$data8['employee_id'] = $_POST['employee_id'];
	$data8['user_id'] = $_POST['user_id'];
	$data8['Link'] = $_POST['Link'];
	$data8['Allow_id'] = $_POST['Allow_id'];
	$data8['account_type'] = $_POST['account_type'];
	$data8['username'] = $_POST['username'];
	$data8['money'] = $_POST['money'];
	$data8['serveice_charges'] = '5';
	$data8['net_amount_credited'] = '95';
	$data8['shopping_wallet_amount'] = '19';
	$data8['digital_amount_credited'] = '76';
	$data8['Panel_type'] = $_POST['Panel_type'];
	$data8['caption'] = $_POST['caption'];
	$data8['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data8['insert_date_time']=date('Y-m-d H:i:s');
	$data8['insert_month']= date('m');
    $data8['insert_year']= date('Y');
    $data8['insert_day']= date('d');
    $data8['insert_year_month']= date('Y-m');
    $data8['insert_year_month_data'] =date('Y-m-d');
    $data8['insert_year_month_data_time']= date('Y-m-d H:i:s');
	

if ($_SESSION['subpanels']) {
	if ($_SESSION['subpanels']>='8') {
$message8=$this->mydigital_api($data8);
if ($message8) {
	$this->Model->insertData('share_allow_data_inform',$data8);
}
		redirect('E_Panelist_page_new/sub_panel_8');
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data8);
redirect('E_Panelist_page_new/sub_panel_8');
	}
}else{
    // $this->Model->insertData('share_allow_data_inform',$data8);
redirect('E_Panelist_page_new/sub_panel_8');
}
}


redirect('E_Panelist_page_new/sub_panel_8');



}
function My_digital_money_sub_panel_9(){
	 if((!empty($_POST['employee_id'])) && (!empty($_POST['user_id'])) && (!empty($_POST['Link'])) && (!empty($_POST['Allow_id'])) && (!empty($_POST['account_type'])) && (!empty($_POST['username']))
	 && (!empty($_POST['money'])) && (!empty($_POST['Panel_type'])) && (!empty($_POST['caption']))){

    
    			$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

	if ($share_data) {
		redirect('E_Panelist_page_new/sub_panel_9');
	}
	// echo '<pre>'; print_r($_POST); 
	$data9['employee_id'] = $_POST['employee_id'];
	$data9['user_id'] = $_POST['user_id'];
	$data9['Link'] = $_POST['Link'];
	$data9['Allow_id'] = $_POST['Allow_id'];
	$data9['account_type'] = $_POST['account_type'];
	$data9['username'] = $_POST['username'];
	$data9['money'] = $_POST['money'];
	$data9['serveice_charges'] = '5';
	$data9['net_amount_credited'] = '95';
	$data9['shopping_wallet_amount'] = '19';
	$data9['digital_amount_credited'] = '76';
	$data9['Panel_type'] = $_POST['Panel_type'];
	$data9['caption'] = $_POST['caption'];
	$data9['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
	$data9['insert_date_time']=date('Y-m-d H:i:s');
	$data9['insert_month']= date('m');
    $data9['insert_year']= date('Y');
    $data9['insert_day']= date('d');
    $data9['insert_year_month']= date('Y-m');
    $data9['insert_year_month_data'] =date('Y-m-d');
    $data9['insert_year_month_data_time']= date('Y-m-d H:i:s');
	

	if ($_SESSION['subpanels']) {
		if ($_SESSION['subpanels']>='9') {
	$message9=$this->mydigital_api($data9);
	if ($message9) {
		$this->Model->insertData('share_allow_data_inform',$data9);
	}
			redirect('E_Panelist_page_new/sub_panel_9');
		}else{
		    // $this->Model->insertData('share_allow_data_inform',$data9);
	redirect('E_Panelist_page_new/sub_panel_9');
		}
	}else{
	    // $this->Model->insertData('share_allow_data_inform',$data9);
	redirect('E_Panelist_page_new/sub_panel_9');
	}
	}


	redirect('E_Panelist_page_new/sub_panel_9');



	}

	function My_digital_money_Demo_panel(){
    	$share_data = $this->Model->getData('share_allow_data_inform',array('Allow_id'=>$_POST['Allow_id'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));

		if ($share_data) {
			redirect('E_Panelist_page/demo_panel');
		}
		// echo '<pre>'; print_r($_POST); 
		$data90['employee_id'] = $_POST['employee_id'];
		$data90['user_id'] = $_POST['user_id'];
		$data90['Link'] = $_POST['Link'];
		$data90['Allow_id'] = $_POST['Allow_id'];
		$data90['account_type'] = $_POST['account_type'];
		$data90['username'] = $_POST['username'];
		$data90['money'] = $_POST['money'];
		$data90['serveice_charges'] = '5';
		$data90['net_amount_credited'] = '95';
		$data90['shopping_wallet_amount'] = '19';
		$data90['digital_amount_credited'] = '76';
		$data90['Panel_type'] = $_POST['Panel_type'];
		$data90['caption'] = $_POST['caption'];
		$data90['Amount_Occurred_date'] = date('Y-m-d',strtotime("+30 days"));
		$data90['insert_date_time']=date('Y-m-d H:i:s');
		$data90['insert_month']= date('m');
	    $data90['insert_year']= date('Y');
	    $data90['insert_day']= date('d');
	    $data90['insert_year_month']= date('Y-m');
	    $data90['insert_year_month_data'] =date('Y-m-d');
	    $data90['insert_year_month_data_time']= date('Y-m-d H:i:s');
		$this->Model->insertData('share_allow_data_inform',$data90);

		redirect('E_Panelist_page/demo_panel');
	}

	function panel(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='panel' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

		//COMMENT BY MOHD ALAM 28/05/2020
		//$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='panel' AND allow_year_month_data >='2020-02-04' AND  expirey_date <='2020-02-17' LIMIT 5";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/panel';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_1(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));
			
		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_1' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_1';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_2(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_2' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_2';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_3(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_3' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_3';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_4(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_4' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_4';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_5(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_5' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_5';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_6(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_6' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_6';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_7(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_7' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_7';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_8(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_8' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_8';
    	$this->load->view('new_user/containt', $data);
	}

	function sub_panel_9(){
		$user_id =  $this->session->userdata('employee_id');
		$givenDate=date("Y-m-d");
		$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
		$to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));

		$allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='sub_panel_9' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";

        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);

        $data['main_containt']='new_user/sub_panel_9';
    	$this->load->view('new_user/containt', $data);
	}

	function demo_panel(){
		$user_id =  $this->session->userdata('employee_id'); 


					$givenDate=date("Y-m-d");
					$from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
					$to_date		 = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));
// echo '<pre>'; print_r($givenDate); exit;
		// $data['custumer_login'] = $this->Model->getData('allow_data_my_digital',array('id'=>$id));
		     // $allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='panel' AND allow_year_month_data  BETWEEN '".$to_date."' AND '".$from_date."'";
					 $allow_data_my_digital = "SELECT * FROM allow_data_my_digital WHERE panel_name='demo_panel' AND allow_year_month_data >='".$to_date."' AND  expirey_date <='".$from_date."'  ";
        $data['allow_data_my_digital'] = $this->Model->getSqlData($allow_data_my_digital);
        // echo '<pre>'; print_r($data['allow_data_my_digital']); exit;
        $this->load->view('demo_panel',$data);
	}
 public function Customer_orders()
	{	
		

		$id =  $this->session->userdata('id'); 
		$user_id =  $this->session->userdata('employee_id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$data['Customer_orders'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('user_id'=>$user_id),'ID','DESC');
// echo '<pre>'; print_r($data['Customer_orders']); exit;
		$this->load->view('E_panelist_Customer_orders',$data);
		// echo "<pre>";print_r($data);exit;
	}
			function Order_details(){

		$id =  $this->session->userdata('id'); 
		$user_id =  $this->session->userdata('employee_id'); 
		$data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		// echo '<pre>'; print_r($_GET); exit;
		$txid = $_GET['id'];
		$Order_details = $this->Model->getData('e_paenlist_order_data',array('txnid'=>$txid));
		$data['Order_details'] = $Order_details;
        $data['Order_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Order_details[0]['address_id']));

		$this->load->view('E_panelist_Order_details',$data);
		// echo '<pre>'; print_r($data['Order_details']); exit;
	}
	public function Eplanelist_process_payment(){
		// echo '<pre>'; print_r($_POST); exit;
	
		if (!empty($_POST['cod'])) {
			# code...
				echo '<pre>'; print_r($_POST); exit;
		$id =   $this->session->userdata('employee_id');; 
		$size = $this->input->post('size');
		// $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		
		// $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$epanelist_Shipping_address= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));
		$shipping_ID =  $epanelist_Shipping_address[0]['ID'];
		$shipping_user_id =  $epanelist_Shipping_address[0]['user_id'];
		$shipping_employee_id=  $epanelist_Shipping_address[0]['employee_id'];
		$shipping_Name =  $epanelist_Shipping_address[0]['Name'];
		$shipping_Phone_number =  $epanelist_Shipping_address[0]['Phone_number'];
		$shipping_Pincode =  $epanelist_Shipping_address[0]['Pincode'];
		$shipping_Locality =  $epanelist_Shipping_address[0]['Locality'];
		$shipping_address =  $epanelist_Shipping_address[0]['address'];
		$shipping_City =  $epanelist_Shipping_address[0]['City'];
		$shipping_state =  $epanelist_Shipping_address[0]['state'];
		$shipping_Landmark =  $epanelist_Shipping_address[0]['Landmark'];
		$shipping_Alternate_Phone =  $epanelist_Shipping_address[0]['Alternate_Phone'];
		$shipping_Address_type =  $epanelist_Shipping_address[0]['Address_type'];

		$billing_address_1 = $this->input->post('address_1');
		$billing_address_2 = $this->input->post('address_2');
		$billing_site_name = $this->input->post('site_name');
		$billing_pincode = $this->input->post('pincode');
		$billing_areas = $this->input->post('areas');
		$billing_cities = $this->input->post('cities');
		$billing_states = $this->input->post('states');
		$product_id = $this->input->post('product_id');
		$quantity = $this->input->post('quantity');
		$product_name = $this->input->post('product_name');
		$Product_Picture = $this->input->post('Product_picture');
		// echo '<pre>'; print_r($product_name); exit;
		$company_name = $this->input->post('company_name');
		$subtotal = $this->input->post('subtotal');
		$original = $this->input->post('original');
		$gst_price = $this->input->post('gst_price');
		$Shipping_Charges = $this->input->post('Shipping_Charges');
		$total_gst = $this->input->post('total_gst');
		// $Promo_amount = $this->input->post('Promo_amount');
		$total_shipping = $this->input->post('total_shipping');
		$user_id = $this->input->post('user_id');
		$total_price = $this->input->post('total_price');
		$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	
// echo '<pre>'; print_r($total_price); exit;


          // $promo_id = $this->input->post('promo_id');

          // if ($promo_id) {
          // 	$promo_code_id = $promo_id;
          // }else{
          // 	$promo_code_id = '0';
          // }


          // if($Promo_amount){

          // 	$promo_amout = $Promo_amount;

          // }else{
          // 	$promo_amout = 0;
          // }

     




		 if($Shipping_address!="" && $product_id!="" && $user_id!=""){
		$i=0;
		foreach ($product_id as $key => $value) {
			
		    $order_data = array(
					'user_id'=>$user_id,
					'Shipping_address'=>$Shipping_address,
					'shipping_ID'=>$shipping_ID,
					'shipping_user_id'=>$shipping_user_id,
					'shipping_employee_id'=>$shipping_employee_id,
					'shipping_Name'=>$shipping_Name,
					'shipping_Phone_number'=>$shipping_Phone_number,
					'shipping_Pincode'=>$shipping_Pincode,
					'shipping_Locality'=>$shipping_Locality,
					'shipping_address_in'=>$shipping_address,
					'shipping_City'=>$shipping_City,
					'shipping_state'=>$shipping_state,
					'shipping_Landmark'=>$shipping_Landmark,
					'shipping_Alternate_Phone'=>$shipping_Alternate_Phone,
					'shipping_Address_type'=>$shipping_Address_type,
					

					'billing_address_1'=>$billing_address_1,
					'billing_address_2'=>$billing_address_2,
					'billing_site_name'=>$billing_site_name,
					'billing_pincode'=>$billing_pincode,
					'billing_areas'=>$billing_areas,
					'billing_cities'=>$billing_cities,
					'billing_states'=>$billing_states,




					'product_id'=>$value,
					'Product_Name'=>$product_name[$i],
					'Product_Picture'=>$Product_Picture[$i],
					'Prices' => $subtotal[$i],
					'product_qty' => $quantity[$i],
					'Original_Prices'=>$original[$i],
					'size'=>$size[$i],
					'gst_price'=>$gst_price[$i],
					'total_gst'=>$total_gst,
					// 'promo_code_id'=>$promo_code_id,
					// 'Promo_amount'=>$promo_amout,
					'Shipping_Charges'=>$Shipping_Charges[$i],
					'total_shipping'=>$total_shipping,
					'txnid'=>$txnid,
					'total_amount'=>$total_price,
					'after_discounted_amount'=>'0',
					'payment_method'=>'COD',
					'address_id'=>$Shipping_address,
					'order_date_time'=>date('Y-m-d H:i:s'),
					'order_month'=> date('m'),
                    'order_year'=> date('Y'),
                    'order_day'=> date('d'),
                    'order_year_month'=> date('Y-m'),
                    'order_year_month_data' =>date('Y-m-d'),
                    'order_year_month_data_time'=> date('Y-m-d H:i:s'),
					
				);
		    // echo '<pre>'; print_r($order_data); exit;
		 $order_id = $this->Model->insertData('e_paenlist_order_data',$order_data);
		// $order_id = $this->Model->insertData('order_data',array_map('strtoupper', $order_data));
		 $i++;
		}








		// $user_order_data = $this->Model->getData('e_paenlist_order_data',array('txnid'=>$txnid));
		// $data['user_order_data'] = $user_order_data;
		// $data['user_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$user_order_data[0]['address_id']));
		// echo '<pre>'; print_r($data['user_manage_addresses']); exit;


		// $this->cart->destroy();
		/*$this->cart->destroy();*/
		$data['total_shipping']=$_POST['total_shipping'];
		$data['total_gst']=$_POST['total_gst'];
		$data['payment_method']='DIGITAL WALLET';
		// $data['Promo_amount']=$_POST['Promo_amount'];
		// $data['promo_id']=$_POST['promo_id'];
		$data['Order_Date']=date('d-M-Y');
		$data['shipping_address']=$_POST['Shipping_address'];
		$data['total_price']=$_POST['total_price'];
		$data['total_cart'] = $this->cart->total_items();
		$data['txnid']= $txnid;
		$this->load->view('Eplanelist_process_payment_notcomplete',$data);
	}else{
       	echo 'fail';
      }
}
			if (!empty($_POST['payumoney'])) {





  $servername='172.19.2.230';
$username='root';
$password='';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
// $servername='172.19.2.230';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");

$var = $this->session->userdata('employee_id');


$result=mysqli_query($conn,'select * from customers where id = '.$var.'');
$customer_information=mysqli_fetch_assoc($result);

$data['customer_information'] = $customer_information;
// echo '<pre>'; print_r($data['customer_information']); exit;

$email_id =  $customer_information['primary_email'];
		$user_name =  $customer_information['first_name'];
		$contact_number =  $customer_information['contact_1'];

$data['promo_amout'] = 0;

$amount = $this->input->post('total_price');
          $data['total_price'] = $amount;
           $total_cart = $this->cart->total_items();
          $data['total_cart'] = $total_cart;
           $product_info = 'Total '.$total_cart.' product in cart';
          $data['product_info'] = $product_info;
          $customer_name = $user_name;
          $data['customer_name'] = $customer_name;
           $customer_emial = $email_id;
		  $data['customer_emial'] = $customer_emial;
		  $customer_mobile = $contact_number;
		  $data['customer_mobile'] = $customer_mobile;
		  $customer_address = $this->input->post('Shipping_address');
$data['customer_employee_id'] = $this->session->userdata('employee_id');


		  $MERCHANT_KEY = "rjQUPktU"; //change  merchant with yours
           $data['MERCHANT_KEY'] =  $MERCHANT_KEY;
	       $SALT = "e5iIg1jwi8";  //change salt with yours 
           $data['SALT'] =  $SALT;


            $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	        $data['txnid'] =  $txnid;
	         //optional udf values 
	        $udf1 = '';
	        $udf2 = '';
	        $udf3 = '';
	        $udf4 = '';
	        $udf5 = '';

	        $hashstring = $MERCHANT_KEY . '|' . $txnid . '|' . $amount . '|' . $product_info . '|' . $customer_name . '|' . $customer_emial . '|' . $udf1 . '|' . $udf2 . '|' . $udf3 . '|' . $udf4 . '|' . $udf5 . '||||||' . $SALT;
	         $hash = strtolower(hash('sha512', $hashstring));
              $data['hash'] =  $hash;

	          $success = base_url() . 'E_panelist_payumoney';  
	           $data['success'] =  $success;
	        $fail = base_url() . 'E_panelist_payumoney';
	         $data['fail'] =  $fail;
	        $cancel = base_url() . 'E_panelist_payumoney';
	         $data['cancel'] =  $cancel;



	         $data['action'] = "https://test.payu.in"; //for live change action  https://secure.payu.in



			$data['manage_addresses']= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$_POST['Shipping_address']));
			// echo '<pre>'; print_r($data['manage_addresses']); exit;
			$data['address_1'] = $_POST['address_1'];
			$data['address_2'] = $_POST['address_2'];
			$data['site_name'] = $_POST['site_name'];
			$data['pincode'] = $_POST['pincode'];
			$data['areas'] = $_POST['areas'];
			$data['cities'] = $_POST['cities'];
			$data['states'] = $_POST['states'];
			// echo '<pre>'; print_r($_POST); exit;
// echo '<pre>'; print_r($data); exit;
			$this->load->view('E_panelist_payumoney',$data);
		}

if (!empty($_POST['Withdrawl_balance'])) {
	
	if ($_POST['otp_epanelist']) {
		// echo '<pre>'; print_r($_POST); exit;
		$date_infor = date('Y-m-d');
		$forget_data = $this->Model->getData('epanelist_otp',array('otp_code'=>$_POST['otp_epanelist'],'otp_date'=>$date_infor));
	// echo '<pre>'; print_r($forget_data); exit;
		if ($forget_data) {
			# code...
		// echo '<pre>'; print_r($_POST); exit;
		$id =   $this->session->userdata('employee_id');; 
		$size = $this->input->post('size');
		// $data['manage_addresses'] = $this->Model->getData('manage_addresses',array('Customer_id'=>$id));
		
		// $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
		$Shipping_address = $this->input->post('Shipping_address');
		$epanelist_Shipping_address= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$Shipping_address));
		$shipping_ID =  $epanelist_Shipping_address[0]['ID'];
		$shipping_user_id =  $epanelist_Shipping_address[0]['user_id'];
		$shipping_employee_id=  $epanelist_Shipping_address[0]['employee_id'];
		$shipping_Name =  $epanelist_Shipping_address[0]['Name'];
		$shipping_Phone_number =  $epanelist_Shipping_address[0]['Phone_number'];
		$shipping_Pincode =  $epanelist_Shipping_address[0]['Pincode'];
		$shipping_Locality =  $epanelist_Shipping_address[0]['Locality'];
		$shipping_address =  $epanelist_Shipping_address[0]['address'];
		$shipping_City =  $epanelist_Shipping_address[0]['City'];
		$shipping_state =  $epanelist_Shipping_address[0]['state'];
		$shipping_Landmark =  $epanelist_Shipping_address[0]['Landmark'];
		$shipping_Alternate_Phone =  $epanelist_Shipping_address[0]['Alternate_Phone'];
		$shipping_Address_type =  $epanelist_Shipping_address[0]['Address_type'];

		$billing_address_1 = $this->input->post('address_1');
		$billing_address_2 = $this->input->post('address_2');
		$billing_site_name = $this->input->post('site_name');
		$billing_pincode = $this->input->post('pincode');
		$billing_areas = $this->input->post('areas');
		$billing_cities = $this->input->post('cities');
		$billing_states = $this->input->post('states');
		$product_id = $this->input->post('product_id');
		$quantity = $this->input->post('quantity');
		$product_name = $this->input->post('product_name');
		$Product_Picture = $this->input->post('Product_picture');
		// echo '<pre>'; print_r($product_name); exit;
		$company_name = $this->input->post('company_name');
		$subtotal = $this->input->post('subtotal');
		$original = $this->input->post('original');
		$gst_price = $this->input->post('gst_price');
		$Shipping_Charges = $this->input->post('Shipping_Charges');
		$total_gst = $this->input->post('total_gst');
		// $Promo_amount = $this->input->post('Promo_amount');
		$total_shipping = $this->input->post('total_shipping');
		$user_id = $this->input->post('user_id');
		$total_price = $this->input->post('total_price');
		$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	
	 if($Shipping_address!="" && $product_id!="" && $user_id!=""){
		$i=0;
		foreach ($product_id as $key => $value) {
			
		    $order_data = array(
					'user_id'=>$user_id,
					'Shipping_address'=>$Shipping_address,
					'shipping_ID'=>$shipping_ID,
					'shipping_user_id'=>$shipping_user_id,
					'shipping_employee_id'=>$shipping_employee_id,
					'shipping_Name'=>$shipping_Name,
					'shipping_Phone_number'=>$shipping_Phone_number,
					'shipping_Pincode'=>$shipping_Pincode,
					'shipping_Locality'=>$shipping_Locality,
					'shipping_address_in'=>$shipping_address,
					'shipping_City'=>$shipping_City,
					'shipping_state'=>$shipping_state,
					'shipping_Landmark'=>$shipping_Landmark,
					'shipping_Alternate_Phone'=>$shipping_Alternate_Phone,
					'shipping_Address_type'=>$shipping_Address_type,
					

					'billing_address_1'=>$billing_address_1,
					'billing_address_2'=>$billing_address_2,
					'billing_site_name'=>$billing_site_name,
					'billing_pincode'=>$billing_pincode,
					'billing_areas'=>$billing_areas,
					'billing_cities'=>$billing_cities,
					'billing_states'=>$billing_states,




					'product_id'=>$value,
					'Product_Name'=>$product_name[$i],
					'Product_Picture'=>$Product_Picture[$i],
					'Prices' => $subtotal[$i],
					'product_qty' => $quantity[$i],
					'Original_Prices'=>$original[$i],
					'size'=>$size[$i],
					'gst_price'=>$gst_price[$i],
					'total_gst'=>$total_gst,
					// 'promo_code_id'=>$promo_code_id,
					// 'Promo_amount'=>$promo_amout,
					'Shipping_Charges'=>$Shipping_Charges[$i],
					'total_shipping'=>$total_shipping,
					'txnid'=>$txnid,
					'total_amount'=>$total_price,
					'after_discounted_amount'=>'0',
					'payment_method'=>'DIGITAL WALLET',
					'address_id'=>$Shipping_address,
					'order_date_time'=>date('Y-m-d H:i:s'),
					'order_month'=> date('m'),
                    'order_year'=> date('Y'),
                    'order_day'=> date('d'),
                    'order_year_month'=> date('Y-m'),
                    'order_year_month_data' =>date('Y-m-d'),
                    'order_year_month_data_time'=> date('Y-m-d H:i:s'),
					
				);
		    // echo '<pre>'; print_r($order_data); exit;
		 $order_id = $this->Model->insertData('e_paenlist_order_data',$order_data);
		// $order_id = $this->Model->insertData('order_data',array_map('strtoupper', $order_data));
		 $i++;
		}








		// $user_order_data = $this->Model->getData('e_paenlist_order_data',array('txnid'=>$txnid));
		// $data['user_order_data'] = $user_order_data;
		// $data['user_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$user_order_data[0]['address_id']));
		// echo '<pre>'; print_r($data['user_manage_addresses']); exit;


		// $this->cart->destroy();
		/*$this->cart->destroy();*/
		$data['total_shipping']=$_POST['total_shipping'];
		$data['total_gst']=$_POST['total_gst'];
		$data['payment_method']='DIGITAL WALLET';
		// $data['Promo_amount']=$_POST['Promo_amount'];
		// $data['promo_id']=$_POST['promo_id'];
		$data['Order_Date']=date('d-M-Y');
		$data['shipping_address']=$_POST['Shipping_address'];
		$data['total_price']=$_POST['total_price'];
		$data['total_cart'] = $this->cart->total_items();
		$data['txnid']= $txnid;
		$this->load->view('Eplanelist_process_payment_notcomplete',$data);
	}else{
       	echo 'fail';
      }
  }else{
  	$this->session->set_flashdata('msg','Invalid OTP code is entered.');
			redirect('Home');
  }
  }else{
  	$this->session->set_flashdata('msg','Plz Enter Otp Code.');
			redirect('Home');	
  }
}

	}
	public function customer_package_subpanel($value)
	{
		$data['employee_id'] = $value['employee_id'];
		$data['user_id'] = $value['user_id'];
		$url = "https://www.oxiinc.com/api/customer_package_subpanel?".http_build_query($data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
	}
	public function mydigital_api($data){
		$url = "https://www.oxiinc.com/api/mydigital_task?".http_build_query($data);
		//echo "<pre>";print_r($url);die();
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        $output = curl_exec($ch);
        curl_close($ch);
		return $output;

	}		
}