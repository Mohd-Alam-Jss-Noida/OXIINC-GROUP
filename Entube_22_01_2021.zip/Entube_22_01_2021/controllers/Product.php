<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
         $this->load->model('Files');
         // $this->load->model('Orders_model');
         
         if(!$this->session->userdata('is_logged_in')){
         	redirect('login');
         }
	}
	public function Add_product()
	{
        $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
		$data['main_containt']='add_product_page';
        $this->load->view('containt',$data);
	}
	function getSubCategory(){
       $postData = $_POST;
        // $postData['category_id'] = 1;

        $sub_category_list = $this->Model->getData('subcategory',array('status'=>'1'));

        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['category_id'] == $value['category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }
    function getproCategory(){
       $postData = $_POST;
        // $postData['category_id'] = 1;

        $sub_category_list = $this->Model->getData('product_category',array('status'=>'1'));

        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['sub_category_id'] == $value['sub_category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }
    public function Product_List()
	{
        $product_list = $this->Model->getData('wellness');
        $data['product_list'] = $product_list;
		$data['main_containt']='product_List';
        $this->load->view('containt',$data);
	}
	public function Product_eidt()
	{
        $ID = $_GET['ID'];
        $data['category_name'] = $this->Model->getData('category',array('status'=>'1'));
        $data['sub_category_name'] = $this->Model->getData('subcategory',array('status'=>'1'));
		$data['product_category_name'] = $this->Model->getData('product_category',array('status'=>'1'));
		$data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));
		$data['main_containt']='Product_eidt';

        $this->load->view('containt',$data);
	}
	// public function Product_edit_form()
	// {

	// 	$this->Model->updateData('wellness',$_POST,array('ID'=>$_POST['ID']));
 //        $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
	// 	redirect('Product/Product_List');
	// }
     function Product_edit_form(){
        // echo '<pre>'; print_r($_POST); exit;
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Product_Picture'])){
            $uploaddir = './uploads/product/';
            $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

            if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('wellness',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        
         $product_list = $this->Model->getData('wellness');
        $data['product_list'] = $product_list;
        $data['main_containt']='product_List';
        $this->load->view('containt',$data);
    }
	function Product_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('wellness',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

        redirect('Product/product_List');
    }
    function products_add(){
         $user_array = $_POST;
         $this->Model->insertData('wellness',$user_array);
          $this->session->set_flashdata('msg','successfully your Product image uploaded');
            redirect('Product/add_product');
    }
    function ViewMultipleImage(){

      $ID = $_GET['ID'];
    
    $data['multiple_picture'] = $this->Model->getData('multiple_picture',array('Product_id'=>$ID));
    // echo '<pre>'; print_r($data['table']); exit;
    $data['main_containt']='ViewMultipleImage';

        $this->load->view('containt',$data);

    }
    function edit_MultipleImage(){
     $ID = $_GET['ID'];
     $data['edit_picture'] = $this->Model->getData('multiple_picture',array(' ID'=>$ID));
     // echo '<pre>'; print_r($data['multiple_picture']); exit;
     $data['main_containt']='edit_MultipleImage';

        $this->load->view('containt',$data);
    }
    function delect_MultipleImage(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('multiple_picture',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Product image has been deleted successfully.');

        redirect('Product/product_List');
    }
    function eidt_MultipleImage_info(){
      // $postData = $_POST;
      // echo '<pre>'; print_r($postData); exit;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Product_Picture_Mult'])){
            $uploaddir = './uploads/Multiple_Picture/';
            $photo1=rand().$_FILES['Product_Picture_Mult']['name'];
            $uploadfile = $uploaddir . $photo1;

            if (move_uploaded_file($_FILES['Product_Picture_Mult']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Product_Picture_Mult'] =  $photo1;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('multiple_picture',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        
         $product_list = $this->Model->getData('wellness');
        $data['product_list'] = $product_list;
        $data['main_containt']='product_List';
        $this->load->view('containt',$data);
    }
    function UploadMoreImage(){
       $ID = $_GET['ID'];
     $data['UploadMoreImage'] = $this->Model->getData('wellness',array(' ID'=>$ID));
     // echo '<pre>'; print_r($data['UploadMoreImage']); exit;
      $data['main_containt']='UploadMoreImage';

        $this->load->view('containt',$data);
    }
    function UploadMoreImage_edit(){
          // echo '<pre>'; print_r($_FILES); exit;
          $ID = $this->input->get_post('Product_id');
          // echo '<pre>'; print_r( $ID); exit;
             $data = array();
        if($this->input->post('userSubmit') && !empty($_FILES['Multiple_Picture']['name'][0])){
            $count = count($_FILES['Multiple_Picture']['name']);
            // $user_id =  $Product_id;
            for($i = 0; $i<$count; $i++){
            $_FILES['upload_File']['name'] = rand()."_Mr_khan_Oxiinc_".$_FILES['Multiple_Picture']['name'][$i];  
             $_FILES['upload_File']['type'] = $_FILES['Multiple_Picture']['type'][$i];
            $_FILES['upload_File']['tmp_name'] = $_FILES['Multiple_Picture']['tmp_name'][$i];
             $_FILES['upload_File']['error'] = $_FILES['Multiple_Picture']['error'][$i]; 
             $_FILES['upload_File']['size'] = $_FILES['Multiple_Picture']['size'][$i];
              $uploadPath = 'uploads/Multiple_Picture/';
               $configs['upload_path'] = $uploadPath;
                $configs['allowed_types'] = 'gif|jpg|png';
                 $this->load->library('upload', $configs);
                $this->upload->initialize($configs);

                if($this->upload->do_upload('upload_File')){
                    $fileData = $this->upload->data();
                    $uploadData[$i]['Product_Picture_Mult'] = $_FILES['upload_File']['name'];
                    $uploadData[$i]['Product_id'] = $ID;
                    
                   
                }
            } 
            // echo '<pre>'; print_r($uploadData); exit;

            if(!empty($uploadData)){
                //Insert file information into the database
                $insert = $this->Files->insert($uploadData);
               
            }
        }           

            $this->session->set_flashdata('msg','successfully your Product image uploaded');
            redirect('Product/product_List');
            
            
        }
   
	// function get_product_list(){
 //        $requestData= $_REQUEST;

 //        $totalData = $this->model->getAllData('wellness');
 //        $totalFiltered = $totalData;
 //        $sql = "SELECT * FROM wellness  ";
 //        if( !empty($requestData['search']['value']) ) { 
 //             $sql.="  WHERE ( Product_Name LIKE '%".$requestData['search']['value']."%' ) ";
 //        }

 //        $totalFiltered =$this->model->count_by_query($sql);
 //        $sql.=" ORDER BY Product_Name ".$requestData['order'][0]['dir']." LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

 //        $product_details=$this->model->getSqlData($sql);
 //        $data = array();

 //        foreach ($product_details as $key => $value) {
 //            $category_data = $this->model->getData('category',array('category_id'=>$value['category_id']));
 //            $sub_category_data = $this->model->getData('subcategory',array('sub_category_id'=>$value['sub_category_id']));
 //            $stock_status = '';
            
 //            $nestedData=array();
 //            $nestedData[] = $value['ID'];
 //            $nestedData[] = strtoupper($value['Product_Name']);
 //            $nestedData[] = strtoupper($category_data[0]['sub_category_name']);
 //            $nestedData[] = strtoupper($sub_category_data[0]['sub_category_name']);
 //            $nestedData[] = "<i class='fa fa-rupee'></i> ".$value['Original_Prices'];	
 //            $nestedData[] = "<i class='fa fa-rupee'></i> ".$value['Prices'];
 //         /*   $nestedData[] = "<i class='fa fa-rupee'></i> ".$value['old_price'];*/

 //            if($value['status']=='0'){
 //                $update_active = access('product_list','update_access') ?  "onclick='update_product_status(this,1,".$value['product_id'].")'":"";
 //                $nestedData[] = "<a href='javascript:void(0);'".$update_active." >DE-ACTIVE</a>";
 //            }else{
 //                $update_deactive = access('product_list','update_access') ?  "onclick='update_product_status(this,0,".$value['product_id'].")'":"";
 //                $nestedData[] = "<a href='javascript:void(0);'".$update_deactive.">ACTIVE</a>";
 //            }


 //            if($value['stock_status']=='0'){
 //                $nestedData[] = "<a href='javascript:void(0);' onclick='update_stock_status(this,1,".$value['product_id'].")'>Out of Stock</a>";
 //            }else{
 //                $nestedData[] = "<a href='javascript:void(0);' onclick='update_stock_status(this,0,".$value['product_id'].")'>In Stock</a>";
 //            }

 //            // $edit = ('product_list','update_access') || access('product_list','full_access')) ? "<li><a href=".base_url()."admin/edit_product?product_id=".$value['product_id']."><i class='fa fa-pencil'></i></a></li>":'' ;
 //            // $delete = access('product_list','full_access') ? "<li><a href='#' onclick='delete_product(this,".$value['product_id'].")'><i class='fa fa-trash'></i></a></li>" : '';

 //            $nestedData[] = "<ul class='table-options'>".$edit.$delete."</ul>";

 //            $data[] = $nestedData;
 //        }

 //        $json_data = array(
 //            "draw"            => intval($requestData['draw'] ),  
 //            "recordsTotal"    => intval($totalData ), 
 //            "recordsFiltered" => intval($totalFiltered ), 
 //            "data"            => $data,
 //        );
 //        echo json_encode($json_data); 
 //    }
// public function wellness()
// 	{
//         $sub_category_data = $this->model->getData('subcategory',array('category_id'=>'1'));
//         $data['sub_category_data'] = $sub_category_data;
// 		$data['main_containt']='wellness';

//         $this->load->view('containt',$data);
// 	}
// 	public function electronics()
// 	{
//         $sub_category_data = $this->model->getData('subcategory',array('category_id'=>'2'));
//         $data['sub_category_data'] = $sub_category_data;
// 		$data['main_containt']='electronics';
//         $this->load->view('containt',$data);
// 	}
// 	public function home_kitchen()
// 	{
//          $sub_category_data = $this->model->getData('subcategory',array('category_id'=>'3'));
//         $data['sub_category_data'] = $sub_category_data;
// 		$data['main_containt']='homekitchen';
//         $this->load->view('containt',$data);
// 	}
// 	public function womens()
// 	{

// 		$data['main_containt']='womens';

//         $this->load->view('containt',$data);
// 	}
// 	public function baby_kids()
// 	{

// 		$data['main_containt']='baby_kids';

//         $this->load->view('containt',$data);
// 	}
// 	public function FamilyNutrition()
// 	{
        
//         // echo "hiii";
//         $FamilyNutrition = $this->model->getData('wellness',array('Wellness_type'=>'FN','status'=>1));
//         $data['FamilyNutrition'] = $FamilyNutrition;
// 		$this->load->view('FamilyNutrition',$data);
// 	}
// 	public function WeightLoss()
// 	{
        
//         // echo "hiii";
//         $weightloss = $this->model->getData('wellness',array('Wellness_type'=>'WL','status'=>1));
//         $data['weightloss'] = $weightloss;
// 		$this->load->view('WeightLoss',$data);
// 	}
// 	public function BeautyCare()
// 	{
        
//         // echo "hiii";
//         $BeautyCare = $this->model->getData('wellness',array('Wellness_type'=>'BC','status'=>1));
//         $data['BeautyCare'] = $BeautyCare;
// 		$this->load->view('BeautyCare',$data);
// 	}
// 	public function PersonalCare()
// 	{
        
//         // echo "hiii";
//         $PersonalCare = $this->model->getData('wellness',array('Wellness_type'=>'PC','status'=>1));
//         $data['PersonalCare'] = $PersonalCare;
// 		$this->load->view('PersonalCare',$data);
// 	}
// 	public function HomeCare()
// 	{
        
//         // echo "hiii";
//         $HomeCare = $this->model->getData('wellness',array('Wellness_type'=>'HC','status'=>1));
//         $data['HomeCare'] = $HomeCare;
// 		$this->load->view('HomeCare',$data);
// 	}
// 	public function GymCare()
// 	{
        
//         // echo "hiii";
//         $GymCare = $this->model->getData('wellness',array('Wellness_type'=>'GC','status'=>1));
//         $data['GymCare'] = $GymCare;
// 		$this->load->view('GymCare',$data);
// 	}
}