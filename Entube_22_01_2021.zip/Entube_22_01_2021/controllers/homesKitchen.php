<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class homesKitchen extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('model');
         $this->load->model('text');
         $this->load->model('orders_model');
    }
    public function HomeAppliances()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $HomeAppliances = $this->model->getData('homekitchen',array('HomeKitchen_type'=>'HA','status'=>1));
        $data['HomeAppliances'] = $HomeAppliances;
		$this->load->view('HomeAppliances',$data);
	}
	public function HomeFurnishing()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $HomeFurnishing = $this->model->getData('homekitchen',array('HomeKitchen_type'=>'HF','status'=>1));
        $data['HomeFurnishing'] = $HomeFurnishing;
		$this->load->view('HomeFurnishing',$data);
	}
	public function KitchenAppliances()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $KitchenAppliances = $this->model->getData('homekitchen',array('HomeKitchen_type'=>'KA','status'=>1));
        $data['KitchenAppliances'] = $KitchenAppliances;
		$this->load->view('KitchenAppliances',$data);
	}
	public function LightingSolutions()
	{
        
        // echo "hiii";
        $data['categories'] = $this->text->get_categories();
        $LightingSolutions = $this->model->getData('homekitchen',array('HomeKitchen_type'=>'LS','status'=>1));
        $data['LightingSolutions'] = $LightingSolutions;
		$this->load->view('LightingSolutions',$data);
	}
}
// homesKitchen/LightingSolutions