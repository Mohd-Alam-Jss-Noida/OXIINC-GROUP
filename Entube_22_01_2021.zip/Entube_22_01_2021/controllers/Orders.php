<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
         $this->load->model('Orders_model');

         if(!$this->session->userdata('is_logged_in')){
         	redirect('login');
         }
	}
	public function Orders_same()
	{

		$table = $this->Model->getData('orders');
		$data['h'] = $table;
		 $data['main_containt']='orderstable';
        
        $this->load->view('containt',$data);
	}
	public function Create_new_orderss()
	{
		// echo '<pre>'; print_r($_POST);exit;

		$this->Orders_model->insertData($_POST);
		// $data['main_containt']='orderstable';
		redirect('orders/orders_same');
	}
	public function View()
	{
		$id = $_GET['ID'];
		$table = $this->Model->getData('orders',array('id'=>$id));
		$data['view'] = $table;
		$data['main_containt']='view_order';
        
        $this->load->view('containt',$data);
	}
	public function Ordereidt()
	{

		$ID = $_GET['ID'];
		
		$data['table'] = $this->Model->getData('orders',array('ID'=>$ID));

		$data['main_containt']='ordereidt';
        
        $this->load->view('containt',$data);
	}
	public function Edit_order_form()
	{

		$this->Model->updateData('orders',$_POST,array('ID'=>$_POST['ID']));

		redirect('orders/orders_same');
	}
	public function invoices()
	{
		$table = $this->Model->getData('orders');
		$data['h'] = $table;
		 $data['main_containt']='invoices';
        
        $this->load->view('containt',$data);
	}
	public function invoices_view()
	{
		$id = $_GET['ID'];
		$table = $this->Model->getData('orders',array('id'=>$id));
		$data['view'] = $table;
		$data['main_containt']='view_invoices';
        
        $this->load->view('containt',$data);
	}
	public function Create_new_order()
	{
		 $data['main_containt']='createneworder';
        
        $this->load->view('containt',$data);
	}
	public function shipment()
	{
		 $data['main_containt']='shipment';
        
        $this->load->view('containt',$data);
	}
	public function credimemos()
	{
		 $data['main_containt']='credimemos';
        
        $this->load->view('containt',$data);
	}
	public function transactions()
	{
		 $data['main_containt']='transactions';
        
        $this->load->view('containt',$data);
	}
	public function recurringprofile()
	{
		 $data['main_containt']='recurringprofile';
        
        $this->load->view('containt',$data);
	}
	public function billingagreements()
	{
		 $data['main_containt']='billingagreements';
        
        $this->load->view('containt',$data);
	}
	public function teamsandconditions()
	{
		 $data['main_containt']='teamsandconditions';
        
        $this->load->view('containt',$data);
	}
	public function managetaxrules()
	{
		 $data['main_containt']='managetaxrules';
        
        $this->load->view('containt',$data);
	}
	public function add_new_tax_rules()
	{
		 $data['main_containt']='addnewtaxrules';
        
        $this->load->view('containt',$data);
	}
	public function manage_tax_zones_rates()
	{
		 $data['main_containt']='managetaxzonesrates';
        
        $this->load->view('containt',$data);
	}
	public function add_new_tax_rate()
	{
		 $data['main_containt']='addnewtaxrate';
        
        $this->load->view('containt',$data);
	}
	public function import_export_tax_rates()
	{
		 $data['main_containt']='importexporttaxrates';
        
        $this->load->view('containt',$data);
	}
	public function customer_tax_classes()
	{
		 $data['main_containt']='customertaxclasses';
        
        $this->load->view('containt',$data);
	}
	public function add_new()
	{
		 $data['main_containt']='addnew';
        
        $this->load->view('containt',$data);
	}
	public function porduct_tax_classes()
	{
		 $data['main_containt']='porducttaxclasses';
        
        $this->load->view('containt',$data);
	}
	public function product_add_new()
	{
		 $data['main_containt']='productaddnew';
        
        $this->load->view('containt',$data);
	}
	public function Camera_wrap()
	{
		$table = $this->Model->getData('slider');
		$data['sliderpicture'] = $table;
		 $data['main_containt']='Slider';
        
        $this->load->view('containt',$data);
	}
	public function indexpage()
	{

		$table = $this->Model->getData('slider',array('status'=>1));
		// $anothertablename = $this->model->getData('anothertablename');

		$data['slider'] = $table;
		// $data['anothertablename'] = $anothertablename;
		$data['main_containt']='indexpage';

        $this->load->view('containt',$data);
	}
	function Upend_heading_List(){
		$upend_list = $this->Model->getData('upend_wrapper');
		$data['upend_list'] = $upend_list;
		$data['main_containt']='upend_heading_List';
        $this->load->view('containt',$data);	
	}
	function Upend_delete(){
        $upend_id = $this->input->get_post('upend_id');
        $this->Model->deleteData('upend_wrapper',array('upend_id'=>$upend_id));
        
        $this->session->set_flashdata('msg' ,'The Upend Heading has been deleted successfully.');

        redirect('orders/upend_heading_List');
    }
    public function Upend_eidt()
	{
        $upend_id = $_GET['upend_id'];
		
		$data['table'] = $this->Model->getData('upend_wrapper',array('upend_id'=>$upend_id));
		$data['main_containt']='upend_eidt';

        $this->load->view('containt',$data);
	}
	public function Edit_upend_form()
	{

		$this->Model->updateData('upend_wrapper',$_POST,array('upend_id'=>$_POST['upend_id']));
        $this->session->set_flashdata('msg','Upend Update Successfully ');
		redirect('orders/upend_heading_List');
	}
	
}
