<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class part2 extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
        $this->load->model('part2_model');
        if(!$this->session->userdata('is_logged_in')){
         	redirect('login');
         }
	}
	public function form()
	{
		$this->load->view('part2');
	}
	public function add()
	{
		 // echo '<pre>'; print_r($_POST);exit;
		$this->part2_model->add($_POST);
		 redirect('part2/list');
	}
	public function list()
	{
		$table = $this->part2_model->get('demotwo');
		$data['h'] = $table;
		$this->load->view('list',$data);

	}
	public function edit()
	{
		
		$id = $_GET['id'];
		$data['demotwo'] = $this->part2_model->get('demotwo',array('id'=>$id));
        // echo '<pre>';
		// print_r($table);
		$this->load->view('editabc',$data);
	}
	public function update()
	{
		// echo '<pre>'; print_r($_POST);exit;
		$this->part2_model->update('demotwo',$_POST,array('id'=>$_POST['id']));
		redirect('part2/list');
	}
}