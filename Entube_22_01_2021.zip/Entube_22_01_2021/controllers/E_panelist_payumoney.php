<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class E_panelist_payumoney extends CI_Controller {
  public function __construct() {
        parent::__construct();
        $this->load->helper('url');   
         $this->load->model('Model');   
    }

  public function index() {
       $status = $this->input->post('status');
      if (empty($status)) {
            redirect('Home');
        }
        // echo '<pre>'; print_r($_POST); exit;
       // echo '<pre>'; print_r($_POST); 
         $total_cart = $this->cart->total_items();
         $data['total_cart'] = $total_cart;
         $firstname = $this->input->post('firstname');
         $address1 = $this->input->post('address1');




$epanelist_Shipping_address= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$address1));
$shipping_ID =  $epanelist_Shipping_address[0]['ID'];
    $shipping_user_id =  $epanelist_Shipping_address[0]['user_id'];
    $shipping_employee_id=  $epanelist_Shipping_address[0]['employee_id'];
    $shipping_Name =  $epanelist_Shipping_address[0]['Name'];
    $shipping_Phone_number =  $epanelist_Shipping_address[0]['Phone_number'];
    $shipping_Pincode =  $epanelist_Shipping_address[0]['Pincode'];
    $shipping_Locality =  $epanelist_Shipping_address[0]['Locality'];
    $shipping_address =  $epanelist_Shipping_address[0]['address'];
    $shipping_City =  $epanelist_Shipping_address[0]['City'];
    $shipping_state =  $epanelist_Shipping_address[0]['state'];
    $shipping_Landmark =  $epanelist_Shipping_address[0]['Landmark'];
    $shipping_Alternate_Phone =  $epanelist_Shipping_address[0]['Alternate_Phone'];
    $shipping_Address_type =  $epanelist_Shipping_address[0]['Address_type'];




         $promo_id = $this->input->post('address2');
         $promo_amout = $this->input->post('city');
         $total_gst = $this->input->post('zipcode');
         $total_shipping = $this->input->post('country');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $posted_hash = $this->input->post('hash');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $firstname = $this->input->post('firstname');
        $salt = "Mt1vS3WJzu"; //  Your salt
        $add = $this->input->post('additionalCharges');
        If (isset($add)) {
            $additionalCharges = $this->input->post('additionalCharges');
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {

            $retHashSeq = $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
         $data['hash'] = hash("sha512", $retHashSeq);
          $data['amount'] = $amount;
          $data['txnid'] = $txnid;
          $data['posted_hash'] = $posted_hash;
          $data['status'] = $status;
          if($status == 'success'){


$user_id =  $this->session->userdata('employee_id'); 



if ($promo_id) {
            $promo_code_id = $promo_id;
          }else{
            $promo_code_id = '0';
          }
// $product_id = $items['id'];
// echo '<pre>'; print_r($this->cart->contents('id')); exit;

// echo '<pre>'; print_r($qty); exit;
$i=0;
           foreach ($this->cart->contents() as $items){
     // $qtys = $items['qty'];
            $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
            $GST_Persentage =  $data[0]['GST_Persentage'];


              if($GST_Persentage >0 ){
              $gst_value = $GST_Persentage/100; 
               $gst_prices = $gst_value*$items['price'];
               $gst_price = $gst_prices*$items['qty'];
                 // $total_price = $items['price']+$gst_price;
                 }else{
                  $gst_price = 0;
                  }




                  $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
                                    $Shipping_Charges =  $data[0]['Shipping_Charges'];

                if ($Shipping_Charges >0) {
                  $Shipping_Charges = $Shipping_Charges*$items['qty'] ;
                }else{
                   $Shipping_Charges = 0 ;
                    
                }


// echo '<pre>'; print_r($Shipping_Charges); exit;



                                         


                $order_data = array(
          'user_id'=>$user_id,
          'Shipping_address'=>$address1,
          'shipping_ID'=>$shipping_ID,
          'shipping_user_id'=>$shipping_user_id,
          'shipping_employee_id'=>$shipping_employee_id,
          'shipping_Name'=>$shipping_Name,
          'shipping_Phone_number'=>$shipping_Phone_number,
          'shipping_Pincode'=>$shipping_Pincode,
          'shipping_Locality'=>$shipping_Locality,
          'shipping_address_in'=>$shipping_address,
          'shipping_City'=>$shipping_City,
          'shipping_state'=>$shipping_state,
          'shipping_Landmark'=>$shipping_Landmark,
          'shipping_Alternate_Phone'=>$shipping_Alternate_Phone,
          'shipping_Address_type'=>$shipping_Address_type,
          // 'email_id'=>$email,
          // 'user_name'=>$firstname,
          // 'contact_number'=>$phone,
          'product_id'=>$items['id'],
          'Product_Name'=>$items['name'],
          'Product_Picture'=>$items['picture'],
          'size'=>$items['size'],
          'Prices' => $items['subtotal'],
          'product_qty' => $items['qty'],
          'Original_Prices'=>$items['original'],
          'gst_price'=>$gst_price,
          'total_gst'=>$total_gst,
          'promo_code_id'=>$promo_code_id,
          'Promo_amount'=>$promo_amout,
          'Shipping_Charges'=>$Shipping_Charges,
          'total_shipping'=>$total_shipping,
          'txnid'=>$txnid,
          'total_amount'=>$amount,
          'after_discounted_amount'=>'0',
          'payment_method'=>'PayUMoney',
          'address_id'=>$address1,
          'order_date_time'=>date('Y-m-d H:i:s'),
          'order_month'=> date('m'),
          'order_year'=> date('Y'),
          'order_day'=> date('d'),
          'order_year_month'=> date('Y-m'),
          'order_year_month_data' =>date('Y-m-d'),
          'order_year_month_data_time'=> date('Y-m-d H:i:s'),
          
        );
                $order_id = $this->Model->insertData('e_paenlist_order_data',$order_data);
         $i++;
       }
  
 //       if($promo_id){

 //        $statuss['Active_states']='0';
 //    $this->Model->updateData('promo_codo',$statuss,array('ID'=>$promo_id));
 // }




    $user_order_data = $this->Model->getData('e_paenlist_order_data',array('txnid'=>$txnid));
    $data['user_order_data'] = $user_order_data;
      $data['user_manage_addresses'] = $this->Model->getData('epanelist_manage_addresses',array('ID'=>$address1));
  //     $id =  $this->session->userdata('id'); 
  // $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
       $this->cart->destroy();
 $this->load->view('checkout_now_success', $data);   
         }
         else{
              $this->load->view('payumoney_failure', $data); 
         }
     
    }
     public function confirm() {
       $status = $this->input->post('status');
      if (empty($status)) {
            redirect('Home');
        }
        // echo '<pre>'; print_r($_POST); exit;
       // echo '<pre>'; print_r($_POST); 
         $total_cart = $this->cart->total_items();
         $data['total_cart'] = $total_cart;
         $firstname = $this->input->post('firstname');
         $address1 = $this->input->post('address1');




$epanelist_Shipping_address= $this->Model->getData('epanelist_manage_addresses',array('ID'=>$address1));
$shipping_ID =  $epanelist_Shipping_address[0]['ID'];
    $shipping_user_id =  $epanelist_Shipping_address[0]['user_id'];
    $shipping_employee_id=  $epanelist_Shipping_address[0]['employee_id'];
    $shipping_Name =  $epanelist_Shipping_address[0]['Name'];
    $shipping_Phone_number =  $epanelist_Shipping_address[0]['Phone_number'];
    $shipping_Pincode =  $epanelist_Shipping_address[0]['Pincode'];
    $shipping_Locality =  $epanelist_Shipping_address[0]['Locality'];
    $shipping_address =  $epanelist_Shipping_address[0]['address'];
    $shipping_City =  $epanelist_Shipping_address[0]['City'];
    $shipping_state =  $epanelist_Shipping_address[0]['state'];
    $shipping_Landmark =  $epanelist_Shipping_address[0]['Landmark'];
    $shipping_Alternate_Phone =  $epanelist_Shipping_address[0]['Alternate_Phone'];
    $shipping_Address_type =  $epanelist_Shipping_address[0]['Address_type'];




         $promo_id = $this->input->post('address2');
         $promo_amout = $this->input->post('city');
         $total_gst = $this->input->post('zipcode');
         $total_shipping = $this->input->post('country');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $posted_hash = $this->input->post('hash');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $firstname = $this->input->post('firstname');
        $salt = "Mt1vS3WJzu"; //  Your salt
        $add = $this->input->post('additionalCharges');
        If (isset($add)) {
            $additionalCharges = $this->input->post('additionalCharges');
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {

            $retHashSeq = $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
         $data['hash'] = hash("sha512", $retHashSeq);
          $data['amount'] = $amount;
          $data['txnid'] = $txnid;
          $data['posted_hash'] = $posted_hash;
          $data['status'] = $status;
          if($status == 'success'){


$user_id =  $this->session->userdata('employee_id'); 



if ($promo_id) {
            $promo_code_id = $promo_id;
          }else{
            $promo_code_id = '0';
          }
// $product_id = $items['id'];
// echo '<pre>'; print_r($this->cart->contents('id')); exit;

// echo '<pre>'; print_r($qty); exit;
$i=0;
           foreach ($this->cart->contents() as $items){
     // $qtys = $items['qty'];
            $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
            $GST_Persentage =  $data[0]['GST_Persentage'];


              if($GST_Persentage >0 ){
              $gst_value = $GST_Persentage/100; 
               $gst_prices = $gst_value*$items['price'];
               $gst_price = $gst_prices*$items['qty'];
                 // $total_price = $items['price']+$gst_price;
                 }else{
                  $gst_price = 0;
                  }




                  $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
                                    $Shipping_Charges =  $data[0]['Shipping_Charges'];

                if ($Shipping_Charges >0) {
                  $Shipping_Charges = $Shipping_Charges*$items['qty'] ;
                }else{
                   $Shipping_Charges = 0 ;
                    
                }


// echo '<pre>'; print_r($Shipping_Charges); exit;



                                         


                $order_data = array(
          'user_id'=>$user_id,
          'Shipping_address'=>$address1,
          'shipping_ID'=>$shipping_ID,
          'shipping_user_id'=>$shipping_user_id,
          'shipping_employee_id'=>$shipping_employee_id,
          'shipping_Name'=>$shipping_Name,
          'shipping_Phone_number'=>$shipping_Phone_number,
          'shipping_Pincode'=>$shipping_Pincode,
          'shipping_Locality'=>$shipping_Locality,
          'shipping_address_in'=>$shipping_address,
          'shipping_City'=>$shipping_City,
          'shipping_state'=>$shipping_state,
          'shipping_Landmark'=>$shipping_Landmark,
          'shipping_Alternate_Phone'=>$shipping_Alternate_Phone,
          'shipping_Address_type'=>$shipping_Address_type,
          // 'email_id'=>$email,
          // 'user_name'=>$firstname,
          // 'contact_number'=>$phone,
          'product_id'=>$items['id'],
          'Product_Name'=>$items['name'],
          'Product_Picture'=>$items['picture'],
          'size'=>$items['size'],
          'Prices' => $items['subtotal'],
          'product_qty' => $items['qty'],
          'Original_Prices'=>$items['original'],
          'gst_price'=>$gst_price,
          'total_gst'=>$total_gst,
          'promo_code_id'=>$promo_code_id,
          'Promo_amount'=>$promo_amout,
          'Shipping_Charges'=>$Shipping_Charges,
          'total_shipping'=>$total_shipping,
          'txnid'=>$txnid,
          'total_amount'=>$amount,
          'after_discounted_amount'=>'0',
          'payment_method'=>'PayUMoney',
          'address_id'=>$address1,
          'order_date_time'=>date('Y-m-d H:i:s'),
          'order_month'=> date('m'),
          'order_year'=> date('Y'),
          'order_day'=> date('d'),
          'order_year_month'=> date('Y-m'),
          'order_year_month_data' =>date('Y-m-d'),
          'order_year_month_data_time'=> date('Y-m-d H:i:s'),
          
        );
                $order_id = $this->Model->insertData('e_paenlist_order_data',$order_data);
         $i++;
       }
  
 //       if($promo_id){

 //        $statuss['Active_states']='0';
 //    $this->Model->updateData('promo_codo',$statuss,array('ID'=>$promo_id));
 // }




   $data['total_shipping']=$_POST['country'];
    $data['total_gst']=$_POST['zipcode'];
    $data['payment_method']='PayUMoney';
    $data['Promo_amount']=$_POST['city'];
    $data['promo_id']=$_POST['address2'];
    $data['Order_Date']=date('d-M-Y');
    $data['shipping_address']=$_POST['address1'];
    $data['total_price']=$_POST['amount'];
    $data['total_cart'] = $this->cart->total_items();
    $data['txnid']= $_POST['txnid'];
  //     $id =  $this->session->userdata('id'); 
  // $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
    // echo '<pre>'; print_r($data); exit;
       $this->cart->destroy();
 $this->load->view('Eplanelist_payment_process_notcomplete_payumoney', $data);   
         }
         else{
              $this->load->view('payumoney_failure', $data); 
         }
     
    }
 
    
   }
