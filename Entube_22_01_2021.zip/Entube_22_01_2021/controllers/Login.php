<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        $this->load->model('Model');
	}

	function index(){
		$this->load->view('loginpage');
	}

	public function process() {
		$user_email = htmlspecialchars(filter_var($_POST['user_email'], FILTER_SANITIZE_EMAIL));
		$password = md5($_POST['user_password']);
		$login = $this->Model->getData('users',array('user_email'=>$user_email,'user_password'=>$password));
		if(!isset($login) || empty($login)){
			$this->session->set_flashdata('msg','login failed');
			redirect('login');
		}
		else{
			$session_array = array(
				'user_email' =>$user_email,
				'admin_id' =>$login[0]['id'],
				'is_logged_in'=>true
			);
			$this->session->set_userdata($session_array);
			//redirect('welcome');
			redirect(site_url('Dashboard'));
		}
	}

	function logout(){
		$this->session->set_userdata(array('is_logged_in' => FALSE));
		$this->session->sess_destroy();
		redirect(site_url('login'));
	}
}