<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Upend_information extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Upend_information_add');
        
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function add(){
        if($this->input->post('userSubmit')){
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['Product_Picture']['name'])){
                $config['upload_path'] = 'uploads/wrapper/wellness/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['Product_Picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('Product_Picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'upend_id' => $this->input->post('upend_id'),
                'Product_Name' => $this->input->post('Product_Name'),
                'Short_Description' => $this->input->post('Short_Description'),
                'Offers' => $this->input->post('Offers'),
                'Prices' => $this->input->post('Prices'),
                // 'upend_heading' => $this->input->post('upend_heading'),
                'Product_Picture    ' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->Upend_information_add->insert($userData);
            $this->session->set_flashdata('msg','successfully your Product Information uploaded');
            redirect('home/upend_information');
            
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}