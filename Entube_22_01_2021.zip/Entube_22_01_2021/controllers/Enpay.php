<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Enpay extends CI_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->helper('url');   
         $this->load->model('Model');   
    }

	public function index() {
       $status = $this->input->post('status');
      if (empty($status)) {
            redirect('Home');
        }



$customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$this->session->userdata('id')));

 $total_sum_credit=0; $total_sumzcz=0; $i=0;
foreach ($customer_enpay as $key => $value) {
  
 if ($value['debits_amount']>0) {
                         $debits_amount =  $value['debits_amount'];
                        
                      }else{
                        $debits_amount = 0;
                      }

                       if ($value['Credits_amount']>0) {
                         $Credits_amount =  $value['Credits_amount'];
                        
                      }else{
                        $Credits_amount = 0;
                      }


  $total_sumzcz+=$debits_amount;
    $total_sum_credit+=$Credits_amount;
}

$enpay_amount = $total_sumzcz-$total_sum_credit;



// echo '<pre>'; print_r($enpay_amount); exit;










       // echo '<pre>'; print_r($_POST); 
         $total_cart = $this->cart->total_items();
         $data['total_cart'] = $total_cart;
         $firstname = $this->input->post('firstname');
         $address1 = $this->input->post('address1');
         $promo_id = $this->input->post('address2');
         $promo_amout = $this->input->post('city');
         $total_gst = $this->input->post('zipcode');
         $total_shipping = $this->input->post('country');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $posted_hash = $this->input->post('hash');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $firstname = $this->input->post('firstname');
        $salt = "Mt1vS3WJzu"; //  Your salt
        $add = $this->input->post('additionalCharges');
        If (isset($add)) {
            $additionalCharges = $this->input->post('additionalCharges');
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {

            $retHashSeq = $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
         $data['hash'] = hash("sha512", $retHashSeq);
          $data['amount'] = $amount;
          $data['txnid'] = $txnid;
          $data['posted_hash'] = $posted_hash;
          $data['status'] = $status;
          if($status == 'success'){


$customer_id =  $this->session->userdata('id'); 




if ($promo_id) {
            $promo_code_id = $promo_id;
          }else{
            $promo_code_id = '0';
          }
// $product_id = $items['id'];
// echo '<pre>'; print_r($this->cart->contents('id')); exit;

// echo '<pre>'; print_r($qty); exit;
$i=0;
           foreach ($this->cart->contents() as $items){
     // $qtys = $items['qty'];
            $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
            $GST_Persentage =  $data[0]['GST_Persentage'];


              if($GST_Persentage >0 ){
              $gst_value = $GST_Persentage/100; 
               $gst_prices = $gst_value*$items['price'];
               $gst_price = $gst_prices*$items['qty'];
                 // $total_price = $items['price']+$gst_price;
                 }else{
                  $gst_price = 0;
                  }




                  $data = $this->Model->getData('wellness',array('ID'=>$items['id']));
                                    $Shipping_Charges =  $data[0]['Shipping_Charges'];

                if ($Shipping_Charges >0) {
                  $Shipping_Charges = $Shipping_Charges*$items['qty'] ;
                }else{
                   $Shipping_Charges = 0 ;
                    
                }


// echo '<pre>'; print_r($Shipping_Charges); exit;



                                         


                $order_data = array(
          'customer_id'=>$customer_id,
          'email_id'=>$email,
          'user_name'=>$firstname,
          'contact_number'=>$phone,
          'product_id'=>$items['id'],
          'Product_Name'=>$items['name'],
          'Product_Picture'=>$items['picture'],
          'Prices' => $items['subtotal'],
          'product_qty' => $items['qty'],
          'Original_Prices'=>$items['original'],
          'size'=>$items['size'],
          'gst_price'=>$gst_price,
          'total_gst'=>$total_gst,
          'promo_code_id'=>$promo_code_id,
          'Promo_amount'=>$promo_amout,
          'Shipping_Charges'=>$Shipping_Charges,
          'total_shipping'=>$total_shipping,
          'txnid'=>$txnid,
          'total_amount'=>$amount,
          'after_discounted_amount'=>'0',
          'payment_method'=>'enpay/PayUMoney',
          'address_id'=>$address1,
          'order_date_time'=>date('Y-m-d H:i:s'),
          'order_month'=> date('m'),
          'order_year'=> date('Y'),
          'order_day'=> date('d'),
          'order_year_month'=> date('Y-m'),
          'order_year_month_data' =>date('Y-m-d'),
          'order_year_month_data_time'=> date('Y-m-d H:i:s'),
          
        );
                $order_id = $this->Model->insertData('order_data',$order_data);
         $i++;
       }
  
       if($promo_id){

        $statuss['Active_states']='0';
    $this->Model->updateData('promo_codo',$statuss,array('ID'=>$promo_id));
 }












$debits_amountss['Customer_id']= $this->session->userdata('id');
$debits_amountss['Credits_amount']= $enpay_amount;
$this->Model->insertData('customer_enpay',$debits_amountss);















    $user_order_data = $this->Model->getData('order_data',array('txnid'=>$txnid));
    $data['user_order_data'] = $user_order_data;
      $data['user_manage_addresses'] = $this->Model->getData('manage_addresses',array('ID'=>$address1));
      $id =  $this->session->userdata('id'); 
  $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
       $this->cart->destroy();
 $this->load->view('checkout_now_success', $data);   
         }
         else{
              $this->load->view('payumoney_failure', $data); 
         }
     
    }
 
    
   }
