<?php
defined('BASEPATH') OR exit('No direct script access allowed');

header('Access-Control-Allow-Origin: *');

class Fetch_values extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

    function __construct(){
        parent::__construct();

        $this->load->model('Model');
        $this->load->model('Text');
        $this->load->model('Files');
        $this->load->model('Cart_model');
        $this->load->model('Add_category_model');
        // $this->load->model('customer');
    }
    function fetch_states(){
        $strSql = "SELECT * FROM states WHERE country_id=".$_POST['id'];
        $states =$this->Model->getSqlData($strSql);
        if(count($states) > 0){
            echo '<option value="">Select State</option>';
            foreach ($states as $key => $value) {
                echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            } 
        }
        else{
            echo '<option value="">State not available</option>';
        }
    }

    function fetch_city(){
        $strSql = "SELECT * FROM cities WHERE state_id=".$_POST['id'];
        $city =$this->Model->getSqlData($strSql);
        //echo "<pre>";print_r($city);die();
        if(count($city) > 0){
            echo '<option value="">Select city</option>';
            foreach ($city as $key => $value) {
                echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            } 
        }
        else{
            echo '<option value="">City not available</option>';
        }
    }

    function country_code(){
        $strSql = "SELECT * FROM countries WHERE id=".$_POST['id'];
        $country_code =$this->Model->getSqlData($strSql);
        echo ('+'.$country_code[0]['phonecode']);	
    }
}