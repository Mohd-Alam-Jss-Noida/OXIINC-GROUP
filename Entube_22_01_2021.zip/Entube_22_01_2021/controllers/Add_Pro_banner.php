<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Add_Pro_banner extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Add_Pro_bannerss');
        
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function Add(){
        if($this->input->post('userSubmit')){
            // echo '<pre>'; print_r($_FILES); exit;
            
            //Check whether user upload picture
            if(!empty($_FILES['banner_Picture']['name'])){
                $config['upload_path'] = 'uploads/Pro_banner/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['banner_Picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('banner_Picture')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'banner_name' => $this->input->post('banner_name'),
                'category_id' => $this->input->post('category_id'),
                'sub_category_id' => $this->input->post('sub_category_id'),
                'product_category_id' => $this->input->post('product_category_id'),
                'banner_Picture' => $picture
            );

            
            //Pass user data to model
            $insertUserData = $this->Add_Pro_bannerss->insert($userData);
            $this->session->set_flashdata('msg','successfully your Banner image uploaded');
            redirect('slider/Add_Pro_banner');
            
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}