<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');

class Entube_channel extends CI_Controller {
    private $user_id_upload = '';
    private $user_name = '';
    private $user_info = '';
    private $employee_id = '';

    function  __construct() {
        parent::__construct();
        $this->load->model('Wellness_add');
        $this->load->model('Model');
        $this->load->model('Entube_model');
        $this->load->model('Files');
        $this->load->model('Dbs');
        $this->load->helper('string');
        $this->load->helper('file'); //load file helper
        $this->load->helper('url');
        $this->load->library('form_validation'); //load validation library
        date_default_timezone_set("Asia/Calcutta");

        if($this->session->userdata('entube_customer_logged_in')){
            $this->user_id_upload = $this->session->userdata('username');
            $this->user_info = 1; // 1 for epanelist_user
            $this->employee_id = $this->session->userdata('employee_id');
                 
        }elseif($this->session->userdata('logged_in')){
            $this->user_id_upload = $this->session->userdata('id');
            $this->user_info = 2; // 2 for entube_user
            $this->employee_id = 0;
        }
    }

    public function entube_studio(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }else{
            redirect(base_url('Entube/logout'));
        }
        $this->db->select('ad.*, wu.view');
        $this->db->from('add_video ad'); 
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->where('ad.user_id', $user_id_upload);
        $this->db->where('ad.is_deleted', 0);
        $this->db->order_by("ad.ID", "DESC");
        $query = $this->db->get();
        $data['add_video'] = $query->result_array();
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/entube_studio';
        $this->load->view('new_user/containt', $data);
    }

    public function video_upload() {
        if( $this->session->userdata('entube_customer_logged_in') || $this->session->userdata('logged_in') ){
            $data['playlist_details'] = $this->Model->getDataOrderBy('playlist_names',array('user_id'=>$this->user_id_upload, 'status'=>'1'), 'playlistname','ASC');
            $data['get_category'] = $this->Model->getDataOrderBy('category',array('status'=>'1'), 'category_name','ASC');
            $data['main_containt']='new_user/video_upload';
            $this->load->view('new_user/containt', $data);
        }
        else{
            redirect(base_url());
       }
    }

    public function sub_category(){
        if ($_POST['id'] == "") {
            echo '<option value="">Select Video Sub Category</option>';
        }
        else{
            $strSql = "SELECT * FROM subcategory WHERE status ='1' AND category_id=".$_POST['id'];
            $sub_category_data =$this->Model->getSqlData($strSql);
            if(count($sub_category_data) > 0){
                echo '<option value="">Select Video Sub Category</option>';
                foreach ($sub_category_data as $key => $value) {
                    echo '<option value="'.$value['sub_category_id'].'">'.$value['sub_category_name'].'</option>';
                } 
            }
            else{
                echo '<option value="">Video Sub Category not available</option>';
            }
        }
    }

    public function video_insert(){
    	if( $this->session->userdata('entube_customer_logged_in') || $this->session->userdata('logged_in') ){
            //echo "<pre>";print_r($_POST);die();
	        if (isset($_POST["save_video"]) && !empty($_POST["save_video"])){
	            $this->form_validation->set_error_delimiters('<div class="erroemsg no-margin">', '</div>');
	            $this->form_validation->set_rules('Video_Title', 'Video title', 'required');
	            $this->form_validation->set_rules('Short_Description', 'About video', 'required');
                $this->form_validation->set_rules('selected_image_url', 'Upload Thumbnail', 'required');
	            $this->form_validation->set_rules('category_id', 'Video category name', 'required');
	            $this->form_validation->set_rules('video_audience', 'Video audience', 'required');
	            $this->form_validation->set_rules('video_visibility', 'Video visibility', 'required');
	            if (empty($_FILES['Multiple_Video']['name'])) {
	                $this->form_validation->set_rules('Multiple_Video', 'Upload Video', 'required');
	            }
	            if ($this->form_validation->run() == FALSE) {
	                $data['playlist_details']= $this->Model->getDataOrderBy('playlist_names',array('user_id'=>$this->user_id_upload, 'status'=>'1'), 'playlistname','ASC');
	                $data['get_category'] = $this->Model->getDataOrderBy('category',array('status'=>'1'), 'category_name','ASC');
	                $data['main_containt']='new_user/video_upload';
	                $this->load->view('new_user/containt', $data);
	            }
	            else{
                    $random_str = date("dmY_").rand();
                    if(!empty($_FILES['Multiple_Video']['name'])){
                        $video_config['upload_path'] = 'uploads/video/';
                        $video_config['allowed_types'] = 'mp4|avi|mkv|mov|mwv|3gp';
                        $video_config['overwrite'] = FALSE;
                        $video_config['remove_spaces'] = TRUE;
                        $video_config['maintain_ratio'] = FALSE;
                        $video_config['max_width'] = '500';
                        $video_config['max_height'] = '500';
                        $exploded = explode('.',$_FILES['Multiple_Video']['name']);
                        $ext = $exploded[count($exploded) - 1];
                        $video_config['file_name'] = $random_str."_entube.".$ext;
                        $this->load->library('upload', $video_config);
                        $video_config['image_library'] = 'gd2';
                        $this->upload->initialize($video_config);
                        if($ext=='mp4' || $ext=='avi' || $ext=='mkv' || $ext=='mov' || $ext=='mwv' || $ext=='3gp'){
                            if($this->upload->do_upload('Multiple_Video')){
                                $uploadData = $this->upload->data();
                                $video = $uploadData['file_name'];
                            }
                            else{
                                $this->session->set_flashdata('msg','Video Uploaded Failed Please Try Again? Thank You!!!.');
                                redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
                            }
                        }
                        else{
                            $this->session->set_flashdata('msg','Please select correct video formate, e.g. - mp4, avi, mkv, mov, mwv, 3gp.');
                            redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
                        }
                    }
                    else{
                        $this->session->set_flashdata('msg','Video Uploade file does not exist. Please Try Again? Thank You!!!.');
                        redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
                    }

	                if(!empty($_POST['selected_image_url'])){
	                    define('UPLOAD_DIR', 'uploads/product/');
	                    $image_parts = explode(";base64,", $_POST['selected_image_url']);
	                    $image_mime_type = explode("image/", $image_parts[0]);
	                    $image_type = $image_mime_type[1];
	                    $image_base64 = base64_decode($image_parts[1]);
	                    $file_name = $random_str."_entube_add_img.png";
	                    $file_path = UPLOAD_DIR . $file_name;
	                    $upload_image = file_put_contents($file_path, $image_base64);
	                    if ($upload_image) {
	                        $picture = $file_name;
	                    }
	                    else{
	                        $this->session->set_flashdata('msg','Image Uploaded Failed Please Try Again? Thank You!!!.');
	                        redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
	                    }
	                }
	                else{
	                    $this->session->set_flashdata('msg','Image file does not exist. Please Try Again? Thank You!!!.');
	                    redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
	                }

	                $userData = array(
	                    'user_id'=> $this->user_id_upload,
	                    'Video_Title' => $this->input->post('Video_Title'),
	                    'Short_Description' => $this->input->post('Short_Description'),
	                    'video' => $video,
	                    'picture' => $picture,
	                    'category_id' => $this->input->post('category_id'),
	                    'video_audience' => $this->input->post('video_audience'),
	                    'video_visibility' => $this->input->post('video_visibility'),
	                    'playlist_id' => $this->input->post('video_playlist'),
                        'video_hashtag' => $this->input->post('video_hashtag'),
                        'save_video' => $this->input->post('save_video'),
                        'status' => ($this->input->post('save_video') == 'publish') ? 1 : 0,
	                    'user_info' => $this->user_info
	                );
	                $insert_id = $this->Model->insertData('add_video', $this->security->xss_clean($userData));
	                //echo "<pre>";print_r($insert_id);die();
	                if ($insert_id) {
	                    $playlist_video = array(
	                        'user_id' => $this->user_id_upload,
	                        'employee_id' => $this->employee_id,
	                        'playlistname_id' => $this->input->post('video_playlist'),
	                        'video_id' => $insert_id,
	                        'video_category_id' => $this->input->post('category_id'),
	                        'status' => 1
	                    );
	                    $playlist_video_id = $this->Model->insertData('playlist_video_select', $this->security->xss_clean($playlist_video));

	                    $this->session->set_flashdata('msg','Your video uploaded successfully.');
	                    redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
	                }
	                else{
	                    $this->session->set_flashdata('msg','Your video uploading failed.');
	                    redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
	                }
	            } 
	        }
	        else{
	            redirect(base_url('Entube_channel/video_upload'));
	        }
	    }
	    else{
            redirect(base_url());
	   }
    }

    public function dummy_page() {
        $data['main_containt']='new_user/dummy_page';
        $this->load->view('new_user/containt', $data);
    }

    public function dummy_upload_video() {
        //echo "<pre>";print_r($_FILES);//die();
        if($this->input->post('submit')){
            if(!empty($_FILES['video_file']['name'])){
                $configVideo['upload_path'] = 'uploads/video/';
                $configVideo['allowed_types'] = '*';
                $configVideo['overwrite'] = FALSE;
                $configVideo['remove_spaces'] = TRUE;
                $configVideo['maintain_ratio'] = FALSE;
                $configVideo['max_width'] = '500';
                $configVideo['max_height'] = '500';
                $configVideo['file_name'] = rand()."_dumy_video.mp4";
                $this->load->library('upload', $configVideo);
                $configVideo['image_library'] = 'gd2';
                $this->upload->initialize($configVideo);
                if($this->upload->do_upload('video_file')){
                    $uploadData = $this->upload->data();
                    $video = $uploadData['file_name'];
                    $this->session->set_flashdata('msg','Video Successfully Uploaded.');
                    redirect(base_url('Entube_channel/dummy_page'));
                }
                else{
                    $this->session->set_flashdata('msg','Video Uploaded Failed.');
                    redirect('Entube_channel/dummy_page');
                }
            }
            else{
                $this->session->set_flashdata('msg','Please Choose video file.');
                redirect('Entube_channel/dummy_page');
            }
        }
        $this->session->set_flashdata('msg','Video File not found');
        redirect(base_url('Entube_channel/dummy_page'));
    }

    public function video_edit(){
        if( $this->session->userdata('entube_customer_logged_in') || $this->session->userdata('logged_in') ){
            $data['get_category'] = $this->Model->getDataOrderBy('category',array('status'=>'1'), 'category_name','ASC');
            $data['playlist_details'] = $this->Model->getData('playlist_names',array('user_id'=>$this->user_id_upload, 'status'=>'1'));
            $data['video_details'] =$this->Model->getData('add_video',array('user_id'=>$this->user_id_upload,'ID'=>$this->uri->segment(3)));
            $data['video_details'] = $data['video_details'][0];
            //echo "<pre>";print_r($data['video_details']);die();
            $data['main_containt']='new_user/video_edit';
            $this->load->view('new_user/containt', $data);
        }
        else{
            redirect(base_url());
       }
    }

    public function video_update(){
        //echo "<pre>";print_r($_POST);die();
        if($this->input->post()){
            $post_data = $this->input->post();
            if (isset($post_data["update_video"]) && !empty($post_data["update_video"])){
                $this->form_validation->set_error_delimiters('<div class="erroemsg">', '</div>');
                $this->form_validation->set_rules('Video_Title', 'Video title', 'required');
                $this->form_validation->set_rules('Short_Description', 'About video', 'required');
                $this->form_validation->set_rules('category_id', 'Video category name', 'required');
                $this->form_validation->set_rules('video_audience', 'Video audience', 'required');
                $this->form_validation->set_rules('video_visibility', 'Video visibility', 'required');
                
                if($this->form_validation->run() == FALSE){
                    $data['get_category'] = $this->Model->getData('category',array('status'=>'1'));
                    $data['playlist_details'] = $this->Model->getData('playlist_names',array('user_id'=>$this->user_id_upload, 'status'=>'1'));
                    $data['video_details'] =$this->Model->getData('add_video',array('user_id'=>$this->user_id_upload,'ID'=>$this->uri->segment(3)));
                    $data['video_details'] = $data['video_details'][0];
                    $data['main_containt']='new_user/video_edit';
                    $this->load->view('new_user/containt', $data);
                }
                else{
                    $random_str = date("dmY_").rand();
                    if(!empty($_POST['selected_image_url'])){
                        define('UPLOAD_DIR', 'uploads/product/');
                        $image_parts = explode(";base64,", $_POST['selected_image_url']);
                        $image_mime_type = explode("image/", $image_parts[0]);
                        $image_type = $image_mime_type[1];
                        $image_base64 = base64_decode($image_parts[1]);
                        $file_name = $random_str."_entube_update_img.png";
                        $file_path = UPLOAD_DIR . $file_name;
                        $upload_image = file_put_contents($file_path, $image_base64);
                        if ($upload_image) {
                            $picture = $file_name;
                            unlink("uploads/product/".$this->input->post('old_image'));
                        }
                        else{
                            $this->session->set_flashdata('msg','Image Uploaded Failed Please Try Again? Thank You!!!.');
                            redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
                        }
                    }
                    else{
                        $picture = $this->input->post('old_image');
                    }

                    $userData = array(
                        'Video_Title' => $this->input->post('Video_Title'),
                        'Short_Description' => $this->input->post('Short_Description'),
                        'picture' => $picture,
                        'category_id' => $this->input->post('category_id'),
                        'video_audience' => $this->input->post('video_audience'),
                        'video_visibility' => $this->input->post('video_visibility'),
                        'playlist_id' => $this->input->post('video_playlist'),
                        'video_hashtag' => $this->input->post('video_hashtag'),
                        'save_video' => $this->input->post('update_video'),
                        'status' => ($this->input->post('update_video') == 'publish') ? 1 : 0,
                        'user_id'=> $this->user_id_upload,
                        'user_info' => $this->user_info
                    );
                    $update_id = $this->Model->updateData('add_video',$this->security->xss_clean($userData), array('user_id'=>$this->user_id_upload, 'ID'=>$this->uri->segment(3)));
                    if ($update_id) {
                        $playlist_video_update = array(
                            'playlistname_id' => $this->input->post('video_playlist')
                        );
                        $playlist_video_id = $this->Model->updateData('playlist_video_select',$this->security->xss_clean($playlist_video_update), array('user_id'=>$this->user_id_upload, 'video_id'=>$this->uri->segment(3)));

                        $this->session->set_flashdata('msg','Your video Updated successfully.');
                        redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
                    }
                    else{
                        $this->session->set_flashdata('msg','Your video uploading failed.');
                        redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
                    }
                }
            }
            else{
                redirect(base_url('Entube_channel/entube_studio/'.$this->user_id_upload));
            }
        }
        else{
            redirect(base_url('Entube_channel/entube_studio/'.$this->user_id_upload));
        }
    }

    public function video_delete() {        
        $postData = array(
            'status'=> 0,
            'is_deleted'=> 1
        );
        $where_data = array(
            'ID'=> $this->uri->segment(3),
            'user_id'=> $this->user_id_upload
        );
        $delete_id = $this->Model->updateData('add_video', $this->security->xss_clean($postData), $where_data);
        if($delete_id){
            $this->session->set_flashdata('msg','Your video details deleted successfully.');
            redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
        }
        else{
            $this->session->set_flashdata('msg','Your video details deleted failed.');
            redirect('Entube_channel/entube_studio/'.$this->user_id_upload);
        }
    }

function Pro_Banner_edit_form(){

   $image = $_FILES['picture']['name'];
  $image_ext = pathinfo($image, PATHINFO_EXTENSION);
  if(!$_FILES['picture']['size'] == 0){
    //  echo "<pre>";print_r("hi");
    // echo "<pre>";print_r($_FILES);exit();
    if ($image_ext=="png" || $image_ext=="jpg" || $image_ext=="gif") {
  # code...

      $postData = $_POST;
      $ID = $this->input->get_post('ID');
      if(!empty($_FILES['picture'])){
        $uploaddir = './uploads/product/';
        $image= rand()."entube_gagan".".png";
        $uploadfile = $uploaddir . $image;

        if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              
          $postData['picture'] = $image;
        }
      }


      $this->Model->updateData('add_video',$this->security->xss_clean($postData),array('ID'=>$ID)); 
      $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
      redirect('Upload_video/List_Of_Upload');
    }else{
      $this->session->set_flashdata('msg','something went wrong.........');
      redirect('Upload_video/List_Of_Upload');
    }
  }else{
    // echo "<pre>";print_r("no");exit();

    $postData = $_POST;

    $ID = $this->input->get_post('ID');
    $this->Model->updateData('add_video',$this->security->xss_clean($postData),array('ID'=>$ID)); 
    $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
    redirect('Upload_video/List_Of_Upload');
  }
        // $Pro_banner = $this->Model->getData('pro_banner');
        // $data['Pro_banner'] = $Pro_banner;
        // $data['main_containt']='List_Pro_banner';
        // $this->load->view('containt',$data);
      

         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}
function sponsored_video($value=''){
  $add_video = $this->Model->getDataOrderBy('add_video',array('user_id'=>$this->session->userdata('username')),'ID','DESC');
  $data['add_video'] = $add_video;
  $strSql = "SELECT * FROM countries";
  $data['countries'] =$this->Model->getSqlData($strSql);
  $budget_and_audience = "SELECT * FROM budget_and_audience where status!=3";
  $data['budget_and_audience'] =$this->Model->getSqlData($budget_and_audience);
  // echo "<pre>";print_r($data['add_video']);
  $this->load->view('sponsored_video',$data);
}
function sponsored_video_submit($value=''){
  // $allow_data="";


  // echo "<pre>";print_r($_FILES['product_image']);exit();
  $add_money = $this->db->query('SELECT SUM(amount) AS amount FROM wallet WHERE emp_id='.$this->session->userdata('employee_id'));
  $add_money_amount= $add_money->result_array();
  if ($_POST['total_payable']<=$add_money_amount[0]['amount']) {
   
  $video_allow_id = $_POST['video_id'];
  $var['allow_video'] = '1';
  $PQR =  mt_rand(10000,999999);
  $SKU = 'OXIINC'.$PQR;
  $this->Model->updateData('add_video',$var,array('ID'=>$_POST['video_id']));
  $video_data = $this->Model->getData('add_video',array('ID'=>$_POST['video_id']));
  $allow_data = array(
                    'employee_id'=>$this->session->userdata('employee_id'),
                    'emp_code'=>$this->session->userdata('username'),
                    'category_id'=>$video_data[0]['category_id'],
                    'Video_Title'=>$video_data[0]['Video_Title'],
                    'Short_Description'=>$video_data[0]['Short_Description'],
                    'large_Description'=>$video_data[0]['large_Description'],
                    'Specification_Description'=>$video_data[0]['Specification_Description'],
                    'picture'=>$video_data[0]['picture'],
                    'video'=>$video_data[0]['video'],
                    'video_ID'=>$video_data[0]['ID'],
                    'video_allow_id'=>$video_data[0]['ID'],
                    'panel_name'=>$_POST['panel_name'],
                    'budget'=>$_POST['budget'],
                    'target_audience'=>$_POST['target_audience'],
                    'country'=>$_POST['country'],
                    'payable_amount'=>$_POST['total_payable'],
                    'gst'=>$_POST['gst'],
                    'city'=>$_POST['city'],
                    'manage'=>$_POST['manage'],
                    'gender'=>$_POST['gender'],
                    'perclickcharge'=>$_POST['perclickcharge'],
                    'expirey_date'=>$_POST['expirey_date'],
                    'caption_code'=>$SKU,
                    'allow_year_month_data' =>$_POST['allow_year_month_data'],
                    'allow_year_month_data_time'=> date('Y-m-d H:i:s')
                    
                );
  if(!empty($_FILES['product_image'])){
  $uploaddir = 'uploads/product/';
  $oxiinc=rand().".png";
  $uploadfile = $uploaddir . $oxiinc;
    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadfile)) {
      $allow_data['product_image'] = $oxiinc;
      $allow_data['product_link'] = $_POST['product_link'];
    }
}
  // echo "<pre>";print_r($allow_data);exit();
  $a_id = $this->Model->insertData('allow_data_my_digital',$allow_data);
  $data=array(
                'emp_id' =>$this->session->userdata('employee_id'),
                'user_id' =>$this->session->userdata('user_id'),
                'emp_code' =>$this->session->userdata('employee_code'),
                'amount' =>'-'.$_POST['total_payable'],
                'created_date' =>date('d-M-Y')
                 );
              $this->Model->insertData('wallet',$data);
  $sponsored_video_view = array(
                    'v_id'=>$video_data[0]['ID'],
                    'a_id'=>$a_id,
                    'target_audience'=>$_POST['target_audience']
                );
  $this->Model->insertData('sponsored_video_view',$sponsored_video_view);
  redirect('Upload_video/sponsored_video');
}else{
  $this->session->set_flashdata('msg1','You have insufficient balance..');
              redirect('Home');
}
}
    
    public function guest_profile(){
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$this->user_id_upload));
        $data['custumer_login'] = $data['custumer_login'][0];

        if ($data['custumer_login']['countries']) {
            $this->db->select('co.name AS counrty_name, st.name AS state_name, ct.name AS city_name');
            $this->db->from('countries co'); 
            $this->db->join('states st', 'co.id = st.country_id');
            $this->db->join('cities ct', 'st.id = ct.state_id');
            $this->db->where('co.id', $data['custumer_login']['countries']);
            $this->db->where('st.id', $data['custumer_login']['states']);
            $this->db->where('ct.id', $data['custumer_login']['cities']);
            $query = $this->db->get();

            $data['custumer_address'] = $query->result_array();
            $data['custumer_address'] = $data['custumer_address'][0];
        }
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/guest_profile';
        $this->load->view('new_user/containt', $data);
    }

    public function channel(){
        $sql_query = $this->db->query('SELECT ID, Video_Title, Short_Description, picture, datatime, user_id FROM add_video WHERE status = 1 AND user_id= "'.$this->uri->segment(3).'" ORDER BY ID DESC LIMIT 8');
        $data['video_details'] = $sql_query->result_array();
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/channel_home';
        $this->load->view('new_user/containt', $data);
    }

    public function videos(){
        //$data['video_details'] = $this->Model->getDataOrderBy('add_video',array('user_id'=>$this->uri->segment(3), 'status' => 1), 'ID','DESC');
        $sql_query = $this->db->query('SELECT ID, Video_Title, Short_Description, picture, datatime, user_id FROM add_video WHERE status = 1 AND user_id= "'.$this->uri->segment(3).'" ORDER BY ID DESC');
        $data['video_details'] = $sql_query->result_array();
        $data['main_containt']='new_user/videos';
        $this->load->view('new_user/containt', $data);
    }

    public function playlist(){
        $data['playlist_details'] = $this->Model->getData('playlist_names',array('user_id'=>$this->uri->segment(3), 'status'=>'1'));
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/playlist';
        $this->load->view('new_user/containt', $data);
    }

    public function channels(){
        $this->db->select('*');
        $this->db->from('subscribe_channel'); 
        $this->db->where('my_id', $this->uri->segment(3));
        $this->db->where('status', 1);
        $this->db->order_by('ID', 'DESC');
        $query = $this->db->get();
        $data['subscribe_channel'] = $query->result_array();
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/channels';
        $this->load->view('new_user/containt', $data);
    }

    public function discussion(){
        $custumer_details = $this->Model->getData('custumer_login',array('id'=>$this->uri->segment(3), 'status'=>'1'));
        $data['custumer_details'] = $custumer_details[0];

        $sql_query = $this->db->query('SELECT * FROM channel_discussion WHERE user_id = "'.$this->uri->segment(3).'" AND is_deleted = 0 ORDER BY id DESC');
        $data['discussion_count'] = $sql_query->num_rows();
        $data['discussion_details'] = $sql_query->result_array();

        //echo "<pre>";print_r($data['discussion_details']);die();
        $data['main_containt']='new_user/discussion';
        $this->load->view('new_user/containt', $data);
    }

    public function insert_channel_discussion(){
        //echo "<pre>";print_r($_POST);die();
        if($this->session->userdata('entube_customer_logged_in')){
            $comment_id = $this->session->userdata('username');
                 
        }elseif($this->session->userdata('logged_in')){
            $comment_id = $this->session->userdata('id');
        }
        $postData = array(
            'user_id'=> $this->uri->segment(3),
            'comment_id'=> $comment_id,
            'discussion' => $this->input->post('cha_discussion')
        );
        $insert_data = $this->Model->insertData('channel_discussion', $this->security->xss_clean($postData));
        if($insert_data){
            $this->session->set_flashdata('msg','Channel discussion Added successfully.');
            redirect('Entube_channel/discussion/'.$this->uri->segment(3));
        }
        else{
            $this->session->set_flashdata('msg','Add channel discussion failed.');
            redirect('Entube_channel/discussion/'.$this->uri->segment(3));
        }
    }

    public function channel_about(){
        $data['custumer_details'] = $this->Model->getData('custumer_login',array('id'=>$this->uri->segment(3), 'status'=>'1'));
        $data['custumer_details'] = $data['custumer_details'][0];

        $data['channel_details'] = $this->Model->getData('custumer_channel',array('user_id'=>$this->uri->segment(3)));
        $data['channel_details'] = $data['channel_details'][0];
        //echo "<pre>";print_r($data);die();
        $add_video = $this->Model->getData('add_video',array('user_id'=>$this->uri->segment(3)));
        $watch=0;
        
        if(isset($add_video) && !empty($add_video)) foreach ($add_video as $value) {
         
            $query_1 = $this->db->query('SELECT count(ip) FROM views WHERE post_id='.$value['ID']);
            $row_1= $query_1->result_array();

            $query_2 = $this->db->query('SELECT count(user_id) FROM views WHERE post_id='.$value['ID']);

            $row_2= $query_2->result_array();

            $one=$row_1[0]['count(ip)'];
            $two=$row_2[0]['count(user_id)'];
            $watch += $one + $two;
        }
        $data['custumer_watch'] = $watch;
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/channel_about';
        $this->load->view('new_user/containt', $data);
    }

    public function customise_channel(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }else{
            redirect(base_url('Entube/logout'));
        }
        $sql_query = $this->db->query('SELECT ID, Video_Title, Short_Description, picture, datatime, user_id FROM add_video WHERE status = 1 AND user_id = "'.$user_id_upload.'" ORDER BY ID DESC LIMIT 9');
        $data['video_details'] = $sql_query->result_array();
        //echo "<pre>";print_r($data['video_details']);die();
        $data['main_containt']='new_user/customise_home';
        $this->load->view('new_user/containt', $data);
    }

    public function customise_videos(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }else{
            redirect(base_url('Entube/logout'));
        }

        $this->db->select('ad.ID, ad.Video_Title, ad.Short_Description, ad.picture, ad.datatime, ad.user_id, wu.view');
        $this->db->from('add_video ad'); 
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->where('ad.user_id', $user_id_upload);
        $this->db->where('ad.is_deleted', 0);
        $this->db->where('ad.status', 1);
        

        if($this->input->post()){
            $post_data = $this->input->post();
            if (isset($post_data["id"]) && !empty($post_data["id"]) && isset($post_data["column_name"]) && !empty($post_data["column_name"]) && isset($post_data["option"]) && !empty($post_data["option"])) {

                if ($post_data["column_name"] == "view") {
                    $this->db->order_by("wu.view", "DESC");
                }
                else{
                    $this->db->order_by("ad.datatime", $post_data["option"]);
                }
                $query = $this->db->get();
                $video_details = $query->result_array();
                //echo "<pre>";print_r($video_details);die();
                ?>
                <ul class="list-inline video-list">
                    <?php if(isset($video_details) && !empty($video_details)) foreach ($video_details as $key => $value) { ?>
                        <li class="equal-height-col">
                            <div class="item-containt-col">
                                <a href="<?php echo base_url('watch/'.$value['user_id'].'/'.$value['ID']); ?>" class="video-img-col">
                                    <img src="<?php echo base_url('uploads/product/'.$value['picture']);?>" alt=""/>
                                    <i class="fas fa-play-circle"></i>
                                    <div class="video-overlay"></div>
                                </a>
                                <div class="video-containt-col">
                                    <a href="<?php echo base_url('watch/'.$value['user_id'].'/'.$value['ID']); ?>" class="video-title" style="color: #fff !important;"><?php echo character_limiter($value['Video_Title'], 80);?></a>
                                    <div class="video-views">
                                        <span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
                                        <span><i class="far fa-calendar-alt"></i>
                                            <?php
                                            $FromDate = new DateTime(date("Y-m-d H:i:s"));
                                            $ToDate   = new DateTime($value['datatime']);
                                            $Interval = $FromDate->diff($ToDate);
                                            $Difference["Hours"] = $Interval->h;
                                            $Difference["Weeks"] = floor($Interval->d/7);
                                            $Difference["Days"] = $Interval->d % 7;
                                            $Difference["Months"] = $Interval->m;
                                            $Difference["minute"] = $Interval->i;
                                            $Difference["second"] = $Interval->s;
                                            $Difference["Year"] = $Interval->y;
                                            if($Difference["Year"]){
                                                echo $Difference["Year"]." "."Year";
                                            }else
                                            if($Difference["Months"]){
                                                echo $Difference["Months"]." "."Months";
                                            }else
                                            if($Difference["Weeks"]){
                                                echo $Difference["Weeks"]." "."Weeks";
                                            }else
                                            if($Difference["Days"]){
                                                echo $Difference["Days"]." "."Days";
                                            }else
                                            if($Difference["Hours"]){
                                                echo $Difference["Hours"]." "."Hours";
                                            }else
                                            if($Difference["minute"]){
                                                echo $Difference["minute"]." "."Minute";
                                            }else
                                            if($Difference["second"]){
                                                echo $Difference["second"]." "."Second";
                                            }
                                            echo " "."ago";
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php } else{ ?>
                        <p class="text-center">This channel has no upload videos.</p>
                    <?php } ?>
                </ul>
                <?php
            }
            else{
                $this->db->order_by("wu.view", "DESC");
                $query = $this->db->get();
                $data['video_details'] = $query->result_array();
                $data['main_containt']='new_user/customise_videos';
                $this->load->view('new_user/containt', $data);
            }
        }
        else{
            $this->db->order_by("wu.view", "DESC");
            $query = $this->db->get();
            $data['video_details'] = $query->result_array();
            $data['main_containt']='new_user/customise_videos';
            $this->load->view('new_user/containt', $data);
        }
        /*$data['video_details'] = $this->Model->getDataOrderBy('add_video',array('user_id'=>$user_id_upload, 'status' => 1), 'ID','DESC');
        echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/customise_videos';
        $this->load->view('new_user/containt', $data);*/
    }

    public function customise_playlist(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }else{
            redirect(base_url('Entube/logout'));
        }
        if($this->input->post()){
            $post_data = $this->input->post();
            if (isset($post_data["id"]) && !empty($post_data["id"]) && isset($post_data["column_name"]) && !empty($post_data["column_name"]) && isset($post_data["option"]) && !empty($post_data["option"])) {
                $playlist_details= $this->Model->getDataOrderBy('playlist_names', array('user_id'=>$user_id_upload, 'status'=>'1'), $post_data['column_name'], $post_data['option']);
                ?>
                <ul class="list-inline video-list">
                    <?php
                    if(isset($playlist_details) && !empty($playlist_details)) foreach ($playlist_details as $value){
                        $query_count = $this->db->query('SELECT video_id FROM playlist_video_select WHERE playlistname_id = '.$value['ID'].' GROUP BY video_id ORDER BY video_id DESC');
                        $row_photo= $query_count->result_array();
                        $playlist_count = $query_count->num_rows();
                        if ($playlist_count > 0) {
                            $photo = $this->Model->getDataOrderBy('add_video', array('ID'=>$row_photo[0]['video_id'], 'status'=>'1'), 'ID', 'DESC');
                            if($photo){
	                            ?>
	                            <li>
	                                <a href="<?php echo base_url('Entube/playlist_video/'.$value['ID']."/".$photo[0]['ID']); ?>" class="item-containt-col">
	                                    <div class="video-img-col video-img-block">
	                                        <div class="playlist-text" style="background-image: url('<?php echo base_url().'uploads/product/'.$photo[0]['picture'];?>');">
	                                            <div class="playlist-col">
	                                                <h4><?php echo $playlist_count; ?></h4>
	                                                <img src="<?php echo base_url('black/img/play.png'); ?>" style="width: 20px"/>
	                                            </div>
	                                        </div>
	                                        <div class="play-all-txt">
	                                            <i class="fas fa-play-circle"></i> 
	                                            <span>Play All</span>
	                                        </div>
	                                        <div class="video-overlay"></div>
	                                    </div>
	                                    <div class="video-containt-col">
	                                        <div class="video-title" ><?php echo $value['playlistname']; ?></div>
	                                    </div>
	                                </a>     
	                            </li>
	                            <?php
	                           }
                        }
                        else{ ?>
                            <li>
                                <a href="javascript:void(0);" class="item-containt-col">
                                    <div class="video-img-col video-img-block">
                                        <div class="playlist-text" style="background-image: url('<?php echo base_url('uploads/product/videodefault.jpg');?>');">
                                            <div class="playlist-col">
                                                <h4>No videos</h4>
                                                <img src="<?php echo base_url('black/img/play.png'); ?>" style="width: 20px"/>
                                            </div>
                                        </div>
                                        <div class="play-all-txt">
                                            <i class="fas fa-play-circle"></i> 
                                            <span>Play All</span>
                                        </div>
                                        <div class="video-overlay"></div>
                                    </div>
                                    <div class="video-containt-col">
                                        <div class="video-title" ><?php echo $value['playlistname']; ?></div>
                                    </div>
                                </a>     
                            </li>
                            <?php
                        } 
                    }
                    else{ ?>
                        <p class="text-center">This channel has no playlists.</p>
                        <?php
                    } ?>
                </ul>
                <?php
            }
            else{
                $data['playlist_details'] = $this->Model->getDataOrderBy('playlist_names', array('user_id'=>$user_id_upload, 'status'=>'1'), 'ID', 'DESC');
                $data['main_containt']='new_user/customise_playlist';
                $this->load->view('new_user/containt', $data);
            }
        }
        else{
            $data['playlist_details'] = $this->Model->getDataOrderBy('playlist_names', array('user_id'=>$user_id_upload, 'status'=>'1'), 'ID', 'DESC');
            $data['main_containt']='new_user/customise_playlist';
            $this->load->view('new_user/containt', $data);
        }
    }

    public function add_playlist_name(){
        if($this->input->post()) {
            $post_data = $this->input->post();
            if (isset($post_data["playlist_name"]) && !empty($post_data["playlist_name"])) {
                $postData = array(
                    'user_id' => $this->user_id_upload,
                    'employee_id' => $this->employee_id,
                    'playlistname' => $this->input->post('playlist_name'),
                    'status' => 1
                );
                $strSql = $this->db->query("SELECT playlistname FROM playlist_names WHERE user_id = '".$this->user_id_upload."' && LOWER(playlistname) = '".strtolower($postData['playlistname'])."' ");
                $get_playlist = $strSql->result_array();
                //echo "<pre>";print_r($strSql);die();
                if ($get_playlist) {
                    echo "yes";
                }
                else{
                    echo $insert_playlist = $this->Model->insertData('playlist_names', $this->security->xss_clean($postData));
                }
            }
            else{
                echo "0";
            }
        }
        else{
            echo "0";
        }
    }

    public function customise_channels(){
        if ($this->user_id_upload != $this->uri->segment(3)) {
            redirect(base_url('Entube/logout'));
        }
        else{
            $this->db->select('*');
            $this->db->from('subscribe_channel');
            $this->db->where('my_id', $this->user_id_upload);
            $this->db->where('status', 1);
            $this->db->order_by('ID', 'DESC');
            $query = $this->db->get();
            $data['subscribe_channel'] = $query->result_array();
            //echo "<pre>";print_r($data['subscribe_channel']);die();
            $data['main_containt']='new_user/customise_channels';
            $this->load->view('new_user/containt', $data);
        }
    }

    public function customise_discussion(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }else{
            redirect(base_url('Entube/logout'));
        }
        $custumer_details = $this->Model->getData('custumer_login',array('id'=>$user_id_upload, 'status'=>'1'));
        $data['custumer_details'] = $custumer_details[0];

        $sql_query = $this->db->query('SELECT * FROM channel_discussion WHERE (user_id = "'.$this->uri->segment(3).'" OR comment_id = "'.$this->uri->segment(3).'") AND is_deleted = 0 ORDER BY id DESC');
        $data['discussion_count'] = $sql_query->num_rows();
        $data['discussion_details'] = $sql_query->result_array();
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/customise_discussion';
        $this->load->view('new_user/containt', $data);
    }

    public function insert_customise_discussion(){
        //echo "<pre>";print_r($_POST);die();
        if($this->session->userdata('entube_customer_logged_in')){
            $comment_id = $this->session->userdata('username');
                 
        }elseif($this->session->userdata('logged_in')){
            $comment_id = $this->session->userdata('id');
        }
        $postData = array(
            'user_id'=> $this->input->post('id'),
            'comment_id'=> $comment_id,
            'discussion' => $this->input->post('cha_discussion')
        );
        $insert_data = $this->Model->insertData('channel_discussion', $this->security->xss_clean($postData));
        if($insert_data) {
            $get_data = 1;
        }
        else{
            $get_data = 0;
        }
        echo $get_data;die();
    }

    public function update_customise_discussion(){
        //echo "<pre>";print_r($_POST);die();
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
                 
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
        }
        $update_data = array(
            'discussion' => $this->input->post('update_cha_discussion')
        );
        $where_data = array(
            'id'=> $this->input->post('id'),
            'user_id'=> $this->input->post('user_id'),
            'comment_id'=> $this->input->post('comment_id')
        );
        $update_id = $this->Model->updateData('channel_discussion', $this->security->xss_clean($update_data), $where_data);
        if($update_id){
            $this->session->set_flashdata('discussion_msg','Channel discussion updated successfully.');
            redirect('Entube_channel/customise_discussion/'.$user_id_upload);
        }
        else{
            $this->session->set_flashdata('discussion_msg','channel discussion updated failed.');
            redirect('Entube_channel/customise_discussion/'.$user_id_upload);
        }
    }

    public function delete_channel_discussion(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
        }
        $postData = array(
            'is_deleted'=> 1
        );
        $delete_id = $this->Model->updateData('channel_discussion', $postData, array('id'=>$this->uri->segment(3)));
        if($delete_id){
            $this->session->set_flashdata('discussion_msg','Channel discussion deleted successfully.');
            redirect('Entube_channel/customise_discussion/'.$user_id_upload);
        }
        else{
            $this->session->set_flashdata('discussion_msg','channel discussion deleted failed.');
            redirect('Entube_channel/customise_discussion/'.$user_id_upload);
        }
    }

    public function customise_about(){
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id_upload = $this->session->userdata('username');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }elseif($this->session->userdata('logged_in')){
            $user_id_upload = $this->session->userdata('id');
            if ($user_id_upload != $this->uri->segment(3)) {
                redirect(base_url('Entube/logout'));
            }
        }else{
            redirect(base_url('Entube/logout'));
        }
        $data['custumer_details'] = $this->Model->getData('custumer_login',array('id'=>$user_id_upload, 'status'=>'1'));
        $data['custumer_details'] = $data['custumer_details'][0];

        $data['channel_details'] = $this->Model->getData('custumer_channel',array('user_id'=>$user_id_upload));
        $data['channel_details'] = $data['channel_details'][0];
        
        $add_video = $this->Model->getData('add_video',array('user_id'=>$this->user_id_upload));
        $watch=0;
        
        if(isset($add_video) && !empty($add_video)) foreach ($add_video as $value) {
         
            $query_1 = $this->db->query('SELECT count(ip) FROM views WHERE post_id='.$value['ID']);
            $row_1= $query_1->result_array();

            $query_2 = $this->db->query('SELECT count(user_id) FROM views WHERE post_id='.$value['ID']);

            $row_2= $query_2->result_array();

            $one=$row_1[0]['count(ip)'];
            $two=$row_2[0]['count(user_id)'];
            $watch += $one + $two;
        }
        $data['custumer_watch'] = $watch;
        $data['user_id_upload'] = $user_id_upload;
        //echo "<pre>";print_r($data);die();
        $data['main_containt']='new_user/customise_about';
        $this->load->view('new_user/containt', $data);
    }

    public function update_channel_name(){
        //echo "<pre>";print_r($_POST);die();
        $strSql = $this->db->query("SELECT user_id FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
        $channel_details = $strSql->result_array();
        if ($channel_details) {
            $postData = array(
                'channel_name' => $this->input->post('channel_name')
            );
            $update_about = $this->Model->updateData('custumer_channel', $postData, array('user_id'=>$this->input->post('id')));
            if($update_about) {
                $sql_query = $this->db->query("SELECT channel_name FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $channel_data = $sql_query->result_array();
                $channel_data = $channel_data[0]['channel_name'];
            }
            else{
                $channel_data = 0;
            }
            echo $channel_data;die();
        }
        else{
            $postData = array(
                'user_id'=> $this->input->post('id'),
                'channel_name' => $this->input->post('channel_name')
            );
            $insert_about = $this->Model->insertData('custumer_channel', $this->security->xss_clean($postData));
            if($insert_about) {
                $sql_query = $this->db->query("SELECT channel_name FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $channel_data = $sql_query->result_array();
                $channel_data = $channel_data[0]['channel_name'];
            }
            else{
                $channel_data = 0;
            }
            echo $channel_data;die();
        }
    }

    public function update_channel_logo(){
        if(!empty($_FILES['photo']['name'])){
            $config['upload_path'] = 'uploads/customer_channel_logo/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name'] = date("dmY_").rand()."_channel_logo".".png";
            
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            
            if($this->upload->do_upload('photo')){
                $uploadData = $this->upload->data();
                $channel_logo = $uploadData['file_name'];
            }
            else{
                $this->session->set_flashdata('msg' ,'Channel icon update Failed.');
                redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
            }
        }
        else{
            $this->session->set_flashdata('msg' ,'Please choose correct channel icon formate.');
            redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
        }

        $channel_details = $this->Model->getData('custumer_channel', array('user_id'=>$this->user_id_upload));
        //echo "<pre>";print_r($channel_details);die();
        if ($channel_details) {
            $postData = array(
                'channel_logo' => $channel_logo
            );
            unlink("uploads/customer_channel_logo/".$this->input->post('old_cha_logo'));

            $this->Model->updateData('custumer_channel', $postData, array('user_id'=>$this->user_id_upload));
            $this->session->set_flashdata('msg' ,'Channel logo update successfully.');
            redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
        }
        else{
            $postData = array(
                'user_id'=> $this->user_id_upload,
                'channel_logo' => $channel_logo
            );
            $this->Model->insertData('custumer_channel', $this->security->xss_clean($postData));
            $this->session->set_flashdata('msg' ,'Channel logo insert successfully.');
            redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
        }
    }

    public function update_channel_banner($value=''){
        if(!empty($_FILES['channel_banner']['name'])){
            $config['upload_path'] = 'uploads/customer_channel_banner/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name'] = date("dmY_").rand()."_channel_banner".".png";
            
            //Load upload library and initialize configuration
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            
            if($this->upload->do_upload('channel_banner')){
                $uploadData = $this->upload->data();
                $channel_banner = $uploadData['file_name'];
            }
            else{
                $this->session->set_flashdata('msg' ,'Channel banner update Failed.');
                redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
            }
        }
        else{
            $this->session->set_flashdata('msg' ,'Please choose correct channel banner formate.');
            redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
        }
        $channel_details = $this->Model->getData('custumer_channel', array('user_id'=>$this->user_id_upload));
        //echo "<pre>";print_r($channel_details);die();
        if ($channel_details) {
            $postData = array(
                'channel_banner' => $channel_banner
            );
            unlink("uploads/customer_channel_banner/".$this->input->post('old_cha_banner'));

            $this->Model->updateData('custumer_channel', $postData, array('user_id'=>$this->user_id_upload));
            $this->session->set_flashdata('msg' ,'Channel banner update successfully.');
            redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
        }
        else{
            $postData = array(
                'user_id'=> $this->user_id_upload,
                'channel_banner' => $channel_banner
            );
            $this->Model->insertData('custumer_channel', $this->security->xss_clean($postData));
            $this->session->set_flashdata('msg' ,'Channel banner insert successfully.');
            redirect('Entube_channel/customise_channel/'.$this->user_id_upload);
        }
    }

    public function update_channel_description(){
        //echo "<pre>";print_r($_POST);die();
        $strSql = $this->db->query("SELECT channel_about FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
        $channel_details = $strSql->result_array();
        if ($channel_details) {
            $postData = array(
                'channel_about' => $this->input->post('desc_value')
            );
            $update_about = $this->Model->updateData('custumer_channel', $postData, array('user_id'=>$this->input->post('id')));
            if($update_about) {
                $sql_query = $this->db->query("SELECT channel_about FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $about_data = $sql_query->result_array();
                $about_data = $about_data[0]['channel_about'];
            }
            else{
                $about_data = FALSE;
            }
            echo $about_data;die();
        }
        else{
            $postData = array(
                'user_id'=> $this->input->post('id'),
                'channel_about' => $this->input->post('desc_value')
            );
            $insert_about = $this->Model->insertData('custumer_channel', $this->security->xss_clean($postData));
            if($insert_about) {
                $sql_query = $this->db->query("SELECT channel_about FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $about_data = $sql_query->result_array();
                $about_data = $about_data[0]['channel_about'];
            }
            else{
                $about_data = FALSE;
            }
            echo $about_data;die();
        }
    }

    public function update_channel_business_email(){
        //echo "<pre>";print_r($_POST);die();
        $strSql = $this->db->query("SELECT user_id FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
        $channel_details = $strSql->result_array();
        if ($channel_details) {
            $postData = array(
                'channel_email' => $this->input->post('business_email')
            );
            $update_about = $this->Model->updateData('custumer_channel', $postData, array('user_id'=>$this->input->post('id')));
            if($update_about) {
                $sql_query = $this->db->query("SELECT channel_email FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $get_email = $sql_query->result_array();
                $get_email = $get_email[0]['channel_email'];
            }
            else{
                $get_email = FALSE;
            }
            echo $get_email;die();
        }
        else{
            $postData = array(
                'user_id'=> $this->input->post('id'),
                'channel_email' => $this->input->post('business_email')
            );
            $insert_about = $this->Model->insertData('custumer_channel', $this->security->xss_clean($postData));
            if($insert_about) {
                $sql_query = $this->db->query("SELECT channel_email FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $get_email = $sql_query->result_array();
                $get_email = $get_email[0]['channel_email'];
            }
            else{
                $get_email = FALSE;
            }
            echo $get_email;die();
        }
    }

    public function update_channel_country(){
        //echo "<pre>";print_r($_POST);die();
        $strSql = $this->db->query("SELECT user_id FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
        $channel_details = $strSql->result_array();
        if ($channel_details) {
            $postData = array(
                'channel_country' => $this->input->post('country_id')
            );
            $update_about = $this->Model->updateData('custumer_channel', $postData, array('user_id'=>$this->input->post('id')));
            if($update_about) {
                $sql_query = $this->db->query("SELECT channel_country FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $country_data = $sql_query->result_array();
                $country_data = $country_data[0]['channel_country'];
            }
            else{
                $country_data = FALSE;
            }
            echo $country_data;die();
        }
        else{
            $postData = array(
                'user_id'=> $this->input->post('id'),
                'channel_country' => $this->input->post('country_id')
            );
            $insert_about = $this->Model->insertData('custumer_channel', $this->security->xss_clean($postData));
            if($insert_about) {
                $sql_query = $this->db->query("SELECT channel_country FROM custumer_channel WHERE user_id = '".$this->input->post('id')."' ");
                $country_data = $sql_query->result_array();
                $country_data = $country_data[0]['channel_country'];
            }
            else{
                $country_data = FALSE;
            }
            echo $country_data;die();
        }
    }
}