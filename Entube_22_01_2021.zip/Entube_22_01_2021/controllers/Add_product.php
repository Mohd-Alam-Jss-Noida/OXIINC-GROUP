<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Add_product extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Wellness_add');
        $this->load->model('Model');
        $this->load->model('Files');
        $this->load->helper('string');
        
        if(!$this->session->userdata('is_logged_in')){
            redirect('login');
         }
    }
    
    function Add(){
       date_default_timezone_set("Asia/Calcutta"); 
       // error_reporting(E_ALL); ini_set('display_errors', 1);
       //  echo '<pre>'; print_r($_FILES); exit;
         // echo '<pre>'; print_r($this->input->post('Multiple_Picture_color')); exit;
        if($this->input->post('userSubmit')){  
            //Check whether user upload picture
            if(!empty($_FILES['Multiple_image']['name'])){
                $config['upload_path'] = 'uploads/product/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = rand()."_entube_image".".png";
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('Multiple_image')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }

            if(!empty($_FILES['Multiple_Video']['name'])){
                $configVideo['upload_path'] = 'uploads/video/'; # check path is correct
                $configVideo['allowed_types'] = '*'; # add video extenstion on here
                $configVideo['overwrite'] = FALSE;
                $configVideo['remove_spaces'] = TRUE;
                // $video_name = random_string('numeric', 5);
                $exploded = explode('.',$_FILES['Multiple_Video']['name']);
                $ext = $exploded[count($exploded) - 1]; 
                // print_r($ext);exit();
                $configVideo['file_name'] = "entube".rand().".mp4";
               // print_r($configVideo['file_name']);exit();
                $this->load->library('upload', $configVideo);
                $this->upload->initialize($configVideo);


                if($this->upload->do_upload('Multiple_Video')){
                    $uploadData = $this->upload->data();
                    $video = $uploadData['file_name'];
                }else{
                        $video = '';
                }
            }else{
                $video = '';
            }
                $userData = array(
                    'category_id' => $this->input->post('category_id'),
                     
                    'Video_Name' => $this->input->post('Video_Name'),
                    'Video_Title' => $this->input->post('Video_Title'),
                     'Short_Description' => $this->input->post('Short_Description'),
                    'large_Description' => $this->input->post('large_Description'),
                    'Specification_Description' => $this->input->post('Specification_Description'),
                     'status' => "1",
                     'upload_time' => date('d-m-Y'),
                    'picture' => $picture,
                    'video' => $video
                );

                $this->Model->insertData('add_video',$userData);
                // print_r($userData);exit();
                $this->session->set_flashdata('msg','successfully your Video uploaded');
                redirect('Slider/Add_Video');
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
        
    }
    
}