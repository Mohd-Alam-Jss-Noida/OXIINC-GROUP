<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wrapper extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
         // $this->load->model('Orders_model');
         
         if(!$this->session->userdata('is_logged_in')){
         	redirect('Login');
         }
	}
public function Wellness()
	{ 
		 // $category_data = $this->Model->getData('category');
   //      $data['category_data'] = $category_data;
        $data['upend_information'] = $this->Model->getAllData('upend_wrapper');
		$data['main_containt']='wrapper_wellness';

        $this->load->view('containt',$data);
	}
	public function electronics()
	{

		$data['main_containt']='wrapper_electronics';

        $this->load->view('containt',$data);
	}
	public function home_kitchen()
	{

		$data['main_containt']='wrapper_homekitchen';

        $this->load->view('containt',$data);
	}
	public function womens()
	{

		$data['main_containt']='wrapper_womens';

        $this->load->view('containt',$data);
	}
	public function baby_kids()
	{

		$data['main_containt']='wrapper_baby_kids';

        $this->load->view('containt',$data);
	}
	
}