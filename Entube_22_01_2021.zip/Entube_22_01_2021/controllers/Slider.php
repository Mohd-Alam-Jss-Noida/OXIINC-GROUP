<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Slider extends CI_Controller {
	
	function __construct() {
        parent::__construct();
        
         $this->load->model('Model');
         $this->load->model('Customer_login_Information');
         // $this->load->model('Orders_model');
         
         if(!$this->session->userdata('is_logged_in')){
         	redirect('Login');
         }
	}

public function View()
	{
		$id = $_GET['id'];
		$table = $this->Model->getData('slider',array('id'=>$id));
		$data['view'] = $table;
		$data['main_containt']='view_slider';
        
        $this->load->view('containt',$data);
	}
	public function Slider_eidt()
	{
            // echo '<pre>'; print_r($_GET); exit;
		$id = $_GET['id'];
		
		$data['table'] = $this->Model->getData('slider',array('id'=>$id));
// echo '<pre>'; print_r($data); exit;
		$data['main_containt']='edit_slider';
        
        $this->load->view('containt',$data);
	}
	function Delete(){
        $user_id = $this->input->get_post('id');
        $this->Model->deleteData('slider',array('id'=>$user_id));
        
        $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

        redirect('Slider/Slide_list');
    }
//     public function delete_image($id){
//     $image_path = base_url().'uploads/images/'; // your image path

//     // get db record from image to be deleted
//     $query_get_image = $this->db->get_where('slider', array('id' => $id));
//     foreach ($query_get_image->result() as $record)
//     {
//         // delete file, if exists...
//         $filename = $image_path . $record->picture; 
//         if (file_exists($filename))
//         {
//             unlink($filename);
//         }

//         // ...and continue with your code
//         $this->model->delete($id);
//         $query = $this->db->get("slider");
//         $data['records'] = $query->result();
//         $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');
//         redirect('orders/camera_wrap');
//     }
// }
    function Edit(){
          $postData = $_POST;
        $id = $this->input->get_post('id');

        if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/images/';
            $uploadfile = $uploaddir . basename($_FILES['picture']['name']);

            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['picture'] = basename($_FILES['picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('slider',$postData,array('id'=>$id)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
        
        $table = $this->Model->getData('slider');
        $data['sliderpicture'] = $table;
        $data['main_containt']='Slide_list';
        $this->load->view('containt',$data);

         // $this->Model->updateData('slider',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The File has been updated successfully.');
         //   redirect('Orders/Camera_wrap');
}
function Add_banner(){
    $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
    $data['main_containt']='add_banner';
        
        $this->load->view('containt',$data);
}
function Add_Pro_banner(){
    $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
    $data['main_containt']='Add_Pro_banner';
        
        $this->load->view('containt',$data);
}
function List_Pro_banner(){

    $Pro_banner = $this->Model->getData('pro_banner');
        $data['Pro_banner'] = $Pro_banner;
        $data['main_containt']='List_Pro_banner';
        $this->load->view('containt',$data);
}
function List_Of_Cancel_Product(){

    $cancellation_request = $this->Model->getData('cancellation_request',array('status'=>'1'));
            // $strSql = "SELECT * FROM cancellation_request  payment_method='enpay'OR payment_method='PayUMoney'";
            //     $cancellation_request =$this->Model->getSqlData($strSql);
        $data['cancellation_request'] = $cancellation_request;
        $data['main_containt']='cancellation_request';
        $this->load->view('containt',$data);
}
function List_Of_Return_Product(){

    $return_order = $this->Model->getData('return_order',array('status'=>'1'));
     // $Pincode = $return_order[0]['address_id'];
     // echo '<pre>'; print_r($Pincode); 
     
     // $return_orderasa = $this->Model->getData('manage_addresses',array('ID'=>$Pincode));
     // echo '<pre>'; print_r($return_orderasa); exit;
//      $address_id = $return_order[0]['address_id'];
// echo '<pre>'; print_r($address_id); exit;
        $data['return_order'] = $return_order;
        $data['main_containt']='return_order_page';
        $this->load->view('containt',$data);
}
function Pro_Banner_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('pro_banner',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

        redirect('Slider/List_Pro_banner');
    }
public function Pro_Banner_eidt()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Banner_eidt'] = $this->Model->getData('pro_banner',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Banner_eidt']); exit;
        $data['main_containt']='Pro_Banner_eidt';
        
        $this->load->view('containt',$data);
    }
    function Pro_Banner_edit_form(){

        $postData = $_POST;
        $ID = $this->input->get_post('ID');
// echo '<pre>'; print_r($postData); exit;
        if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/product/';
            $image= rand()."_entube_gagan".".png";
            $uploadfile = $uploaddir . $image;

            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['picture'] = $image;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('add_video',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
         redirect('Slider/List_Of_Upload');
        // $Pro_banner = $this->Model->getData('pro_banner');
        // $data['Pro_banner'] = $Pro_banner;
        // $data['main_containt']='List_Pro_banner';
        // $this->load->view('containt',$data);
      

         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}

  public function Pro_Video_eidt()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Video_eidt'] = $this->Model->getData('add_video',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Video_eidt']); exit;
        $data['main_containt']='Pro_Video_eidt';
        
        $this->load->view('containt',$data);
    }
       function Pro_Video_edit_form(){

        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['video'])){
            $uploaddir = './uploads/video/';
             $video=rand()."_entube_gagan".".mp4";
            $uploadfile = $uploaddir . $video;

            if (move_uploaded_file($_FILES['video']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['video'] = $video;
            }
        }
        // echo '<pre>'; print_r($postData['video']); exit;
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('add_video',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
         redirect('Slider/List_Of_Upload');
        // $Pro_banner = $this->Model->getData('pro_banner');
        // $data['Pro_banner'] = $Pro_banner;
        // $data['main_containt']='List_Pro_banner';
        // $this->load->view('containt',$data);
      

         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}
public function List_banner()
    {
        $table =$this->Model->getDataOrderBy('banner',array(),'ID','DESC');
        $data['bannerpicture'] = $table;
         $data['main_containt']='list_banner';
        
        $this->load->view('containt',$data);
    }
    public function Banner_eidt()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];
         $data['categpry_list'] = $this->Model->getData('category',array('status'=>'1'));
        $data['sub_category_list'] =$this->Model->getData('subcategory',array('status'=>'1'));
        $data['banner'] = $this->Model->getData('banner',array('ID'=>$ID));

        $data['main_containt']='banner_eidt';
        
        $this->load->view('containt',$data);
    }
    function Banner_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('banner',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The Banner has been deleted successfully.');

        redirect('Slider/List_banner');
    }
    function getSubCategory(){
       $postData = $_POST;
        // $postData['category_id'] = 1;

        $sub_category_list = $this->Model->getData('subcategory',array('status'=>'1'));

        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['category_id'] == $value['category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }
      function Banner_edit_form(){
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['banner_Picture'])){
            $gagan=rand().".png";
            $uploaddir = './uploads/banner/';
            $uploadfile = $uploaddir . $gagan;

            if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['banner_Picture'] = $gagan;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('banner',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
        
        redirect('Slider/List_banner');


         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}
public function Camera_wrap()
    {
        // $table = $this->Model->getData('slider');
        // $data['sliderpicture'] = $table;
         $data['main_containt']='Slider';
        
        $this->load->view('containt',$data);
    }
    function Upend_heading_List(){
        $upend_list = $this->Model->getData('upend_wrapper');
        $data['upend_list'] = $upend_list;
        $data['main_containt']='upend_heading_List';
        $this->load->view('containt',$data);    
    }
    public function Upend_eidt()
    {
        $upend_id = $_GET['upend_id'];
        
        $data['table'] = $this->Model->getData('upend_wrapper',array('upend_id'=>$upend_id));
        $data['main_containt']='upend_eidt';

        $this->load->view('containt',$data);
    }
    function Upend_delete(){
        $upend_id = $this->input->get_post('upend_id');
        $this->Model->deleteData('upend_wrapper',array('upend_id'=>$upend_id));
        
        $this->session->set_flashdata('msg' ,'The Upend Heading has been deleted successfully.');

        redirect('Slider/upend_heading_List');
    }
    public function Edit_upend_form()
    {

        $this->Model->updateData('upend_wrapper',$_POST,array('upend_id'=>$_POST['upend_id']));
        $this->session->set_flashdata('msg','Upend Update Successfully ');
        redirect('Slider/upend_heading_List');
    }
    public function Upend_information_list()
    {
        $product_list = $this->Model->getData('wrapper_wellness');
        $data['product_list'] = $product_list;
        $data['main_containt']='Upend_information_list';
        $this->load->view('containt',$data);
    }
    public function Append_information_eidt()
    {
        $ID = $_GET['ID'];
        
        $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
        $data['main_containt']='Append_information_eidt';

        $this->load->view('containt',$data);
    }
    function Append_information_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('wrapper_wellness',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

        redirect('Slider/Upend_information_list');
    }
    public function Slide_list()
    {
        // echo '<pre>'; print_r($_POST);exit;

        $table = $this->Model->getData('slider');
        $data['sliderpicture'] = $table;
        $data['main_containt']='Slide_list';
        $this->load->view('containt',$data);
    }
    public function Url_Upend_heading()
    {

        $data['main_containt']='Url_Upend_heading';

        $this->load->view('containt',$data);
    }
    public function url_Enter_upend()
    {
        $url_enter=$_POST;
        // echo '<pre>'; print_r($_POST);exit;

        // $this->Add_category_model->insertupend($_POST);
         $this->Model->insertData('url_append_heading',$url_enter);
        $this->session->set_flashdata('msg',' Successfully your Url upend_heading Add');
        redirect('Slider/Url_Upend_heading');
    }
    public function Url_Append_information()
    { 
         // $category_data = $this->Model->getData('category');
   //      $data['category_data'] = $category_data;
        $data['upend_information'] = $this->Model->getAllData('url_append_heading');
         $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
        $data['main_containt']='Url_Append_information';

        $this->load->view('containt',$data);
    }
    function Url_Upend_heading_List(){
        $table = $this->Model->getData('url_append_heading');
        $data['url_append_heading'] = $table;
        $data['main_containt']='url_append_heading_list';
        $this->load->view('containt',$data);
    }
    function Url_Upend_delete(){
        $url_id = $this->input->get_post('url_id');
        $this->Model->deleteData('url_append_heading',array('url_id'=>$url_id));
        
        $this->session->set_flashdata('msg' ,'The Url Upend Heading has been deleted successfully.');

        redirect('Slider/Url_Upend_heading_List');
    }
    public function Url_Upend_eidt()
    {
        $url_id = $_GET['url_id'];
        
        $data['table'] = $this->Model->getData('url_append_heading',array('url_id'=>$url_id));
        $data['main_containt']='url_upend_head_eidt';

        $this->load->view('containt',$data);
    }
    public function url_Enter_upend_edit()
    {

        $this->Model->updateData('url_append_heading',$_POST,array('url_id'=>$_POST['url_id']));
        $this->session->set_flashdata('msg','Append Heading Update Successfully ');
        redirect('Slider/Url_Upend_heading_List');
    }
      function Add_Promo_Code_2(){
        $custumer_login = $this->Model->getData('custumer_login');
        $data['custumer_login'] = $custumer_login;
        $data['main_containt']='Add_Promo_Code_2';
        
        $this->load->view('containt',$data);
}
    function Add_Advertisement_banner(){
    
       $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
        $data['main_containt']='Add_Advertisement_banner';
        
        $this->load->view('containt',$data);
}
function Url_Upend_information_list(){

    $product_list = $this->Model->getData('url_append_info');
        $data['product_list'] = $product_list;
        $data['main_containt']='Url_Upend_information_list';
        $this->load->view('containt',$data);
}
function Url_Append_information_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('url_append_info',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

        redirect('Slider/Url_Upend_information_list');
    }
    function Url_Append_information_eidt(){
        $ID = $_GET['ID'];
        $data['url_append_heading'] = $this->Model->getData('url_append_heading',array('status'=>'1'));
         $data['product_category_name'] = $this->Model->getData('product_category',array('status'=>'1'));
        $data['table'] = $this->Model->getData('url_append_info',array('ID'=>$ID));
        $data['main_containt']='Url_Append_information_eidt';

        $this->load->view('containt',$data);

    }
    function Url_append_edit_form(){
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Product_Picture'])){
            $uploaddir = './uploads/append/';
            $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

            if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('url_append_info',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        
        $product_list = $this->Model->getData('url_append_info');
        $data['product_list'] = $product_list;
        $data['main_containt']='Url_Upend_information_list';
        $this->load->view('containt',$data);
    }
    function Edit_Upend_Product(){
        // echo '<pre>'; print_r($_POST); exit;
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Product_Picture'])){
            $uploaddir = './uploads/wrapper/wellness/';
            $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

            if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('wrapper_wellness',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
        
        $product_list = $this->Model->getData('wrapper_wellness');
        $data['product_list'] = $product_list;
        $data['main_containt']='Upend_information_list';
        $this->load->view('containt',$data);
    }
    function List_Advertisement_banner(){

    $advertisement = $this->Model->getData('advertisement');
        $data['advertisement'] = $advertisement;
        $data['main_containt']='advertisement_list';
        $this->load->view('containt',$data);
}
function Advertisement_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('advertisement',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Advertisement Banner has been deleted successfully.');

        redirect('Slider/List_Advertisement_banner');
    }
    function Advertisement_eidt(){
        $ID = $_GET['ID'];
         $data['category_name'] = $this->Model->getData('category',array('status'=>'1'));
        $data['sub_category_name'] = $this->Model->getData('subcategory',array('status'=>'1'));
      
        $data['table'] = $this->Model->getData('advertisement',array('ID'=>$ID));
        $data['main_containt']='Advertisement_eidt';

        $this->load->view('containt',$data);

    }
    function Edit_advertisment_banner(){
        // echo '<pre>'; print_r($_POST); exit;
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Advertisement_Picture'])){
            $uploaddir = './uploads/Advertisement/';
            $uploadfile = $uploaddir . basename($_FILES['Advertisement_Picture']['name']);

            if (move_uploaded_file($_FILES['Advertisement_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Advertisement_Picture'] = basename($_FILES['Advertisement_Picture']['name']);
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('advertisement',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Advertisement has been Updated successfully.');
        
        $advertisement = $this->Model->getData('advertisement');
        $data['advertisement'] = $advertisement;
        $data['main_containt']='advertisement_list';
        $this->load->view('containt',$data);
    }
    function Add_new_Customer()
    {
        $data['main_containt']='Add_new_Customer';

        $this->load->view('containt',$data);
    }
    function Add_customer_info()
    {
       $user_name = $this->input->get_post('user_name');
       $last_name = $this->input->get_post('last_name');
        $email_id =  $this->input->get_post('email_id');
        $password = $this->input->get_post('password');
        $contact_number =  $this->input->get_post('contact_number');
        

        if($user_name!='' && $email_id!='' && $password!='' && $contact_number!=''){
            $email_info=$this->Model->getData('custumer_login',array('email_id'=>$email_id));
            $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$contact_number));

            if(isset($email_info) && empty($email_info)){
                if(isset($mobile_info) && empty($mobile_info)){
                    $array_data=array(
                        'user_name'=>$user_name,
                        'last_name'=>$last_name,
                        'email_id'=>$email_id,
                        'password'=>md5($password),
                        'contact_number'=>$contact_number,
                        'resigtation_month'=> date('m'),
                        'resigtation_year'=> date('Y'),
                        'resigtation_day'=> date('d'),
                        'resigtation_year_month'=> date('Y-m'),
                        'resigtation_year_month_data' =>date('Y-m-d'),
                        'resigtation_year_month_data_time'=> date('Y-m-d H:i:s'),
                        
                    );
                     $user_inserted_id=$this->Model->insertData('custumer_login',array_map('strtoupper', $array_data));

                     if(!empty($_FILES['Pan_Picture']['name'])){
                         $config['upload_path'] = 'uploads/Customer_pan/';
                         $config['allowed_types'] = 'jpg|jpeg|png|gif';
                        $config['file_name'] = $_FILES['Pan_Picture']['name'];
                        
                        //Load upload library and initialize configuration
                        $this->load->library('upload',$config);
                        $this->upload->initialize($config);
                        
                        if($this->upload->do_upload('Pan_Picture')){
                            $uploadData = $this->upload->data();
                            $picture = $uploadData['file_name'];
                        }else{
                            $picture = '';
                        }
                    }else{
                        $picture = 'no';
                    }
                 $userData = array(
                'Customer_id' =>  $user_inserted_id, 
                'pan_number' => $this->input->post('pan_number'),
                'Pan_Full_Name' => $this->input->post('Pan_Full_Name'),
                'Pan_Picture' => $picture
                 );
                 $this->Customer_login_Information->insert($userData);
                 if($user_inserted_id){

                        $this->session->set_flashdata('msg' ,'Customer account has been registered successfully.');
                        redirect('Slider/Add_new_Customer');
                    }else{

                        $this->session->set_flashdata('msg' ,'Error while signing up. please try again.');
                        redirect('Slider/Add_new_Customer');

                    }
                        // $user = "oxiinc";
                        // $password = "microlan@123";
                        // $senderId = "OXIINC";
                        // $channel = "Trans";
                        // $dcs = "0";
                        // $flashsms = "0";
                        // $route = "6";
                        // $mobile = $contact_number;
                        // $text_message = "Dear ". $user_name. ". Thank you for Register with us, We have received your Number no ".$contact_number.". We will process your Register at your chosen date and time.";
                        // $sms = urlencode($text_message);

                        // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

                        // try  
                        // {
                        //     $ch = curl_init();
                        //     curl_setopt($ch, CURLOPT_HEADER, 0);
                        //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        //     curl_setopt($ch, CURLOPT_URL, $smsurl);
                        //     $data = curl_exec($ch);
                        //     curl_close($ch);
                        //     $response = $data;
                        // }  
                        // catch (Exception $e)  
                        // {  
                        //     $response = $e->getMessage();  
                        // }
                    
                   

                }else{

                    $this->session->set_flashdata('msg' ,'Mobile number is already registered with us.');
                        redirect('Slider/Add_new_Customer');

                }
            }else{

                $this->session->set_flashdata('msg' ,'Email address is already registered with us. Please enter unique email address');
                        redirect('Slider/Add_new_Customer');

            }
        }else{
            

            $this->session->set_flashdata('msg' ,'Required parameters are missing.');
                        redirect('Slider/Add_new_Customer');
    }
}
 function List_of_customer(){
   
    $custumer_login = $this->Model->getDataOrderBy('custumer_login',array(),'id','DESC');
        $data['custumer_login'] = $custumer_login;
        $data['main_containt']='List_of_customer';
        $this->load->view('containt',$data);
}
function Customer_eidt(){
     $ID = $_GET['id'];
        
        $data['custumer_login'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
        $data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$ID));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Customer_eidt';

        $this->load->view('containt',$data);
}
function edit_customer_info(){

   $user_name = $this->input->get_post('user_name');
       $last_name = $this->input->get_post('last_name');
        $email_id =  $this->input->get_post('email_id');
        $id = $this->input->get_post('id');
        $contact_number =  $this->input->get_post('contact_number');
        $status =  $this->input->get_post('status');
        
                    $array_data=array(
                        'user_name'=>$user_name,
                        'last_name'=>$last_name,
                        'email_id'=>$email_id,
                        // 'password'=>md5($password),
                        'contact_number'=>$contact_number,
                        'status'=>$status,
                        
                    );
                     $this->Model->updateData('custumer_login',$array_data,array('id'=>$id)); 
                     


                        $this->session->set_flashdata('msg' ,'Customer account Updated has been registered successfully.');
                        redirect('Slider/List_of_customer');      

}
function Pan_information(){
     $id = $_GET['id'];
      $data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$id));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Pan_information';

        $this->load->view('containt',$data);
}
function Promo_Code(){
     $id = $_GET['id'];
      $data['customer_login_info'] = $this->Model->getData('custumer_login',array('id'=>$id));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Promo_Code';

        $this->load->view('containt',$data);
}
function Edit_customer_pan_info(){

    $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['Pan_Picture'])){
            $uploaddir = './uploads/Customer_pan/';
            $uploadfile = $uploaddir . basename($_FILES['Pan_Picture']['name']);

            if (move_uploaded_file($_FILES['Pan_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['Pan_Picture'] = basename($_FILES['Pan_Picture']['name']);
            }
        }
        // echo '<pre>'; print_r($postData['Pan_Picture']); exit;
         $this->Model->updateData('customer_pan_info',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
         redirect('Slider/List_of_customer'); 
}
function Customer_Delete(){
        $id = $this->input->get_post('id');
        $this->Model->deleteData('custumer_login',array('id'=>$id));
        $this->session->set_flashdata('msg' ,'The Customer Account has been deleted successfully.');

        redirect('Slider/List_of_customer');
    }
    function Add_customer_Promo_info(){

        $promo_codo = $_POST;
        // echo '<pre>'; print_r($promo_codo); exit;
       $id = $this->Model->insertData('promo_codo',$promo_codo);
       // echo '<pre>'; print_r($id); exit;
       $this->session->set_flashdata('msg' ,'The Promo code has been add successfully.');
       redirect('Slider/Add_Promo_Code_2');
    }
      function Add_Promo_info(){

        $promo_codo = $_POST;
        // echo '<pre>'; print_r($promo_codo); exit;
       $id = $this->Model->insertData('promo_codo',$promo_codo);
       // echo '<pre>'; print_r($id); exit;
       $this->session->set_flashdata('msg' ,'The Promo code has been add successfully.');
       redirect('Slider/Add_Promo_Code');
    }
     function List_Of_Promo_Code(){

    $promo_codo = $this->Model->getData('promo_codo');
        $data['promo_codo'] = $promo_codo;
        $data['main_containt']='List_Of_Promo_Code';
        $this->load->view('containt',$data);
}
     function enpay(){

     $custumer_login = $this->Model->getData('custumer_login');
        $data['custumer_login'] = $custumer_login;
        $data['main_containt']='enpay';
        $this->load->view('containt',$data);
}
function enpay_Balance(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        //  $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        // $data['customer_enpay'] = $customer_enpay;
    $data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
        // echo '<pre>'; print_r($data); exit;
        $data['main_containt']='enpay_Balance';
        $this->load->view('containt',$data);

}
function Debits_enpay(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        //  $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        // $data['customer_enpay'] = $customer_enpay;
        $data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
        $data['main_containt']='Debits_enpay';
        $this->load->view('containt',$data);

}
function Add_enpay_amount(){
 $this->Model->updateData('custumer_login',$_POST,array('id'=>$_POST['id']));
        $this->session->set_flashdata('msg','enpay amount Update Successfully ');
 redirect('Slider/enpay');
}
function Add_debits_amount(){
 $this->Model->insertData('customer_enpay',$_POST);
        $this->session->set_flashdata('msg','enpay amount Update Successfully ');
 redirect('Slider/enpay');
}
function Credits_enpay(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
         $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        $data['customer_enpay'] = $customer_enpay;
        $data['main_containt']='Credits_enpay';
        $this->load->view('containt',$data);

}
function Promo_code_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('promo_codo',array('ID'=>$ID));
        $this->session->set_flashdata('msg' ,'The Promo Code has been deleted successfully.');

        redirect('Slider/List_Of_Promo_Code');
    }
    function Promo_code_eidt(){
     $ID = $_GET['ID'];
        
        // $data['custumer_login'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
        $data['promo_codo'] = $this->Model->getData('promo_codo',array('ID'=>$ID));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
        $data['main_containt']='Promo_code_eidt';
// echo '<pre>'; print_r($data['promo_codo']); exit;
        $this->load->view('containt',$data);
}
   public function Edit_Promo_code_info()
    {

        $this->Model->updateData('promo_codo',$_POST,array('ID'=>$_POST['ID']));
        $this->session->set_flashdata('msg','Promo code Update Successfully ');
        redirect('Slider/List_Of_Promo_Code');
    }
 function List_Of_Wishlist(){

    $wishlist = $this->Model->getData('wishlist');
        $data['wishlist'] = $wishlist;
        $data['main_containt']='List_Of_Wishlist';
        $this->load->view('containt',$data);
}
 function append_List_Of_Wishlist(){

    // $wishlist = $this->Model->getData('wishlist');
        // $data['wishlist'] = $wishlist;
        $data['main_containt']='append_List_Of_Wishlist';
        $this->load->view('containt',$data);
}
 function List_Of_order_confirmation(){

    $data['customer_order_data'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1'),'ID','DESC');
    // echo '<pre>'; print_r($data['customer_order_data']); exit;
        $data['main_containt']='List_Of_order_confirmation';
        $this->load->view('containt',$data);
}
function Product_invoice(){
    $ID = $_GET['ID'];
  $data['Product_invoice'] = $this->Model->getData('order_data',array('ID'=>$ID));
  // echo '<pre>'; print_r($data['Product_invoice']); exit;
   $this->load->view('Product_invoice',$data);
}
function Invoice_print(){
     $ID = $_GET['ID'];
  $data['Product_invoice'] = $this->Model->getData('order_data',array('ID'=>$ID));
  $this->load->library('pdfgenerator');
  $html = $this->load->view('admin_pdf_invoice', $data, true);
   // $this->load->view('admin_pdf_invoice', $data);
  $filename = 'Invoice'.time();
                $this->pdfgenerator->generate($html, $filename, true, 'A4', 'letter');
}
// function order_Confirmation(){
//     // echo '<pre>'; print_r($_GET); exit;
//     $ID = $_GET['ID'];
//     // echo '<pre>'; print_r($ID); exit;
//     $status['dispatchment_confirmation']='1';
//     $this->Model->updateData('order_data',$status,array('ID'=>$ID));
//     $this->session->set_flashdata('msg','Promo code Update Successfully ');
//     redirect('Slider/List_Of_order_confirmation');
//     // echo '<pre>'; print_r($ID); exit;
// }
function List_Of_Dispatchment(){
     $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'0'),'ID','DESC');
     // $data['dispatchment_confirmation'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='List_Of_Dispatchment';
        $this->load->view('containt',$data);
}
function  E_panelist_List_Of_Dispatchment(){
         $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'0'),'ID','DESC');
     // $data['dispatchment_confirmation'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='E_panelist_List_Of_Dispatchment';
        $this->load->view('containt',$data);
}
function Dispatchment_Confirmation(){
 

    $ID = $_POST['ID'];
    $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];

    // echo '<pre>'; print_r($ID); exit;
    $status['dispatchment_confirmation']='1';
    $status['dispatchment_confirmation_info']=$dispatchment_confirmation_info;
  $Update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
    redirect('Slider/List_Of_Dispatchment');
    // echo '<pre>'; print_r($ID); exit;
}
function  E_panelist_Dispatchment_Confirmation(){
        $ID = $_POST['ID'];
    $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];

    // echo '<pre>'; print_r($ID); exit;
    $status['dispatchment_confirmation']='1';
    $status['dispatchment_confirmation_info']=$dispatchment_confirmation_info;
  $Update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Dispatchment');
}
function List_Of_Shipping(){

     $data['shipping_confirmation'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='List_Of_Shipping';
        $this->load->view('containt',$data);
}
function  E_panelist_List_Of_Shipping(){

     $data['shipping_confirmation'] = $this->Model->getData('e_paenlist_order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
    // echo '<pre>'; print_r($data['dispatchment_confirmation']); exit;
        $data['main_containt']='E_panelist_List_Of_Shipping';
        $this->load->view('containt',$data);
}
function shipping_Confirmation(){

    $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];

    $status['shipping_confirmation']='1';
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Slider/List_Of_Shipping');
    // echo '<pre>'; print_r($ID); exit;
}
function E_panelist_shipping_Confirmation(){
        $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];

    $status['shipping_confirmation']='1';
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Shipping');
}
function List_Of_Vendor(){
 $data['order_delivered'] = $this->Model->getData('order_data',array('shipping_confirmation'=>'1','order_intransit'=>'0','out_for_delivery'=>'0'));
 $data['main_containt']='List_Of_Vendor';
  $this->load->view('containt',$data);
}
function E_panelist_List_Of_Vendor(){
     $data['order_delivered'] = $this->Model->getData('e_paenlist_order_data',array('shipping_confirmation'=>'1','order_intransit'=>'0','out_for_delivery'=>'0'));
 $data['main_containt']='E_panelist_List_Of_Vendor';
  $this->load->view('containt',$data);
}
function Out_For_Delivery(){
 $data['Out_For_Delivery'] = $this->Model->getData('order_data',array('order_intransit'=>'1','out_for_delivery'=>'0'));
 $data['main_containt']='Out_For_Delivery';
  $this->load->view('containt',$data);
}
function E_panelist_Out_For_Delivery(){
     $data['Out_For_Delivery'] = $this->Model->getData('e_paenlist_order_data',array('order_intransit'=>'1','out_for_delivery'=>'0'));
 $data['main_containt']='E_panelist_Out_For_Delivery';
  $this->load->view('containt',$data);
}
function Delivered_Confirmation(){
    // echo '<pre>'; print_r($_GET); exit;
    $ID = $_GET['ID'];
    // echo '<pre>'; print_r($ID); exit;
    $status['order_delivered']='1';
    $this->Model->updateData('order_data',$status,array('ID'=>$ID));
    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Slider/List_Of_Vendor');
    // echo '<pre>'; print_r($ID); exit;
}
function In_transit_Confirmation(){

    $ID = $_POST['ID'];
    $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];

    $status['order_intransit']='1';
    $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Slider/List_Of_Vendor');

}
function E_panelist_In_transit_Confirmation(){
    $ID = $_POST['ID'];
    $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];

    $status['order_intransit']='1';
    $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Vendor');
}
function Out_for_Delivery_Confirmation(){

     $ID = $_POST['ID'];
    $Out_For_Delivery_confirmation_info = $_POST['Out_For_Delivery_confirmation_info'];

     $status['out_for_delivery']='1';
    $status['Out_For_Delivery_confirmation_info']=$Out_For_Delivery_confirmation_info;

  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Slider/Out_For_Delivery');

}
function E_panelist_Out_for_Delivery_Confirmation(){
         $ID = $_POST['ID'];
    $Out_For_Delivery_confirmation_info = $_POST['Out_For_Delivery_confirmation_info'];

     $status['out_for_delivery']='1';
    $status['Out_For_Delivery_confirmation_info']=$Out_For_Delivery_confirmation_info;

  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Slider/E_panelist_Out_For_Delivery');
}
function Deliverd_info_Confirmation(){
      $ID = $_POST['ID'];
    $Delivered_confirmation_info = $_POST['Delivered_confirmation_info'];

     $status['order_delivered']='1';
    $status['Delivered_confirmation_info']=$Delivered_confirmation_info;

  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Slider/List_Of_Delivered');
}
function E_panelist_Deliverd_info_Confirmation(){
          $ID = $_POST['ID'];
    $Delivered_confirmation_info = $_POST['Delivered_confirmation_info'];

     $status['order_delivered']='1';
    $status['Delivered_confirmation_info']=$Delivered_confirmation_info;

  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Delivered');
}
function List_Of_Delivered(){
    $data['List_Of_Delivered'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'0'),'ID','DESC');
     $data['main_containt']='List_Of_Delivered';
        $this->load->view('containt',$data);
}
function E_panelist_List_Of_Delivered(){
      $data['List_Of_Delivered'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'0'),'ID','DESC');
     $data['main_containt']='E_panelist_List_Of_Delivered';
        $this->load->view('containt',$data);
}
function List_Of_Order_Delivered_product(){
     $data['List_Of_Order_Delivered_product'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1'),'ID','DESC');
     $data['main_containt']='List_Of_Order_Delivered_product';
        $this->load->view('containt',$data);
}
function E_panelist_List_Of_Order_Delivered_product(){
         $data['List_Of_Order_Delivered_product'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1'),'ID','DESC');
     $data['main_containt']='E_panelist_List_Of_Order_Delivered_product';
        $this->load->view('containt',$data);
}
function cancel_enpay_debits(){
   $ID = $_GET['ID'];
    // echo '<pre>'; print_r($ID); exit;
   $cancellation_request = $this->Model->getData('cancellation_request',array('ID'=>$ID));
   $cancel['Customer_id'] = $cancellation_request[0]['customer_id'];
   $cancel['customer_name'] = $cancellation_request[0]['user_name'];
   $cancel['custumer_email']   = $cancellation_request[0]['email_id'];
   $cancel['debits_amount']   = $cancellation_request[0]['Prices'];
   $cancel['debits_status']   = '1';
 $id =   $this->Model->insertData('customer_enpay',$cancel);
 
    $status['status']='0';
  $ID =   $this->Model->updateData('cancellation_request',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','cancellation Request Amount Update Successfully ');
    redirect('Slider/List_Of_Cancel_Product');
}
function Cancellation_Confirm(){
   $ID = $_GET['ID'];
 $status['status']='0';
  $ID =   $this->Model->updateData('cancellation_request',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','cancellation Request Amount Update Successfully ');
    redirect('Slider/List_Of_Cancel_Product');
}
function Return_Confirm_account(){
   $ID = $_GET['ID'];
 $status['status']='0';
  $ID =   $this->Model->updateData('return_order',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Return Product Update Successfully ');
    redirect('Slider/List_Of_Return_Product');
}
public function Total_GST_Report()
    {
        $order_data = $this->Model->getData('order_data',array('order_confirmation'=>'1'));
        $data['order_data'] = $order_data;
         $data['main_containt']='Total_GST_Report';
        
        $this->load->view('containt',$data);
    }
    function Order_delete(){
        $ID = $this->input->get_post('ID');
        $this->Model->deleteData('order_data',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The order has been deleted successfully.');

        redirect('Slider/List_Of_order_confirmation');
    }
    public function Registred_users()
    {
        $Registred_users_COUNT = $this->Model->CountWhereRecord('custumer_login',array('status'=>'1'));
         $data['Registred_users_COUNT'] = $Registred_users_COUNT;
        $Registred_users = $this->Model->getData('custumer_login',array('status'=>'1'));
        $data['Registred_users'] = $Registred_users;
         $data['main_containt']='Registred_users';
        
        $this->load->view('containt',$data);
    }
     function List_chart(){

        $data['main_containt']='List_chart';
        $this->load->view('containt',$data);
}
   function List_Login_Logout(){

        $data['main_containt']='List_Login_Logout';
        $this->load->view('containt',$data);
}
 function Add_seminar_information(){

        $data['main_containt']='Add_seminar_information';
        $this->load->view('containt',$data);
}
function enter_seminar_information(){
$seminar_info = $_POST;
 
   $this->Model->insertData('add_seminar_information',$seminar_info);
 $this->session->set_flashdata('msg','Seminar Information Add successfully');
    redirect('Slider/Add_seminar_information');
}
function Seminar_Information_List(){
    $Add_seminar_information = $this->Model->getData('add_seminar_information');
        $data['Add_seminar_information'] = $Add_seminar_information;
         $data['main_containt']='Seminar_Information_List';
        
        $this->load->view('containt',$data);
}
function update_seminar_information(){
    $this->Model->updateData('add_seminar_information',$_POST,array('ID'=>$_POST['ID']));
$this->session->set_flashdata('msg','Seminar Information Update successfully');
        redirect('Slider/Seminar_Information_List');
}
function List_Of_Ticket_Book_Customer(){
    $summary = $this->Model->getData('summary');
        $data['summary'] = $summary;
         $data['main_containt']='List_Of_Ticket_Book_Customer';
        
        $this->load->view('containt',$data);

}
function delete_seminar_ticket(){
      $ID = $this->input->get_post('ID');
        $this->Model->deleteData('summary',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The Ticket has been deleted successfully.');

        redirect('Slider/List_Of_Ticket_Book_Customer');

}
function Add_user_role_by_department(){
    $data['id'] = $_POST['id'];
    // echo '<pre>'; print_r($data['id']); exit;
    $data['Add_user'] = $this->Model->getData('users',array('id'=>$_POST['id']));
    // echo '<pre>'; print_r($data['Add_user']); exit;
    $data['main_containt']='Add_user_role_by_department';
        $this->load->view('containt',$data);
}
function add_user_role_insert(){
$id = $this->Model->updateData('users',$_POST,array('id'=>$_POST['user_id']));
// echo '<pre>'; print_r($id); exit;
$this->session->set_flashdata('msg' ,'User Role Add successfully.');
redirect('Usersadmin/Add_User_Role');
}
function Add_Video(){

        // echo '<pre>'; print_r($product_list); exit;
    $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
        $data['main_containt']='add_product_page';
        $this->load->view('containt',$data);
}
function List_Of_Upload(){
    $add_video = $this->Model->getDataOrderBy('add_video',array(),'ID','DESC');
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='List_Of_Upload';
        $this->load->view('containt',$data);
}
function delete_video(){
    $ID = $this->input->get_post('ID');
        $this->Model->deleteData('add_video',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The order has been deleted successfully.');

        redirect('Slider/List_Of_Upload');
}
function Digital_Markating_Program(){
            $product_list = $this->Model->getDataOrderBy('add_video',array('allow_video'=>'0'),'ID','DESC');
        $data['product_list'] = $product_list;
        // echo '<pre>'; print_r($product_list); exit;
        $data['main_containt']='Digital_Markating_Program';
        $this->load->view('containt',$data);
}
function My_Digital_allow(){
   // echo '<pre>'; print_r($_POST); 
    $video_allow_id = $_POST['video_allow_id'];
    $i = 0;
        foreach ($video_allow_id as $key => $value) {

             $PQR =  mt_rand(10000,999999);
            $SKU = 'OXIINC'.$PQR;
// echo '<pre>'; print_r($SKU); exit;
$var['allow_video'] = '1';
 $this->Model->updateData('add_video',$var,array('ID'=>$value));


            $product_data = $this->Model->getData('add_video',array('ID'=>$value));
            // echo '<pre>'; print_r($product_data); exit;
            $allow_data = array(
                   
                    'category_id'=>$product_data[0]['category_id'],
                    'Video_Name'=>$product_data[0]['Video_Name'],
                    'Video_Title'=>$product_data[0]['Video_Title'],
                    'Short_Description'=>$product_data[0]['Short_Description'],
                    'large_Description'=>$product_data[0]['large_Description'],
                    'Specification_Description'=>$product_data[0]['Specification_Description'],
                    'picture'=>$product_data[0]['picture'],
                    'video'=>$product_data[0]['video'],
                    
                    'video_ID'=>$product_data[0]['ID'],
                    'video_allow_id'=>$value,
                    'panel_name'=>$_POST['panel_name'],
                    'expirey_date'=>$_POST['expirey_date'],
                    'caption_code'=>$SKU,
                    'allow_information'=>$_POST['Shipping_confirmation_info'],

                    'allow_month'=> date('m'),
                    'allow_year'=> date('Y'),
                    'allow_day'=> date('d'),
                    'allow_year_month'=> date('Y-m'),
                    'allow_year_month_data' =>date('Y-m-d'),
                    'allow_year_month_data_time'=> date('Y-m-d H:i:s')
                    
                );
         $order_id = $this->Model->insertData('allow_data_my_digital',$allow_data);
        
        $i++;
        }
        $this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Slider/Digital_Markating_Program');
       // echo '<pre>'; print_r($i); 
// echo '<pre>'; print_r($allow_data); exit;
}
function List_Of_Allow_Video_For_Digital_Marketing(){
         $product_list = $this->Model->getDataOrderBy('add_video',array('allow_video'=>'1'),'ID','DESC');
        $data['product_list'] = $product_list;
        // echo '<pre>'; print_r($product_list); exit;
        $data['main_containt']='List_of_Allow_Product_For_Digital_Marketing';
        $this->load->view('containt',$data);
}
function My_Digital_allow_no(){
    $product_allow_id = $_POST['video_allow_id'];
    $i = 0;
        foreach ($product_allow_id as $key => $value) {
            $var['allow_video'] = '0';
 $this->Model->updateData('add_video',$var,array('ID'=>$value));
               $i++;
        }
         $this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Slider/List_Of_Allow_Video_For_Digital_Marketing');
}


public function Update_image()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Banner_eidt'] = $this->Model->getData('add_video',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Banner_eidt']); exit;
        $data['main_containt']='Pro_Banner_eidt';
        
        $this->load->view('containt',$data);
    }


function allowed(){

        // echo '<pre>'; print_r($product_list); exit;
    $givenDate=date("Y-m-d");
    $Next_Monday=date('Y-m-d', strtotime('next monday', strtotime($givenDate)));
    $Previous_Monday= date('Y-m-d', strtotime('previous monday', strtotime($givenDate)));
    //$query = $this->db->query('select * from allow_data_my_digital where allow_year_month_data between "'.$Previous_Monday.'"  and "'.$Next_Monday.'" ');
    $query = $this->db->query('SELECT * FROM allow_data_my_digital WHERE allow_year_month_data BETWEEN "2019-03-01" AND "2019-03-07" ');
    //SELECT * FROM allow_data_my_digital WHERE allow_year_month_data BETWEEN "2019-03-01" AND "2019-03-07"
         $row= $query->result_array();
         $data['add_video'] = $row;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='allowed';
        $this->load->view('containt',$data);
// echo '<pre>'; print_r($row['data']); exit;
}

public function Update_allowed()
    {
            // echo '<pre>'; print_r($_GET); exit;
        $ID = $_GET['ID'];

        $data['Pro_Banner_eidt'] = $this->Model->getData('allow_data_my_digital',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Banner_eidt']); exit;
        $data['main_containt']='Edit_allowed';
        
        $this->load->view('containt',$data);
    }
    
          function Pro_allowed_edit_form(){

        $postData = $_POST;
        $ID = $this->input->get_post('ID');
// echo '<pre>'; print_r($_FILES['picture']); exit;
        if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/product/';
            $image= rand()."entube_gagan".".png";
            $uploadfile = $uploaddir . $image;

            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
              $postData['picture'] = $image;
            }
        }
// echo '<pre>'; print_r($postData); exit;

        $this->Model->updateData('allow_data_my_digital',$postData,array('ID'=>$ID)); 
         $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
         redirect('Slider/allowed');
        
}
function allowed_delete_video(){
    $ID = $this->input->get_post('ID');
    // echo  $ID;
        $this->Model->deleteData('allow_data_my_digital',array('ID'=>$ID));
        
        $this->session->set_flashdata('msg' ,'The video has been deleted successfully.');

        redirect('Slider/allowed');
}

function Approve(){
    $add_video = $this->Model->getDataOrderBy('add_video',array('status'=>'0','reason'=>' '),'ID','DESC');
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='Approve_Disapprove_video';
        $this->load->view('containt',$data);
}
function Pending(){
    $add_video = $this->Model->getDataOrderBy('add_video',array('status'=>'0','reason'=>' '),'ID','DESC');
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='Approve_Disapprove_video';
        $this->load->view('containt',$data);
}
function Approved_list(){
    $add_video = $this->Model->getDataOrderBy('add_video',array('status'=>'1'),'approved_time','DESC');
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='Approve_List_video';
        $this->load->view('containt',$data);
}
function Reject_list(){
    $strSql = "SELECT * FROM add_video WHERE status='0' AND reason!=' ' ORDER BY ID DESC";
              $data['countries'] =$this->Model->getSqlData($strSql);
    $add_video = $this->Model->getSqlData($strSql);
        $data['add_video'] = $add_video;
        // echo '<pre>'; print_r($add_video); exit;
        $data['main_containt']='Reject_List_video';
        $this->load->view('containt',$data);
}
function Approve_video(){
    
//   echo "<pre>"; print_r($_POST);
    $data['status'] ="1";
    $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
// if($conn){
//    echo "connect"; 
// }else{
//     echo "not connect"; 
// }





   
    $data['status'] ="1";
    $data['priority'] =$_POST['priority'];
  date_default_timezone_set('Asia/Kolkata');
      $data['approved_time'] =date('d-m-Y H:i');
    $add_video= $this->Model->getData('add_video',array('ID'=>$_POST['ID']));
    
    // echo "<pre>"; print_r($data);exit();
       $login_gagan_info = $this->Model->getData('custumer_login',array('id'=>$add_video[0]['user_id'],'status'=>'1'));
                                  if(!$login_gagan_info){

                                      $email=$add_video[0]['user_id'];
                                      // echo 'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"';
              $result=mysqli_query($conn,'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"');
$customer_information=mysqli_fetch_assoc($result);
$to_email_address=$customer_information['email'];
// echo "<pre>";print_r($customer_information['email']);


                                  }else{

                                    if($login_gagan_info[0]['channel_name']){
                                       $email= $login_gagan_info[0]['channel_name'];
                                      }else{
                                     $email= $login_gagan_info[0]['user_name']." ".$login_gagan_info[0]['last_name'];
                                      }
                                      $to_email_address= $login_gagan_info[0]['email_id'];
                                  }
                                 
                                   $subject = 'Your video has been approved';
                $emailer = 'emailer/approve.html';
                $mail_content = file_get_contents($emailer);
                 $img_url='https://www.entube.in/uploads/product/'.$add_video[0]['picture'];
                // echo '<pre>'; print_r($mail_content); exit;
                 $mail_content = str_replace('@__imgurl__@', $img_url, $mail_content);
                 $mail_content = str_replace('@_users_names_@', $email, $mail_content);
                 $mail_content = str_replace('@_video_@', $add_video[0]['ID'], $mail_content);
                 // $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                 $mail_content = str_replace('@_title_@', $add_video[0]['Video_Name'], $mail_content);

                 $this->load->library('email');
                

                            $config = Array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.oxiinc.in',
    'smtp_port' => 587,
    'smtp_user' => 'noreply@entube.in',
    'smtp_pass' => '@@entube',
     'mailtype' => 'html',
    'charset' => 'iso-8859-1'
);

                    
$this->email->initialize($config);
$this->email->from('noreply@entube.in', 'Entube');
$this->email->to($to_email_address);
// // $this->email->cc('another@another-example.com');
// // $this->email->bcc('them@their-example.com');

$this->email->subject($subject); 
$this->email->message($mail_content);
// $this->email->attach($mail_content);
$this->email->send();
    $this->Model->updateData('add_video',$data,array('ID'=>$_POST['ID']));
    redirect('Slider/Approve');
    
}
function Dis_Approve_video(){
    
   
    // $data['status'] ="1";
    //  print_r($_POST);
    // exit();
    $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
$add_video= $this->Model->getData('add_video',array('ID'=>$_POST['ID']));
       $login_gagan_info = $this->Model->getData('custumer_login',array('id'=>$add_video[0]['user_id'],'status'=>'1'));
                                  if(!$login_gagan_info){

                                      $email=$add_video[0]['user_id'];
                                      // echo 'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"';
              $result=mysqli_query($conn,'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"');
$customer_information=mysqli_fetch_assoc($result);
$to_email_address=$customer_information['email'];
// echo "<pre>";print_r($customer_information['email']);


                                  }else{

                                    if($login_gagan_info[0]['channel_name']){
                                       $email= $login_gagan_info[0]['channel_name'];
                                      }else{
                                     $email= $login_gagan_info[0]['user_name']." ".$login_gagan_info[0]['last_name'];
                                      }
                                      $to_email_address= $login_gagan_info[0]['email_id'];
                                  }
                                 
                                   $subject = 'Your video has been rejected';
                $emailer = 'emailer/reject.html';
                $mail_content = file_get_contents($emailer);
                 $img_url='https://www.entube.in/uploads/product/'.$add_video[0]['picture'];
                // echo '<pre>'; print_r($mail_content); exit;
                 $mail_content = str_replace('@__imgurl__@', $img_url, $mail_content);
                 $mail_content = str_replace('@_users_names_@', $email, $mail_content);
                 $mail_content = str_replace('@_video_@', $add_video[0]['ID'], $mail_content);
                 $mail_content = str_replace('@_reason_@', $_POST['reason'], $mail_content);
                 // $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                 $mail_content = str_replace('@_title_@', $add_video[0]['Video_Name'], $mail_content);

                 $this->load->library('email');
                

                            $config = Array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.oxiinc.in',
    'smtp_port' => 587,
    'smtp_user' => 'noreply@entube.in',
    'smtp_pass' => '@@entube',
     'mailtype' => 'html',
    'charset' => 'iso-8859-1'
);

                    
$this->email->initialize($config);
$this->email->from('noreply@entube.in', 'Entube');
$this->email->to($to_email_address);
// // $this->email->cc('another@another-example.com');
// // $this->email->bcc('them@their-example.com');

$this->email->subject($subject); 
$this->email->message($mail_content);
// $this->email->attach($mail_content);
$this->email->send();
 date_default_timezone_set('Asia/Kolkata');
      $_POST['approved_time'] =date('d-m-Y H:i');
    $this->Model->updateData('add_video',$_POST,array('ID'=>$_POST['ID']));
    redirect('Slider/Approve');
    
}
function Dis_Approve_video_list(){
    
   
    // $data['status'] ="1";
    //  print_r($_POST);
    // exit();
     $servername='49.50.117.106';
$username='membero_oxiinc';
$password='YD4{B@Cp;[wS';
$dbname = "membero_oxiinc";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
$add_video= $this->Model->getData('add_video',array('ID'=>$_POST['ID']));
       $login_gagan_info = $this->Model->getData('custumer_login',array('id'=>$add_video[0]['user_id'],'status'=>'1'));
                                  if(!$login_gagan_info){

                                      $email=$add_video[0]['user_id'];
                                      // echo 'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"';
              $result=mysqli_query($conn,'SELECT * FROM `login` WHERE `username` LIKE "'.$email.'"');
$customer_information=mysqli_fetch_assoc($result);
$to_email_address=$customer_information['email'];
// echo "<pre>";print_r($customer_information['email']);


                                  }else{

                                    if($login_gagan_info[0]['channel_name']){
                                       $email= $login_gagan_info[0]['channel_name'];
                                      }else{
                                     $email= $login_gagan_info[0]['user_name']." ".$login_gagan_info[0]['last_name'];
                                      }
                                      $to_email_address= $login_gagan_info[0]['email_id'];
                                  }
                                 
                                   $subject = 'Your video has been rejected';
                $emailer = 'emailer/reject.html';
                $mail_content = file_get_contents($emailer);
                 $img_url='https://www.entube.in/uploads/product/'.$add_video[0]['picture'];
                // echo '<pre>'; print_r($mail_content); exit;
                 $mail_content = str_replace('@__imgurl__@', $img_url, $mail_content);
                 $mail_content = str_replace('@_users_names_@', $email, $mail_content);
                 $mail_content = str_replace('@_video_@', $add_video[0]['ID'], $mail_content);
                 $mail_content = str_replace('@_reason_@', $_POST['reason'], $mail_content);
                 // $mail_content = str_replace('@_contact_number_@', $mobile_info[0]['contact_number'], $mail_content);
                 $mail_content = str_replace('@_title_@', $add_video[0]['Video_Name'], $mail_content);

                 $this->load->library('email');
                

                            $config = Array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.oxiinc.in',
    'smtp_port' => 587,
    'smtp_user' => 'noreply@entube.in',
    'smtp_pass' => '@@entube',
     'mailtype' => 'html',
    'charset' => 'iso-8859-1'
);

                    
$this->email->initialize($config);
$this->email->from('noreply@entube.in', 'Entube');
$this->email->to($to_email_address);
// // $this->email->cc('another@another-example.com');
// // $this->email->bcc('them@their-example.com');

$this->email->subject($subject); 
$this->email->message($mail_content);
// $this->email->attach($mail_content);
$this->email->send();
date_default_timezone_set('Asia/Kolkata');
      $_POST['approved_time'] =date('d-m-Y H:i');
    $this->Model->updateData('add_video',$_POST,array('ID'=>$_POST['ID']));
    redirect('Slider/Approved_list');
    
}
    // function Url_append_edit_form(){
    //     // echo '<pre>'; print_r($_POST); exit;
    //     $ID = $this->input->get_post('ID');
    //     $Product_Name = $this->input->get_post('Product_Name');
    //     $Product_offer = $this->input->get_post('Product_offer');
    //     $Product_short_name = $this->input->get_post('Product_short_name');

        

            
    //         if($_FILES['Product_Picture']['name'] != ''){

    //             $uploaddir = './uploads/append/';
    //             $filename = rand().basename($_FILES['Product_Picture']['name']);
    //             $uploadfile = $uploaddir.$filename;
                

    //             if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
    //               echo "File is valid, and was successfully uploaded.\n";
    //               $picture = $filename;
    //             } else {
    //                echo "Upload failed";
    //                $picture = "";
    //             }
    //         }
    //         else{
    //            $picture =  $_POST['Product_Picture'];
    //         }
    //         $update_data = array(
    //             'Product_Name'=>$Product_Name,
    //             'Product_offer'=>$Product_offer,
    //             'Product_short_name'=>$Product_short_name,
                
    //             'Product_Picture' => $picture
    //         );
    //         $this->Model->updateData('url_append_info',$update_data,array('ID'=>$ID));

             
    //         $this->session->set_flashdata('msg','Supplier updated successfully.');
    //         redirect('Slider/Url_Upend_information_list');
    //     }
//     function editprojectimage_pro($ID)  
// {

//   $config['upload_path'] = './uploads/append/';
//   $config['allowed_types'] = 'jpg|jpeg|png|gif';
//   // $config['max_size'] = '2000';


//   $this->load->library('upload', $config);

//   if ( ! $this->upload->do_upload())
//   {
//    //check for errors with the upload
//    $error = array('error' => $this->upload->display_errors());
//    // $this->load->view('templates/header');
//    // $this->load->view('edit-project-image');
//    // $this->load->view('templates/footer');
//   }
//   else
//   {
//    //upload the new image
//    $upload_data = $this->upload->data();
//    $image_name = $upload_data['Product_Picture'];

//    if($_POST){

//    $data = array(
//     'Product_Name' => $this->input->post('Product_Name'),
//                 'Product_offer' => $this->input->post('Product_offer'),
//                 'Product_short_name' => $this->input->post('Product_short_name'),
//     'Product_Picture'=>$image_name
    
//    );

//                         //update
//    $this->Text->update_project($data);
//    }
  
//    redirect(base_url().'slider/Add_Advertisement_banner');

//   }
// }
    // function Url_append_edit_form(){
    //     $ID = $this->input->get_post('ID');

    //     if($this->input->post('userSubmit')){
    //         // echo '<pre>'; print_r($_FILES); exit;
            
    //         //Check whether user upload picture
    //         if(!empty($_FILES['Product_Picture']['name'])){
    //             $config['upload_path'] = 'uploads/Advertisement/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['Product_Picture']['name'];
                
    //             //Load upload library and initialize configuration
    //             $this->load->library('upload',$config);
    //             $this->upload->initialize($config);
                
    //             if($this->upload->do_upload('Product_Picture')){
    //                 $uploadData = $this->upload->data();
    //                 $picture = $uploadData['file_name'];
    //             }else{
    //                 $picture = '';
    //             }
    //         }else{
    //             $picture = '';
    //         }
            
    //         //Prepare array of user data
    //         $userData = array(
    //             'Product_Name' => $this->input->post('Product_Name'),
    //             'Product_offer' => $this->input->post('Product_offer'),
    //             'Product_short_name' => $this->input->post('Product_short_name'),
    //             'Product_Picture' => $picture
    //         );

            
    //         //Pass user data to model
    //         $this->Model->updateData('url_append_info',$userData,array('ID'=>$ID));
    //         // $insertUserData = $this->Advertisement_add->insert($userData);
    //         $this->session->set_flashdata('msg','successfully your Banner image uploaded');
    //         redirect('slider/Add_Advertisement_banner');
            
            
    //     }
    //     //Form for adding user data
    //     // $this->load->view('views/camera_wrap');
        
    // }
    // function update_supplier_form(){
    //     $ID = $this->input->get_post('ID');
    //     $banner_name = $this->input->get_post('banner_name');
    //     $category_id = $this->input->get_post('category_id');
    //     $sub_category_id = $this->input->get_post('sub_category_id');
 
    //         if(!empty($_FILES['banner_Picture']['name']))
    //         {

    //             $config['upload_path'] = 'uploads/banner/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['banner_Picture']['name'];
    //              $this->load->library('upload',$config);
    //              $this->upload->initialize($config);

    //             if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $config)) {
    //               echo "File is valid, and was successfully uploaded.\n";
    //               $picture = $file_name;
    //             } else {
    //                echo "Upload failed";
    //                $picture = "";
    //             }
    //         }
    //         else{
    //            $picture =  $_POST['picture'];
    //         }
            
          
    //         $update_data = array(
    //             'banner_name'=>$banner_name,
    //             'category_id'=>$category_id,
    //             'sub_category_id'=>$sub_category_id,
    //             'banner_Picture' => $picture
    //         );
    //         // print_array($update_data);
    //         $this->model->updateData('banner',$update_data,array('ID'=>$ID)); 
    //         $this->session->set_flashdata('msg','banner updated successfully.');
    //         redirect('slider/list_banner');
        
    //   }
    //   function add(){
    //     if($this->input->post('userSubmit')){
    //         // echo '<pre>'; print_r($_FILES); exit;
            
    //         //Check whether user upload picture
    //         if(!empty($_FILES['Product_Picture']['name'])){
    //             $config['upload_path'] = 'uploads/product/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['Product_Picture']['name'];
                
    //             //Load upload library and initialize configuration
    //             $this->load->library('upload',$config);
    //             $this->upload->initialize($config);
                
    //             if($this->upload->do_upload('Product_Picture')){
    //                 $uploadData = $this->upload->data();
    //                 $picture = $uploadData['file_name'];
    //             }else{
    //                 $picture = '';
    //             }
    //         }else{
    //             $picture = '';
    //         }
            
    //         //Prepare array of user data
    //         $userData = array(
    //             'Product_Name' => $this->input->post('Product_Name'),
    //             'category_id' => $this->input->post('category_id'),
    //             'sub_category_id' => $this->input->post('sub_category_id'),
    //             'sub_category_name' => $this->input->post('sub_category_name'),
    //             'Short_Description' => $this->input->post('Short_Description'),
    //             'Original_Prices' => $this->input->post('Original_Prices'),
    //             'Prices' => $this->input->post('Prices'),
    //             'Product_Picture' => $picture
    //         );

            
    //         //Pass user data to model
    //         $insertUserData = $this->wellness_add->insert($userData);
    //         $this->session->set_flashdata('msg','successfully your Product image uploaded');
    //         redirect('Product/add_product');
            
            
    //     }
    //     //Form for adding user data
    //     // $this->load->view('views/camera_wrap');
        
    // }

public function user_tracking_information()
{
 $query1 = $this->db->query('select * from users_tracking order by id  DESC');

// $data['Out_For_Delivery']= $query->result_array();

$this->load->library('pagination');
         $config=[
        'base_url' => base_url("Slider/user_tracking_information"),
        'per_page' =>10,
        'total_rows' => $query1->num_rows()
 ];
 $config['full_tag_open'] = "<ul class='pagination'>";
$config['full_tag_close'] ="</ul>";
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
$config['next_tag_open'] = "<li>";
$config['next_tagl_close'] = "</li>";
$config['prev_tag_open'] = "<li>";
$config['prev_tagl_close'] = "</li>";
$config['first_tag_open'] = "<li>";
$config['first_tagl_close'] = "</li>";
$config['last_tag_open'] = "<li>";
$config['last_tagl_close'] = "</li>";
//  $config["num_links"] = 10;
 if($this->uri->segment(3)){
   $limit=$this->uri->segment(3);  
   $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
 $query = $this->db->query("select * from users_tracking order by id  DESC limit $limit,10");   
 }else{
     $limit1=0;
     $limit=10;  
     
$query = $this->db->query("select * from users_tracking order by id  DESC limit $limit1,10");
 }
$data['user_tracking_info']= $query->result_array();
  $this->pagination->initialize($config);
 $data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r($data['Out_For_Delivery']);exit();

  $this->load->view('containt',$data);
}
public function user_tracking_information_pagination()
{ 
    if($_POST['username']){
     $sql="select * from users_tracking where username='".$_POST['username']."' and date_1 between '" .$_POST['start']. " 00:00:00' and  '" . $_POST['end'] . " 00:00:00'  order by id  desc";
     $data['username']=$_POST['username'];
     $data['start']=$_POST['start'];
     $data['end']=$_POST['end'];
    }else{
  $sql="select * from users_tracking where   date_1 between '" .$_POST['start']. " 00:00:00' and  '" . $_POST['end'] . " 00:00:00'  order by id  desc";
  $data['start']=$_POST['start'];
  $data['end']=$_POST['end'];
    }
    $query1 = $this->db->query($sql);
    $this->load->library('pagination');
         $config=[
        'base_url' => base_url("Slider/user_tracking_information_pagination_call/".$_POST['username']."/".$_POST['start']."/".$_POST['end']),
        'per_page' =>10,
        'total_rows' => $query1->num_rows(),

        'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
        'full_tag_close'=>'</ul>',

        'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
        'cur_tag_close'=>'</a></li>',

        'num_tag_open'=>'<li>',
        'num_tag_close'=>'</li>',

        'first_link'=>'First',
        'first_tag_open'=>'<li>',
        'first_tag_close'=>'</li>',

        'last_link'=>'Last',
        'last_tag_open'=>'<li>',
        'last_tag_close'=>'</li>',

        'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
        'prev_tag_open'=>'<li>',
        'prev_tag_close'=>'</li>',

        'next_link'=>'<span aria-hidden="true">&raquo;</span>',
        'next_tag_open'=>'<li>',
        'next_tag_close'=>'</li>'
 ];
//  $config["num_links"] = 10;
 if($this->uri->segment(6)){
   $limit=$this->uri->segment(6);  
   $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
   $run_data=$sql." limit $limit,10";
 
 }else{
     $limit1=0;
     $limit=10;  
     
$run_data= $sql." limit $limit1,10";
 }
 // echo $run_data;
 $query_data = $this->db->query($run_data);   
$data['user_tracking_info']= $query_data->result_array();
  $this->pagination->initialize($config);
 $data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r( $query_data->result_array());exit();
  $this->load->view('containt',$data);
}

public function user_tracking_information_pagination_call()
{ 
    if($this->uri->segment(3)){
     $sql="select * from users_tracking where username='".$this->uri->segment(3)."' and date_1 between '" .$this->uri->segment(4). " 00:00:00' and  '" . $this->uri->segment(5) . " 00:00:00'  order by id  desc";

     $data['username']=$_POST['username'];
     $data['start']=$_POST['start'];
     $data['end']=$_POST['end'];
    }else{
  $sql="select * from users_tracking where   date_1 between '" .$this->uri->segment(4). " 00:00:00' and  '" . $this->uri->segment(5) . " 00:00:00'  order by id  desc";
     $data['start']=$_POST['start'];
     $data['end']=$_POST['end'];
    }
    $query1 = $this->db->query($sql);
    $this->load->library('pagination');
         $config=[
        'base_url' => base_url("Slider/user_tracking_information_pagination_call/".$this->uri->segment(3)."/".$this->uri->segment(4)."/".$this->uri->segment(5)),
        'per_page' =>10,
        'total_rows' => $query1->num_rows(),

        'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
        'full_tag_close'=>'</ul>',

        'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
        'cur_tag_close'=>'</a></li>',

        'num_tag_open'=>'<li>',
        'num_tag_close'=>'</li>',

        'first_link'=>'First',
        'first_tag_open'=>'<li>',
        'first_tag_close'=>'</li>',

        'last_link'=>'Last',
        'last_tag_open'=>'<li>',
        'last_tag_close'=>'</li>',

        'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
        'prev_tag_open'=>'<li>',
        'prev_tag_close'=>'</li>',

        'next_link'=>'<span aria-hidden="true">&raquo;</span>',
        'next_tag_open'=>'<li>',
        'next_tag_close'=>'</li>'
 ];
//  $config["num_links"] = 10;
 if($this->uri->segment(6)){
   $limit=$this->uri->segment(6);  
   $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
   $run_data=$sql." limit $limit,10";
 
 }else{
     $limit1=0;
     $limit=10;  
     
$run_data= $sql." limit $limit1,10";
 }
 // echo $run_data;
 $query_data = $this->db->query($run_data);   
$data['user_tracking_info']= $query_data->result_array();
  $this->pagination->initialize($config);
 $data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r($sql);exit();
  $this->load->view('containt',$data);
}
function budget_and_audience($value=''){
    $add_video = $this->Model->getDataOrderBy('budget_and_audience',array('status!='=>'3'),'created_date','DESC');
        $data['budget_and_audience'] = $add_video;
     $data['main_containt']='budget_and_audience';
 // echo"<pre>";print_r($sql);exit();
  $this->load->view('containt',$data);
}
function budget_and_audience_add($value=''){
    // echo "<pre>";print_r($_POST);exit();
    if(!empty($_POST['id'])){
          $this->Model->updateData('budget_and_audience',$_POST,array('id'=>$_POST['id']));
          redirect('slider/budget_and_audience');
    }else{
         $this->Model->insertData('budget_and_audience',$_POST);
         redirect('slider/budget_and_audience');
    }
  
}
function advertisement_list($value=''){
     $givenDate=date("Y-m-d");
     $from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
     $to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));
     $sql ="SELECT  shad.*,svv.*
	   FROM allow_data_my_digital AS shad 
	   LEFT JOIN sponsored_video_view AS svv ON shad.ID = svv.a_id
	   WHERE shad.allow_year_month_data >='".$to_date."'
	   AND shad.allow_year_month_data <='".$from_date."' order by shad.ID DESC ";
    $data['advertisement_list'] = $this->Model->getSqlData($sql);
    $data['main_containt']='advertisement_list_view';
    $this->load->view('containt',$data);
}
function advertisement_list_fetch($value=''){
	 $givenDate=date("Y-m-d");
     $from_date = date('Y-m-d', strtotime('next sunday', strtotime($givenDate)));
     $to_date = date('Y-m-d', strtotime('previous sunday', strtotime($givenDate)));
     $sql ="SELECT  shad.*,svv.*
	   FROM allow_data_my_digital AS shad 
	   LEFT JOIN sponsored_video_view AS svv ON shad.ID = svv.a_id
	   WHERE shad.allow_year_month_data >='".$to_date."'
	   AND shad.allow_year_month_data <='".$from_date."' AND shad.ID ='".$_POST['id']."'  ";
	   $strSql = "SELECT * FROM countries";
  $data['countries'] =$this->Model->getSqlData($strSql);
  $budget_and_audience = "SELECT * FROM budget_and_audience where status!=3";
  $data['budget_and_audience'] =$this->Model->getSqlData($budget_and_audience);
    $data['advertisement_list'] = $this->Model->getSqlData($sql);
     $this->load->view('advertisement_list_fetch',$data);
}
function sponsored_video_submit($value=''){
	$data=$_POST;
	$this->Model->updateData('allow_data_my_digital',$data,array('ID'=>$_POST['id']));
    redirect('Slider/advertisement_list');
}
function sponsored_video_delete($value=''){
	$this->Model->deleteData('allow_data_my_digital',array('ID'=>$this->uri->segment(3)));
	redirect('Slider/advertisement_list');
}
}