$(document).ready(function($){

	
//-- Owlcarousel
	var owl = $('.home-section-01 .owl-carousel');
	  owl.owlCarousel({
		margin: 25,
		nav: true,
		loop: true,
		//autoplay:true,
		//autoplayTimeout:3000,
		//autoplayHoverPause:true,
		responsive: {
		  0: {
			margin: 15,
			items: 2
		  },
		  640: {
			items: 3
		  },
		  1280: {
			items: 4
		  },
		  1600: {
			items: 5
		  }
		}
	  })

});




