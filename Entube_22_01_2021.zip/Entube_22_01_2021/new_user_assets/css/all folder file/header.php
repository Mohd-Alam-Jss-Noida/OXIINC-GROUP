	<header>
	    <div class="row">
		  <div class="container-fluid">
		    <nav class="navbar navbar-default">
			  <div class="container-fluid">
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
	
					<i class="fa fa-ellipsis-v fa-w-6"></i>
				  </button>
				  <div class="menu-icon">
				    <img src="images/menu-icon.png" alt=""/>
				    <img src="images/close-icon.png" alt=""/>
				  </div>
				  <a href="#"><img src="images/entube-logo.png" class="logo-col" alt="Entube"/></a>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/admin-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#" data-toggle="modal" data-target="#GuestloginModal"><i class="fas fa-fw fa-user-circle"></i> Guest Login</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#" data-toggle="modal" data-target="#EPanelistloginModal"><i class="fas fa-fw fa-user-circle"></i> E-Panelist Login</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/bell-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
						<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-fw fa-star "></i> Somthing else here</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/message-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
						<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-fw fa-star "></i> Somthing else here</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/grid-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#"><i class="fab fa-youtube-square"></i> Enews Media TV</a></li>
						<li><a href="#"><i class="fab fa-youtube"></i> EnTube Serial Trailer</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-video"></i> EnTube For Movie</a></li>
						<li><a href="#"><i class="fab fa-youtube"></i> EnTube For Artist</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-compact-disc"></i> EnTube Music</a></li>
						<li><a href="#"><i class="fab fa-youtube"></i> EnTube Academy</a></li>
						<li><a href="#"><i class="fab fa-youtube"></i> EnTube Gaming</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/video-upload-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#"><i class="fas fa-upload"></i> Upload Your Video</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fab fa-youtube"></i> Go Live Now</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/search-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li>
						  <form class="search-section">
						    <input type="text" class="search-textbox" id="" placeholder="Search for...">
						    <button type="submit" class="search-btn">Submit</button>
						  </form>
						</li>
					  </ul>
					</li>
					<!--<li>
					  <div class="search">
					    <input type="text" class="form-control input-sm" maxlength="64" placeholder="Search" />
					    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search" aria-hidden="true"></i></button>
					  </div>
					</li>-->
				  </ul>
				</div>
			  </div>
			</nav>
			<div class="slide-nav">
			  <ul class="list-unstyled">
			    <li class="active-li"><a href="#"><img src="images/icons/home-icon.png" alt="" class="leftmenu-icon"/><span>Home</span></a></li>
				<li><a href="#"><img src="images/icons/Trending-icon.png" alt="" class="leftmenu-icon"/><span>Trending</span></a></li>
				<li><a href="#"><img src="images/icons/Library-icon.png" alt="" class="leftmenu-icon"/><span>Library</span></a></li>
				<li><a href="#"><img src="images/icons/History-icon.png" alt="" class="leftmenu-icon"/><span>History</span></a></li>
				<li><a href="#"><img src="images/icons/Watch-icon.png" alt="" class="leftmenu-icon"/><span>Watch Later</span></a></li>
				<li><a href="#"><img src="images/icons/Liked-icon.png" alt="" class="leftmenu-icon"/><span>Liked Videos</span></a></li>

				<li class="list-title">Paid Subscription</li>
				<li><a href="#"><img src="images/icons/entube-premimum-icon.png" alt="" class="leftmenu-icon"/><span>EnTube Premimum</span></a></li>
				<li><a href="#"><img src="images/icons/entube-movies-icon.png" alt="" class="leftmenu-icon"/><span>EnTube Movies</span></a></li>
				<li><a href="#"><img src="images/icons/entube-graming.png" alt="" class="leftmenu-icon"/><span>EnTube Graming</span></a></li>
				<li><a href="#"><img src="images/icons/entube-graming.png" alt="" class="leftmenu-icon"/><span>EnTube Live</span></a></li>
				
				<li class="list-title">Industry</li>
				<li><a href="#"><img src="images/icons/oxiinc-digital-revolution-icon.png" alt="" class="leftmenu-icon"/><span>Oxiinc Digital Revolution</span></a></li>
				<li><a href="#"><img src="images/icons/political-icon.png" alt="" class="leftmenu-icon"/><span>Political</span></a></li>
				<li><a href="#"><img src="images/icons/advertisement-icon.png" alt="" class="leftmenu-icon"/><span>Advertisement</span></a></li>
				<li><a href="#"><img src="images/icons/gaming-icon.png" alt="" class="leftmenu-icon"/><span>Gaming</span></a></li>
				<li><a href="#"><img src="images/icons/knowledge-icon.png" alt="" class="leftmenu-icon"/><span>Knowledge</span></a></li>
				<li><a href="#"><img src="images/icons/health_food_snacks_icon.png" alt="" class="leftmenu-icon"/><span>Health_Food_Snacks</span></a></li>
				<li><a href="#"><img src="images/icons/clothing-icon.png" alt="" class="leftmenu-icon"/><span>Clothing</span></a></li>
				<li><a href="#"><img src="images/icons/laptop-icon.png" alt="" class="leftmenu-icon"/><span>Laptop</span></a></li>
				<li><a href="#"><img src="images/icons/automation-robotics-icon.png" alt="" class="leftmenu-icon"/><span>Automation Robotics</span></a></li>
				<li><a href="#"><img src="images/icons/entertainment-icon.png" alt="" class="leftmenu-icon"/><span>Entertainment</span></a></li>
				
				<li class="list-title">More From Entube</li>
				<li><a href="#"><img src="images/icons/gallary-icon.png" alt="" class="leftmenu-icon"/><span>EnTube Movies</span></a></li>
				<li><a href="#"><img src="images/icons/entube-music.png" alt="" class="leftmenu-icon"/><span>EnTube Music</span></a></li>
				<li><a href="#"><img src="images/icons/entertainment-icon.png" alt="" class="leftmenu-icon"/><span>EnTube Serials</span></a></li>
				
				<li><a href="#"><img src="images/icons/gallary-icon.png" alt="" class="leftmenu-icon"/><span>Gallary</span></a></li>
				<li><a href="#"><img src="images/icons/setting-icon.png" alt="" class="leftmenu-icon"/><span>Setting</span></a></li>
				<li><a href="#"><img src="images/icons/History-icon.png" alt="" class="leftmenu-icon"/><span>Report History</span></a></li>
				<li><a href="#"><img src="images/icons/help-icon.png" alt="" class="leftmenu-icon"/><span>Help</span></a></li>
				<li><a href="#"><img src="images/icons/feedback-icon.png" alt="" class="leftmenu-icon"/><span>Send Feedback</span></a></li>
			  </ul>
			</div>
		  </div>
		</div>
	</header>
	
	
<!-- Guest login Modal -->
<div class="modal fade login-container" id="GuestloginModal" tabindex="-1" role="dialog" aria-labelledby="GuestLoginModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content login-form-block">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<img src="images/entube-logo.png" alt="" class="img-responsive logo-col"/>
		<form>
		  <input type="email" class="input-textbox" id="" placeholder="Email">
		  <input type="password" class="input-textbox" id="" placeholder="Password">
		  <button type="submit" class="input-submitbtn">Sign in</button>
		  <button type="submit" class="input-submitbtn">Reset</button>
	    </form>
		<div class="forgot-txt">
		  <a href="#">Forgot Password?</a>
		  <a href="#">New User? Register</a>
		</div>
      </div>
    </div>
  </div>
</div>

<!-- E-Panelist login Modal -->
<div class="modal fade login-container" id="EPanelistloginModal" tabindex="-1" role="dialog" aria-labelledby="GuestLoginModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content login-form-block">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<img src="images/entube-logo.png" alt="" class="img-responsive logo-col"/>
		<form>
		  <input type="email" class="input-textbox" id="" placeholder="Email">
		  <input type="password" class="input-textbox" id="" placeholder="Password">
		  <button type="submit" class="input-submitbtn">Sign in</button>
		  <button type="submit" class="input-submitbtn">Reset</button>
	    </form>
		<div class="forgot-txt">
		  <a href="#">Forgot Password?</a>
		  <a href="#">New User? Register</a>
		</div>
      </div>
    </div>
  </div>
</div>

