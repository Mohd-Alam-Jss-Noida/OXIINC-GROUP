<!-- Css -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
<!-- Fontawesome -->
<link href="css/fontawesome/all.css" rel="stylesheet">
<link href="css/fontawesome/fontawesome.css" rel="stylesheet">
<link href="css/fontawesome/brands.css" rel="stylesheet">
<link href="css/fontawesome/solid.css" rel="stylesheet">
<link href="css/animate.css" rel="stylesheet">


<link href="css/common-style.css" rel="stylesheet">
<link href="css/custom-inner-style.css" rel="stylesheet">
<link href="css/custom-inner-responsive.css" rel="stylesheet">


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->