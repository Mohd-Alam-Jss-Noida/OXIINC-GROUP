$(document).ready(function($){
	
	
//-- Main Wrapper Height	
	var contentheight = $(window).height() - $("header").height() - $("footer").height() + "px";
	$(".main-wrapper").css("min-height", contentheight);
	
	
//-- Toggle the side navigation
	$('.menu-icon').on('click', function(){
		$(this).toggleClass('active-leftnav');
        $('.slide-nav').toggleClass('left-slide');
    });
	

	
});




