
<!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- Fontawesome -->
  <script defer src="js/fontawesome/all.js"></script>
  <script defer src="js/fontawesome/brands.js"></script>
  <script defer src="js/fontawesome/solid.js"></script>
  <script defer src="js/fontawesome/fontawesome.js"></script>
  
  <script defer src="js/common-script.js"></script>
  <script defer src="js/custom-inner-script.js"></script>
