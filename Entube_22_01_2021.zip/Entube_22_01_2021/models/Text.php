<?php
class Text extends CI_Model {
    
    function __construct() {
        parent::__construct();
    }
public function get_categories(){
    $query = $this->db->get('category');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->category_id] = $category;
        $return[$category->category_id]->subs = $this->get_sub_categories($category->category_id); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;
}
    public function get_sub_categories($category_id)
    {
    $this->db->where('category_id', $category_id);
    $query = $this->db->get('subcategory');
    return $query->result();
    }
public function Product_id($id){
     // $this->db->select('Product_id');
        $this->db->where('Customer_id', $id);

        $query = $this->db->get('wishlist');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->Product_id_sub($category->Product_id); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
     public function Product_id_sub($category_id)
    {
    $this->db->where('ID', $category_id);
    $query = $this->db->get('wellness');
    return $query->result();
    }
    public function Multiple_image($sub_category_id,$limit,$offset){
         $this->db->where('status', '1');
         $this->db->where('stock_status >=', '1');
        $this->db->where('sub_category_id', $sub_category_id);
        $this->db->limit($limit,$offset);
        $this->db->order_by("ID", "desc");
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
      public function num_rows($sub_category_id)
  {
// $id=$this->session->userdata('id');
   $q=$this->db->select()
            ->from('wellness')
            ->where(['sub_category_id'=>$sub_category_id])
            ->get();
           return $q->num_rows();
  }
 public function PRO_num_rows($product_category_id)
  {
// $id=$this->session->userdata('id');
   $q=$this->db->select()
            ->from('wellness')
            ->where(['product_category_id'=>$product_category_id])
            ->get();
           return $q->num_rows();
  }
    // public function Multiple_image($sub_category_id,$limit,$start){
    // public function Multiple_image($sub_category_id){
    //      $this->db->where('status', '1');
    //      $this->db->where('stock_status >=', '1');
    //     $this->db->where('sub_category_id', $sub_category_id);
    //     // $this->db->limit($limit,$start);
    //     $this->db->order_by("ID", "desc");
  
    //     $query = $this->db->get('wellness');
    // $return = array();

    // foreach ($query->result() as $category)
    // {
    //     $return[$category->ID] = $category;
    //     $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    // }
    // // echo '<pre>'; print_r($return); exit;
    // return $return;

    // }
        public function Multiple_out($sub_category_id,$limit,$offset){
         $this->db->where('status', '1');
         $this->db->where('stock_status <=', '0');
        $this->db->where('sub_category_id', $sub_category_id);
       $this->db->limit($limit,$offset);
        $this->db->order_by("ID", "desc");
  
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
    public function Rangeslider($sub_category_id,$price_max,$price_min){
        $this->db->where('sub_category_id', $sub_category_id);
        $this->db->where('Prices >=', $price_min);
        $this->db->where('Prices <=', $price_max);
        // $this->db->where("((Prices >='".$price_min."' AND Prices <='".$price_max."') OR (Prices >='".$price_min1."' AND Prices <='".$price_max1."'))", NULL, FALSE);
      // echo   $sql="select * from wellness where sub_category_id='".$sub_category_id."' Prices BETWEEN '".$price_min."' AND '".$price_max."'" ;
        // $this->db->limit($limit,$start);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
     public function Second_Rangeslider($sub_category_id,$price_max,$price_min,$verified_status){
        $this->db->where('sub_category_id', $sub_category_id);
        $this->db->where('Prices >=', $price_min);
        $this->db->where('Prices <=', $price_max);
        $this->db->where('verified_status', $verified_status);
        // $this->db->where("((Prices >='".$price_min."' AND Prices <='".$price_max."') OR (Prices >='".$price_min1."' AND Prices <='".$price_max1."'))", NULL, FALSE);
   // echo    $sql ="select * from wellness where sub_category_id='".$sub_category_id."' Prices BETWEEN '".$price_min."' AND '".$price_max."' AND verified_status='".$verified_status."' "; 
      // echo   $sql ="SELECT * FROM `wellness` Where sub_category_id='".$sub_category_id."' OR Prices BETWEEN '".$price_min."' AND '".$price_max."' OR verified_status='".$verified_status."'";
        // $this->db->limit($limit,$start);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
      public function Pro_Second_Rangeslider($product_category_id,$price_max,$price_min,$verified_status){
        $this->db->where('product_category_id', $product_category_id);
        $this->db->where('Prices >=', $price_min);
        $this->db->where('Prices <=', $price_max);
         $this->db->where('verified_status', $verified_status);
        // $this->db->limit($limit,$start);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
    public function Pro_three_Rangeslider($product_category_id,$price_max,$price_min){
        $this->db->where('product_category_id', $product_category_id);
        $this->db->where('Prices >=', $price_min);
        $this->db->where('Prices <=', $price_max);
       
        // $this->db->limit($limit,$start);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
        public function three_Rangeslider($sub_category_id,$price_max,$price_min){
        $this->db->where('sub_category_id', $sub_category_id);
        $this->db->where('Prices >=', $price_min);
        $this->db->where('Prices <=', $price_max);
        // $this->db->where('verified_status', $verified_status);
        // $this->db->where("((Prices >='".$price_min."' AND Prices <='".$price_max."') OR (Prices >='".$price_min1."' AND Prices <='".$price_max1."'))", NULL, FALSE);
   // echo    $sql ="select * from wellness where sub_category_id='".$sub_category_id."' Prices BETWEEN '".$price_min."' AND '".$price_max."' AND verified_status='".$verified_status."' "; 
      // echo   $sql ="SELECT * FROM `wellness` Where sub_category_id='".$sub_category_id."' OR Prices BETWEEN '".$price_min."' AND '".$price_max."' OR verified_status='".$verified_status."'";
        // $this->db->limit($limit,$start);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
   public function Pro_Rangeslider($product_category_id,$price_max,$price_min){
        $this->db->where('product_category_id', $product_category_id);
        $this->db->where('Prices >=', $price_min);
        $this->db->where('Prices <=', $price_max);
        // $this->db->limit($limit,$start);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
    public function get_sub_Multiple($category_id)
    {
    $this->db->where('Product_id', $category_id);
    $query = $this->db->get('multiple_picture');
    return $query->result();
    }
    public function Pro_Multiple_image($product_category_id,$limit,$offset){
         $this->db->where('status', '1');
          $this->db->where('stock_status >=', '1');
           $this->db->limit($limit,$offset);
        $this->db->where('product_category_id', $product_category_id);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_Pro_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }
    public function Pro_Multiple_out($product_category_id,$limit,$offset){
         $this->db->where('status', '1');
          $this->db->where('stock_status <=', '0');
           $this->db->limit($limit,$offset);
        $this->db->where('product_category_id', $product_category_id);
        $query = $this->db->get('wellness');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->ID] = $category;
        $return[$category->ID]->subs = $this->get_Pro_sub_Multiple($category->ID); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;

    }

    public function get_Pro_sub_Multiple($category_id)
    {
        
    $this->db->where('Product_id', $category_id);
    $query = $this->db->get('multiple_picture');
    return $query->result();
    }
    public function get_upend(){
    $query = $this->db->get('upend_wrapper');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->upend_id] = $category;
        $return[$category->upend_id]->subs = $this->get_sub_upend($category->upend_id); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;
}
public function get_sub_upend($category_id)
    {
    $this->db->where('upend_id', $category_id);
    $query = $this->db->get('wrapper_wellness');
    return $query->result();
    }
    public function get_url_upend(){
    $query = $this->db->get('url_append_heading');
    $return = array();

    foreach ($query->result() as $category)
    {
        $return[$category->url_id] = $category;
        $return[$category->url_id]->subs = $this->get_sub_url_upend($category->url_id); // Get the categories sub categories
    }
    // echo '<pre>'; print_r($return); exit;
    return $return;
    }
    public function get_sub_url_upend($category_id)
    {
    $this->db->where('url_id', $category_id);
    $query = $this->db->get('url_append_info');
    return $query->result();
    }
    function update_project($ID, $postData)
    {
  $this->db->where('ID', $ID);
  $this->db->update('url_append_info', $postData);

    }
    public function add_article(){

    }
}