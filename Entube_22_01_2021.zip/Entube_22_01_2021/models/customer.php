<?php
class customer extends CI_Model {
    
    function __construct() {
        parent::__construct();
    }
    public function fetchcustomerdata($email_id = null)
    {
    if($email_id){
    	$sql="SELECT * FROM custumer_login WHERE id = ?";
    	$query = $this->query($sql,array($email_id));
    	$result = $query;
    	return $result;
    }
    }
}