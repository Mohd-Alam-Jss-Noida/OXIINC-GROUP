<?php
class Main_model extends CI_Model {
    
    function __construct() {
        parent::__construct();
    }
public function get_sub_category(postData){
    $response = array();
 
    // Select record
    $this->db->select('sub_category_id,sub_category_name');
    $this->db->where('category_id', $postData['city']);
    $q = $this->db->get('subcategory');
    $response = $q->result_array();

    return $response;
}

}