<?php
class Entube_model extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	public function get_banner_data($limit_val = ''){
		$this->db->select('category_id, sub_category_id, banner_Picture, banner_name');
        $this->db->order_by("ID", "DESC");
        $this->db->where('status', 1);
        $this->db->limit($limit_val);
        $query = $this->db->get('banner');
        if ($query->num_rows() > 0){
            return $query->result_array();
        }else{
            return FALSE;
        }
    }

    //RECOMMENDED_VIDEOS AND RECENTLY_UPLOADED_VIDEOS AND MOST_VIEWED VIDEOS
    public function recommended_recently_uploaded_videos($recommended, $priority, $most_viewed, $limit_val){
        $this->db->select('ad.ID, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, cc.channel_name, cc.channel_logo, wu.view');
        $this->db->from('add_video ad'); 
        $this->db->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT');
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        if($recommended) {
            $this->db->where('ad.recommended', $recommended);
            $this->db->order_by('ad.ID', 'DESC');
        }
        if($priority) {
            $this->db->where('ad.priority', $priority);
            $this->db->order_by('ad.ID', 'DESC');
        }
        if($most_viewed) {
            $this->db->order_by('wu.view', 'DESC');
        }
        $this->db->limit($limit_val);
        $query = $this->db->get();
        return $query->result_array();
    }

    //YOU MAY LIKE VIDEOS
    public function get_ip_recommended_videos($column_name, $user_like, $limit_val){
        $this->db->select('ad.ID, ad.user_id, ad.Video_Title, ad.picture, ad.datatime, cc.channel_name, cc.channel_logo, vi.ip, wu.view');
        $this->db->from('add_video ad'); 
        $this->db->join('views vi', 'ad.ID = vi.post_id', 'INNER');
        $this->db->join('watched_user wu', 'wu.post_id = vi.post_id', 'LEFT');
        $this->db->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT');
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        $this->db->where('vi.'.$column_name, $user_like);
        $this->db->group_by('ad.ID');
        $this->db->order_by('vi.post_id', 'DESC');
        $this->db->limit($limit_val);
        $query = $this->db->get();
        return $query->result_array();
    }

    //START CODE WATCH CONTROLLER GET DATA
    public function watch_video($video_id){
		$query = $this->db->select('ad.ID, ad.category_id, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, ad.video, ad.Short_Description, ad.video_hashtag, cc.channel_name, cc.channel_logo, wu.view')
        	->from('add_video ad') 
        	->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT')
        	->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT')
        	->where('ad.ID', $video_id)
        	->where('ad.status', 1)
        	->where('ad.is_deleted', 0)
        	->get();
        return $query->result_array();
	}

	public function watch_next_video($category_id, $video_id){
		$query = $this->db->select('ad.ID, ad.category_id, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, ad.video, ad.Short_Description, cc.channel_name, cc.channel_logo, wu.view')
        	->from('add_video ad') 
        	->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT')
        	->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT')
        	->where('ad.category_id', $category_id)
            ->where('ad.ID !=', $video_id)
        	->where('ad.status', 1)
        	->where('ad.is_deleted', 0)
        	->order_by('ad.ID', 'DESC')
        	//->limit(1)
        	->get();
        return $query->result_array();
	}

	public function watch_more_videos_on_page_load($next_video_id, $limit){
		$this->db->select('ad.ID, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, cc.channel_name, cc.channel_logo, wu.view');
        $this->db->from('add_video ad'); 
        $this->db->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT');
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->where('ad.ID !=', $next_video_id);
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        $this->db->order_by('ad.ID', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result_array();
	}

    public function get_channel_data($user_id){
    	$this->db->select('channel_name, channel_logo, channel_banner');
        $this->db->from('custumer_channel');
        $this->db->where('user_id', $user_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0){
        	$channel_details = $query->result_array();
        	$channel_details = $channel_details[0];
        }else{
            $channel_details = FALSE;
        }
        //echo "<pre>";print_r($channel_details);die();
        return $channel_details;
	}

    public function get_channel_data_guest_user($user_id){
    	$this->db->select('cl.email_id, cc.channel_name, cc.channel_logo');
	        $this->db->from('custumer_login cl');
	        $this->db->join('custumer_channel cc', 'cl.id = cc.user_id', 'LEFT');
	        $this->db->where('cl.id', $user_id);
	        $query = $this->db->get();
        if ($query->num_rows() > 0){
        	$channel_details = $query->result_array();
        	$channel_details = $channel_details[0];
        }else{
            $channel_details = FALSE;
        }
        return $channel_details;
	}

	public function get_videos_orderby_view_desc($limit_val = '', $offset_val = ''){
		$query = $this->db->select('ad.ID, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, wu.post_id, cc.channel_name, cc.channel_logo, wu.view')
        	->from('add_video ad') 
        	->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT')
        	->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT')
        	->where('ad.status', 1)
        	->where('ad.is_deleted', 0)
        	->order_by('wu.view', 'DESC')
        	->limit($limit_val, $offset_val)
        	->get();
        return $query->result_array();
	}

	public function get_videos_orderby_id_desc($limit_val = '', $offset_val = ''){
		$query = $this->db->select('ad.ID, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, wu.post_id, wu.view, cc.channel_name')
        	->from('add_video ad') 
        	->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT')
        	->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT')
        	->where('ad.status', 1)
        	->where('ad.priority', 1)
        	->where('ad.is_deleted', 0)
        	->order_by('ad.ID', 'DESC')
        	->limit($limit_val, $offset_val)
        	->get();
        return $query->result_array();
	}

    //AUTOCOMPLETE SEARCH
    public function autocomplete_search($video_title) {
        $this->db->select('ID, Video_Title');
        $this->db->from('add_video');
        $this->db->like('LOWER(Video_Title)', strtolower($video_title), FALSE);
        $this->db->where('status', 1);
        $this->db->where('is_deleted', 0);
        $this->db->order_by('Video_Title', 'ASC');
        $this->db->limit(10);
        $query = $this->db->get();
        $result = ($query->num_rows() > 0) ? $query->result_array() : FALSE;
        //echo "<pre>";print_r($result);die();
        return $result;
    }

    public function search($video_title, $limit_val = '', $offset_val = ''){
        $title_parts = explode(" ", $video_title);
        $this->db->select('ad.ID, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, wu.post_id, cc.channel_name, cc.channel_logo, wu.view');
        $this->db->from('add_video ad');
        $this->db->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT');
        $this->db->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT');
        $this->db->like('LOWER(Video_Title)', strtolower($video_title), FALSE);
        $this->db->or_like('LOWER(Short_Description)', strtolower($video_title), FALSE);
        if(count($title_parts) > 1) foreach ($title_parts as $key => $value){
            $this->db->or_like('LOWER(Video_Title)', strtolower($value), FALSE);
            $this->db->or_like('LOWER(Short_Description)', strtolower($value), FALSE);
        }
        $this->db->where('ad.status', 1);
        $this->db->where('ad.is_deleted', 0);
        $this->db->order_by('ad.Video_Title', 'ASC');
        $this->db->order_by('wu.view', 'DESC');
        $this->db->limit($limit_val, $offset_val);
        $query = $this->db->get();
        //echo "<pre>";print_r($query);die();
        return ($query->num_rows() > 0) ? $query->result_array() : FALSE;
    }

    public function get_Watch_history($limit_val = '', $offset_val = '', $user_id){
        $query = $this->db->select('ad.ID, ad.user_id, ad.datatime, ad.Video_Title, ad.picture, wu.post_id, cc.channel_name, cc.channel_logo, wu.view')
            ->from('add_video ad')
            ->join('views vw', 'vw.post_id = ad.ID', 'INNER')
            ->join('custumer_channel cc', 'cc.user_id = ad.user_id', 'LEFT')
            ->join('watched_user wu', 'ad.ID = wu.post_id', 'LEFT')
            ->where('vw.user_id', $user_id)
            ->where('ad.status', 1)
            ->where('ad.is_deleted', 0)
            ->order_by('ad.datatime', 'ASC')
            ->limit($limit_val, $offset_val)
            ->get();
        return ($query->num_rows() > 0) ? $query->result_array() : FALSE;
    }
}
?>