	<!-- Start Container -->
	<div class="main-wrapper">
		<section class="video-detail-page">
			<div class="row">
				<div class="container-fluid large-devise-screen">
					<!-- Video Left Section -->
					<div class="left-container">
						<div class="containt-block">
							<section class="trending-section-01">
								<a href="#" class="trending-cat">
								<span class="icon-col"><img src="<?php echo base_url('new_user_assets/images/tmusic-icon.png'); ?>" alt=""></span>
								<span class="title-col">Music</span>
								</a>
								<a href="#" class="trending-cat">
								<span class="icon-col"><img src="<?php echo base_url('new_user_assets/images/tnews-icon.png'); ?>" alt=""></span>
								<span class="title-col">News</span>
								</a>
								<a href="#" class="trending-cat">
								<span class="icon-col"><img src="<?php echo base_url('new_user_assets/images/tmovies-icon.png'); ?>" alt=""></span>
								<span class="title-col">Movies</span>
								</a>
								<a href="#" class="trending-cat">
								<span class="icon-col"><img src="<?php echo base_url('new_user_assets/images/tgaming-icon.png'); ?>" alt=""></span>
								<span class="title-col">Gaming</span>
								</a>
							</section>
							<section class="trending-section-02 home-video-slider">
								<h2 class="headding-01">Most Trending Videos</h2>
								<div class="video-list-inline" style="width: 100%">
									<?php
									if(isset($most_viewed) && !empty($most_viewed)) foreach ($most_viewed as $key => $value) {
										if($value['channel_name']) {
							          		$channel_name = $value['channel_name'];
			                            } elseif ($value['user_id']) {
			                            	$channel_name = $value['user_id'];
			                            } else{
			                            	$channel_name = OXIINC_CHANNEL;
			                            }

			                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

			                            if($value['channel_logo']) {
			                            	$channel_logo = $value['channel_logo'];
			                            } elseif ($channel_name == OXIINC_CHANNEL) {
			                            	$channel_logo = 'oxiinc-digital-icon.png';
			                            } else{
			                            	$channel_logo = 'channel-logo.jpg';
			                            }
										?>
										<div class="item equal-height-col">
											<div class="item-containt-col">
												<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
													<img src="<?php echo $video_image ;?>" class="trending-video-item-img" alt="" />
													<i class="fas fa-play-circle"></i>
													<div class="video-overlay"></div>
												</a>
												<div class="video-containt-col">
													<div class="chanel-img-col">
														<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
															<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
														</a>
													</div>
													<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo $value['Video_Title']; ?></a>
													<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>" class="video-channel" style="color:#fff;"><?php echo $channel_name; ?> <i class="fas fa-check-circle"></i></a>
													<div class="video-views">
														<span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
														<span><i class="far fa-calendar-alt"></i>
															<?php
											                    $FromDate = new DateTime(date("Y-m-d H:i:s"));
											                    $ToDate   = new DateTime($value['datatime']);
											                    $Interval = $FromDate->diff($ToDate);
											                    $Difference["Hours"] = $Interval->h;
											                    $Difference["Weeks"] = floor($Interval->d/7);
											                    $Difference["Days"] = $Interval->d % 7;
											                    $Difference["Months"] = $Interval->m;
											                    $Difference["minute"] = $Interval->i;
											                    $Difference["second"] = $Interval->s;
											                    $Difference["Year"] = $Interval->y;
											                    if($Difference["Year"]){
											                    echo $Difference["Year"]." "."Year";
											                    }else
											                    if($Difference["Months"]){
											                    echo $Difference["Months"]." "."Months";
											                    }else
											                    if($Difference["Weeks"]){
											                    echo $Difference["Weeks"]." "."Weeks";
											                    }else
											                    if($Difference["Days"]){
											                    echo $Difference["Days"]." "."Days";
											                    }else
											                    if($Difference["Hours"]){
											                    echo $Difference["Hours"]." "."Hours";
											                    }else
											                    if($Difference["minute"]){
											                    echo $Difference["minute"]." "."Minute";
											                    }else
											                    if($Difference["second"]){
											                    echo $Difference["second"]." "."Second";
											                    }
											                    echo " "."ago";
											                ?>
														</span>
													</div>
												</div>
												<span class="dropdown video-login-popup video-login-popup2">
													<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu">
														<li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
														<li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
													</ul>
												</span>
											</div>
										</div>
										<?php
									}
									else{ ?>
										<h2 style="text-align: center;">Trending Video not found.</h2>
									<?php
									}
									?>
									<div id="trending_videos_load"></div>
								</div>
							</section>
						</div>
					</div>
					<!-- Video Right Section -->
					<div class="right-container">
						<div class="video-detail-advertise-banner" style="margin-bottom: 36px;">
							<a href="https://www.oxiinc.in" target="_blank"><img src="<?php echo base_url('black/img/banner.png'); ?>" class="img-responsive" alt=""></a>
						</div>
						<h2 class="headding-01" style="font-size: 22px !important; margin-bottom: 18px !important;">Recently Trending Videos</h2>
						<?php
						if(isset($Recently_uploaded) && !empty($Recently_uploaded)) foreach ($Recently_uploaded as $key => $value) {
							if($value['channel_name']) {
				          		$channel_name = $value['channel_name'];
                            } elseif ($value['user_id']) {
                            	$channel_name = $value['user_id'];
                            } else{
                            	$channel_name = OXIINC_CHANNEL;
                            }

                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');
							?>
							<div class="video-card">
								<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-card-img">
									<img src="<?php echo $video_image ;?>" class="trending-mp-video-img" alt=""/>
									<i class="fas fa-play-circle"></i>
									<div class="video-overlay"></div>
								</a>
								<div class="video-card-info">
									<span class="title"><a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>"><?php echo $value['Video_Title']; ?></a></span>
									<span class="channel-title"><a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name; ?> <i class="far fa-check-circle"></i></a></span>
									<span class="views_and_date">
										<i class="far fa-eye"></i> <?php echo ($value['view'] > 0) ? $value['view']." views" : " 0 view"; ?>
										<i class="far fa-calendar-alt" style="margin-left: 30px;"></i>
										<?php
										$FromDate = new DateTime(date("Y-m-d H:i:s"));
										$ToDate   = new DateTime($value['datatime']);
										$Interval = $FromDate->diff($ToDate);
										$Difference["Hours"] = $Interval->h;
										$Difference["Weeks"] = floor($Interval->d/7);
										$Difference["Days"] = $Interval->d % 7;
										$Difference["Months"] = $Interval->m;
										$Difference["minute"] = $Interval->i;
										$Difference["second"] = $Interval->s;
										$Difference["Year"] = $Interval->y;

										if($Difference["Year"]){
											echo $Difference["Year"]." "."Year";
										}else
										if($Difference["Months"]){
											echo $Difference["Months"]." "."Months";
										}else
										if($Difference["Weeks"]){
											echo $Difference["Weeks"]." "."Weeks";
										}else
										if($Difference["Days"]){
											echo $Difference["Days"]." "."Days";
										}else
										if($Difference["Hours"]){
											echo $Difference["Hours"]." "."Hours";
										}else
										if($Difference["minute"]){
											echo $Difference["minute"]." "."Minute";
										}else
										if($Difference["second"]){
											echo $Difference["second"]." "."Second";
										} 
										echo " "."ago";
										?>
									</span>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
										<li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
										<li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
									</ul>
								</span>
							</div>
							<?php
						}
						else{ ?>
							<h4 style="text-align: center;">Recently trending Video not found.</h4>
						<?php
						}
						?>
						<div id="recently_videos_load"></div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<!-- End Container -->

	<!-- TRENDING VIDEOS AND RECENTLY VIDEOS LOAD ON PAGE SCROLL JAVASCRIPT CODE -->
	<script type="text/javascript">
		$(document).ready(function(){
			var data_limit = 20;
			var data_offset = 10;
			$(window).scroll(function () {
				if($(window).scrollTop() == $(document).height() - $(window).height()) {
					$.ajax({
						url: "<?php echo base_url('Entube/trending_videos_on_page_scroll'); ?>",
						type: "POST",
						data: "data_limit=" + data_limit + "&data_offset=" + data_offset,
						dataType:"text",
						success: function(data){
							//alert(data);
							$("#trending_videos_load").html(data)
						}

					})
					$.ajax({
						url: "<?php echo base_url('Entube/recently_videos_on_page_scroll'); ?>",
						type: "POST",
						data: "data_limit=" + data_limit + "&data_offset=" + data_offset,
						dataType:"text",
						success: function(data){
							//alert(data);
							$("#recently_videos_load").html(data)
						}
					})
					data_limit += 20;
				}
			});
		});
	</script>

