<!-- Start Container -->
<link href="https://vjs.zencdn.net/7.3.0/video-js.css" rel="stylesheet">
<link href="<?php echo base_url("new"); ?>/video-js.min.css" rel="stylesheet">
<link href="<?php echo base_url("new"); ?>/videojs-resolution-switcher.css" rel="stylesheet">
<link href="https://vjs.zencdn.net/7.6.5/video-js.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>black/vendor/jquery/jquery.min.js"></script>
<?php
if(isset($watch) && !empty($watch)){
	$value = $watch[0];

	if($value['channel_name']) {
  		$channel_name = $value['channel_name'];
    } elseif ($value['user_id']) {
    	$channel_name = $value['user_id'];
    } else{
    	$channel_name = OXIINC_CHANNEL;
    }

    $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

    if($value['channel_logo']) {
    	$channel_logo = $value['channel_logo'];
    } elseif ($channel_name == OXIINC_CHANNEL) {
    	$channel_logo = 'oxiinc-digital-icon.png';
    } else{
    	$channel_logo = 'channel-logo.jpg';
    }

	$video_ID = $value['ID'];
	$category_id = $value['category_id'];
	$video_file = $value['video'];
	$Video_Title = $value['Video_Title'];
	$view = $value['view'];
	$user_id = $value['user_id'];
	$datatime = $value['datatime'];
	$Short_Description = $value['Short_Description'];
	$video_hashtag = explode(",", $value['video_hashtag']);
	//echo "<pre>";print_r($video_hashtag);die();
	?>
	<div class="main-wrapper">
		<section class="video-detail-page">
			<div class="row">
				<div class="container-fluid large-devise-screen">
					<!-- Video Left Section -->
					<div class="left-container">
						<div class="main-video-col">
							<video id="video_1" class="video-js vjs-default-skin" width="100%" controls="controls" preload="none" poster='<?php echo $video_image;?>' data-setup='{ "aspectRatio":"1200:700", "playbackRates": [1, 1.5, 2] }' onended="run()">
								<source src="<?php echo base_url('uploads/video/'.$video_file);?>" type='video/mp4' />
							</video>
						</div>
						<div id="refresh_like_dislike_info">
							<div class="containt-block">
								<p class="hash-tag-col">
									<?php
									if(isset($value['video_hashtag']) && !empty($value['video_hashtag'])) foreach ($video_hashtag as $key => $hash_val){ ?>
										<a href="<?php echo site_url('Entube/search/'.$hash_val);?>">#<?php echo $hash_val;?></a>
									<?php } ?>
								</p>
								<h2><?php echo $Video_Title; ?></h2>
								<div class="col-left">
									<span><i class="far fa-eye"></i><?php echo ($view > 0) ? $view." views" : "0 view";?></span>
								</div>
								<div class="col-right">
									<?php
									$query1 = $this->db->query('SELECT count(id) FROM like_dislike WHERE like1=1 AND  v_id='.$video_ID);
									$row1= $query1->result_array();

									$query12 = $this->db->query('SELECT count(id) FROM like_dislike WHERE dislike=1 AND  v_id='.$video_ID);
									$row12= $query12->result_array();
									
									if($this->session->userdata('entube_customer_logged_in')) {
										$query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$video_ID.' AND user_id="'.$this->session->userdata('username').'" AND like1=1');

										$row= $query->result_array();
										$num=$query->num_rows();

										if ($num) { ?>
											<i class="far fa-thumbs-up" aria-hidden="true" style="font-size: 18px;color: blue;" ></i>
										<?php }
										else { ?>
											<i class="far fa-thumbs-up" aria-hidden="true" style="font-size: 18px" onclick="get_like();"></i>
										<?php } ?>
										<span><?php echo($row1[0]['count(id)']);?> </span>
										<?php
										$query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$video_ID.' AND user_id="'.$this->session->userdata('username').'" AND dislike=1');
										$row= $query->result_array();
										$num=$query->num_rows();
										if ($num) { ?>
											<i class="far fa-thumbs-down" aria-hidden="true" style="font-size: 18px;color: blue;" ></i>
										<?php }
										else { ?>
											<i class="far fa-thumbs-down" aria-hidden="true" style="font-size: 18px" onclick="get_dislike();"></i>
										<?php } ?>
										<span><?php echo($row12[0]['count(id)']);?> </span>
										<?php
									}
									elseif($this->session->userdata('logged_in')) {
										$query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$video_ID.' AND user_id="'.$this->session->userdata('id').'" AND like1=1');
										$row= $query->result_array();
										$num=$query->num_rows();
										if ($num) {  ?>
											<i class="far fa-thumbs-up" aria-hidden="true" style="font-size: 18px;color: blue;" ></i>
										<?php }
										else { ?>
											<i class="far fa-thumbs-up" aria-hidden="true" style="font-size: 18px" onclick="get_like();"></i>
										<?php } ?>
										<span><?php echo($row1[0]['count(id)']);?> </span>
										<?php
										$query = $this->db->query('SELECT * FROM like_dislike WHERE v_id='.$video_ID.' AND user_id="'.$this->session->userdata('id').'" AND dislike=1');
										$row= $query->result_array();
										$num=$query->num_rows();
										if ($num) { ?>
											<i class="far fa-thumbs-down" aria-hidden="true" style="font-size: 15px;color: blue;" ></i>
										<?php }
										else { ?>
											<i class="far fa-thumbs-down" aria-hidden="true" style="font-size: 15px" onclick="get_dislike();"></i>
										<?php } ?>
										<span><?php echo($row12[0]['count(id)']);?> </span>
										<?php
									}
									else{ ?>
										<span data-toggle="modal" data-target="#EPanelistloginModal"><i class="far fa-thumbs-up"></i><?php echo $row1[0]['count(id)']; ?></span>
										<span data-toggle="modal" data-target="#EPanelistloginModal"><i class="far fa-thumbs-down"></i><?php echo $row12[0]['count(id)']; ?></span>
										<?php
									}
									if ($this->session->userdata('entube_customer_logged_in')) {
										$queryw = $this->db->query('SELECT * FROM watch_later WHERE v_id='.$video_ID.' AND user_id="'.$this->session->userdata('username').'" AND status=1');
										$num1=$queryw->num_rows();
										if ($num1) { ?>
											<span style="color: blue;"><i class="fas fa-bars" aria-hidden="true" ></i> Save</span>
										<?php } else{ ?>
											<span onclick="watch_later();"><i class="fas fa-bars" aria-hidden="true"></i> Save</span>
										<?php }
									}
									elseif($this->session->userdata('logged_in')) {
										$queryw = $this->db->query('SELECT * FROM watch_later WHERE v_id='.$video_ID.' AND user_id="'.$this->session->userdata('id').'" AND status=1');
										$num1=$queryw->num_rows();
										if ($num1) { ?>
											<span style="color: blue;"><i class="fas fa-bars" aria-hidden="true" ></i> Save</span>
										<?php }else{ ?>
											<span onclick="watch_later();"><i class="fas fa-bars" aria-hidden="true"></i> Save</span>
										<?php }
									}
									else{ ?>
										<span data-toggle="modal" data-target="#EPanelistloginModal"><i class="fas fa-bars"></i> Save</span>
										<?php
									}
									?>
									<span><i class="fas fa-share-square"></i> Share</span>
									<!-- <span><i class="fas fa-bars"></i> Save</span>
									<span class="dropdown">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-bars"></i> Save</a>
										<ul class="dropdown-menu">
											<li><a href="#">Want to watch this again later?</a></li>
											<li><a href="#">Sign in to add this video to a playlist.</a></li>
											<li role="separator" class="divider"></li>
											<li><a href="#"><i class="fas fa-fw fa-star "></i> Sign in</a></li>
										</ul>
									</span> -->
								</div>
							</div>
						</div>
						<?php
						if($this->session->userdata('entube_customer_logged_in')){ ?>
							<script type="text/javascript">
								function get_like(argument) {
									$.ajax({
										type:"post",
										url:"<?php echo base_url("Entube/like_dislike"); ?>",
										data:{
											'v_id':"<?php echo $video_ID; ?>",
											'like1':1,
											'dislike':0,
											'user_id':"<?php echo $this->session->userdata('username'); ?>"
										},
										success:function(data){
											$("#refresh_like_dislike_info").load(" #refresh_like_dislike_info");
										}
									});
								}
								function get_dislike(argument) {
									$.ajax({
										type:"post",
										url:"<?php echo base_url("Entube/like_dislike"); ?>",
										data:{
											'v_id':"<?php echo $video_ID; ?>",
											'like1':0,
											'dislike':1,
											'user_id':"<?php echo $this->session->userdata('username'); ?>"
										},
										success:function(data){
											$("#refresh_like_dislike_info").load(" #refresh_like_dislike_info");
										}
									});
								}
								function watch_later() {
									$.ajax({
										type:"post",
										url:"<?php echo base_url("Entube/watch_later"); ?>",
										data:{
											'v_id':"<?php echo $video_ID; ?>",
											'status':1,
											'user_id':"<?php echo $this->session->userdata('username'); ?>"
										},
										success:function(data){
											$("#refresh_like_dislike_info").load(" #refresh_like_dislike_info");
										}
									});
								}
							</script>
							<?php
						}
						elseif($this->session->userdata('logged_in')){ ?>
							<script type="text/javascript">
								function get_like(argument) {
									$.ajax({
										type:"post",
										url:"<?php echo base_url("Entube/like_dislike"); ?>",
										data:{
											'v_id':"<?php echo $video_ID; ?>",
											'like1':1,
											'dislike':0,
											'user_id':"<?php echo $this->session->userdata('id'); ?>"
										},
										success:function(data){
											$("#refresh_like_dislike_info").load(" #refresh_like_dislike_info");
										}
									});
								}
								function get_dislike(argument) {
									$.ajax({
										type:"post",
										url:"<?php echo base_url("Entube/like_dislike"); ?>",
										data:{
											'v_id':"<?php echo $video_ID; ?>",
											'like1':0,
											'dislike':1,
											'user_id':"<?php echo $this->session->userdata('id'); ?>"
										},
										success:function(data){
											$("#refresh_like_dislike_info").load(" #refresh_like_dislike_info");
										}
									});
								}
								function watch_later() {
									$.ajax({
										type:"post",
										url:"<?php echo base_url("Entube/watch_later"); ?>",
										data:{
											'v_id':"<?php echo $video_ID; ?>",
											'status':1,
											'user_id':"<?php echo $this->session->userdata('id'); ?>"
										},
										success:function(data){
											$("#refresh_like_dislike_info").load(" #refresh_like_dislike_info");
										}
									});
								}
							</script>
							<?php
						}
						?>
						<div class="containt-block">
							<div class="col-left space-left">
								<a href="<?php echo base_url("Entube/channel/".$user_id); ?>">
									<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt="" class="channel-logo" width="40px" height="40px" style="border-radius: 50%;">
								</a>
								<a href="<?php echo base_url("Entube/channel/".$user_id); ?>" class="title-01 fwd"><?php echo $channel_name;?> <i class="far fa-check-circle"></i></a>
								<span class="title-02 fwd">Published on <?php echo date("M-d-Y", strtotime($datatime));?></span>
							</div>
							<span id="refresh_subscribe">
								<div class="col-right col-2-right">
									<?php if ($user_id) {
										$ashfak_khan_channel = $user_id;
									} else {
										$ashfak_khan_channel = '0';
									}
									?>
									<input type="hidden" name="channel_name" id="channel_name" value="<?php echo $ashfak_khan_channel;?>">
									<?php
									if ($this->session->userdata('logged_in')) {
										$subscribe_channel_info = $this->Model->getData('subscribe_channel',array('channel_id'=>$ashfak_khan_channel,'my_id'=>$this->session->userdata('id')));
									}
									else if ($this->session->userdata('entube_customer_logged_in')) {
										$subscribe_channel_info = $this->Model->getData('subscribe_channel',array('channel_id'=>$ashfak_khan_channel,'my_id'=>$this->session->userdata('username')));
									}
									if (!empty($subscribe_channel_info)) {
										$channel_count= $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$ashfak_khan_channel));
										?>
										<span class="subscribe-btn after_subscribe_info">Un-Subscribe <strong><?php echo $channel_count;?></strong></span>
										<span class="notification-btn after_subscribe_info"><i class="far fa-bell"></i></span>

									<?php }
									else {
										if ($this->session->userdata('logged_in')) {
											$channel_count= $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$ashfak_khan_channel));
											?>
											<span class="subscribe-btn szdcvjk">Subscribe <strong><?php echo $channel_count;?></strong></span>
											<span class="notification-btn szdcvjk"><i class="far fa-bell"></i></span>
										<?php }
										else if ($this->session->userdata('entube_customer_logged_in')) {
											$channel_count= $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$ashfak_khan_channel));
											?>
											<span class="subscribe-btn szdcvjk">Subscribe <strong><?php echo $channel_count;?></strong></span>
											<span class="notification-btn szdcvjk"><i class="far fa-bell"></i></span>
											<?php ?>
										<?php }
										else {
											$channel_count= $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$ashfak_khan_channel));
											?>
											<span class="subscribe-btn" data-toggle="modal" data-target="#EPanelistloginModal">Subscribe <strong><?php echo $channel_count;?></strong></span>
											<span class="notification-btn" data-toggle="modal" data-target="#EPanelistloginModal"><i class="far fa-bell"></i></span>
										<?php }
									} ?>
								</div>
							</span>
							<div class="col-2-full space-left">
								<span class="title-03 fwd">Description :</span>
								<span class="title-04 fwd"><?php echo $Short_Description; ?></span>
							</div>
						</div>
						<div class="containt-block">
							<div class="col-left fwd">
								<?php
								$query = $this->db->query("SELECT COUNT(*) AS total_comments FROM comment_section WHERE v_id = ".$video_ID." order by id  DESC");
								$row = $query->result_array();
								?>
								<span><?php echo $row[0]['total_comments'];?> Comments</span>
								<span><i class="fas fa-sort"></i> SORT BY</span>
							</div>
							<div class="col-left space-left col-3-full">
								<?php
								if($this->session->userdata('logged_in')){
									$login123 = $this->Model->getData('custumer_login',array('id'=>$this->session->userdata('id'),'status'=>'1'));
									?>
									<a href="<?php echo base_url("Entube/channel/".$login123[0]['id']); ?>"><img src="<?php echo base_url("uploads/customer_channel_logo/".$login123[0]['photo']); ?>" alt="" class="channel-logo" width="40px" height="40px" style="border-radius: 50%;"></a>
									<form action="<?php echo base_url("Entube/comment_section"); ?>" method="post" class="form-horizontal">
										<textarea class="video-textareabox" name="comment" placeholder="Add a public comment..." rows="2" required="" style="resize:none;"></textarea>
										<input type="hidden" name="v_id" value="<?php echo $video_ID; ?>">
										<input type="hidden" name="user_id" value="<?php echo $login123[0]['email_id']; ?>">
										<input type="hidden" name="photo" value="<?php echo base_url("uploads/customer_channel_logo/".$login123[0]['photo']); ?>">
										<input type="hidden" name="usertype" value="0">
										<input type="hidden" name="url" value="<?php echo current_url(); ?>">
										<button type="reset" class="video-submitbtn">Cancel</button>
										<button type="submit" class="video-submitbtn">Comment</button>
									</form>
									<?php
								}
								elseif($this->session->userdata('entube_customer_logged_in')){ ?>
									<a href="<?php echo base_url("Entube/channel/".$this->session->userdata('user_id')); ?>"><img src="<?php echo $this->session->userdata('profileImage'); ?>" alt="" class="channel-logo" width="40px" height="40px" style="border-radius: 50%;"></a>
									<form action="<?php echo base_url("Entube/comment_section"); ?>" method="post" class="form-horizontal">
										<textarea class="video-textareabox" name="comment" placeholder="Add a public comment..." rows="2" required="" style="resize:none;"></textarea>
										<input type="hidden" name="v_id" value="<?php echo $video_ID; ?>">
										<input type="hidden" name="user_id" value="<?php echo $this->session->userdata('username'); ?>">
										<input type="hidden" name="photo" value="<?php echo $this->session->userdata('profileImage'); ?>">
										<input type="hidden" name="usertype" value="1">
										<input type="hidden" name="url" value="<?php echo current_url(); ?>">
										<button type="reset" class="video-submitbtn">Cancel</button>
										<button type="submit" class="video-submitbtn">Comment</button>
									</form>
									<?php
								}
								else{ ?>
									<span class="video-user-icon"><i class="fas fa-user"></i></span>
									<form action="<?php echo base_url("Entube/comment_section"); ?>" method="post" class="form-horizontal">
										<textarea class="video-textareabox" name="comment" placeholder="Add a public comment..." rows="2" required="" style="resize:none;"></textarea>
										<button type="reset" class="video-submitbtn">Cancel</button>
										<button type="button" class="video-submitbtn" data-toggle="modal" data-target="#EPanelistloginModal">Comment</button>
									</form>
									<?php
								}
								?>
							</div>
							<div id="watch_comment_load"></div>
						</div>
					</div>
					<!-- Video Right Section -->
					<div class="right-container">
						<div class="video-detail-advertise-banner">
							<a href="https://www.oxiinc.in" target="_blank"><img src="<?php echo base_url('black/img/banner.png'); ?>" class="img-responsive" alt=""></a>
						</div>
						<div class="block-title">
							<span>Up Next</span>
							<span>
								Autoplay
								<div class="pretty p-switch">
									<input type="checkbox" class='check-control auto_ak' checked="" id="myCheck_khan" />
									<div class="state p-success">
										<label lass='check green'></label>
									</div>
								</div>
							</span>
						</div>
						<?php
						if(isset($watch_next) && !empty($watch_next)){
							
							$next_video_id = $watch_next['ID'];

							if($watch_next['channel_name']) {
						  		$chnl_nam = $watch_next['channel_name'];
						    } elseif ($watch_next['user_id']) {
						    	$chnl_nam = $watch_next['user_id'];
						    } else{
						    	$chnl_nam = OXIINC_CHANNEL;
						    }

						    $video_image = (isset($watch_next['picture']) && !empty($watch_next['picture']) && file_exists('uploads/product/'.$watch_next['picture'])) ? base_url('uploads/product/'.$watch_next['picture']) : base_url('uploads/product/default_video_image.jpg');

							?>
							<div class="video-card">
								<div class="video-card-img">
									<a href="<?php echo base_url("watch/$chnl_nam/".$watch_next['ID']); ?>">
										<img src="<?php echo $video_image;?>" class="trending-mp-video-img" alt="" />
										<i class="fas fa-play-circle"></i>
										<div class="video-overlay"></div>
									</a>
								</div>
								<div class="video-card-info">
									<span class="title">
										<a href="<?php echo base_url("watch/$chnl_nam/".$watch_next['ID']); ?>"><?php echo $watch_next['Video_Title']; ?></a>
									</span>
									<span class="channel-title">
										<a href="<?php echo base_url("Entube_channel/channel/".$watch_next['user_id']) ?>"><?php echo $chnl_nam; ?> <i class="far fa-check-circle"></i></a>
									</span>
									<span class="views_and_date">
										<i class="far fa-eye"></i> <?php echo ($watch_next['view'] > 0) ? $watch_next['view']." views" : " 0 view"; ?>
										<i class="far fa-calendar-alt" style="margin-left: 30px;"></i>
										<?php
										$FromDate = new DateTime(date("Y-m-d H:i:s"));
										$ToDate   = new DateTime($watch_next['datatime']);
										$Interval = $FromDate->diff($ToDate);
										$Difference["Hours"] = $Interval->h;
										$Difference["Weeks"] = floor($Interval->d/7);
										$Difference["Days"] = $Interval->d % 7;
										$Difference["Months"] = $Interval->m;
										$Difference["minute"] = $Interval->i;
										$Difference["second"] = $Interval->s;
										$Difference["Year"] = $Interval->y;

										if($Difference["Year"]){
											echo $Difference["Year"]." "."Year";
										}else
										if($Difference["Months"]){
											echo $Difference["Months"]." "."Months";
										}else
										if($Difference["Weeks"]){
											echo $Difference["Weeks"]." "."Weeks";
										}else
										if($Difference["Days"]){
											echo $Difference["Days"]." "."Days";
										}else
										if($Difference["Hours"]){
											echo $Difference["Hours"]." "."Hours";
										}else
										if($Difference["minute"]){
											echo $Difference["minute"]." "."Minute";
										}else
										if($Difference["second"]){
											echo $Difference["second"]." "."Second";
										} 
										echo " "."ago";
										?>
									</span>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
										<li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
										<li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
									</ul>
								</span>
							</div>
							<?php
						}
						?>
						<div id="watch_video_load"></div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div class="loader" style="display: none;"><img src=""></div>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/pretty-checkbox@3.0/dist/pretty-checkbox.min.css">
	<script src='https://vjs.zencdn.net/7.6.5/video.js'></script>
	<script type="text/javascript">
		//videojs('video_1').videoJsResolutionSwitcher();

		function run() {
			var chkPassport = document.getElementById("myCheck_khan");
			if (chkPassport.checked) {
				window.location.href= '<?php echo base_url('watch/'.$chnl_nam.'/'.$next_video_id);?>';
			}
			else {
			}
		}

		$(".szdcvjk").click(function() {
 			//alert("subscribe");
 			var hasError=0;
 			var value_info = jQuery("#channel_name").val();
 			var my_id = "<?php 
 			if($this->session->userdata('logged_in')){
 				echo $this->session->userdata('id');
 			}else if($this->session->userdata('entube_customer_logged_in')){
 				echo $this->session->userdata('username');
 			}?>";
 			if(hasError==1){
 				return false;
 			}
 			else {
 				var data = {};
 				data.report = {};
 				data.report.value_info = value_info;
 				data.report.my_id = my_id;
 				var q = JSON.stringify(data);
 				jQuery.ajax({
 					type: "POST",
 					url: "<?php echo site_url('Customer_login_page/Subscribe_channel');?>",
 					data: {'jsonObj' : q},
 					cache: false,
 					beforeSend: function(){ jQuery('.loader').css('display','block');},
 					success: function(data){
					// alert(data);
					jQuery('.loader').css('display','none');
					// jQuery("#sales_report").html(res);
					location.reload();
					//$("#refresh_subscribe").load(" #refresh_subscribe");
				}
			});
 			}
 		});

		$(".after_subscribe_info").click(function() {
 			//alert("un-subscribe");
 			var hasError=0;
 			var value_info = jQuery("#channel_name").val();
 			var my_id = "<?php 
 			if($this->session->userdata('logged_in')){
 				echo $this->session->userdata('id');
 			}else if($this->session->userdata('entube_customer_logged_in')){
 				echo $this->session->userdata('username');
 			}?>";

 			if(hasError==1){
 				return false;
 			}
 			else {
 				var data = {};
 				data.report = {};
 				data.report.value_info = value_info;
 				data.report.my_id = my_id;
 				var q = JSON.stringify(data);
 				jQuery.ajax({
 					type: "POST",
 					url: "<?php echo site_url('Customer_login_page/Subscribe_channel_after');?>",
 					data: {'jsonObj' : q},
 					cache: false,
 					beforeSend: function(){ jQuery('.loader').css('display','block');},
 					success: function(data){
 						jQuery('.loader').css('display','none');
 						location.reload();
					//$("#refresh_subscribe").load(" #refresh_subscribe");
				}
			});
 			}
 		});
		
		$(document).ready(function() {
		    // Configure/customize these variables.
		    var showChar = 100;  // How many characters are shown by default
		    var ellipsestext = "...";
		    var moretext = "Show more";
		    var lesstext = "Show less";

		    $('.more').each(function() {
		    	var content = $(this).html();

		    	if(content.length > showChar) {

		    		var c = content.substr(0, showChar);
		    		var h = content.substr(showChar, content.length - showChar);

		    		var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

		    		$(this).html(html);
		    	}
		    });

		    $(".morelink").click(function(){
		    	if($(this).hasClass("less")) {
		    		$(this).removeClass("less");
		    		$(this).html(moretext);
		    	} else {
		    		$(this).addClass("less");
		    		$(this).html(lesstext);
		    	}
		    	$(this).parent().prev().toggle();
		    	$(this).prev().toggle();
		    	return false;
		    });
		});

		$(document).ready(function(){
			var data_limit = 20;
			$.ajax({
				url: "<?php echo base_url('Entube/watch_more_videos_on_page_load'); ?>",
				type: "POST",
				data:"category_id=" + <?php echo $category_id; ?> + "&next_video_id=" + <?php echo $next_video_id; ?> + "&video_limit=" + data_limit,
				dataType:"text",
				success: function(data){
					// alert(data);
					$("#watch_video_load").html(data)
				}
			});

			$.ajax({
				url: "<?php echo base_url('Entube/page_load_comment'); ?>",
				type: "POST",
				data:"v_id=" +<?php echo $video_ID; ?>+ "&comment_limit=" + data_limit,
				dataType:"text",
				success: function(data){
					// alert(data);
					$("#watch_comment_load").html(data)
				}
			});

			$(window).scroll(function (){
				if($(window).scrollTop() == $(document).height() - $(window).height()) {
					$.ajax({
						url: "<?php echo base_url('Entube/watch_more_videos_on_page_load'); ?>",
						type: "POST",
						data:"category_id=" + <?php echo $category_id; ?> + "&next_video_id=" + <?php echo $next_video_id; ?> + "&video_limit=" + data_limit,
						dataType:"text",
						success: function(data){
							// alert(data);
							$("#watch_video_load").html(data)
						}
					});

					$.ajax({
						url: "<?php echo base_url('Entube/page_load_comment'); ?>",
						type: "POST",
						data:"v_id=" +<?php echo $video_ID; ?>+ "&comment_limit=" + data_limit,
						dataType:"text",
						success: function(data){
							// alert(data);
							$("#watch_comment_load").html(data)
						}
					});
					data_limit += 20;
				}
			});
		});

		function like_comment(value) {
            // alert(value)
            var hasError=0;
			// var comment_id = value;
			var customer_id = "<?php echo $this->session->userdata('id'); ?>";
			var video_id = "<?php echo $video_ID; ?>";
			// var phone_no = jQuery("#phone_no").val();
			if(hasError==1){
				return false;
			}
			else{
				var data = {};
				data.report = {};
				data.report.comment_id = value;
				data.report.customer_id = customer_id;
				data.report.video_id = video_id;
				data.report.user_type = '0';
				data.report.like1 = '1';
				data.report.dislike = '0';;
				// data.report.phone_no = phone_no;

				var q = JSON.stringify(data);
				// alert(q);
				jQuery.ajax({
					type: "POST",
					url: "<?php echo site_url('Customer_login_page/like_dislike_comment');?>",
					data: {'jsonObj' : q},
					cache: false,
					// beforeSend: function(){ jQuery('.loader').css('display','block');},
					success: function(data){
						// alert(data);
						// jQuery('.loader').css('display','none');
						// jQuery("#sales_report").html(res);
						// location.reload();
						$.ajax({
							url: "<?php echo base_url('Entube/page_load_comment'); ?>",
							type: "POST",
							data:"v_id=" +<?php echo $video_ID; ?>+ "&comment_limit=" + data_limit,
							dataType:"text",
							success: function(data){
								// alert(data);
								$("#watch_comment_load").html(data)
							}
						})
					}
				});
			}
		}

		function like_comment1(value) {
			//alert(value)
			var hasError = 0;
			// var comment_id = value;
			var customer_id = "<?php echo $this->session->userdata('employee_id'); ?>";
			var video_id = "<?php echo $video_ID; ?>";
			// var phone_no = jQuery("#phone_no").val();
			if (hasError == 1) {
				return false;
			}
			else {
				var data = {};
				data.report = {};
				data.report.comment_id = value;
				data.report.customer_id = customer_id;
				data.report.video_id = video_id;
				data.report.user_type = '1';
				data.report.like1 = '1';
				data.report.dislike = '0';;
				// data.report.phone_no = phone_no;

				var q = JSON.stringify(data);
				//alert(q);
				jQuery.ajax({
					type: "POST",
					url: "<?php echo site_url('Customer_login_page/like_dislike_comment');?>",
					data: {
						'jsonObj': q
					},
					cache: false,
				    // beforeSend: function(){ jQuery('.loader').css('display','block');},
				    success: function(data) {
				    	//alert("SUCCESS");
				        //alert(data);
				        // jQuery('.loader').css('display','none');
				        // jQuery("#sales_report").html(res);
				        // location.reload();
				        $.ajax({
				        	url: "<?php echo base_url('Entube/page_load_comment'); ?>",
				        	type: "POST",
				        	data: "v_id=" + <?php echo $video_ID; ?> + "&comment_limit=" + data_limit,
				        	dataType: "text",
				        	success: function(data) {
				                //alert(data);
				                $("#watch_comment_load").html(data)
				            }

				        })
				    }
				});
			}
		}

		function dilike_copmment(value) {
			// alert(value)
			var hasError=0;
			// var comment_id = value;
			var customer_id = "<?php echo $this->session->userdata('id'); ?>";
			var video_id = "<?php echo $video_ID; ?>";
			// var phone_no = jQuery("#phone_no").val();

			if(hasError==1){
				return false;
			}
			else{
				var data = {};
				data.report = {};
				data.report.comment_id = value;
				data.report.customer_id = customer_id;
				data.report.video_id = video_id;
				data.report.user_type = '0';
				data.report.like1 = '0';
				data.report.dislike = '1';;
				// data.report.phone_no = phone_no;


				var q = JSON.stringify(data);
				// alert(q);
				jQuery.ajax({
					type: "POST",
					url: "<?php echo site_url('Customer_login_page/like_dislike_comment');?>",
					data: {'jsonObj' : q},
					cache: false,
				// beforeSend: function(){ jQuery('.loader').css('display','block');},
				success: function(data){
					$.ajax({
						url: "<?php echo base_url('Entube/page_load_comment'); ?>",
						type: "POST",
						data:"v_id=" +<?php echo $video_ID; ?>+ "&comment_limit=" + data_limit,
						dataType:"text",
						success: function(data){

				// alert(data);
				$("#watch_comment_load").html(data)
			}

		})
				}
			});
			}
		}

		function dilike_copmment1(value) {
			// alert(value)
			var hasError=0;
			// var comment_id = value;
			var customer_id = "<?php echo $this->session->userdata('employee_id'); ?>";
			var video_id = "<?php echo $video_ID; ?>";
			// var phone_no = jQuery("#phone_no").val();

			if(hasError==1){
				return false;
			}
			else{
				var data = {};
				data.report = {};
				data.report.comment_id = value;
				data.report.customer_id = customer_id;
				data.report.video_id = video_id;
				data.report.user_type = '1';
				data.report.like1 = '0';
				data.report.dislike = '1';;
				// data.report.phone_no = phone_no;


				var q = JSON.stringify(data);
				// alert(q);
				jQuery.ajax({
					type: "POST",
					url: "<?php echo site_url('Customer_login_page/like_dislike_comment');?>",
					data: {'jsonObj' : q},
					cache: false,
				// beforeSend: function(){ jQuery('.loader').css('display','block');},
				success: function(data){
					$.ajax({
						url: "<?php echo base_url('Entube/page_load_comment'); ?>",
						type: "POST",
						data:"v_id=" +<?php echo $video_ID; ?>+ "&comment_limit=" + data_limit,
						dataType:"text",
						success: function(data){

				// alert(data);
				$("#watch_comment_load").html(data)
			}

		})
				}
			});
			}
		}

		function comment_reply(value) {
			var hasError=0;
			var comment_id = value;
			var customer_id = "<?php echo $this->session->userdata('id'); ?>";
			var video_id = "<?php echo $video_ID; ?>";
			// var phone_no = jQuery("#phone_no").val();
			if(hasError==1){
				return false;
			}
			else{
				var data = {};
				data.report = {};
				data.report.comment_id = comment_id;
				data.report.customer_id = customer_id;
				data.report.video_id = video_id;
				// data.report.phone_no = phone_no;
				var q = JSON.stringify(data);
				// alert(q);
				jQuery.ajax({
					type: "POST",
					url: "<?php echo site_url('Customer_login_page/comment_reply_information');?>",
					data: {'jsonObj' : q},
					cache: false,
					beforeSend: function(){ jQuery('.loader123').css('display','block'); jQuery("#comment_replt_information_khan").html("");},
					success: function(res){
						jQuery('.loader123').css('display','none');
						jQuery("#comment_replt_information_khan").html(res);
					}
				});
			}
		}

		function comment_reply_ashfak() {
			var hasError=0;
			var comment_id = jQuery("#comment_id_khan").val();
			var customer_id = jQuery("#customer_id_khan").val();
			var video_id = jQuery("#video_id_khan").val();
			var comment_reply = jQuery("#comment_reply_khan").val();

			if(hasError==1){
				return false;
			}
			else{
				var data = {};
				data.report = {};
				data.report.comment_id = comment_id;
				data.report.customer_id = customer_id;
				data.report.video_id = video_id;
				data.report.comment_reply = comment_reply;
				var q = JSON.stringify(data);
				// alert(q);
				jQuery.ajax({
					type: "POST",
					url: "<?php echo site_url('Customer_login_page/comment_reply_information_khan');?>",
					data: {'jsonObj' : q},
					cache: false,
					beforeSend: function(){ jQuery('.loader123').css('display','block'); jQuery("#comment_replt_information_khan").html("");},
					success: function(res){
						jQuery('.loader123').css('display','none');
						jQuery("#comment_replt_information_khan").html(res);
					}
				});
			}
		}
	</script>
<?php }
else { ?>
	<!-- Video Not Available -->
	<style>
		body {
			padding: 0;
			margin:0;
		}
		canvas {
			position: absolute;
			z-index: 0;
		}
		.background {
			width: 100%;
			display: flex;
			z-index: 3;
			height:100vh;
			flex-direction: column;
			align-content: center;
			justify-content: center;
			font-family: "Text Me One", sans-serif;
		}
		h1, p{
			display: block;
			width: 100%;
			text-align: center;
			padding: 0;
			margin: 1vmin;
		}
		h1 {
			font-size: 24vmin;
		}
		p {
			font-size: 7vmin;
			font-family: Helvetica, Arial, sans-serif
		}
		cite {
			font-size: 12px;
			position: relative;
			z-index: 10;
		}
		a {
			color: #000;
			text-decoration: none;
			border-bottom: 1px solid #000; 
		}
	</style>
	<div class="main-wrapper">
		<section class="video-detail-page">
			<div class="container-fluid">
				<div class="row">
					<div class="container">
						<canvas id="background"></canvas>
						<div class="background">
							<h1> <a href=""> Video Not Available_ </a></h1>
							<p>: : . : : . : :</p>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<script type="text/javascript">
		const particles = [];
		for (let i = 0; i < 100; i++) {
			particles.push({
				x: Math.random() > .5 ? 0 : window.innerWidth,
				y: window.innerHeight / 2,
				vx: Math.random() * 2 - 1,
				vy: Math.random() * 2 - 1,
				history: [],
				size: 4 + Math.random() * 6,
				color: Math.random() > .5 ? "#000000" : Math.random() > .5 ? "#FF0000" : "#FFFF00"
			});
		}

		const mouse = {
			x: window.innerWidth / 2,
			y: window.innerHeight / 2
		};

		const canvas = document.getElementById('background');

		if (canvas && canvas.getContext) {
			var context = canvas.getContext('2d');
			Initialize();
		}

		function Initialize() {
			canvas.addEventListener('mousemove', MouseMove, false);
			window.addEventListener('resize', ResizeCanvas, false);
			TimeUpdate();
			context.beginPath();
			ResizeCanvas();
		}

		function TimeUpdate(e) {
			context.clearRect(0, 0, window.innerWidth, window.innerHeight);
			for (let i = 0; i < particles.length; i++) {
				particles[i].x += particles[i].vx;
				particles[i].y += particles[i].vy;

				if (particles[i].x > window.innerWidth) {
					particles[i].vx = -1 - Math.random();
				} else if (particles[i].x < 0) {
					particles[i].vx = 1 + Math.random();
				} else {
					particles[i].vx *= 1 + Math.random() * 0.005;
				}

				if (particles[i].y > window.innerHeight) {
					particles[i].vy = -1 - Math.random();
				} else if (particles[i].y < 0) {
					particles[i].vy = 1 + Math.random();
				} else {
					particles[i].vy *= 1 + Math.random() * 0.005;
				}

				context.strokeStyle = particles[i].color;
				context.beginPath();
				for (var j = 0; j < particles[i].history.length; j++) {
					context.lineTo(particles[i].history[j].x, particles[i].history[j].y);
				}
				context.stroke();

				particles[i].history.push({
					x: particles[i].x,
					y: particles[i].y });

				if (particles[i].history.length > 45) {
					particles[i].history.shift();
				}

				for (var j = 0; j < particles[i].history.length; j++) {
					particles[i].history[j].x += 0.01 * (mouse.x - particles[i].history[j].x) / (45 / j);
					particles[i].history[j].y += 0.01 * (mouse.y - particles[i].history[j].y) / (45 / j);
				}
				let distanceFactor = DistanceBetween(mouse, particles[i]);
				distanceFactor = Math.pow(Math.max(Math.min(10 - distanceFactor / 10, 10), 2), .5);

				context.fillStyle = particles[i].color;
				context.beginPath();
				context.arc(particles[i].x, particles[i].y, particles[i].size * distanceFactor, 0, Math.PI * 2, true);
				context.closePath();
				context.fill();
			}
			requestAnimationFrame(TimeUpdate);
		}

		function MouseMove(e) {
			mouse.x = e.layerX;
			mouse.y = e.layerY;
			//context.fillRect(e.layerX, e.layerY, 5, 5);
			//Draw( e.layerX, e.layerY );
		}

		function Draw(x, y) {
			context.strokeStyle = '#ff0000';
			context.lineWidth = 4;
			context.lineTo(x, y);
			context.stroke();
		}

		function ResizeCanvas(e) {
			canvas.width = window.innerWidth;
			canvas.height = window.innerHeight;
		}

		function DistanceBetween(p1, p2) {
			const dx = p2.x - p1.x;
			const dy = p2.y - p1.y;
			return Math.sqrt(dx * dx + dy * dy);
		}
	</script>
<?php } ?>
<!-- End Container -->