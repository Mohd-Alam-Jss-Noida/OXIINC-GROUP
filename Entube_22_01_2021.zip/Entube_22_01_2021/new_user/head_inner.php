<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<?php if($this->uri->segment(1)=="watch") { ?>
		<title><?php echo $watch[0]['Video_Title'];?> | EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	<?php } else { ?>
		<title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	<?php } ?>

	<!-- Favicon Icon -->
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url('black/img/logoo/iconn.png');?>">
	<!-- Css -->
	<link href="<?php echo base_url('new_user_assets/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
	<!-- Fontawesome -->
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/all.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/fontawesome.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/brands.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/solid.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/animate.css');?>" rel="stylesheet">
	<!-- Scrollbar Css -->
	<link href="<?php echo base_url('new_user_assets/css/mCustomScrollbar.css');?>" rel="stylesheet">

	<!-- Datepicker Css -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
	<!-- Data Table Css -->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css"/>
	
	<link href="<?php echo base_url('new_user_assets/css/common-style.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/home.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/custom-inner-style.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/custom-inner-responsive.css');?>" rel="stylesheet">
</head>
<body<?php
	$panel_url = $this->uri->segment(2);
    if ($panel_url == 'panel' || $panel_url == 'sub_panel_1' || $panel_url == 'sub_panel_2' || $panel_url == 'sub_panel_3' || $panel_url == 'sub_panel_4' || $panel_url == 'sub_panel_5' || $panel_url == 'sub_panel_6' || $panel_url == 'sub_panel_7' || $panel_url == 'sub_panel_8' || $panel_url == 'sub_panel_9' || $panel_url == 'my_digital') { ?> class="open_panel_menu"<?php }elseif ($panel_url == 'my_digital_statement' || $panel_url == 'panel_statement' || $panel_url == 'sub_panel_1_statement' || $panel_url == 'sub_panel_2_statement' || $panel_url == 'sub_panel_3_statement' || $panel_url == 'sub_panel_4_statement' || $panel_url == 'sub_panel_5_statement' || $panel_url == 'sub_panel_6_statement' || $panel_url == 'sub_panel_7_statement' || $panel_url == 'sub_panel_8_statement' || $panel_url == 'sub_panel_9_statement' || $panel_url == 'serach_My_entube_report') { ?> class="open_panel_menu"<?php }?>>
	<div id="main-page-wrapper">