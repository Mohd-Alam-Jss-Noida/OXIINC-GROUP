<!-- Start Container -->
<div class="main-wrapper">
	<section class="video-detail-page">
		<div class="row">
			<div class="container-fluid large-devise-screen">
				<div class="my-channel-section-01 channel-dashboard-section-01 myvws-statement-section-01">
					<h2 class="headding-01">Channel videos</h2>
					<a href="<?php echo site_url('Entube_channel/video_upload')?>" class="cust-channel-btn">Upload Video</a>
					<a href="<?php echo site_url("Entube_channel/channel/".$this->uri->segment(3));?>" class="cust-channel-btn">Back</a>
					<?php if($this->session->flashdata('msg')) { ?>
						<div class="sucess-msg" id="flash_msg"><?php echo $this->session->flashdata('msg');?></div>
					<?php } ?>
					<div class="default-block block-02 tbl-data-block">
						<div class="data-table-col">
							<table class="table table-bordered table-hover dt-responsive">
								<thead>
									<tr>
										<th>Sr No</th>
										<th>Video</th>
										<th>Video Title</th>
										<th>Video Link</th>
										<th>Visibility</th>
										<!-- <th>Restrictions</th> -->
										<th>Status</th>
										<th>Date</th>
										<th>Views</th>
										<th>Comments</th>
										<th>Likes</th>
										<th>Dislike</th>
										<!-- <th>Action</th> -->
									</tr>
								</thead>
								<tbody>
									<?php
										$i=1;
										if(isset($add_video) && !empty($add_video)) foreach ($add_video as $value){
											
											$video_link = ($value['status'] == 1) ? site_url('watch/'.$value['user_id'].'/'.$value['ID']) : site_url('Entube_channel/video_edit/'.$value['ID']);
											$share_link = ($value['status'] == 1) ? site_url('watch/'.$value['user_id'].'/'.$value['ID']) : '';

											$query = $this->db->query("SELECT COUNT(*) AS total_comments FROM comment_section WHERE v_id= ".$value['ID']." ");
											$comments = $query->result_array();
											$comments = $comments[0]['total_comments'];

											$query_like = $this->db->query("SELECT * FROM like_dislike WHERE v_id= ".$value['ID']." ");
											$like_data = $query_like->result_array();
											$total_like = 0; $total_dislike = 0;
											if(isset($like_data) && !empty($like_data)) foreach ($like_data as $value1) {
												if ($value1['like1'] == 1) {
													$total_like++;
												}
												if ($value1['dislike'] == 1) {
													$total_dislike++;
												}
											}
											?>
											<tr>
												<td><?php echo $i++; ?></td>
												<td>
													<a href="<?php echo $video_link;?>" class="img-col">
														<img src="<?php echo base_url('uploads/product/'.$value['picture']);?>" alt=""/>
														<i class="fas fa-play-circle"></i>
														<div class="video-overlay"></div>
													</a>
												</td>
												<td>
													<div class="title-col desc-col">
														<?php echo $value['Video_Title'];?> <br>
														<a href="<?php echo site_url('Entube_channel/video_edit/'.$value['ID'])?>"><i class="fas fa-pencil-alt"></i></a>
														<a href="<?php echo site_url('Entube_channel/video_delete/'.$value['ID'])?>" onclick="return confirm('Are you sure you want to delete this video?');"><i class="fas fa-trash-alt"></i></a>
													</div>
												</td>
												<td><a class="vlink-col" href="<?php echo $share_link;?>"><?php echo $share_link;?></a></td>
												<td><i class="far fa-eye"></i> <?php echo $value['video_visibility'];?></td>
												<!-- <td>
													<?php if ($value['video_audience'] == "adult") { ?>
														Only 18 Plus
													<?php } else{?>
														Normal
													<?php } ?>
												</td> -->
												<!-- <td class="text-center">
													<?php 
													if($value['reason']){ ?>
														<span class="error_color">Disapproved due to<br>  <?php //echo $value['reason']; ?></span>
													<?php }else if($value['status']=="0"){ ?>
														Approval Pending
													<?php } else { ?>
														Approved
													<?php } ?>
												</td> -->
												<?php
													if($value['save_video'] == 'save_draft') { ?>
														<td><a href="<?php echo site_url('Entube_channel/video_edit/'.$value['ID'])?>" class="sdraft-btn">Edit Draft</a></td>
														<?php
													}
													else{ ?>
														<td>Published</td>
													<?php
													}
												?>
												<td><?php echo date("M d,", strtotime($value['upload_time']));?><br><?php echo date("Y", strtotime($value['upload_time']));?></td>
												<td><?php echo (isset($value['view']) && !empty($value['view'])) ? $value['view'] : "0";?></td>
												<td><?php echo (isset($comments) && !empty($comments)) ? $comments : "0";?></td>
												<td><?php echo (isset($total_like) && !empty($total_like)) ? $total_like : "0";?></td>
												<td><?php echo (isset($total_dislike) && !empty($total_dislike)) ? $total_dislike : "0";?></td>
												<!-- <?php
													if($value['save_video'] == 'save_draft') { ?>
														<td><a href="<?php //echo site_url('Entube_channel/video_edit/'.$value['ID'])?>" class="sdraft-btn">Edit Draft</a></td>
														<?php
													}
													else{ ?>
														<td><div class="sdraft-btn publish-btn">Publish</div></td>
													<?php
													}
												?> -->
											</tr>
											<?php
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	/*ALERT MAEEAGE HIDE AFTER 10 SECOND JAVA SCRIPT CODE*/
	setTimeout(function() {
		$('#flash_msg').fadeOut();
	}, 10000 );
</script>
