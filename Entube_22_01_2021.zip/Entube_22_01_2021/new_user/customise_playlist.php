<?Php $this->load->view('new_user/customise_header');?>
<!-- Tab panes -->
<div class="tab-content">
	<!-- Start Playlist Tab -->
	<div>
		<div class="tab-container fwd">
			<div class="left-content left-block">
				<div id="playlist_name_success" class="success_message" style="display:none; margin: -30px 0px 20px 0px !important;"></div>
				<div id="playlist_orderby_error" class="error_message" style="display:none; margin: -30px 0px 20px 0px !important;"></div>
				<div id="reload_div">
					<a href="<?php echo base_url("Entube_channel/playlist/".$this->uri->segment(3));?>" class="back-btn"><i class="fas fa-long-arrow-alt-left"></i></a>
					<div class="tab-title">Created playlists</div>
					<div class="tab-title btn cust-channel-btn"  data-toggle="modal" data-target="#playlistModel" style="margin: -10px 0px 0px 10px !important;"><i class="fa fa-plus-circle" aria-hidden="true"></i> New playlists</div>
					<div class="dropdown video-login-popup video-login-popup2">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SORT BY <i class="fas fa-caret-down"></i></a>
						<ul class="dropdown-menu">
							<li id="playlists-video1" class="playlists-orderby" onclick="orderby_playlist('<?php echo $this->uri->segment(3);?>', 'ID', 'DESC', 1);"><a href="javascript:void(0);">Last playlist added</a></li>
							<li id="playlists-video2" onclick="orderby_playlist('<?php echo $this->uri->segment(3);?>', 'playlistname', 'ASC', 2);"><a href="javascript:void(0);">Playlist order (ASC)</a></li>
							<li id="playlists-video3" onclick="orderby_playlist('<?php echo $this->uri->segment(3);?>', 'playlistname', 'DESC', 3);"><a href="javascript:void(0);">Playlist order (DESC)</a></li>
						</ul>
					</div>
					<hr class="devider-line-hr-02">
					<!-- ADD NEW PLAYLISTS MODEL -->
					<div class="modal fade login-container" id="playlistModel" tabindex="-1" role="dialog" aria-labelledby="GuestLoginModalLabel">
						<div class="modal-dialog" role="document">
							<div class="modal-content login-form-block" style="background-color: #20acc9;">
								<div class="modal-body">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<img src="<?php echo base_url('new_user_assets/images/entube-logo.png');?>" alt="" class="img-responsive logo-col"/>
									<form id="playlist_form">
										<label for="example" style="color: #fff; float: left;">Add New Playlist</label>
										<div class="form-group">
											<input type="text" name="playlist_name" id="playlist_name" value="" class="input-textbox" id="" placeholder="Add New Playlist" autocomplete="off" required="">
										</div>
										<div class="clrfix"></div>
										<button type="reset" class="input-submitbtn">Cancel</button>
										<button type="button" id="submit_btn_disable" class="input-submitbtn" onclick="submit_playlist('<?php echo $this->uri->segment(3);?>');">Submit</button>
										<div id="playlist_name_error" class="error_message" style="display:none;"></div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div id="playlist_orderby_none">
						<ul class="list-inline video-list">
							<?php
							if(isset($playlist_details) && !empty($playlist_details)) foreach ($playlist_details as $value){
								$query_count = $this->db->query('SELECT video_id FROM playlist_video_select WHERE playlistname_id = '.$value['ID'].' GROUP BY video_id ORDER BY video_id DESC');
								$row_photo = $query_count->result_array();
								$playlist_count = $query_count->num_rows();
								if ($playlist_count > 0) {
									$photo = $this->Model->getDataOrderBy('add_video', array('ID'=>$row_photo[0]['video_id'], 'status'=>'1'), 'ID', 'DESC');
									if($photo){
										?>
										<li>
											<a href="<?php echo base_url('Entube/playlist_video/'.$value['ID']."/".$photo[0]['ID']); ?>" class="item-containt-col">
												<div class="video-img-col video-img-block">
													<div class="playlist-text" style="background-image: url('<?php echo base_url().'uploads/product/'.$photo[0]['picture'];?>');">
														<div class="playlist-col">
															<h4><?php echo $playlist_count; ?></h4>
															<img src="<?php echo base_url('black/img/play.png'); ?>" style="width: 20px"/>
														</div>
													</div>
													<div class="play-all-txt">
														<i class="fas fa-play-circle"></i> 
														<span>Play All</span>
													</div>
													<div class="video-overlay"></div>
												</div>
												<div class="video-containt-col">
													<div class="video-title" ><?php echo $value['playlistname']; ?></div>
												</div>
											</a>     
										</li>
										<?php
									}
								}
								else{ ?>
									<li>
										<a href="javascript:void(0);" class="item-containt-col">
											<div class="video-img-col video-img-block">
												<div class="playlist-text" style="background-image: url('<?php echo base_url('uploads/product/videodefault.jpg');?>');">
													<div class="playlist-col">
														<h4>No videos</h4>
														<img src="<?php echo base_url('black/img/play.png'); ?>" style="width: 20px"/>
													</div>
												</div>
												<div class="play-all-txt">
													<i class="fas fa-play-circle"></i> 
													<span>Play All</span>
												</div>
												<div class="video-overlay"></div>
											</div>
											<div class="video-containt-col">
												<div class="video-title" ><?php echo $value['playlistname']; ?></div>
											</div>
										</a>     
									</li>
									<?php
								}
							}
							else{ ?>
								<p class="text-center">This channel has no playlists.</p>
								<?php
							}
							?>
						</ul>
					</div>
					<div id="playlist_orderby_block"></div>
				</div>
			</div>
			<div class="right-content right-block">
				<!-- <div class="tab-title">Featured channels</div>
				<div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div> -->
			</div>
		</div>
	</div>
</div>

<!-- THIS BELLOW DIV CLOSE FOR HEADER DIV -->
</div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	function submit_playlist(argument){
		var playlist_name = $.trim($("#playlist_name").val());
        if(playlist_name == ""){
        	$("#playlist_name_error").css({"display": "block"}).html("Please enter your playlist name.");
        	return false;
        }
        else{
        	$.ajax({
        		url: "<?php echo base_url('Entube_channel/add_playlist_name');?>",
        		type: "POST",
        		data: 'id=' + argument + '&playlist_name=' + playlist_name,
        		dataType:"text",
        		cache: false,
        		beforeSend: function(){
	        		$("#submit_btn_disable").text('Sending .....').prop('disabled', true);
	        	},
	        	complete: function(){
	        		$("#submit_btn_disable").text('Submit').prop('disabled', false);
   				},
        		success: function(data){
                    if (data == 'yes') {
                    	$("#playlist_name_error").css({"display": "block"}).html("Playlist name already exists please enter other playlist name.");
        				return false;
                    }
                    else if (data == 0) {
                    	$("#playlist_name_error").css({"display": "block"}).html("Playlist name added failed please try again.");
        				return false;
                    }
                    else{
                    	$('#playlist_name_error').css('display','none');
                    	$('#playlistModel').modal('hide');
                    	$("#playlist_form")[0].reset();
                    	$("#playlist_name_success").css({"display": "block"}).html("Playlist name added successfully.");
                    	setTimeout(function() {
                    		$('#playlist_name_success').fadeOut();
                    	}, 5000 );
                    	$( "#reload_div" ).load(window.location.href + " #reload_div" );
                    	$(".modal-backdrop").remove();			//REMOVE PLAYLIST MODEL STRUCTURE
                    	$("body").removeClass('modal-open');	//REMOVE CLASS FROM MAIN BODY
                    	$('body').css('padding-right', '');		//REMOVE CSS FROM MAIN BODY
                    }
                }
            });
        }
        return false;
    }

    function orderby_playlist(argument='', column_name='', option='', add_class=''){
    	if(add_class == 1){
    		$("#playlists-video1").addClass('playlists-orderby');
    		$("#playlists-video2").removeClass('playlists-orderby');
    		$("#playlists-video3").removeClass('playlists-orderby');
    	}
    	if(add_class == 2){
    		$("#playlists-video2").addClass('playlists-orderby');
    		$("#playlists-video1").removeClass('playlists-orderby');
    		$("#playlists-video3").removeClass('playlists-orderby');
    	}
    	if(add_class == 3){
    		$("#playlists-video3").addClass('playlists-orderby');
    		$("#playlists-video1").removeClass('playlists-orderby');
    		$("#playlists-video2").removeClass('playlists-orderby');
    	}


        if(argument == "" || column_name == "" || option == ""){
        	alert("FUNCTION PARAMETER NULL NOT ACCEPTED.");
        	$("#playlist_orderby_error").css({"display": "block"}).html("FUNCTION PARAMETER NULL NOT ACCEPTED.");
        	return false;
        }
        else{
        	$.ajax({
        		url: "<?php echo base_url('Entube_channel/customise_playlist/');?>" +argument,
        		type: "POST",
        		data: 'id=' + argument + '&column_name=' + column_name + '&option=' + option,
        		dataType:"text",
        		cache: false,
        		success: function(data){
                    //alert(data);
                    $("#playlist_orderby_none").css({"display": "none"});
                    $('#playlist_orderby_block').html(data);
                }
            });
        }
        return false;
    }
</script>