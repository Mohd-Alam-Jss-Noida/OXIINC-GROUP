    <!-- Start Container -->
    <div class="main-wrapper">
        <section class="video-detail-page myvws-section-01">
            <div id="wrapper">
                <div id="content-wrapper">
                    <div class="container-fluid pb-0">
                        <div class="video-block section-padding">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="main-title">
                                        <h2 class="headding-01">Sub Panel 9</h2>
                                        <img src="<?php echo base_url('new_user_assets/images/panel.jpg');?>" width="100%">
                                    </div>
                                </div>
                                <?php
                                if(isset($allow_data_my_digital) && !empty($allow_data_my_digital)) foreach ($allow_data_my_digital as $row){
                                    $share_data= $this->Model->CountWhereRecord('share_allow_data_inform',array('Allow_id'=>$row['ID'],'employee_id'=>$this->session->userdata('employee_id'),'user_id'=>$this->session->userdata('user_id')));
                                ?>
                                <div class="video-col-list equal-height-col" data-toggle="modal" data-target="#exampleModalCenter<?php echo $row['ID'];?>">
                                    <div class="video-card history-video">
                                        <div class="video-card-image">
                                            <a href="#"><img class="img-responsive" src="https://www.entube.in/uploads/product/videodefault4.jpg" alt="<?php echo $row['Video_Title'];?>"></a>
                                            <i class="fas fa-play-circle"></i>
                                            <div class="video-overlay"></div>
                                        </div>
                                        <div class="video-card-body">
                                            <div class="video-title">
                                                <a href="#"><?php echo $row['Video_Name'];?></a>
                                            </div>
                                            <?php if($share_data) { ?>
                                            <h6 class="sucess-txt"> Your Sharing Already Done.</h6>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <?php if($share_data>0){ ?>
                                <div class="modal fade" id="exampleModalCenter<?php echo $row['ID'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="gagan<?php echo $row['ID'];?>">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                                
                                                <video controls style="width: 100%;height: auto;" id="myAudio<?php echo $row['ID'];?>" >
                                                    <source src="<?php echo 'https://www.entube.in/'.'uploads/video/'.$row['video'];?>" type="video/mp4" >
                                                    <source src="mov_bbb.ogg" type="video/ogg">
                                                        Your browser does not support HTML5 video.
                                                </video>
                                                <!-- <center >
                                                    <p>
                                                      <a href="http://www.facebook.com/sharer.php?u=<?php echo base_url().'uploads/video/'.$row['video'];?>"  target="_blank" >
                                                        <img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" style="    width: 40px;" />
                                                    </a>
                                                       <a href="https://twitter.com/share?url=<?php echo base_url().'uploads/video/'.$row['video'];?>" target="_blank" >
                                                        <img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" style="    width: 40px;" />
                                                    </a>
                                                        <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo base_url().'uploads/video/'.$row['video'];?>" target="_blank" >
                                                        <img src="https://simplesharebuttons.com/images/somacro/linkedin.png" alt="LinkedIn" style="    width: 40px;" />
                                                    </a>
                                                    </p>
                                                </center> -->
                                                <h6 class="sucess-txt" style="text-align:center;"> Your Sharing Already Done.</h6>
                                                <div class="clrfix"></div>
                                            </div>
                                            <!--<div class="modal-footer" style="background-color:#3E4095">
                                                     <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="button" class="btn btn-primary">Save changes</button> 
                                            </div>-->
                                        </div>
                                    </div>
                                </div>
                                <?php }
                                else{ ?>
                                    <div class="modal fade" id="exampleModalCenter<?php echo $row['ID'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                  <!-- <h5 class="modal-title" id="exampleModalLongTitle">Modal title<?php echo $row['ID'];?></h5> -->
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="gagan<?php echo $row['ID'];?>">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    
                                                    <video id="myAudio<?php echo $row['ID'];?>" controls style="width: 100%; height: auto;">
                                                        <source src="<?php echo 'https://www.entube.in/'.'uploads/video/'.$row['video'];?>" type="video/mp4" >
                                                        <source src="mov_bbb.ogg" type="video/ogg">
                                                            Your browser does not support HTML5 video.
                                                    </video>
                                                    <center id="share<?php echo $row['ID'];?>">
                                                        <form action="<?php echo site_url('E_Panelist_page_new/My_digital_money_sub_panel_9');?>" method="post" id="insertform<?php echo $row['ID'];?>">
                                                            <input type="hidden" name="employee_id" value="<?php echo $this->session->userdata('employee_id');?>">
                                                            <input type="hidden" name="user_id" value="<?php echo $this->session->userdata('user_id');?>">
                                                            <input type="hidden" name="Link" value="<?php echo base_url().'uploads/video/'.$row['video'];?>">
                                                            <input type="hidden" name="Allow_id" value="<?php echo $row['ID'];?>">
                                                            <input type="hidden" name="account_type" value="<?php echo $this->session->userdata('account_type');?>">
                                                            <input type="hidden" name="username" value="<?php echo $this->session->userdata('username');?>">
                                                            <input type="hidden" name="money" value="100">
                                                            <input type="hidden" name="Panel_type" value="entube_Sub_panel_9">
                                                            <label class="input-label">Caption Code</label>
                                                            <input type="text" name="caption" class="form-control input-textbox" value="<?php echo $row['caption_code'];?>" readonly="">
                                                            <button type="submit" id="button<?php echo $row['ID'];?>"  class="btn btn-primary form-control submit-btn">Submit</button>
                                                        </form>
                                                    </center>
                                                    <div class="clrfix"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>

                                <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/jquery/jquery.min.js"></script>



<script>
  $(document).ready(function () {
    // body...
    $("#share<?php echo $row['ID'];?>").hide();
});
  var aud = document.getElementById("myAudio<?php echo $row['ID'];?>");
  aud.onended = function() {
  // alert();
  $("#share<?php echo $row['ID'];?>").show();
};
</script>



<script type="text/javascript">
  $(document).ready(function () {
    // body...
    $("#modal<?php echo $row['ID'];?>").hide();
    var cnt<?php echo $row['ID'];?>=0;
    $(".pop<?php echo $row['ID'];?>").click(function () {
      // body...
      cnt<?php echo $row['ID'];?>=parseInt(cnt<?php echo $row['ID'];?>)+parseInt(1);
      // alert(cnt<?php echo $row['ID'];?>);
      if (cnt<?php echo $row['ID'];?>>=2) {

        $("#myModal<?php echo $row['ID'];?>").modal();
    }else{

    }
});
});
</script>
<div class="modal fade" id="myModal<?php echo $row['ID'];?>" role="dialog" style="margin-top: 10.5%;width: 100%">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          <!-- <h4 class="modal-title">Modal Header</h4> -->
          <p style="color: red">NOTE:-With the help of caption code we will track you share information and if you not Share link then May Be We reduce you Wallet Amount.</p>
      </div>
      <div class="modal-body">
          <form action="<?php echo site_url('E_Panelist_page_new/My_digital_money_sub_panel_9');?>" method="post" id="insertform<?php echo $row['ID'];?>">
            <input type="hidden" name="employee_id" value="<?php echo $this->session->userdata('employee_id');?>">
            <input type="hidden" name="user_id" value="<?php echo $this->session->userdata('user_id');?>">
            <input type="hidden" name="Link" value="<?php echo base_url().'uploads/video/'.$row['video'];?>">
            <input type="hidden" name="Allow_id" value="<?php echo $row['ID'];?>">
            <input type="hidden" name="account_type" value="<?php echo $this->session->userdata('account_type');?>">
            <input type="hidden" name="username" value="<?php echo $this->session->userdata('username');?>">
            <input type="hidden" name="money" value="100">
            <input type="hidden" name="Panel_type" value="entube_Sub_panel_9">
            <label class="input-label">Caption Code</label>
            <input type="text" name="caption" class="form-control input-textbox" value="<?php echo $row['caption_code'];?>" readonly="">
            <button type="submit" id="button<?php echo $row['ID'];?>"  class="btn btn-primary form-control submit-btn">Submit</button>
        </form>
        <script type="text/javascript">
            $(document).ready(function () {
              // body...
              // alert();
              
              $( "#button<?php echo $row['ID'];?>" ).click(function() {
                 $("#button<?php echo $row['ID'];?>").hide();
             });

          });
      </script>
  </div>
  <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  </div>
</div>

</div>
</div>



<script>
  // var vid = document.getElementById("myAudio<?php echo $row['ID'];?>"); 
// $("#exampleModalCenter<?php echo $row['ID'];?>").on("hidden.bs.modal", function () {

//     // $("#myAudio<?php echo $row['ID'];?>").get(0).pause();
//     alert();

// });
$(document).ready(function () {
  // body...
  $("#gagan<?php echo $row['ID'];?>").click(function () {
    // body...
    $("#myAudio<?php echo $row['ID'];?>")[0].pause();
});
//   $("#gagan123<?php echo $row['ID'];?>").click(function () {
//     // body...
//     $("#myAudio<?php echo $row['ID'];?>")[0].pause();
//   });
});
</script>







<?php }?>


</div>
             <!--      <nav aria-label="Page navigation example">
                     <ul class="pagination justify-content-center pagination-sm mb-0">
                        <li class="page-item disabled">
                           <a class="page-link" href="#" tabindex="-1">Previous</a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                           <a class="page-link" href="#">Next</a>
                        </li>
                     </ul>
                 </nav> -->
             </div>


         </div>
     </div>
     <!-- /.content-wrapper -->
 </div>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
     <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
      </button>
  </div>
  <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
  <div class="modal-footer">
      <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
      <a class="btn btn-primary" href="login.html">Logout</a>
  </div>
</div>
</div>
</div>
<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
<!-- Bootstrap core JavaScript-->
<!--<script src="<?php echo base_url();?>js/jquery.min.js"></script>-->
<script src="<?php echo base_url();?>js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo base_url();?>js/jquery.easing.min.js"></script>
<!-- Owl Carousel -->
<script src="<?php echo base_url();?>js/owl.carousel.js"></script>
<!-- Custom scripts for all pages-->
<script src="<?php echo base_url();?>js/custom.js"></script>
</section>
    </div>
    <!-- end Container -->