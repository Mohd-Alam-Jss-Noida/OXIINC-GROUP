<?Php $this->load->view('new_user/customise_header');?>
<!-- Tab panes -->
<div class="tab-content">
	<!-- Start Discussion Tab -->
	<div>
		<div class="tab-container fwd">
			<div class="left-content left-block">
				<a href="<?php echo base_url("Entube_channel/discussion/".$this->uri->segment(3));?>" class="back-btn"><i class="fas fa-long-arrow-alt-left"></i></a>
                <div class="tab-title">Channel Discussion</div>
                <hr class="devider-line-hr-02">
				<div class="containt-block" style="padding: 0px !important;">
					<div id="discussion_success_msg" class="success_message" style="display:none;"></div>
					<?php if($this->session->flashdata('discussion_msg')) { ?>
						<div id="flash_msg" class="success_message"><?php echo $this->session->flashdata('discussion_msg');?></div>
                	<?php } ?>
					<div class="col-left fwd">
						<span><?php echo (isset($discussion_count) && !empty($discussion_count)) ? $discussion_count." Comments" : "0 Comment" ?></span>
					</div>
					<div class="col-left space-left col-3-full" id="add_discussion">
						<span class="video-user-icon">
							<?php if($this->session->userdata('entube_customer_logged_in')){ ?>
								<img src="<?php echo $this->session->userdata('profileImage');?>" class="img-responsive" alt="" style="width: 40px; height: 40px;" />
							<?php } elseif($custumer_details['photo']){ ?>
								<img src="<?php echo base_url("uploads/Customer_pan/".$custumer_details['photo']);?>" class="img-responsive" alt="" style="width: 40px; height: 40px;"/>
							<?php } else{ ?>
								<img src="<?php echo base_url('new_user_assets/images/chanel-img.jpg');?>" class="img-responsive" alt="" style="width: 40px; height: 40px;"/>
							<?php } ?>
						</span>
						<form class="form-horizontal">
							<textarea class="video-textareabox" id="cha_discussion" placeholder="Add a public comment..." rows="2" style="resize: none;"></textarea>
							<button type="reset" class="video-submitbtn">Cancel</button>
							<button type="button" class="video-submitbtn" id="comment_disable" onclick="submit_discussion('<?php echo $this->uri->segment(3);?>');">Comment</button>
							<div id="discussion_error_msg" class="error_message" style="display:none; width: 78% !important;"></div>
						</form>    
					</div>
					<?php if(isset($discussion_details) && !empty($discussion_details)) foreach ($discussion_details as $key=>$value){
					
					$sql_query = $this->db->query('SELECT id, photo, channel_name, user_name, last_name FROM custumer_login WHERE id = "'.$value['comment_id'].'" AND status = 1');
		            $sql_query1 = $this->db->query('SELECT id, channel_name FROM custumer_channel WHERE user_id = "'.$value['comment_id'].'" AND status = 1');
		            $custumer_details = $sql_query->result_array();
					$channel_details = $sql_query1->result_array();
					?>
					<div class="col-left space-left user-comment-col">
					<?php
						if($custumer_details){
							if($custumer_details[0]['photo']){ ?>
								<img src="<?php echo base_url("uploads/Customer_pan/".$custumer_details[0]['photo']);?>" class="video-user-icon2" alt=""/>
							<?php }
						} elseif($this->session->userdata('entube_customer_logged_in')){ ?>
							<img src="<?php echo $this->session->userdata('profileImage');?>" class="video-user-icon2" alt=""/>
						<?php }
						else{ ?>
							<img src="<?php echo base_url('new_user_assets/images/chanel-img.jpg');?>" class="video-user-icon2" alt="" />
						<?php }
						if($channel_details && ($channel_details[0]['channel_name'])) { ?>
                        	<a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $channel_details[0]['channel_name'];?></span></a>
                        <?php }
                        elseif ($custumer_details && ($custumer_details[0]['channel_name'])) { ?>
                            <a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $custumer_details[0]['channel_name'];?></span></a>
                        <?php }
                        elseif ($custumer_details && ($custumer_details[0]['user_name'])) { ?>
                            <a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $custumer_details[0]['user_name']." ".$custumer_details[0]['last_name'];?></span></a>
                        <?php }
                        elseif ($this->session->userdata('name')) { ?>
                            <a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $this->session->userdata('name');?></span></a>
                        <?php }
                        else{ ?>
                            <span class="title-05 fwd"><?php echo "OXIINC GROUP";?></span>
                        <?php }
                    	?>
						<span class="title-06 fwd"><?php echo $value['discussion']?></span>
						<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
						<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
						<div class="dropdown video-login-popup video-login-popup2 cust-discussion">
							<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								<ul class="dropdown-menu">
									<li><a href="javascript:void(0);" onclick="update_discussion('<?php echo $value['id']?>');">Edit</a></li>
									<li><a href="<?php echo base_url('Entube_channel/delete_channel_discussion/'.$value['id'])?>">Delete</a></li>
								</ul>
						</div>
					</div>
					<form class="form-horizontal" action="<?php echo base_url('Entube_channel/update_customise_discussion');?>" id="discussion_block_<?php echo $value['id']?>" method="POST" onsubmit="return comment_discussion('<?php echo $value['id']?>');" style="display: none;">
						<textarea class="video-textareabox" name="update_cha_discussion" id="update_cha_discussion_<?php echo $value['id']?>" placeholder="Add a public comment..." rows="2" autofocus style="resize: none;" ><?php echo $value['discussion']?></textarea>
						<input type="hidden" name="id" value="<?php echo $value['id']?>">
						<input type="hidden" name="user_id" value="<?php echo $value['user_id']?>">
						<input type="hidden" name="comment_id" value="<?php echo $value['comment_id']?>">
						<button type="reset" class="video-submitbtn" onclick="cancel_discussion('<?php echo $value['id']?>');">Cancel</button>
						<button type="submit" class="video-submitbtn">Comment</button>
						<div id="update_cd_error_<?php echo $value['id']?>" class="error_message" style="display:none; width: 78% !important;"></div>
					</form>
					<?php } else{ ?>
				  		<p class="text-center">This channel has no discussion.</p>
					<?php } ?>
				</div>
			</div>
			<!-- <div class="right-content right-block">
				<div class="tab-title">Featured channels</div>
				<div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div>
			</div> -->
		</div>
	</div>
</div>
	</div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	function submit_discussion(argument){
		var cha_discussion = $.trim($("#cha_discussion").val());
        if(cha_discussion == ""){
        	$("#discussion_error_msg").css({"display": "block"}).html("Please enter your channel discussion.");
        	return false;
        }
        else{
        	$.ajax({
        		url: "<?php echo base_url('Entube_channel/insert_customise_discussion');?>",
        		type: "POST",
        		data: 'id=' + argument + '&cha_discussion=' + cha_discussion,
        		dataType:"text",
        		cache: false,
	        	beforeSend: function(){
	        		$("#comment_disable").text('Sending .....').prop('disabled', true);
	        	},
	        	complete: function(){
	        		//alert("Sending successfully.");
   				},
        		success: function(data){
                    //alert(data);
                    if (data){
                    	$("#discussion_error_msg").css({"display": "none"});
                    	$("#discussion_success_msg").css({"display": "block"}).html("Channel discussion Added successfully.");
                    	setTimeout(function() {
                        	window.location.href = "<?php echo base_url('Entube_channel/customise_discussion/')?>" +argument;
                    	}, 3000 );
                    }
                    else{
                    	$("#discussion_success_msg").css({"display": "none"});
                    	$("#discussion_error_msg").css({"display": "block"}).html("Add channel discussion failed.");
                    }
                },
                error: function () {
                	alert("Something went wrong please try again.");
                	$("#discussion_success_msg").css({"display": "none"});
                	$("#discussion_error_msg").css({"display": "block"}).html("Add channel discussion failed.");
                }
            });
        }
        return false;
    }

    function update_discussion(argument){
    	//alert(argument);
        $('#discussion_block_'+argument).css('display','block');
        $('#add_discussion').css('display','none');
        $('#update_cha_discussion_'+argument).focus();
    }
    function cancel_discussion(argument){
    	//alert(argument);
        $('#discussion_block_'+argument).css('display','none');
        $('#add_discussion').css('display','block');
    }
    function comment_discussion(argument){
		var update_cha_discussion = $.trim($("#update_cha_discussion_"+argument).val());
        if(update_cha_discussion == ""){
        	$("#update_cd_error_"+argument).css({"display": "block"}).html("Please enter your channel discussion.");
        	return false;
        }
    }
</script>