    <!-- Start Container -->
    <div class="main-wrapper">
        <section class="video-detail-page">
            <div class="row">
                <div class="container-fluid large-devise-screen">
                    <div class="my-channel-section-01 guest-profile-section-01 video-upload-section-01">
                        <div class="main-title myvws-section-01">
                            <h2 class="headding-01">Upload Video</h2>
                        </div>
                        <div class="login-form-block">
                            <form name="myForm" action="<?php echo base_url("Entube_channel/video_insert"); ?>" method="post" enctype="multipart/form-data">
                                <div class="right-block">
                                    <div class="form-group full-width-col">
                                        <input type="file" name="Multiple_Video" id="Multiple_Video" value="<?php echo set_value('Multiple_Video'); ?>" hidden="hidden" accept=".mp4, .avi, .mkv, .mov, .mwv, .3gp" autocomplete="off" onchange="upload_video_file();">
                                        <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn"><i class="fa fa-upload"></i> Upload Video</button>
                                        <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span><br><br>
                                        <?php echo form_error('Multiple_Video'); ?>
                                        <div class="video-col">
                                            <img src="<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>" id="video_watermark" class="img-responsive" alt=""/>
                                            <video id="show_video_player" controls style="display: none; width:100%; margin: 0 auto;">
                                                <source type="video/mp4">
                                            </video>
                                            <video id="main_video_1" controls style="display: none; width:100%; margin: 0 auto;">
                                                <source type="video/mp4">
                                            </video>
                                            <video id="main_video_2" controls style="display: none; width:100%; margin: 0 auto;">
                                                <source type="video/mp4">
                                            </video>
                                            <video id="main_video_3" controls style="display: none; width:100%; margin: 0 auto;">
                                                <source type="video/mp4">
                                            </video>
                                            <video id="main_video_4" controls style="display: none; width:100%; margin: 0 auto;">
                                                <source type="video/mp4">
                                            </video>
                                        </div>
                                        <p class="note-txt-2" id="upload_video_error" style="display:none; color: #FF0000;"></p>
                                    </div>
                                </div>
                                <div class="left-block">
                                    <div class="form-group full-width-col">
                                        <label>Video Title (required)</label>
                                        <input type="text" name="Video_Title" id="Video_Title" value="<?php echo set_value('Video_Title'); ?>" class="input-textbox input-video-title" tabindex="1" autocomplete="off" maxlength="100" placeholder="Enter Video Title" required>
                                        <div id="count_title" class="count-title">
                                            <span id="current_title" class="current-title">0</span>
                                            <span id="maximum_title" class="maximum-title">/ 100</span>
                                        </div>
                                        <?php echo form_error('Video_Title'); ?>
                                    </div>
                                    <div class="form-group full-width-col">
                                        <label>Video Description</label>
                                        <textarea name="Short_Description" id="Short_Description" class="input-textarea input-video-desc" rows="3" style="resize: none;" tabindex="2" autocomplete="off" maxlength="5000" placeholder="Tell viewers about your video" required><?php echo set_value('Short_Description');?></textarea>
                                        <div id="count_desc" class="count-title">
                                            <span id="current_desc" class="current-title">0</span>
                                            <span id="maximum_desc" class="maximum-title">/ 5000</span>
                                        </div>
                                        <?php echo form_error('Short_Description'); ?>
                                    </div>
                                    <div class="form-group full-width-col">
                                        <label>Thumbnail</label>
                                        <p class="note-txt">Select or upload a picture that shows what's in your video. A good thumbnail stands out and draws viewers' attention.</p>
                                        <input type="file" name="Multiple_image" id="Multiple_image" value="<?php echo set_value('Multiple_image'); ?>" hidden="hidden" accept=".png, .jpg, .jpeg" autocomplete="off" onchange="upload_image_file();" />
                                        <button type="button" id="upload-image-btn" class="cust-channel-btn upload-video-btn" tabindex="3"><i class="fa fa-upload"></i> Upload Thumbnail</button>
                                        <span id="upload-image-text" class="upload-video-text">No file chosen, yet.</span>
                                        <p class="note-txt-2" style="margin-top: 8px;">Note: size : 400 * 230 and Max resolution : 2MB</p>
                                        <div class="all-video-image">
                                            <ul class="list-inline thumb-list">
                                                <li class="thumb-selected-img equal-height-col">
                                                    <img src="<?php echo base_url('new_user_assets/images/video-img/thumbnail-watermark.png'); ?>" id="compress_image" class="remove_selected_thumb img-responsive" />
                                                </li>
                                                <li class="equal-height-col">
                                                    <img src="<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>" id="video_thumbnail_1" class="remove_selected_thumb img-responsive" />
                                                </li>
                                                <li class="equal-height-col">
                                                    <img src="<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>" id="video_thumbnail_2" class="remove_selected_thumb img-responsive" />
                                                </li>
                                                <li class="equal-height-col">
                                                    <img src="<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>" id="video_thumbnail_3" class="remove_selected_thumb img-responsive" />
                                                </li>
                                                <li class="equal-height-col">
                                                    <img src="<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>" id="video_thumbnail_4" class="remove_selected_thumb img-responsive" />
                                                </li>
                                            </ul>
                                            <?php echo form_error('selected_image_url'); ?>
                                            <p class="note-txt-2" id="img_thum_error" style="display:none; color: #FF0000;"></p>
                                        </div>
                                    </div>
                                    <div class="clrfix"></div>
                                    <div class="form-group full-width-col" style="display: none;">
                                        <textarea class="input-textarea" id="selected_image_url" name="selected_image_url" rows="4" cols="50" readonly></textarea>
                                    </div>

                                    <div class="form-group half-width equal-height-col">
                                        <label>Video Category</label>
                                        <select name="category_id" id="category_id" class="input-textbox input-selectbox" tabindex="4" autocomplete="off" required>
                                            <option value="">Select Video Category</option>
                                            <?php foreach ($get_category as $key => $value) {?>
                                            <option value="<?php echo $value['category_id'];?>"> <?php echo $value['category_name'];?></option>
                                            <?php } ?>
                                        </select>
                                        <?php echo form_error('category_id'); ?>
                                    </div>
                                    <div class="form-group half-width equal-height-col">
                                        <label>Video Playlists</label>
                                        <select name="video_playlist" id="video_playlist" class="input-textbox input-selectbox" tabindex="5" autocomplete="off">
                                            <option value="">Select Video Playlists</option>
                                            <?php
                                            if (isset($playlist_details) && !empty($playlist_details)){
                                                foreach ($playlist_details as $key => $value){ ?>
                                                    <option value="<?php echo $value['ID']; ?>" <?php echo set_select('video_playlist',  $value['ID']); ?>><?php echo $value['playlistname']; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group half-width equal-height-col">
                                        <label>Video Audience</label>
                                        <select name="video_audience" id="video_audience" class="input-textbox input-selectbox" tabindex="6" autocomplete="off" required>
                                            <option value="">Select Video Audience</option>
                                            <option value="All"<?php echo set_select('video_audience', 'All'); ?>>All</option>
                                            <option value="adult"<?php echo set_select('video_audience', 'adult'); ?>>Above 18 years</option>
                                        </select>
                                        <?php echo form_error('video_audience'); ?>
                                    </div>
                                    <div class="form-group half-width equal-height-col">
                                        <label>Video Visibility</label>
                                        <select name="video_visibility" id="video_visibility" class="input-textbox input-selectbox" tabindex="7" autocomplete="off" required>
                                            <option value="">Select Video Visibility</option>
                                            <option value="Public"<?php echo set_select('video_visibility', 'Public'); ?>>Public</option>
                                            <option value="Private"<?php echo set_select('video_visibility', 'Private'); ?>>Private</option>
                                        </select>
                                        <?php echo form_error('video_visibility'); ?>
                                    </div>
									
                                    <div class="form-group full-width-col add-hash-tag-col">
									   <label>Video Hashtag (Optional)</label>
									   <p class="note-txt-2">Note: Add Enter after each hashtag</p>
									   <input type="text" name="video_hashtag" id="video_hashtag" class="input-textarea" data-role="tagsinput" tabindex="8">
									</div>	
									<div class="clrfix"></div>
                                    <div class="form-group full-width-col center-align-btn">
                                        <button type="submit" name="save_video" value="save_draft" class="input-submitbtn" tabindex="10">Save Draft</button>
                                        <button type="submit" name="save_video" value="publish" class="input-submitbtn" tabindex="9">Publish</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="clrfix"></div>
    </div>
    <!-- End Container -->

<!-- GENERATE VIDEO THUMBNAUL IMAGE JAVASCRIPT CODE -->
<script type="text/javascript">
    var play_video_obj = document.getElementById("show_video_player");

    var video_obj_1 = document.getElementById("main_video_1");
    var canvas_1 = document.createElement("canvas");
    var cts_img_1 = canvas_1.getContext("2d");
    
    var video_obj_2 = document.getElementById("main_video_2");
    var canvas_2 = document.createElement("canvas");
    var cts_img_2 = canvas_2.getContext("2d");
    
    var video_obj_3 = document.getElementById("main_video_3");
    var canvas_3 = document.createElement("canvas");
    var cts_img_3 = canvas_3.getContext("2d");
    
    var video_obj_4 = document.getElementById("main_video_4");
    var canvas_4 = document.createElement("canvas");
    var cts_img_4 = canvas_4.getContext("2d");
    
    image_width = 400;
    image_height = 230;
    
    function upload_video_file(){

        //VIDEO FILE TYPE VALIDATION
        var validVideoTypes = ['video/mp4', 'video/avi', 'video/mkv', 'video/mov', 'video/mwv', 'video/3gp'];
        var file_name = document.querySelector("#Multiple_Video").files[0];
        if(!validVideoTypes.includes(file_name.type.toLowerCase())){
            alert('Please select correct video formate, e.g. - mp4, avi, mkv, mov, mwv, 3gp.');
            $('#show_video_player').css('display','none');
            $('#video_watermark').css('display','block');
            $(".remove_selected_thumb").removeClass("selected-thumb");
            document.getElementById('Multiple_Video').value = '';
            document.getElementById('selected_image_url').value = '';
            document.getElementById("compress_image").src = '<?php echo base_url('new_user_assets/images/video-img/thumbnail-watermark.png'); ?>';
            document.getElementById("video_thumbnail_1").src = '<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>';
            document.getElementById("video_thumbnail_2").src = '<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>';
            document.getElementById("video_thumbnail_3").src = '<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>';
            document.getElementById("video_thumbnail_4").src = '<?php echo base_url('new_user_assets/images/video-img/video-watermark.png'); ?>';
            $('#upload_video_error').css('display','block').html('Please select correct video formate, e.g. - mp4, avi, mkv, mov, mwv, 3gp.');
            return false;
        }

        $('#upload_video_error').css('display','none');
        $('#img_thum_error').css('display','none');

        default_play_video();
        video_image_1();
        video_image_2();
        video_image_3();
        video_image_4();
    }

    function default_play_video(){
        play_video_obj.load();
        video_watermark.style.display = 'none';
        play_video_obj.style.display = 'block';
        document.querySelector("#show_video_player source").setAttribute('src', URL.createObjectURL(document.querySelector("#Multiple_Video").files[0]));
    }
    
    function video_image_1(){
        video_obj_1.load();
        document.querySelector("#main_video_1 source").setAttribute('src', URL.createObjectURL(document.querySelector("#Multiple_Video").files[0]));
        canvas_1.width = image_width;
        canvas_1.height = image_height;
        video_obj_1.onloadedmetadata = function() {
            var video_duration_1 = video_obj_1.duration;
            video_duration_1 = (video_duration_1 * 25)/100;
            video_obj_1.currentTime = video_duration_1;
            setTimeout(function(){
                cts_img_1.drawImage(video_obj_1, 0, 0, video_obj_1.videoWidth, video_obj_1.videoHeight, 0, 0, canvas_1.width, canvas_1.height);
                document.getElementById("video_thumbnail_1").src = canvas_1.toDataURL();
                $(".remove_selected_thumb").removeClass("selected-thumb");
                $("#video_thumbnail_1").addClass("selected-thumb");
                document.querySelector("#show_video_player").setAttribute('poster', canvas_1.toDataURL());
                document.getElementById('selected_image_url').value = canvas_1.toDataURL();
            }, 3000);
        }
    }
    
    function video_image_2(){
        video_obj_2.load();
        document.querySelector("#main_video_2 source").setAttribute('src', URL.createObjectURL(document.querySelector("#Multiple_Video").files[0]));
        canvas_2.width = image_width;
        canvas_2.height = image_height;
        video_obj_2.onloadedmetadata = function() {
            var video_duration_2 = video_obj_2.duration;
            video_duration_2 = (video_duration_2 * 50)/100;
            video_obj_2.currentTime = video_duration_2;
            setTimeout(function(){
                cts_img_2.drawImage(video_obj_2, 0, 0, video_obj_2.videoWidth, video_obj_2.videoHeight, 0, 0, canvas_2.width, canvas_2.height);
                document.getElementById("video_thumbnail_2").src = canvas_2.toDataURL();
            }, 3000);
        }
    }
    
    function video_image_3(){
        video_obj_3.load();
        document.querySelector("#main_video_3 source").setAttribute('src', URL.createObjectURL(document.querySelector("#Multiple_Video").files[0]));
        canvas_3.width = image_width;
        canvas_3.height = image_height;
        video_obj_3.onloadedmetadata = function() {
            var video_duration_3 = video_obj_3.duration;
            video_duration_3 = (video_duration_3 * 75)/100;
            video_obj_3.currentTime = video_duration_3;
            setTimeout(function(){
                cts_img_3.drawImage(video_obj_3, 0, 0, video_obj_3.videoWidth, video_obj_3.videoHeight, 0, 0, canvas_3.width, canvas_3.height);
                document.getElementById("video_thumbnail_3").src = canvas_3.toDataURL();
            }, 3000);
        }
    }
    
    function video_image_4(){
        video_obj_4.load();
        document.querySelector("#main_video_4 source").setAttribute('src', URL.createObjectURL(document.querySelector("#Multiple_Video").files[0]));
        canvas_4.width = image_width;
        canvas_4.height = image_height;
        video_obj_4.onloadedmetadata = function() {
            var video_duration_4 = video_obj_4.duration;
            video_duration_4 = (video_duration_4 * 95)/100;
            video_obj_4.currentTime = video_duration_4;
            setTimeout(function(){
                cts_img_4.drawImage(video_obj_4, 0, 0, video_obj_4.videoWidth, video_obj_4.videoHeight, 0, 0, canvas_4.width, canvas_4.height);
                document.getElementById("video_thumbnail_4").src = canvas_4.toDataURL();
            }, 3000);
        }
    }

    $(document).ready(function(){
        $('.remove_selected_thumb').click(function(){
            var image_url = $(this).attr('src');
            var url_parts = image_url.split('/');
            if (url_parts[2] != 'entube.in') {
                document.querySelector("#show_video_player").setAttribute('poster', image_url);
                document.getElementById('selected_image_url').value = image_url;
                $(".remove_selected_thumb").removeClass("selected-thumb");
                $(this).addClass("selected-thumb");
                $('#img_thum_error').css('display','none');
            }
        });
    });
</script>

<!-- COMPRESS IMAGE JAVASCRIPT CODE -->
<script type="text/javascript">
    function upload_image_file(){
        var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var uploadFile = document.getElementById("Multiple_image").files[0];

        if ($.inArray(uploadFile.type.toLowerCase(), validImageTypes) < 0){
            alert("Wrong Image Formate? Please select correct image formate, e.g. - png, jpg, jpeg.");
            $("#compress_image").removeClass("selected-thumb");
            document.getElementById("compress_image").src = '<?php echo base_url('new_user_assets/images/video-img/thumbnail-watermark.png'); ?>';
            document.querySelector("#show_video_player").setAttribute('poster', canvas_1.toDataURL());
            document.getElementById('selected_image_url').value = canvas_1.toDataURL();
            document.getElementById("upload-image-text").innerHTML = "No file chosen, yet.";
            document.getElementById("Multiple_image").value = '';
            $('#img_thum_error').css('display','block').html('Wrong Image Formate? Please select correct image formate, e.g. - png, jpg, jpeg.');
            return false;
        }
        fileReader.readAsDataURL(uploadFile);
    
        fileReader.onload = function (event) {
            var image = new Image();
            image.onload=function(){
                if(this.width <= image_width && this.height <= image_height){
                    var canvas = document.createElement("canvas");
                    var context = canvas.getContext("2d");
                    canvas.width = image_width;
                    canvas.height = image_height;
                    context.drawImage(image, 0, 0, image.width, image.height, 0, 0, canvas.width, canvas.height);
                    document.getElementById("compress_image").src = canvas.toDataURL();
                    document.querySelector("#show_video_player").setAttribute('poster', canvas.toDataURL());
                    document.getElementById('selected_image_url').value = canvas.toDataURL();
                    $('#img_thum_error').css('display','none');
                    $(".remove_selected_thumb").removeClass("selected-thumb");
                    $("#compress_image").addClass("selected-thumb");
                }
                else{
                    alert("Uploaded image not valid Height and Width.\nNote: Max Height and Width : 400 * 230");
                    $("#compress_image").removeClass("selected-thumb");
                    document.getElementById("compress_image").src = '<?php echo base_url('new_user_assets/images/video-img/thumbnail-watermark.png'); ?>';
                    document.querySelector("#show_video_player").setAttribute('poster', canvas_1.toDataURL());
                    document.getElementById('selected_image_url').value = canvas_1.toDataURL();
                    document.getElementById("upload-image-text").innerHTML = "No file chosen, yet.";
                    document.getElementById("Multiple_image").value = '';
                    $('#img_thum_error').css('display','block').html('Uploaded image not valid Height and Width. Note: Max Height and Width : 400 * 230');
                    return false;
                }
            }
            image.src = event.target.result;
        }
    }
</script>

<!-- VIDEO FILE AND IMAGE FILE UPLOAD BUTTON JAVASCRIPT CODE -->
<script type="text/javascript">
    //VIDEO FILE UPLOAD BUTTON
    $(document).ready(function($){
        const realFileBtn = document.getElementById("Multiple_Video");
        const customBtn = document.getElementById("upload-video-btn");
        const customTxt = document.getElementById("upload-video-text");
    
        customBtn.addEventListener("click", function() {
            realFileBtn.click();
        });
    
        realFileBtn.addEventListener("change", function() {
            if (realFileBtn.value) {
                customTxt.innerHTML = realFileBtn.value.match(
                    /[\/\\]([\w\d\s\.\-\(\)]+)$/
                    )[1];
            } else {
                customTxt.innerHTML = "No file chosen, yet.";
            }
        });
    });
    
    //IMAGE FILE UPLOAD BUTTON
    $(document).ready(function($){
        const realFileBtn = document.getElementById("Multiple_image");
        const customBtn = document.getElementById("upload-image-btn");
        const customTxt = document.getElementById("upload-image-text");
    
        customBtn.addEventListener("click", function() {
          realFileBtn.click();
        });
    
        realFileBtn.addEventListener("change", function() {
          if (realFileBtn.value) {
            customTxt.innerHTML = realFileBtn.value.match(
              /[\/\\]([\w\d\s\.\-\(\)]+)$/
            )[1];
          } else {
            customTxt.innerHTML = "No file chosen, yet.";
          }
        });
    });
</script>

<!-- VIDEO TITLE AND VIDEO DESCRIPTION WORD COUNTER JAVASCRIPT CODE -->
<script type="text/javascript">
    $('#Video_Title').keyup(function() {
        var characterCount = $(this).val().length,
        current = $('#current_title'),
        maximum = $('#maximum_title'),
        theCount = $('#count_title');
        current.text(characterCount);

        if(characterCount <= 90) {
            current.css('color', '#008000');//GREEN
            maximum.css('color','#666');
            theCount.css('font-weight','normal');
        }
        if(characterCount >= 91) {
            current.css('color', '#FF0000');//RED
            maximum.css('color','#666');
            theCount.css('font-weight','normal');
        }
        if(characterCount >= 100) {
            current.css('color', '#8f0001');//RED
            maximum.css('color', '#8f0001');//RED
            theCount.css('font-weight','bold');
        }
    });

    $('#Short_Description').keyup(function() {
        var characterCount = $(this).val().length,
        current = $('#current_desc'),
        maximum = $('#maximum_desc'),
        theCount = $('#count_desc');
        current.text(characterCount);

        if(characterCount <= 4500) {
            current.css('color', '#008000');//GREEN
            maximum.css('color','#666');
            theCount.css('font-weight','normal');
        }
        if(characterCount >= 4501) {
            current.css('color', '#FF0000');//RED
            maximum.css('color','#666');
            theCount.css('font-weight','normal');
        }
        if(characterCount >= 5000) {
            current.css('color', '#8f0001');//RED
            maximum.css('color', '#8f0001');//RED
            theCount.css('font-weight','bold');
        }
    });  
</script>