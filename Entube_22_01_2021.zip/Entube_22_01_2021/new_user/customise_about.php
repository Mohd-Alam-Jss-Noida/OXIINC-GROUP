        <?Php $this->load->view('new_user/customise_header');
        if ($channel_details['channel_about']) {
            $channel_desc = $channel_details['channel_about'];
        }elseif ($custumer_details['about']) {
            $channel_desc = $custumer_details['about'];
        }else{
            $channel_desc = "This channel has no description.";
        }

        if ($channel_details['channel_email']) {
            $email_id = strtolower($channel_details['channel_email']);
        }elseif ($custumer_details['email_id']) {
            $email_id = strtolower($custumer_details['email_id']);
        }else{
            $email_id = "This channel has no business inquiry email.";
        }

        if ($channel_details['channel_country']) {
            $country_id = $channel_details['channel_country'];
        }elseif ($custumer_details['countries']) {
            $country_id = $custumer_details['countries'];
        }else{
            $country_id = 101;//India
        }
        $sql_query = $this->db->query('SELECT name FROM countries WHERE id='.$country_id);
        $get_country = $sql_query->result_array();
        $country_name = $get_country[0]['name'];

        $country_sql = $this->db->query("SELECT * FROM countries ORDER BY name DESC");
        $country_data = $country_sql->result_array();
        ?>
        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Start About Tab -->
            <div>
                <div class="tab-container fwd">
                    <div class="left-content left-block">
                        <a href="<?php echo base_url("Entube_channel/channel_about/".$this->uri->segment(3));?>" class="back-btn"><i class="fas fa-long-arrow-alt-left"></i></a>
                        <div class="tab-title">Channel About</div>
                        <hr class="devider-line-hr-02">
                        <div class="tab-title fwd">
                            <span class="desc-col"><i class="far fa-eye"></i> <?php echo ($custumer_watch > 0) ? $custumer_watch." views" : "0 view"; ?></span><br><br>
                            <span class="desc-col">Joined <?php if(isset($custumer_details['resigtation_year_month_data'])){ echo date("M d, Y", strtotime($custumer_details['resigtation_year_month_data']));}?></span>
                        </div>
                        <br>
                        <div class="fwd desc-full-col">
                            <div class="tab-title"><strong>Description</strong></div>
                            <div class="textarea-content fwd">
                                <p id="channel_description" style="text-align: justify; display:block;"><?php echo $channel_desc;?></p>
                                <div class="edit-btn" onclick="update_description();"><i class="fas fa-pencil-alt"></i></div>
                            </div>
                            <div class="sucess-msg-icon-banner" id="flash_msg_about" style="display:none;">About your channel description update successfully.</div>
                            <div class="containt-block edit-textarea" id="edit_description" style="display:none; margin-bottom: -40px;">
                                <form class="form-horizontal">
                                    <textarea id="desc_value" class="video-textareabox" placeholder="Add a public comment..." rows="5" required="" style="resize: none;"><?php echo $channel_desc;?></textarea>
                                    <button type="button" class="video-submitbtn" onclick="submit_description('<?php echo $user_id_upload;?>');">Done</button>
                                    <button type="button" class="video-submitbtn" onclick="cancel_description();">Cancel</button>
                                    <div id="desc_error_msg" class="sucessmsg" style="display:none; width: 80% !important;"></div>
                                </form>
                            </div>
                        </div>
                        <div class="detail-col fwd">
                            <div class="fwd desc-full-col">
                                <div class="tab-title"><strong>Details</strong></div>
                                <div class="textarea-content fwd" id="channel_business_email" style="text-align: justify;display:block; margin-bottom: 25px;">
                                    <p><strong>For business enquiries:</strong>
                                        <a href="mailto:<?php echo $email_id ?>?Subject=Hello%20Dear" target="_top"><span class="email-id" id="updated_email_id"><?php echo $email_id;?></span></a>
                                    </p>
                                    <div class="edit-btn" onclick="update_business_email();"><i class="fas fa-pencil-alt"></i></div>
                                    <div class="sucess-msg-icon-banner" id="flash_msg_email" style="display:none; width: 50% !important;">your business enquiries email update successfully.</div>
                                </div>
                                <div class="containt-block channel-country" id="edit_business_email" style="display:none; margin-bottom: 25px;">
                                    <p><strong>Update your business enquiries email:</strong> <br><br>
                                        <input type="text" name="business_email" class="video-textareabox" id="business_email" value="<?php echo $email_id;?>" required="" />
                                    </p>
                                    <button type="button" class="video-submitbtn" onclick="submit_business_email('<?php echo $user_id_upload;?>');">Done</button>
                                    <button type="button" class="video-submitbtn" onclick="cancel_business_email();">Cancel</button>
                                    <div id="business_email_error" class="sucessmsg" style="display:none; width: 61% !important;"></div>
                                </div>
                            </div>
                            <div class="fwd desc-full-col">    
                                <div class="textarea-content fwd" style="display:none;">
                                    <p><strong>Location: </strong><span class="email-id" id="change_country"><?php echo $country_name;?></span></p>
                                    <div class="edit-btn" onclick="update_country();"><i class="fas fa-pencil-alt"></i></div>
                                </div>
                                <div class="containt-block channel-country">
                                    <p><strong>Location: </strong></p><br><br>
                                    <select class="video-textareabox" id="channel_country" onchange="get_channel_country(this.value, '<?php echo $user_id_upload;?>')" required="">
                                        <option value="0">Select Country</option>
                                        <?php foreach ($country_data as $key => $value) { ?>
                                            <option value="<?php echo $value['id']; ?>"<?php if($value['id'] == $country_id){ echo "selected"; } ?>><?php echo $value['name']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <div id="chnl_cntry_error_msg" class="sucessmsg" style="display:none; width: 100% !important;"></div>
                                    <div class="sucess-msg-icon-banner" id="flash_msg_location" style="display:none;">your channel Location update successfully.</div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="containt-block">
                            <p><strong>Links:</strong></p><br>
                            <div class="cust-channel-btn add-links-btn"><i class="fas fa-plus"></i> Links</div>
                        </div> -->
                    </div>
                    <!-- <div class="right-content right-block">
                        <div class="tab-title">Featured channels</div>
                        <div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div>
                    </div> -->
                </div>
            </div>

        </div>
    </div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
    function update_description(){
        $('#channel_description').css('display','none');
        $('#edit_description').css('display','block');
    }

    function cancel_description(){
        $('#channel_description').css('display','block');
        $('#edit_description').css('display','none');
    }

    function submit_description(argument){
        var desc_value = $.trim($("#desc_value").val());
        //alert(argument);
        if(desc_value == ""){
            $("#desc_error_msg").css({"display": "block"}).html("Please enter about your channel description");
            return false;
        }
        else if(desc_value.length < "50"){
            //alert(desc_value.length);
            $("#desc_error_msg").css({"display": "block"}).html("Please enter about your channel description at least 50 characters");
            return false;
        }
        else{
            $.ajax({
                url: "<?php echo base_url('Entube_channel/update_channel_description');?>",
                type: "POST",
                data: 'id=' + argument + '&desc_value=' + desc_value,
                dataType:"text",
                success: function(data){
                    //alert(data);
                    $('#channel_description').css('display','block').html(data);
                    $('#edit_description').css('display','none');
                    $('#flash_msg_about').css('display','block');
                    setTimeout(function() {
                        $('#flash_msg_about').fadeOut();
                    }, 3000 );
                },
                error: function (xhr, textStatus, errorThrown) {
                    alert(textStatus + ':' + errorThrown);
                }
            });
        }
        return false;
    }

    function update_business_email(){
        $('#channel_business_email').css('display','none');
        $('#edit_business_email').css('display','block');
    }

    function cancel_business_email(){
        $('#channel_business_email').css('display','block');
        $('#edit_business_email').css('display','none');
    }

    function submit_business_email(argument){
        var business_email = $.trim($("#business_email").val());
        //alert(business_email);
        if(business_email == "" || business_email == "This channel has no business inquiry email."){
            $("#business_email_error").css({"display": "block"}).html("Please enter your business enquiries email");
            return false;
        }
        else if(! /(.+)@(.+){2,}\.(.+){2,}/.test(business_email)){
            $("#business_email_error").css({"display": "block"}).html("Error: Email formate not valid");
            return false;
        }
        else{
            $.ajax({
                url: "<?php echo base_url('Entube_channel/update_channel_business_email');?>",
                type: "POST",
                data: 'id=' + argument + '&business_email=' + business_email,
                dataType:"text",
                success: function(data){
                    //alert(data);
                    $('#channel_business_email').css('display','block');
                    $('#updated_email_id').html(data);
                    $('#edit_business_email').css('display','none');
                    $('#email_error_msg').css('display','none');
                    $('#flash_msg_email').css('display','block');
                    setTimeout(function() {
                        $('#flash_msg_email').fadeOut();
                    }, 3000 );
                },
                error: function (xhr, textStatus, errorThrown) {
                    alert(textStatus + ':' + errorThrown);
                }
            });
        }
        return false;
    }

    function get_channel_country(country_id, user_id_upload) {
        //alert(country_id);
        if(country_id == 0){
            $("#chnl_cntry_error_msg").css({"display": "block"}).html("Please select channel country");
            return false;
        }
        else{
            $("#chnl_cntry_error_msg").css({"display": "none"}).html("");
            $.ajax({
                url: "<?php echo base_url('Entube_channel/update_channel_country');  ?>",
                type: "POST",
                data: 'id=' + user_id_upload + '&country_id=' + country_id,
                dataType:"text",
                success: function(data){
                    //alert(data);
                    $("#change_country").html(data);
                    $('#flash_msg_location').css('display','block');
                    $('#chnl_cntry_error_msg').css('display','none');
                    setTimeout(function() {
                        $('#flash_msg_location').fadeOut();
                    }, 3000 );
                }
            })
        }
        return false;
    }
</script>