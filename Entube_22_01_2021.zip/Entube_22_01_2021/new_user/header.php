
	<header>
		<div class="row">
			<div class="container-fluid">
				<nav class="navbar navbar-default">
					<div class="container-fluid">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>

								<i class="fa fa-ellipsis-v fa-w-6"></i>
							</button>
							<div class="menu-icon">
								<img src="<?php echo base_url('new_user_assets/images/menu-icon.png');?>" alt=""/>
								<img src="<?php echo base_url('new_user_assets/images/close-icon.png');?>" alt=""/>
							</div>
							<a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/entube-logo.png');?>" class="logo-col" alt="Entube"/></a>
						</div>
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<?php if($this->session->userdata('entube_customer_logged_in') || isset($_COOKIE["epanelist_username"])){
									if (! $this->session->userdata('entube_customer_logged_in')){
										
										$this->session->set_userdata('entube_customer_logged_in', TRUE);
										$this->session->set_userdata('username', $_COOKIE["epanelist_username"]);
										$this->session->set_userdata('name', $_COOKIE["epanelist_name"]);
										$this->session->set_userdata('profileImage', $_COOKIE["epanelist_profileImage"]);
									}

									$channel_details = $this->Entube_model->get_channel_data($this->session->userdata('username'));
							        //echo "<pre>";print_r($channel_details);//die();

							        $cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? base_url('uploads/customer_channel_logo/'.$channel_details['channel_logo']) : $this->session->userdata('profileImage');

							        $cha_name = (isset($channel_details['channel_name']) && !empty($channel_details['channel_name'])) ? $channel_details['channel_name'] : $this->session->userdata('name');

							        $cha_email = $this->session->userdata('username');
								?>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
										<img src="<?php echo $cha_logo ;?>" alt="" style="width: 50px; height: 50px; border-radius: 50%;" />
									</a>
									<ul class="dropdown-menu">
										<li>
										  	<div class="login-user-detail">
												<div class="login-user-img"><img src="<?php echo $cha_logo ;?>"></div>
												<div class="login-user-info">
											  		<span><?php echo ucwords($cha_name) ;?></span>
											  		<span><?php echo strtolower($cha_email) ;?></span>
												</div>
										  	</div>
										  	<div class="clrfix"></div>
										</li>
										<li role="separator" class="divider"></li>

										<li><a href="<?php echo base_url('E_Panelist_page/E_panelist_my_profile');?>" ><i class="fas fa-fw fa-user-circle"></i>My Profile</a></li>
										<li role="separator" class="divider"></li>

										<!-- <li><a href="<?php //echo base_url('E_Panelist_page/My_Digital');?>" ><i class="fas fa-fw fa-video"></i>My VWS</a></li>
										<li role="separator" class="divider"></li> -->

										<li><a href="<?php echo base_url('E_Panelist_page_new/my_digital');?>" ><i class="fas fa-fw fa-video"></i>My VWS</a></li>
										<li role="separator" class="divider"></li>

										<li><a href="<?php echo base_url('E_Panelist_page_new/my_digital_statement');?>" ><i class="fas fa-fw fa-video"></i>My VWS Statement</a></li>
										<li role="separator" class="divider"></li>

										<li><a href="<?php echo base_url('Entube_channel/video_upload'); ?>" ><i class="fas fa-fw fa-video"></i>Creator Studio</a></li>
										<li role="separator" class="divider"></li>

										<!-- <li><a href="<?php //echo base_url("Upload_video/List_Of_Upload"); ?>" ><i class="fas fa-fw fa-video"></i>My Channel</a></li>
										<li role="separator" class="divider"></li> -->

										<li><a href="<?php echo base_url("Entube_channel/channel/".$this->session->userdata('username')); ?>" ><i class="fas fa-fw fa-video"></i>Your Channel</a></li>
										<li role="separator" class="divider"></li>

										<li><a href="<?php  echo base_url('Entube/logout');?>" ><i class="fas fa-fw fa-video"></i>Logout</a></li>
									</ul>
								</li>
								<?php } elseif($this->session->userdata('logged_in') || isset($_COOKIE["guest_user"])){
									if (! $this->session->userdata('logged_in')){
										$this->session->set_userdata('logged_in', TRUE);
										$this->session->set_userdata('id', $_COOKIE["guest_user"]);
									}

							        $channel_details = $this->Entube_model->get_channel_data_guest_user($this->session->userdata('id'));
							        //echo "<pre>";print_r($channel_details);die();

									$cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? base_url('uploads/customer_channel_logo/'.$channel_details['channel_logo']) : base_url('uploads/customer_channel_logo/channel-logo.jpg');

							        $cha_name = (isset($channel_details['channel_name']) && !empty($channel_details['channel_name'])) ? $channel_details['channel_name'] : DEFAULT_CHANNEL;

							        $cha_email=(isset($channel_details['email_id']) && !empty($channel_details['email_id'])) ? $channel_details['email_id'] : '';
									?>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
										<img src="<?php echo $cha_logo ;?>" alt="" style="width: 50px; height: 50px; border-radius: 50%;">
									</a>
									<ul class="dropdown-menu">
										<li>
										  	<div class="login-user-detail">
												<div class="login-user-img"><img src="<?php echo $cha_logo ;?>"></div>
												<div class="login-user-info">
											  		<span><?php echo ucwords($cha_name) ;?></span>
											  		<span><?php echo strtolower($cha_email) ;?></span>
												</div>
										  	</div>
										  	<div class="clrfix"></div>
										</li>
										<li role="separator" class="divider"></li>

										<!-- <li><a href="<?php //echo base_url("Customer_login_page/Customize_channel"); ?>" ><i class="fas fa-fw fa-user-circle"></i>Profile</a></li>
										<li role="separator" class="divider"></li> -->

										<li><a href="<?php echo base_url("Entube_channel/guest_profile"); ?>" ><i class="fas fa-fw fa-user-circle"></i>My Profile</a></li>
										<li role="separator" class="divider"></li>

										<li><a href="<?php echo base_url('Entube_channel/video_upload'); ?>" ><i class="fas fa-fw fa-video"></i>Creator Studio</a></li>
										<li role="separator" class="divider"></li>

										<!-- <li><a href="<?php //echo base_url("Entube/channel/".$this->session->userdata('id')); ?>" ><i class="fas fa-fw fa-video"></i>My Channel</a></li>
										<li role="separator" class="divider"></li> -->

										<li><a href="<?php echo base_url("Entube_channel/channel/".$this->session->userdata('id')); ?>"><i class="fas fa-fw fa-video"></i>Your Channel</a></li>
										<li role="separator" class="divider"></li>

										<li><a href="<?php  echo base_url('Entube/logout');?>" ><i class="fas fa-fw fa-video"></i>Logout</a></li>
									</ul>
								</li>
								<?php }else{?>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('new_user_assets/images/admin-icon.png');?>" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#" data-toggle="modal" data-target="#EPanelistloginModal"><i class="fas fa-fw fa-user-circle"></i> Login</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#" data-toggle="modal" data-target="#RegisterModal"><i class="fas fa-fw fa-user-circle"></i> Register </a></li>
									</ul>
								</li>
								<?php }?>	
								
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('new_user_assets/images/bell-icon.png');?>" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
										<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-fw fa-star "></i> Something else here</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('new_user_assets/images/message-icon.png');?>" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
										<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-fw fa-star "></i> Something else here</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('new_user_assets/images/grid-icon.png');?>" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fab fa-youtube-square"></i> Enews Media TV</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube Serial Trailer</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-video"></i> EnTube For Movie</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube For Artist</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-compact-disc"></i> EnTube Music</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube Academy</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube Gaming</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('new_user_assets/images/video-upload-icon.png');?>" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-upload"></i> Upload Your Video</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fab fa-youtube"></i> Go Live Now</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('new_user_assets/images/search-icon.png');?>" alt=""/></a>
									<ul class="dropdown-menu">
										<li>
											<form class="search-section" action="<?php echo base_url("Entube/search")?>" method="post" onsubmit="return validateSearchForm()">
												<?php
												if ($this->uri->segment(2) == 'search') {
													$video_title =  (isset($_POST['auto_search']) && !empty($_POST['auto_search'])) ? $this->security->xss_clean(trim($_POST['auto_search'])) : $this->security->xss_clean($this->uri->segment(3));
												}
												else{
													$video_title =  '';
												}
												?>
												<input type="text" class="search-textbox" name="auto_search" id="auto_search" value="<?php echo $video_title;?>" placeholder="Search for..." autocomplete="off">
												<button type="submit" class="search-btn">Submit</button>
											</form>
										</li>
									</ul>
								</li>
							</ul>
						</div>
					</div>
				</nav>
				<div class="slide-nav">
					<ul class="list-unstyled scrollbox">
						<?php
                        $panel_url = $this->uri->segment(2);
                        if ($panel_url == 'my_digital' || $panel_url == 'panel' || $panel_url == 'sub_panel_1' || $panel_url == 'sub_panel_2' || $panel_url == 'sub_panel_3' || $panel_url == 'sub_panel_4' || $panel_url == 'sub_panel_5' || $panel_url == 'sub_panel_6' || $panel_url == 'sub_panel_7' || $panel_url == 'sub_panel_8' || $panel_url == 'sub_panel_9') { ?>
							<li class="list-title">DIGITAL MARKETING PROGRAM</li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/panel');?>"><span>Panel</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_1');?>"><span>Sub Panel 1</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_2');?>"><span>Sub Panel 2</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_3');?>"><span>Sub Panel 3</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_4');?>"><span>Sub Panel 4</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_5');?>"><span>Sub Panel 5</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_6');?>"><span>Sub Panel 6</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_7');?>"><span>Sub Panel 7</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_8');?>"><span>Sub Panel 8</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_9');?>"><span>Sub Panel 9</span></a></li>
							<li class="logout-txt"><a href="<?php echo base_url('Entube/logout');?>">LOGOUT</a></li>

						<?php }elseif($panel_url == 'my_digital_statement' || $panel_url == 'panel_statement' || $panel_url == 'sub_panel_1_statement' || $panel_url == 'sub_panel_2_statement' || $panel_url == 'sub_panel_3_statement' || $panel_url == 'sub_panel_4_statement' || $panel_url == 'sub_panel_5_statement' || $panel_url == 'sub_panel_6_statement' || $panel_url == 'sub_panel_7_statement' || $panel_url == 'sub_panel_8_statement' || $panel_url == 'sub_panel_9_statement' || $panel_url == 'serach_My_entube_report'){?>	

							<li class="list-title">DIGITAL MARKETING PROGRAM</li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/panel_statement');?>"><span>Panel</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_1_statement');?>"><span>Sub Panel 1 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_2_statement');?>"><span>Sub Panel 2 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_3_statement');?>"><span>Sub Panel 3 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_4_statement');?>"><span>Sub Panel 4 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_5_statement');?>"><span>Sub Panel 5 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_6_statement');?>"><span>Sub Panel 6 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_7_statement');?>"><span>Sub Panel 7 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_8_statement');?>"><span>Sub Panel 8 Statement</span></a></li>
							<li><a href="<?php echo base_url('E_Panelist_page_new/sub_panel_9_statement');?>"><span>Sub Panel 9 Statement</span></a></li>
							<li class="logout-txt"><a href="<?php echo base_url('Entube/logout');?>">LOGOUT</a></li>

						<?php }else { ?>
							<li class="active-li"><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/home-icon.png');?>" alt="" class="leftmenu-icon"/><span>Home</span></a></li>

							<li><a href="<?php echo base_url('Entube/trending');?>"><img src="<?php echo base_url('new_user_assets/images/icons/trending-icon.png');?>" alt="" class="leftmenu-icon"/><span>Trending</span></a></li>

							<?php if($this->session->userdata('logged_in')){?>
								<li><a href="<?php echo base_url('Customer_login_page/Subscription_channel_information/'.$this->session->userdata('id')); ?>"><img src="<?php echo base_url('new_user_assets/images/icons/trending-icon.png');?>" alt="" class="leftmenu-icon"/><span>Subscribed channels</span></a></li>
							<?php } else if($this->session->userdata('entube_customer_logged_in') ){?>
								<li><a href="<?php echo base_url('Customer_login_page/Subscription_channel_information/'.$this->session->userdata('username')); ?>"><img src="<?php echo base_url('new_user_assets/images/icons/trending-icon.png');?>" alt="" class="leftmenu-icon"/><span>Subscribed channels</span></a></li>
							<?php }?>

							<?php if($this->session->userdata('logged_in')){?>
								<li><a href="<?php echo base_url('Customer_login_page/Subscription_channel_video/'.$this->session->userdata('id')); ?>"><img src="<?php echo base_url('new_user_assets/images/icons/trending-icon.png');?>" alt="" class="leftmenu-icon"/><span>Subscribed Video</span></a></li>
							<?php } else if($this->session->userdata('entube_customer_logged_in') ){?>
								<li><a href="<?php echo base_url('Customer_login_page/Subscription_channel_video/'.$this->session->userdata('username')); ?>"><img src="<?php echo base_url('new_user_assets/images/icons/trending-icon.png');?>" alt="" class="leftmenu-icon"/><span>Subscribed Video</span></a></li>
							<?php }?>


							<li><a href="javascript:void(0)"><img src="<?php echo base_url('new_user_assets/images/icons/library-icon.png');?>" alt="" class="leftmenu-icon"/><span>Library</span></a></li>

							<?php if($this->session->userdata('entube_customer_logged_in') || $this->session->userdata('logged_in')){ ?>
								<li><a href="<?php echo base_url("Entube/history");?>"><img src="<?php echo base_url('new_user_assets/images/icons/history-icon.png');?>" alt="" class="leftmenu-icon"/><span>History</span></a></li>
							<?php } else{ ?>
								<li><a href="javascript:void(0)" data-toggle="modal" data-target="#EPanelistloginModal"><img src="<?php echo base_url('new_user_assets/images/icons/history-icon.png');?>" alt="" class="leftmenu-icon"/><span>History</span></a></li>
							<?php } ?>	

							<?php if($this->session->userdata('entube_customer_logged_in')){ ?>
								<li><a href="<?php echo base_url("Entube/watch_later_video"); ?>"><img src="<?php echo base_url('new_user_assets/images/icons/watch-icon.png');?>" alt="" class="leftmenu-icon"/><span>Watch Later</span></a></li>
							<?php } elseif($this->session->userdata('logged_in')){ ?>
								<li><a href="<?php echo base_url("Entube/watch_later_video"); ?>"><img src="<?php echo base_url('new_user_assets/images/icons/watch-icon.png');?>" alt="" class="leftmenu-icon"/><span>Watch Later</span></a></li>
							<?php } else{ ?>
								<li><a href="javascript:void(0)" data-toggle="modal" data-target="#EPanelistloginModal"><img src="<?php echo base_url('new_user_assets/images/icons/watch-icon.png');?>" alt="" class="leftmenu-icon"/><span>Watch Later</span></a></li>
							<?php } ?>		

							<?php if($this->session->userdata('entube_customer_logged_in')){ ?>
								<li><a href="<?php echo base_url('Entube/liked_video');?>"><img src="<?php echo base_url('new_user_assets/images/icons/liked-icon.png');?>" alt="" class="leftmenu-icon"/><span>Liked Videos</span></a></li>
							<?php } elseif($this->session->userdata('logged_in')){ ?>
								<li><a href="<?php echo base_url('Entube/liked_video');?>"><img src="<?php echo base_url('new_user_assets/images/icons/liked-icon.png');?>" alt="" class="leftmenu-icon"/><span>Liked Videos</span></a></li>
							<?php } else{ ?>
								<li><a href="javascript:void(0)" data-toggle="modal" data-target="#EPanelistloginModal"><img src="<?php echo base_url('new_user_assets/images/icons/liked-icon.png');?>" alt="" class="leftmenu-icon"/><span>Liked Videos</span></a></li>
							<?php }?>	

							<li role="separator" class="divider"></li>

							<li class="list-title">Paid Subscription</li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/entube-premimum-icon.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Premium</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/entube-movies-icon.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Movies</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/entube-graming.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Gaming</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/entube-graming.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Live</span></a></li>

							<li class="list-title">Industry</li>
							<?php $category_info = $this->Model->getDataOrderBy('category',array('status'=>'1'),'category_name','ASC');;?>
							<?php  $i=0; if(isset($category_info) && !empty($category_info)) foreach ($category_info as $categoryss) {?>
								<li><a href="<?php echo base_url('Category/'.$categoryss['seo_category_name']."/"). $categoryss['category_id'];?>"><img src="<?php echo base_url("uploads/menu_icons/".$categoryss['photo']); ?>" alt="<?php echo ucfirst($categoryss['category_name']);?>" class="leftmenu-icon"/><span><?php echo ucfirst($categoryss['category_name']);?></span></a></li>
							<?php }?>


							<li class="list-title">More From Entube</li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/gallary-icon.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Movies</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/entube-music.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Music</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/entertainment-icon.png');?>" alt="" class="leftmenu-icon"/><span>EnTube Serials</span></a></li>

							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/gallary-icon.png');?>" alt="" class="leftmenu-icon"/><span>Gallery</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/setting-icon.png');?>" alt="" class="leftmenu-icon"/><span>Setting</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/history-icon.png');?>" alt="" class="leftmenu-icon"/><span>Report History</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/help-icon.png');?>" alt="" class="leftmenu-icon"/><span>Help</span></a></li>
							<li><a href="<?php echo base_url();?>"><img src="<?php echo base_url('new_user_assets/images/icons/feedback-icon.png');?>" alt="" class="leftmenu-icon"/><span>Send Feedback</span></a></li>
						<?php } ?>
					</ul>
				</div>
			</div>
		</div>
	</header>

	<!-- login Modal -->
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<div class="modal fade login-container" id="EPanelistloginModal" tabindex="-1" role="dialog" aria-labelledby="GuestLoginModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content login-form-block">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<img src="<?php echo base_url('new_user_assets/images/entube-logo.png');?>" alt="" class="img-responsive logo-col"/>
					<form method="post">
						<div class="form-group">
							<input type="text" name="username" id="username" value="" class="input-textbox" id="" placeholder="Enter User Name" autocomplete="off" required="">
							<div class="user_error" id="user_error_username" style="display:none;">Please Enter User Name / Email Address</div>
						</div>
						<div class="form-group">
							<input type="password" name="password" id="password"  value="" class="input-textbox" id="" placeholder="Enter Password" autocomplete="off" required="">
							<div class="pass_error" id="pass_error_password" style="display:none;">Please enter Password</div>
						</div>
						<div class="form-group">
							<div class="g-recaptcha" data-sitekey="6Lf5PaUUAAAAAOFUvXPt74TmJfpUvUpfsMoCTqZK" style="float:left; width:100%;"></div>
							<div id="desc" class="captcha_error" style="display:none;"></div>
						</div>
						<div class="clrfix"></div>
						<button onclick="validateForm(this);" type="button" class="input-submitbtn">Sign in</button>
						<button type="reset" class="input-submitbtn">Reset</button>
						<div class="sucessmsg" id="sucessmsg" style="display:none;"></div>
						<div class="error12msg" id="error12msg" style="display:none;"></div>
					</form>
					<div class="forgot-txt">
					  	<!-- <a href="#">Forgot Password?</a> -->
					  	<a onclick="new_user_register();" href="#" data-toggle="modal" data-target="#RegisterModal"></i> New User? Register </a>
			  		</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Register Modal -->
	<div class="modal fade login-container" id="RegisterModal" tabindex="-1" role="dialog" aria-labelledby="GuestLoginModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content login-form-block">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<img src="<?php echo base_url('new_user_assets/images/entube-logo.png');?>" alt="" class="img-responsive logo-col"/>
					<form id="frmadminlogin" method="post" onsubmit="return register_validation(this);" autocomplete="off">
						<div class="form-group">
							<input type="text" id="usernamesignup" name="usernamesignup" class="input-textbox" placeholder="User Name">
							<div id="name_error_msg" class="erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<input type="text" id="emailsignup" name="emailsignup" class="input-textbox" placeholder="Email Address">
							<div id="email_error_msg" class="erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<?php
							$strSql = "SELECT * FROM countries ORDER BY name ASC";
                            $countries = $this->Model->getSqlData($strSql);
                            ?>
							<select class="input-textbox input-selectbox" id="fetch_country" onchange="get_country(this.value)">
								<option value="">Select Country</option>
								<?php foreach ($countries as $key => $value) { ?>
									<option value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>
								<?php } ?>
							</select>
							<div id="country_error_msg" class="erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<select class="input-textbox input-selectbox" id="fetch_states" onchange="get_states(this.value)">
								<option value="">Select State</option>
							</select>
							<div id="state_error_msg" class="erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<select class="input-textbox input-selectbox" id="fetch_city">
								<option value="">Select City</option>
							</select>
							<div id="city_error_msg" class="erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<input type="text" id="phonesignup" class="input-textbox" maxlength="10" placeholder="Mobile Number">
							<input type="hidden" name="" id="enterisd" value="" class="input-textbox">
							<div id="phone_error_msg" class="erroemsg" style="display:none;"></div>
							<!-- <span id="isd"><i class="far fa-eye"></i></span> -->
						</div>
						<div class="form-group">
							<input type="password" id="passwordsignup" name="passwordsignup" class="input-textbox" placeholder="Your Password">
							<div id="password_error_msg" class="erroemsg" style="display:none;"></div>
							<!-- <span onclick="password_signup()"><i class="far fa-eye"></i></span> -->
						</div>
						<div class="form-group">
							<input type="password" id="passwordsignup_confirm" name="passwordsignup_confirm" class="input-textbox" placeholder="Confirm Your Password">
							<div id="password_confirm_error_msg" class="erroemsg" style="display:none;"></div>
							<!-- <span onclick="password_confirm()"><i class="far fa-eye"></i></span> -->
						</div>
						<!-- <div class="form-group">
							<div class="g-recaptcha" data-sitekey="6Lf5PaUUAAAAAOFUvXPt74TmJfpUvUpfsMoCTqZK" style="float:left; width:100%;"></div>
							<div id="captcha_error_msg" class="captcha_error" style="display:none;"></div>
						</div> -->
						<div class="clrfix"></div>

						<button type="submit" class="input-submitbtn">Sign in</button>
						<button type="reset" class="input-submitbtn">Reset</button>
						<div class="sucessmsg" id="regi_sucess" style="display:none;"></div>
						<div class="error12msg" id="regi_fail" style="display:none;"></div>
					</form>
					<!-- Otp Verfication Modal -->
					<form  id="otp_form" method="post" style="display: none;">
						<div class="form-group">
							<label>Please Enter your OTP</label>
							<input type="hidden" name="otp_phone" id="otp_phone" value="" >
                            <input type="hidden" name="otp_email" id="otp_email" value="">
							<input type="text" name="otp" id="otp" value="" class="input-textbox" placeholder="eg. 112233" autocomplete="off" >
							<div id="otp_errormsg" class="erroemsg" style="display:none;"></div>
						</div>
						<button onclick="otp_verfication_validation(this);" type="button" class="input-submitbtn">Sign up</button>
						<button onclick="resend_otp();" type="button" id="disable_otp_button" class="input-submitbtn">Resend OTP ?</button>
						<div class="sucessmsg" id="otp_sucess" style="display:none;"></div>
						<div class="error12msg" id="otp_fail" style="display:none;"></div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
<!-- login Modal Javascript code start here  -->
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
<script type="text/javascript">
	function validateForm(ele){
		var hasError=0;
		var username= jQuery("#username").val();
		var password= jQuery("#password").val();

		var response = grecaptcha.getResponse();
		//alert(response+ "++Login");
		if(response==''){
			$('#desc').html('Fill the captcha.');
			$('#desc').css('display','block');
			return false;
		}
		$('#desc').html();
		$('#desc').css('display','none');
		
		if(!username){
			$('#user_error_username').css('display','block');
			return false;
		}
		$('#user_error_username').css('display','none');
		if(!password){
			$('#pass_error_password').css('display','block');
			return false;
		}
		$('#pass_error_password').css('display','none');
		if(hasError==1){
			return false;
		}else{
			var account = {};
			account.login = {};
			account.login.user_id = jQuery("#username").val();
			account.login.password = jQuery("#password").val();
			account.login.userSubmit = username;

			var q = JSON.stringify(account);
			//alert(q);
			jQuery.ajax({
				dataType: 'json',
				type: "POST",
				url: "<?php echo site_url('Entube/sgin_process');?>",
				data: {'jsonObj' : q},
				cache: false,
				success: function(res){
					//alert(res.msg);
					//alert(res.status);
					if (res.status=='1') {
						$('#sucessmsg').css('display','block').html(res.msg); 
						$('#error12msg').css('display','none'); 
						window.location.href="<?php echo base_url();?>";
					}else if (res.status=='2') {
						$('#sucessmsg').css('display','block').html(res.msg); 
						$('#error12msg').css('display','none'); 
						window.location.href="<?php echo base_url();?>";
					}else{
						$('#sucessmsg').css('display','none'); 
						$('#error12msg').css('display','block').html(res.msg); 
					}

				}
			});
		}
		return false;
	}
</script>
<!-- login Modal Javascript code end here  -->

<!-- Register Modal Javascript code start here  -->
<script type="text/javascript">
	function get_country(argument) {
	    //alert(argument);
	    $.ajax({
	    	url: "<?php echo base_url('Fetch_values/fetch_states');  ?>",
	    	type: "POST",
	    	data:"id=" + argument,
	    	dataType:"text",
	    	success: function(data){
   				//alert(data);
   				$("#fetch_states").html(data)
   			}
		})
        $.ajax({
        	url: "<?php echo base_url('Fetch_values/country_code');  ?>",
        	type: "POST",
        	data:"id=" + argument,
        	dataType:"text",
        	success: function(data){
			   //alert(data);
			   $("#isd").html(data);
			   document.getElementById('enterisd').value=data;
  			}
		})
    }
	function get_states(argument) {
	    //alert(argument);
	    $.ajax({
	    	url: "<?php echo base_url('Fetch_values/fetch_city');  ?>",
	    	type: "POST",
	    	data:"id=" + argument,
	    	dataType:"text",
	    	success: function(data){
				//alert(data);
				$("#fetch_city").html(data)
			}
		})
	}       
	$(function () {
		$("input[id*='phonesignup']").keydown(function (event) {
			if (event.shiftKey == true) {
				event.preventDefault();
			}
			if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46 || event.keyCode == 190) {
				$("#phone_error_msg").css({"display": "none"}).html("");
			}
			else {
				event.preventDefault();
				$("#phone_error_msg").css({"display": "block"}).html("Only numbers are allowed");
			}
			if($(this).val().indexOf('.') !== -1 && event.keyCode == 190)
				event.preventDefault();

		});
	});
    function register_validation(ele){
	    var rtn = true;
	    var username= jQuery("#usernamesignup").val();
	    var email= jQuery("#emailsignup").val();
	    var country= jQuery("#fetch_country").val();
	    var states= jQuery("#fetch_states").val();
	    var city= jQuery("#fetch_city").val();
	    var phone= jQuery("#phonesignup").val();
	    var password= jQuery("#passwordsignup").val();
	    var passwordconfirm= jQuery("#passwordsignup_confirm").val();
	    var usersubmit =  'hii';
	    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		var regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/

		//var response = grecaptcha.getResponse();
	    //alert(response+ "++Register");
		/*if(response==''){
        	$("#captcha_error_msg").css({"display": "block"}).html("Please fill the captcha");
        	return false;
        }
        else {
        	$("#captcha_error_msg").css({"display": "none"}).html("");
        }*/

		if(username == ""){
			$("#name_error_msg").css({"display": "block"}).html("Please enter your user name");
			rtn = false;
		}
        else if (username.length < 6) {
            $("#name_error_msg").css({"display": "block"}).html("Error: user name should be greater than 6 characters");
            rtn = false;
        }
        else {
            $("#name_error_msg").css({"display": "none"}).html("");
        }
        if(email == ""){
			$("#email_error_msg").css({"display": "block"}).html("Please enter your email address");
			rtn = false;
		}
        else if(! /(.+)@(.+){2,}\.(.+){2,}/.test(email)){
            $("#email_error_msg").css({"display": "block"}).html("Error: Email address not valid");
            rtn = false;
        }
        else {
            $("#email_error_msg").css({"display": "none"}).html("");
        }
        if(country == ""){
			$("#country_error_msg").css({"display": "block"}).html("Please select your country");
			rtn = false;
		}
		else {
            $("#country_error_msg").css({"display": "none"}).html("");
        }
        if(states == ""){
			$("#state_error_msg").css({"display": "block"}).html("Please enter your state");
			rtn = false;
		}
        else {
            $("#state_error_msg").css({"display": "none"}).html("");
        }
        if(city == ""){
			$("#city_error_msg").css({"display": "block"}).html("Please select your city");
			rtn = false;
		}
		else {
            $("#city_error_msg").css({"display": "none"}).html("");
        }
        if(phone == ""){
			$("#phone_error_msg").css({"display": "block"}).html("Please enter your mobile number");
			rtn = false;
		}
        else if(phone.length !== 10){
            $("#phone_error_msg").css({"display": "block"}).html("Error: Mobile number must be 10 digit");
            rtn = false;
        }
        else {
            $("#phone_error_msg").css({"display": "none"}).html("");
        }
        if(password == ""){
			$("#password_error_msg").css({"display": "block"}).html("Please enter your password");
			rtn = false;
		}
        else  if(password.length < 6) {
            $("#password_error_msg").css({"display": "block"}).html("Error: password should be greater than 6 characters");
            rtn = false;
        }
        else if(!regex.test(password)) {
        	$("#password_error_msg").css({"display": "block"}).html("Error: Minimum Six characters, at least one uppercase letter, one lowercase letter and one number! and No Special Characters");
        	rtn = false;
        }
        else {
            $("#password_error_msg").css({"display": "none"}).html("");
        }
        if(passwordconfirm == ""){
			$("#password_confirm_error_msg").css({"display": "block"}).html("Please enter your confirm password");
			rtn = false;
		}
        else  if(passwordconfirm.length < 6) {
            $("#password_confirm_error_msg").css({"display": "block"}).html("Error: confirm password should be greater than 6 characters");
            rtn = false;
        }
        else if(!regex.test(passwordconfirm)) {
        	$("#password_confirm_error_msg").css({"display": "block"}).html("Error: Minimum Six characters, at least one uppercase letter, one lowercase letter and one number! and No Special Characters");
        	rtn = false;
        }
        else if(password!==passwordconfirm){
        	$("#password_confirm_error_msg").css({"display": "block"}).html("Error: Confirm Password not match");
        	rtn = false;
        }
        else {
            $("#password_confirm_error_msg").css({"display": "none"}).html("");
        }
        if (rtn == false){
        	return rtn;
        }
		else{
			var account = {};
			account.login = {};
			account.login.username = jQuery("#usernamesignup").val();
			account.login.email = jQuery("#emailsignup").val();
			account.login.phone = jQuery("#phonesignup").val();
			account.login.password = jQuery("#passwordsignup").val();
			account.login.passwordconfirm = jQuery("#passwordsignup_confirm").val();
			account.login.countries = jQuery("#fetch_country").val();
			account.login.states = jQuery("#fetch_states").val();
			account.login.cities = jQuery("#fetch_city").val();
			account.login.isd =jQuery("#enterisd").val();
			account.login.userSubmit = usersubmit;

			var q = JSON.stringify(account);
        	//alert(q);
        	jQuery.ajax({
	        	dataType: 'json',
	        	type: "POST",
	        	url: "<?php echo site_url('Entube/register_process');?>",
	        	data: {'jsonObj' : q},
	        	cache: false,
	        	beforeSend: function(){ jQuery(".btn-quirk").text('Validating ...').prop('disabled', true);},
	        	success: function(res){
	        		//alert(res.msg);
					//alert(res.status);
					jQuery(".btn-quirk").text('Sign In').prop('disabled', false);
	                if(res.status=='1') {  // Success
	                	$("#regi_sucess").css('display','block').html(res.msg); 
	                	$("#regi_fail").css('display','none');
	                	document.getElementById('frmadminlogin').reset();
	                	document.getElementById('otp_phone').value=res.phone;
	                    document.getElementById('otp_email').value=res.email;

	                   	setTimeout(function(){
	                   		$("#frmadminlogin").css('display','none');
		                	$("#otp_form").css('display','block');
		                	$('#disable_otp_button').prop('disabled', true);
		                	$('#disable_otp_button').prop('title', 'Resend OTP enable after 1 minute');
            			}, 3000);

            			setTimeout(function(){
							$('#disable_otp_button').prop('disabled', false);
							$('#disable_otp_button').prop('title', '');
						}, 60*1000);
	                }
	               else{ // Failed
	               		$("#regi_sucess").css('display','none');
	                	$("#regi_fail").css('display','block').html(res.msg);
	                }
            	}
        	});
    	}
    	return false;
    }

	function password_signup() {
		var x = document.getElementById("passwordsignup");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}
	function password_confirm() {
		var x = document.getElementById("passwordsignup_confirm");
		if (x.type === "password") {
			x.type = "text";
		} else {
			x.type = "password";
		}
	}
</script>
<!-- Register Modal Javascript code end here  -->

<!-- Otp Verfication Modal Javascript code start here  -->
<script type="text/javascript">
	function otp_verfication_validation(ele){
	    var hasError=0;
	    var phone= jQuery("#otp_phone").val();
	    var email= jQuery("#otp_email").val();
	    var otp= jQuery("#otp").val();
	    var usersubmit =  'hii';

	    if(otp==''){
        	$("#otp_errormsg").css({"display": "block"}).html("Please Enter your OTP");
        	hasError=1;
        }
        else {
        	$("#otp_errormsg").css({"display": "none"}).html("");
        }
	    
	    if(hasError==1){
	        return false;
	    }
	    else{
	    	var account = {};
	        account.login = {};
	        account.login.phone = jQuery("#otp_phone").val();
	        account.login.email = jQuery("#otp_email").val();
	        account.login.otp = jQuery("#otp").val();
	        account.login.userSubmit = usersubmit;

	        var q = JSON.stringify(account);
	        //alert(q);
	        jQuery.ajax({
	            dataType: 'json',
	            type: "POST",
	            url: "<?php echo site_url('Entube/verfication_otp');?>",
	            data: {'jsonObj' : q},
	            cache: false,
	            beforeSend: function(){ jQuery(".btn-quirk").text('Validating ...').prop('disabled', true);},
	            success: function(res){
	                //alert(res.msg);
					//alert(res.status);
	                jQuery(".btn-quirk").text('Sign In').prop('disabled', false);
	                if(res.status=='1'){ // Success
	                    $("#otp_sucess").css('display','block').html(res.msg); 
	                	$("#otp_fail").css('display','none');
	                    document.getElementById('otp_form').reset();
	                    setTimeout(function(){
	                        window.location.href = "<?php echo base_url()?>";
	                    }, 3000);
	                }
	                else{ // Failed
	                    $("#otp_sucess").css('display','none');
	                    $("#otp_fail").css('display','block').html(res.msg+ " is wrong OTP? please enter correct OTP."); 
	                }
	            },
	            error: function(){
                	alert(Failed);
        		}
	        });
	    }
	    return false;
	}
</script>
<!-- Otp Verfication Modal Javascript code end here -->

<!-- RESEND OTP Javascript code start here  -->
<script type="text/javascript">
	function resend_otp() {
		//alert("RESEND OTP");
		var account = {};
		account.login = {};
		account.login.phone = jQuery("#otp_phone").val();
		//account.login.phone = "1111111111";
		var q = JSON.stringify(account);
		//alert(q);
		jQuery.ajax({
			dataType: 'json',
			type: "POST",
			url: "<?php echo site_url('Entube/resend_otp');?>",
			data: {'jsonObj' : q},
			cache: false,
			success: function(res){
				//alert(res.msg);
				//alert(res.status);
				if (res.status=='1') {
					$("#otp_sucess").css('display','block').html(res.msg);
					$("#otp_fail").css('display','none');
					$('#disable_otp_button').prop('disabled', true);
					$('#disable_otp_button').prop('title', 'Resend OTP enable after 1 minute');
					setTimeout(function(){
						$('#disable_otp_button').prop('disabled', false);
						$('#disable_otp_button').prop('title', '');
						$("#otp_sucess").css('display','none').html("");
					}, 60*1000);
				}
				else{
					$("#otp_fail").css('display','block').html(res.msg);
					$("#otp_sucess").css('display','none');
					$('#disable_otp_button').prop('disabled', true);
					$('#disable_otp_button').prop('title', 'Resend OTP enable after 1 minute');
					setTimeout(function(){
						$('#disable_otp_button').prop('disabled', false);
						$('#disable_otp_button').prop('title', '');
						$("#otp_fail").css('display','none').html("");
					}, 60*1000);
				}
			}
		});
	}
</script>
<!-- RESEND OTP Javascript code start here  -->

<script type="text/javascript">
	function new_user_register() {
		$("#EPanelistloginModal").css('display','none');
	}
</script>

<script type="text/javascript">
	function validateSearchForm() {
		var auto_search = $("#auto_search").val();
		if (!auto_search) {
			return false;
		}
	}
</script>

