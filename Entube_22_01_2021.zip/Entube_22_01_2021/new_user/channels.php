	<?Php $this->load->view('new_user/channel_header');?>
	<!-- Tab panes -->
	<div class="tab-content">
		<!-- Start Channels Tab -->
		<div role="tabpanel" class="">
			<div class="tab-container fwd">
				<div class="tab-title">Subscribed channels</div>
				<!-- <div class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
					<ul class="dropdown-menu">
						<li><a href="#">Most popular</a></li>
						<li><a href="#">Date added (oldest)</a></li>
						<li><a href="#">Date added (newest)</a></li>
					</ul>
				</div> -->
				<ul class="list-inline video-list custchannels-video-list blcustchan-video-list">
					<?php
					if(isset($subscribe_channel) && !empty($subscribe_channel)) foreach ($subscribe_channel as $key => $value){
						$channel_details = $this->Entube_model->get_channel_data($value['channel_id']);
					    //echo "<pre>";print_r($channel_details);die();

						$cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? base_url('uploads/customer_channel_logo/'.$channel_details['channel_logo']) : base_url('uploads/customer_channel_logo/channel-logo.jpg');

				        $cha_name = (isset($channel_details['channel_name']) && !empty($channel_details['channel_name'])) ? $channel_details['channel_name'] : DEFAULT_CHANNEL;

						$channel_count = $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$value['channel_id']));
						?>
					<li>
						<div class="item-containt-col">
							<a href="<?php echo site_url('Entube_channel/channel/'.$value['channel_id'])?>" class="video-img-col">
								<img src="<?php echo $cha_logo;?>" alt=""/>
							</a>
							<div class="video-containt-col">
								<a class="video-title" href="<?php echo site_url('Entube_channel/channel/'.$value['channel_id'])?>"><?php echo $cha_name;?></a>
								<div class="video-views">
									<span><?php echo ($channel_count > 0) ? $channel_count." subscribers" : "0 subscribers"; ?></span>
									<button type="button" class="subscribe-btn" data-toggle="modal" data-target="#EPanelistloginModal">Subscribe</button>
								</div>
							</div>
						</div>
					</li>
					<?php } else{ ?>
                        <p class="text-center">This channel doesn't feature any other channels.</p>
                    <?php } ?>
				</ul>
			</div>
		</div>

	</div>
</div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->
