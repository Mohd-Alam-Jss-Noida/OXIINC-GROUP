	<!-- Start Container -->
	<div class="main-wrapper">
		<section class="video-detail-page">
			<div class="row">
				<div class="container-fluid large-devise-screen">
					<!-- Video Left Section -->
					<div class="left-container">
						<div class="containt-block">
							<section class="trending-section-02 home-video-slider history-section-01">
								<h2 class="headding-01">Watch history</h2>
								<!-- <div class="video-list-inline">
									<div class="history-date-title">Today</div>
									<div class="item equal-height-col">
										<div class="item-containt-col">
											<a href="#" class="video-img-col">
												<img src="images/video-img/img-01.jpg" class="trending-video-item-img" alt=""/>
												<i class="fas fa-play-circle"></i>
												<div class="video-overlay"></div>
											</a>
											<div class="video-containt-col">
												<div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
												<a href="#" class="video-title">#1Trending Oxiinc.in E-Commerce, B2B, B2C, Business & Service Listing Web Site with Reseller Opportunity, Etc.</a>
												<a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
												<div class="video-views">
													<span><i class="far fa-eye"></i> 6876 views</span>
													<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
												</div>
											</div>
											<span class="dropdown video-login-popup video-login-popup2">
												<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
												<ul class="dropdown-menu">
													<li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
													<li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
												</ul>
											</span>
										</div>
									</div>
									<div class="item equal-height-col">
										<div class="item-containt-col">
											<a href="#" class="video-img-col">
												<img src="images/video-img/img-02.jpg" class="trending-video-item-img" alt=""/>
												<i class="fas fa-play-circle"></i>
												<div class="video-overlay"></div>
											</a>
											<div class="video-containt-col">
												<div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
												<a href="#" class="video-title">#2Trending Oxiinc.com Consumers Empowerment on Digital media platform with digital business with Data Security System , Etc.</a>
												<a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
												<div class="video-views">
													<span><i class="far fa-eye"></i> 5100 views</span>
													<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
												</div>
											</div>
											<span class="dropdown video-login-popup video-login-popup2">
												<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
												<ul class="dropdown-menu">
													<li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
													<li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
												</ul>
											</span>
										</div>
									</div>
								</div> -->
								<div class="video-list-inline" style="width: 100%">
									<?php
									if(isset($Watch_history) && !empty($Watch_history)) foreach ($Watch_history as $key => $value) {
										if($value['channel_name']) {
							          		$channel_name = $value['channel_name'];
			                            } elseif ($value['user_id']) {
			                            	$channel_name = $value['user_id'];
			                            } else{
			                            	$channel_name = OXIINC_CHANNEL;
			                            }

			                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

			                            if($value['channel_logo']) {
			                            	$channel_logo = $value['channel_logo'];
			                            } elseif ($channel_name == OXIINC_CHANNEL) {
			                            	$channel_logo = 'oxiinc-digital-icon.png';
			                            } else{
			                            	$channel_logo = 'channel-logo.jpg';
			                            }
										?>
										<div class="history-date-title">Today</div>
										<div class="item equal-height-col">
											<div class="item-containt-col">
												<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
													<img src="<?php echo $video_image ;?>" class="trending-video-item-img" alt="" />
													<i class="fas fa-play-circle"></i>
													<div class="video-overlay"></div>
												</a>
												<div class="video-containt-col">
													<div class="chanel-img-col">
														<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
															<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
														</a>
													</div>
													<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo $value['Video_Title']; ?></a>
													<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>" class="video-channel" style="color:#fff;"><?php echo $channel_name; ?> <i class="fas fa-check-circle"></i></a>
													<div class="video-views">
														<span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
														<span><i class="far fa-calendar-alt"></i>
															<?php
											                    $FromDate = new DateTime(date("Y-m-d H:i:s"));
											                    $ToDate   = new DateTime($value['datatime']);
											                    $Interval = $FromDate->diff($ToDate);
											                    $Difference["Hours"] = $Interval->h;
											                    $Difference["Weeks"] = floor($Interval->d/7);
											                    $Difference["Days"] = $Interval->d % 7;
											                    $Difference["Months"] = $Interval->m;
											                    $Difference["minute"] = $Interval->i;
											                    $Difference["second"] = $Interval->s;
											                    $Difference["Year"] = $Interval->y;
											                    if($Difference["Year"]){
											                    echo $Difference["Year"]." "."Year";
											                    }else
											                    if($Difference["Months"]){
											                    echo $Difference["Months"]." "."Months";
											                    }else
											                    if($Difference["Weeks"]){
											                    echo $Difference["Weeks"]." "."Weeks";
											                    }else
											                    if($Difference["Days"]){
											                    echo $Difference["Days"]." "."Days";
											                    }else
											                    if($Difference["Hours"]){
											                    echo $Difference["Hours"]." "."Hours";
											                    }else
											                    if($Difference["minute"]){
											                    echo $Difference["minute"]." "."Minute";
											                    }else
											                    if($Difference["second"]){
											                    echo $Difference["second"]." "."Second";
											                    }
											                    echo " "."ago";
											                ?>
														</span>
													</div>
												</div>
												<span class="dropdown video-login-popup video-login-popup2">
													<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu">
														<li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
														<li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
													</ul>
												</span>
											</div>
										</div>
										<?php
									}
									else{ ?>
										<h2 style="text-align: center;">Watch history Video not found.</h2>
									<?php
									}
									?>
									<div id="trending_videos_load"></div>
								</div>
								<div class="clrfix space-01"></div>
								<div class="video-list-inline">
									<div class="history-date-title">3-9-2020</div>
									<div class="item equal-height-col">
										<div class="item-containt-col">
											<a href="#" class="video-img-col">
												<img src="images/video-img/img-01.jpg" class="trending-video-item-img" alt=""/>
												<i class="fas fa-play-circle"></i>
												<div class="video-overlay"></div>
											</a>
											<div class="video-containt-col">
												<div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
												<a href="#" class="video-title">#1Trending Oxiinc.in E-Commerce, B2B, B2C, Business & Service Listing Web Site with Reseller Opportunity, Etc.</a>
												<a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
												<div class="video-views">
													<span><i class="far fa-eye"></i> 6876 views</span>
													<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
												</div>
											</div>
											<span class="dropdown video-login-popup video-login-popup2">
												<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
												<ul class="dropdown-menu">
													<li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
													<li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
												</ul>
											</span>
										</div>
									</div>
									<div class="item equal-height-col">
										<div class="item-containt-col">
											<a href="#" class="video-img-col">
												<img src="images/video-img/img-02.jpg" class="trending-video-item-img" alt=""/>
												<i class="fas fa-play-circle"></i>
												<div class="video-overlay"></div>
											</a>
											<div class="video-containt-col">
												<div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
												<a href="#" class="video-title">#2Trending Oxiinc.com Consumers Empowerment on Digital media platform with digital business with Data Security System , Etc.</a>
												<a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
												<div class="video-views">
													<span><i class="far fa-eye"></i> 5100 views</span>
													<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
												</div>
											</div>
											<span class="dropdown video-login-popup video-login-popup2">
												<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
												<ul class="dropdown-menu">
													<li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
													<li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
												</ul>
											</span>
										</div>
									</div>
								</div>
								<div class="clrfix space-01"></div>
							</section>
						</div>
					</div>
					<!-- History Section -->
					<div class="right-container history-right-col">
						<form class="history-search-block">
							<button type="submit" class="search-btn">Submit</button>
							<input type="text" class="search-textbox" id="" placeholder="Search watch history">
						</form>
						<h3>History type</h3>
						<div class="radio-btn-block">
							<div class="radio">
								<label>
								<input type="radio" class="option-input radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
								Watch history
								</label>
							</div>
							<div class="radio">
								<label>
								<input type="radio" class="option-input radio" name="optionsRadios" id="optionsRadios2" value="option2">
								Search history
								</label>
							</div>
							<div class="radio">
								<label>
								<input type="radio" class="option-input radio" name="optionsRadios" id="optionsRadios3" value="option3">
								Comments
								</label>
							</div>
							<div class="radio">
								<label>
								<input type="radio" class="option-input radio" name="optionsRadios" id="optionsRadios4" value="option4">
								Community
								</label>
							</div>
							<div class="radio">
								<label>
								<input type="radio" class="option-input radio" name="optionsRadios" id="optionsRadios5" value="option5">
								Live chat
								</label>
							</div>
						</div>
						<h3><a href="#">Clear all search history</a></h3>
						<h3><a href="#">Pause search history</a></h3>
						<h3><a href="#">Manage all activity</a></h3>
					</div>
				</div>
			</div>
		</section>
	</div>
	<!-- End Container -->

