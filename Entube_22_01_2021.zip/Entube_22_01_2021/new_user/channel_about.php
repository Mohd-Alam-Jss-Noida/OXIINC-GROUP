		<?Php $this->load->view('new_user/channel_header');?>
		<!-- Tab panes -->
		<div class="tab-content">
			<!-- Start About Tab -->
			<div role="tabpanel" class="">
				<div class="tab-container fwd">
					<div class="left-content">
						<?php
	                        if ($channel_details['channel_about']) {
	                        	$channel_desc = $channel_details['channel_about'];
	                        }elseif ($custumer_details['about']) {
	                        	$channel_desc = $custumer_details['about'];
	                        }else{
	                        	$channel_desc = "This channel has no description.";
	                        }

	                        if ($channel_details['channel_email']) {
	                        	$email_id = strtolower($channel_details['channel_email']);
	                        }elseif ($custumer_details['email_id']) {
	                        	$email_id = strtolower($custumer_details['email_id']);
	                        }else{
	                        	$email_id = "This channel has no business inquiry email.";
	                        }

	                        if ($channel_details['channel_country']) {
	                        	$country_id = $channel_details['channel_country'];
	                        }elseif ($custumer_details['countries']) {
	                        	$country_id = $custumer_details['countries'];
	                        }else{
	                        	$country_id = 101;//India
	                        }
	                        $sql_query = $this->db->query('SELECT name FROM countries WHERE id='.$country_id);
                            $get_country = $sql_query->result_array();
                            $country_name = $get_country[0]['name'];
	                    ?>
						<div class="tab-title"><strong>Description</strong></div>
						<p style="text-align: justify; margin-bottom: 25px;"><?php echo $channel_desc;?></p>
                        <div class="detail-col fwd">
                            <div class="tab-title"><strong>Details</strong></div>
                            <div class="textarea-content fwd">
                                <p><strong>For business enquiries:</strong>
                                    <a href="mailto:<?php echo $email_id ?>?Subject=Hello%20Dear" target="_top"><span class="email-id"><?php echo $email_id;?></span></a>
                                </p><br><br>
                            </div>
                            <div class="textarea-content fwd">
                                <p><strong>Location: </strong><span class="email-id"><?php echo $country_name;?></span></p>
                            </div>
                        </div>
					</div>
					<div class="right-content">
						<div class="tab-title">Stats</div>
						<span class="desc-col">Joined <?php if(isset($custumer_details['resigtation_year_month_data'])){ echo date("M d, Y", strtotime($custumer_details['resigtation_year_month_data']));}?></span>
						<span class="desc-col"><i class="far fa-eye"></i> <?php echo ($custumer_watch > 0) ? $custumer_watch." views" : "0 view"; ?></span>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	</section>
	<div class="clrfix"></div>
	</div>
	<!-- End Container -->
