	<?php
		if($this->session->userdata('entube_customer_logged_in')){
			$channel_image = $this->session->userdata('profileImage');
			$channel_name = $this->session->userdata('name');
		} elseif($this->session->userdata('logged_in')){
			$channel_image = base_url('uploads/customer_channel_logo/channel-logo.jpg');
			$channel_name = DEFAULT_CHANNEL;
		}
		$channel_details = $this->Entube_model->get_channel_data($this->uri->segment(3));
	    //echo "<pre>";print_r($channel_details);die();

		$cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? base_url('uploads/customer_channel_logo/'.$channel_details['channel_logo']) : $channel_image;

		$old_cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? $channel_details['channel_logo'] : '';

		$cha_banner= (isset($channel_details['channel_banner']) && !empty($channel_details['channel_banner']) && file_exists('uploads/customer_channel_banner/'.$channel_details['channel_banner'])) ? base_url('uploads/customer_channel_banner/'.$channel_details['channel_banner']) : base_url('assets/entub.jpg');

		$old_cha_banner = (isset($channel_details['channel_banner']) && !empty($channel_details['channel_banner']) && file_exists('uploads/customer_channel_banner/'.$channel_details['channel_banner'])) ? $channel_details['channel_banner'] : '';

        $cha_name = (isset($channel_details['channel_name']) && !empty($channel_details['channel_name'])) ? $channel_details['channel_name'] : $channel_name;
	?>
	<!-- Start Container -->
	<div class="main-wrapper">
		<section class="video-detail-page">
			<div class="row">
				<div class="container-fluid large-devise-screen">
					<div class="my-channel-section-01 customise-channel-section-01">
					    <h2 class="headding-01">Customise Your Channel</h2>
					    <?php if($this->session->flashdata('msg')) { ?>
							<div class="sucess-msg-icon-banner" id="flash_msg"><?php echo $this->session->flashdata('msg');?></div>
                		<?php } ?>
						<div class="block-01 fwd">
							<div class="banner-img-col fwd">
				                <img src="<?php echo $cha_banner;?>" class="img-fluid" alt="" />
								<div class="upload-img-col">
		                            <img src="<?php echo $cha_logo;?>" class="img-col" alt=""/>
								</div>
								<div class="edit-btn" data-toggle="modal" data-target="#UploadImage"><i class="fas fa-pencil-alt"></i></div>
								<div class="edit-btn-2" data-toggle="modal" data-target="#UploadBannerImage"><i class="fas fa-pencil-alt"></i></div>
							</div>
							<!-- User Image Upload Modal -->
							<div class="modal fade login-container" id="UploadImage" tabindex="-1" role="dialog" aria-labelledby="UploadImageLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content login-form-block">
										<div class="modal-body">
											<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											<div class="fwd">
					                            <img src="<?php echo $cha_logo;?>" class="up-user-img" alt=""/>
					                        </div>
											<div class="fwd">
												<form action="<?php echo base_url("Entube_channel/update_channel_logo");?>" method="post" enctype="multipart/form-data" onsubmit="return validation_channel_icon();">
													<input type="hidden" name="old_cha_logo" value="<?php echo $old_cha_logo; ?>" class="input-textbox" readonly>
													<input type="file" name="photo" id="photo" value="" accept="image/*" hidden="hidden"/>
													<button type="button" id="channel-icon-btn" class="cust-channel-btn upload-video-btn">Upload channel Icon</button>
													<span id="channel-icon-text" class="upload-video-text">No file chosen, yet.</span>
													<button type="submit" name="submit" value="submit" class="cust-channel-btn upload-video-btn">Submit</button>
													<div id="icon_error_msg" class="erroemsg" style="display:none;"></div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- User Banner Image Upload Modal -->
							<div class="modal fade login-container" id="UploadBannerImage" tabindex="-1" role="dialog" aria-labelledby="UploadIBannerImageLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content login-form-block">
										<div class="modal-body">
											<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											<img src="<?php echo $cha_banner;?>" class="up-banner-img" alt=""/>
											<form action="<?php echo base_url("Entube_channel/update_channel_banner");?>" method="post" enctype="multipart/form-data" onsubmit="return validation_channel_banner();">
												<input type="hidden" name="old_cha_banner" value="<?php echo $old_cha_banner; ?>" class="input-textbox" readonly>
												<input type="file" name="channel_banner" id="channel_banner" accept="image/*" hidden="hidden"/>
												<button type="button" id="channel-banner-btn" class="cust-channel-btn upload-video-btn">Upload Channel Banner</button>
												<span id="channel-banner-text" class="upload-video-text">No file chosen, yet.</span>
												<button type="submit" name="submit" value="submit" class="cust-channel-btn upload-video-btn">Submit</button>
												<div id="banner_error_msg" class="erroemsg" style="display:none;"></div>
											</form>
										</div>
									</div>
								</div>
							</div>
							<div class="left-col">
								<h3><a href="<?php echo site_url('Entube_channel/channel/'.$this->uri->segment(3))?>"><span id="upd_chnl_name"><?php echo $cha_name;?></span></a></h3>
								<div class="cust-channel-btn edit-btn" title="Update your channel name" data-toggle="modal" data-target="#Edit_channel" style="margin: -7px 30px 5px 10px !important; float: left !important; font-size: 18px; padding: 0 15px;"><i class="fas fa-pencil-alt" aria-hidden="true"></i></div>
								<div id="channel_name_success" class="success_message" style="display:none; width: auto !important; margin: -3px 0px 0px 0px !important;"></div>
							</div>
							<!-- UPDATE YOUR CHANNEL NAME MODEL -->
							<div class="modal fade login-container" id="Edit_channel" tabindex="-1" role="dialog" aria-labelledby="GuestLoginModalLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content login-form-block" style="background-color: #20acc9;">
										<div class="modal-body">
											<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											<img src="<?php echo base_url('new_user_assets/images/entube-logo.png');?>" alt="" class="img-responsive logo-col"/>
											<form method="post">
												<label for="example" style="color: #fff; float: left;">Update your channel name</label>
												<div class="form-group">
													<input type="text" name="channel_name" id="channel_name" value="" class="input-textbox" id="" placeholder="Update your channel name" autocomplete="off" required="">
												</div>
												<div class="clrfix"></div>
												<button type="reset" class="input-submitbtn">Cancel</button>
												<button type="button" id="channel_btn_disable" class="input-submitbtn" onclick="submit_channel_name('<?php echo $this->uri->segment(3);?>');">Submit</button>
												<div id="channel_name_error" class="error_message" style="display:none;"></div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="block-02 fwd">
							<div class="scroller scroller-left"><i class="glyphicon glyphicon-chevron-left"></i></div>
							<div class="scroller scroller-right"><i class="glyphicon glyphicon-chevron-right"></i></div>
							<!-- Nav tabs -->
							<div class="tab-wrapper">
								<ul class="nav nav-tabs list" role="tablist">
									<li<?php if ($this->uri->segment(2) == 'customise_channel') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/customise_channel/'.$this->uri->segment(3))?>">Home</a></li>
									<li<?php if ($this->uri->segment(2) == 'customise_videos') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/customise_videos/'.$this->uri->segment(3))?>">Videos</a></li>
									<li<?php if ($this->uri->segment(2) == 'customise_playlist') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/customise_playlist/'.$this->uri->segment(3))?>">Playlist</a></li>
									<li<?php if ($this->uri->segment(2) == 'customise_channels') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/customise_channels/'.$this->uri->segment(3))?>">Channels</a></li>
									<li<?php if ($this->uri->segment(2) == 'customise_discussion') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/customise_discussion/'.$this->uri->segment(3))?>">Discussion</a></li>
									<li<?php if ($this->uri->segment(2) == 'customise_about') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/customise_about/'.$this->uri->segment(3))?>">About</a></li>
								</ul>
							</div>
							<div class="devider-col"></div>
							
							<script type="text/javascript">
								//---- Video File Upload Button
								$(document).ready(function($){
									const realFileBtn = document.getElementById("photo");
									const customBtn = document.getElementById("channel-icon-btn");
									const customTxt = document.getElementById("channel-icon-text");

									customBtn.addEventListener("click", function() {
										realFileBtn.click();
									});

									realFileBtn.addEventListener("change", function() {
										if (realFileBtn.value) {
											customTxt.innerHTML = realFileBtn.value.match(
												/[\/\\]([\w\d\s\.\-\(\)]+)$/
												)[1];
										} else {
											customTxt.innerHTML = "No file chosen, yet.";
										}
									});
								});

								//---- Image File Upload Button
								$(document).ready(function($){
									const realFileBtn = document.getElementById("channel_banner");
									const customBtn = document.getElementById("channel-banner-btn");
									const customTxt = document.getElementById("channel-banner-text");

									customBtn.addEventListener("click", function() {
										realFileBtn.click();
									});

									realFileBtn.addEventListener("change", function() {
										if (realFileBtn.value) {
											customTxt.innerHTML = realFileBtn.value.match(
												/[\/\\]([\w\d\s\.\-\(\)]+)$/
												)[1];
										} else {
											customTxt.innerHTML = "No file chosen, yet.";
										}
									});
								});
							</script>
							<script type="text/javascript">
								function validation_channel_icon(argument) {
									var photo = $("#photo").val();
									if (photo == "") {
										$("#icon_error_msg").css({"display": "block"}).html("Please Choose channel icon");
										return false;
									}
								}

								function validation_channel_banner(argument) {
									var channel_banner = $("#channel_banner").val();
									if (channel_banner == "") {
										$("#banner_error_msg").css({"display": "block"}).html("Please Choose channel banner");
										return false;
									}
								}

								function submit_channel_name(argument){
									var channel_name = $.trim($("#channel_name").val());
								    //alert(channel_name);
								    if(channel_name == ""){
								    	$("#channel_name_error").css({"display": "block"}).html("Please enter your channel name.");
								    	return false;
								    }
								    else{
								    	$.ajax({
								    		url: "<?php echo base_url('Entube_channel/update_channel_name');?>",
								    		type: "POST",
								    		data: 'id=' + argument + '&channel_name=' + channel_name,
								    		dataType:"text",
								    		cache: false,
								    		beforeSend: function(){
								    			$("#channel_btn_disable").text('Sending .....').prop('disabled', true);
								    		},
								    		complete: function(){
								    			$("#channel_btn_disable").text('Submit').prop('disabled', false);
								    		},
								    		success: function(data){
								                //alert(data);
								                if (data != 0) {
								                	$('#channel_name_error').css('display','none');
								                	$('#Edit_channel').modal('hide');
								                	$('#upd_chnl_name').html(data);
								                	$("#channel_name_success").css({"display": "block"}).html("Channel name updated successfully.");
								                	setTimeout(function() {
								                		$('#channel_name_success').fadeOut();
								                	}, 5000 );
								                }
								                else{
								                	$("#channel_name_error").css({"display": "block"}).html("Channel name updated failed please try again.");
								                	return false;
								                }
								            }
								        });
								    }
								    return false;
								}
							</script>