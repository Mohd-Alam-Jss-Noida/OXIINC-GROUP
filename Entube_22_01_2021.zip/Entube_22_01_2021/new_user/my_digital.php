	<!-- Start Container -->
	<div class="main-wrapper">
		<section class="video-detail-page myvws-section-01">
			<div id="wrapper">
				<div id="content-wrapper">
					<div class="container-fluid pb-0">
						<div class="video-block section-padding">
							<div class="row">
								<div class="col-md-12">
									<div class="main-title">
										<h2 class="headding-01">Welcome to Epanelist Digital VWS</h2>
										<img src="<?php echo base_url('new_user_assets/images/my_digital.jpg');?>" width="100%">
									</div>
									<br><br>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<!-- end Container -->