<?Php
$this->load->view('new_user/head_inner');

//Start Header and Sidebar
$this->load->view('new_user/header');
//End Header and Sidebar

//Start Container 
$this->load->view($main_containt);
//End Container

//Start Footer
$this->load->view('new_user/footer'); 
$this->load->view('new_user/scripts_inner');
//End Footer
?>