<?Php $this->load->view('new_user/customise_header');?>
<!-- Tab panes -->
<div class="tab-content">
	<!-- Start Videos Tab -->
	<div>
		<div class="tab-container fwd">
			<div class="left-content left-block">
				<div id="playlist_orderby_error" class="error_message" style="display:none; margin: -30px 0px 20px 0px !important;"></div>
				<a href="<?php echo base_url("Entube_channel/videos/".$this->uri->segment(3));?>" class="back-btn"><i class="fas fa-long-arrow-alt-left"></i></a>
				<div class="tab-title">Upload Videos</div>
                <div class="btn cust-channel-btn" id="chang_vdo_titl" style="margin: -10px 0px 0px 10px !important; cursor: auto;">Most popular Videos</div>
				<div class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SORT BY <i class="fas fa-caret-down"></i></a>
					<ul class="dropdown-menu">
						<li id="playlists-video1" class="playlists-orderby" onclick="orderby_playlist('<?php echo $this->uri->segment(3);?>', 'view', 'DESC', 1);"><a href="javascript:void(0);">Most popular</a></li>
						<li id="playlists-video2" onclick="orderby_playlist('<?php echo $this->uri->segment(3);?>', 'datatime', 'DESC', 2);"><a href="javascript:void(0);">Date added (newest)</a></li>
						<li id="playlists-video3" onclick="orderby_playlist('<?php echo $this->uri->segment(3);?>', 'datatime', 'ASC', 3);"><a href="javascript:void(0);">Date added (oldest)</a></li>
					</ul>
				</div>
                <hr class="devider-line-hr-02">
                <div id="playlist_orderby_none">
    				<ul class="list-inline video-list">
    					<?php if(isset($video_details) && !empty($video_details)) foreach ($video_details as $key => $value) { ?>
    						<li class="equal-height-col">
    							<div class="item-containt-col">
    								<a href="<?php echo base_url('watch/'.$value['user_id'].'/'.$value['ID']); ?>" class="video-img-col">
                                        <img src="<?php echo base_url('uploads/product/'.$value['picture']);?>" alt=""/>
    									<i class="fas fa-play-circle"></i>
    									<div class="video-overlay"></div>
    								</a>
    								<div class="video-containt-col">
    									<a href="<?php echo base_url('watch/'.$value['user_id'].'/'.$value['ID']); ?>" class="video-title" style="color: #fff !important;"><?php echo character_limiter($value['Video_Title'], 80);?></a>
    									<div class="video-views">
                                            <span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
                                            <span><i class="far fa-calendar-alt"></i>
                                            	<?php
                                            	$FromDate = new DateTime(date("Y-m-d H:i:s"));
                                            	$ToDate   = new DateTime($value['datatime']);
                                            	$Interval = $FromDate->diff($ToDate);
                                            	$Difference["Hours"] = $Interval->h;
                                            	$Difference["Weeks"] = floor($Interval->d/7);
                                            	$Difference["Days"] = $Interval->d % 7;
                                            	$Difference["Months"] = $Interval->m;
                                            	$Difference["minute"] = $Interval->i;
                                            	$Difference["second"] = $Interval->s;
                                            	$Difference["Year"] = $Interval->y;
                                            	if($Difference["Year"]){
                                            		echo $Difference["Year"]." "."Year";
                                            	}else
                                            	if($Difference["Months"]){
                                            		echo $Difference["Months"]." "."Months";
                                            	}else
                                            	if($Difference["Weeks"]){
                                            		echo $Difference["Weeks"]." "."Weeks";
                                            	}else
                                            	if($Difference["Days"]){
                                            		echo $Difference["Days"]." "."Days";
                                            	}else
                                            	if($Difference["Hours"]){
                                            		echo $Difference["Hours"]." "."Hours";
                                            	}else
                                            	if($Difference["minute"]){
                                            		echo $Difference["minute"]." "."Minute";
                                            	}else
                                            	if($Difference["second"]){
                                            		echo $Difference["second"]." "."Second";
                                            	}
                                            	echo " "."ago";
                                            	?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php } else{ ?>
                        	<p class="text-center">This channel has no upload videos.</p>
                        <?php } ?>
                    </ul>
                </div>
                <div id="playlist_orderby_block"></div>
            </div>
			<div class="right-content right-block">
				<!-- <div class="tab-title">Featured channels</div>
				<div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div> -->
			</div>
		</div>
	</div>
</div>

<!-- THIS BELLOW DIV CLOSE FOR HEADER DIV -->
</div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->

<script type="text/javascript">
	function orderby_playlist(argument='', column_name='', option='', add_class=''){
    	if(add_class == 1){
    		$("#playlists-video1").addClass('playlists-orderby');
    		$("#playlists-video2").removeClass('playlists-orderby');
    		$("#playlists-video3").removeClass('playlists-orderby');
            $("#chang_vdo_titl").text('Most popular Videos');
    	}
    	if(add_class == 2){
    		$("#playlists-video2").addClass('playlists-orderby');
    		$("#playlists-video1").removeClass('playlists-orderby');
    		$("#playlists-video3").removeClass('playlists-orderby');
            $("#chang_vdo_titl").text('added newest Videos');
    	}
    	if(add_class == 3){
    		$("#playlists-video3").addClass('playlists-orderby');
    		$("#playlists-video1").removeClass('playlists-orderby');
    		$("#playlists-video2").removeClass('playlists-orderby');
            $("#chang_vdo_titl").text('added oldest Videos');
    	}


        if(argument == "" || column_name == "" || option == ""){
        	alert("FUNCTION PARAMETER NULL NOT ACCEPTED");
        	$("#playlist_orderby_error").css({"display": "block"}).html("FUNCTION PARAMETER NULL NOT ACCEPTED.");
        	return false;
        }
        else{
        	$.ajax({
        		url: "<?php echo base_url('Entube_channel/customise_videos/');?>" +argument,
        		type: "POST",
        		data: 'id=' + argument + '&column_name=' + column_name + '&option=' + option,
        		dataType:"text",
        		cache: false,
        		success: function(data){
                    //alert(data);
                    $("#playlist_orderby_none").css({"display": "none"});
                    $('#playlist_orderby_block').html(data);
                }
            });
        }
        return false;
    }
</script>