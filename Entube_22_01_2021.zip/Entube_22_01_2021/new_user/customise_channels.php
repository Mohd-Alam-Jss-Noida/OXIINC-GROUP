<?Php $this->load->view('new_user/customise_header');?>
<!-- Tab panes -->
<div class="tab-content">
	<!-- Start Customize Videos Tab -->
	<div>
		<div class="tab-container fwd">
			<div class="left-content left-block">
				<div id="un_subscribe_channel_success" class="success_message" style="display:none; margin: -30px 0px 20px 0px !important;"></div>
				<div id="un_subscribe_channel_error" class="error_message" style="display:none; margin: -30px 0px 20px 0px !important;"></div>
				<a href="<?php echo base_url("Entube_channel/channels/".$this->uri->segment(3));?>" class="back-btn"><i class="fas fa-long-arrow-alt-left"></i></a>
				<div class="tab-title">Subscribed channels</div>
				<!-- <div class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SORT BY <i class="fas fa-caret-down"></i></a>
					<ul class="dropdown-menu">
						<li><a href="#">Most popular</a></li>
						<li><a href="#">Date added (oldest)</a></li>
						<li><a href="#">Date added (newest)</a></li>
					</ul>
				</div> -->
				<hr class="devider-line-hr-02">
				<div id="refresh_subscribe">
					<ul class="list-inline video-list custchannels-video-list">
						<?php
							if(isset($subscribe_channel) && !empty($subscribe_channel)) foreach ($subscribe_channel as $key => $value){
								if($this->session->userdata('entube_customer_logged_in')){
									$channel_image = $this->session->userdata('profileImage');
									$channel_name = $this->session->userdata('name');
								} elseif($this->session->userdata('logged_in')){
									$channel_image = base_url('uploads/customer_channel_logo/channel-logo.jpg');
									$channel_name = DEFAULT_CHANNEL;
								}
								$channel_details = $this->Entube_model->get_channel_data($value['channel_id']);
							    //echo "<pre>";print_r($channel_details);die();

								$cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? base_url('uploads/customer_channel_logo/'.$channel_details['channel_logo']) : $channel_image;

						        $cha_name = (isset($channel_details['channel_name']) && !empty($channel_details['channel_name'])) ? $channel_details['channel_name'] : $channel_name;

								$channel_count = $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$value['channel_id']));
								?>
								<li>
									<div class="item-containt-col">
										<a href="<?php echo site_url('Entube_channel/channel/'.$value['channel_id'])?>" class="video-img-col">
											<img src="<?php echo $cha_logo;?>" alt=""/>
										</a>
										<div class="video-containt-col">
											<a class="video-title" href="<?php echo site_url('Entube_channel/channel/'.$value['channel_id'])?>"><?php echo $cha_name;?></a>
											<div class="video-views">
												<span><?php echo ($channel_count > 0) ? $channel_count." subscribers" : "0 subscribers"; ?></span>
												<button type="button" class="subscribe-btn" id="un_subscribe_disable" onclick="un_subscribe_channel('<?php echo $value['channel_id'];?>', '<?php echo $value['my_id'];?>');">Un-Subscribe</button>
											</div>
										</div>
									</div>
								</li>
								<?php
							}
							else{ ?>
	                            	<p class="text-center">This channel doesn't feature any other channels.</p>
	                        	<?php
	                    	} ?>
					</ul>
				</div>
			</div>
			<div class="right-content right-block">
				<!-- <div class="tab-title">Featured channels</div>
				<div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div> -->
			</div>
		</div>
	</div>
</div>

<!-- THIS BELLOW DIV CLOSE FOR HEADER DIV -->
</div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	function un_subscribe_channel(channel_id='', my_id=''){
		var un_sub = confirm('Do you want to un-subscribe this channel.');
		if (!un_sub){
			return false;
		}
		if(channel_id == "" || my_id == ""){
        	alert("FUNCTION PARAMETER NULL NOT ACCEPTED.");
        	$("#un_subscribe_channel_error").css({"display": "block"}).html("FUNCTION PARAMETER NULL NOT ACCEPTED.");
        	return false;
        }
		else {
			var data = {};
			data.report = {};
			data.report.value_info = channel_id;
			data.report.my_id = my_id;
			var q = JSON.stringify(data);
			jQuery.ajax({
				url: "<?php echo site_url('Customer_login_page/Subscribe_channel_after');?>",
				type: "POST",
				data: {'jsonObj' : q},
				dataType:"json",
				cache: false,
				beforeSend: function(){
	        		$("#un_subscribe_disable").text('Sending .....').prop('disabled', true);
	        	},
	        	complete: function(){
	        		$("#un_subscribe_disable").text('Un-Subscribe').prop('disabled', false);
   				},
				success: function(res){
					//alert(res.status);
					if (res.status) {
						$("#refresh_subscribe").load(" #refresh_subscribe");
						$('#un_subscribe_channel_error').css('display','none');
						$('#un_subscribe_channel_success').css('display','block').html('Un-subscribe channel successfully.');
						setTimeout(function() {
                    		$('#un_subscribe_channel_success').fadeOut();
                    	}, 5000 );
					}
					else{
						$('#un_subscribe_channel_error').css('display','block').html('Un-subscribe channel failed Please try again.');
					}
				},
				error: function () {
                	$('#un_subscribe_channel_error').css('display','block').html('Un-subscribe channel failed Please try again.');
                }
			});
		}
	}
</script>