	<!-- Start Container -->
	<div class="main-wrapper">
	  <section class="video-detail-page">
		<div class="row">
		  <div class="container-fluid large-devise-screen">
			<div class="my-channel-section-01 guest-profile-section-01">
			  <div class="main-title myvws-section-01">
				<h2 class="headding-01">Your Profile Information</h2>
			  </div>
			  <div class="login-form-block">
				<form action="<?php echo base_url("Customer_login_page/edit_channel_icon_image"); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
					<div class="form-group half-width">
						<label>User Name</label>
						<input type="text" value="<?php if(isset($custumer_login['user_name'])){ echo $custumer_login['user_name'];}?>" class="input-textbox" readonly>
					</div>
					<div class="form-group half-width">
						<label>User Email</label>
						<input type="text" value="<?php if(isset($custumer_login['email_id'])){ echo $custumer_login['email_id'];}?>" class="input-textbox" readonly>
					</div>
					<div class="form-group half-width">
						<label>Country Name</label>
						<input type="text" value="<?php if(isset($custumer_address['counrty_name'])){ echo $custumer_address['counrty_name'];}?>" class="input-textbox" readonly>
					</div>
					<div class="form-group half-width">
						<label>State Name</label>
						<input type="text" value="<?php if(isset($custumer_address['state_name'])){ echo $custumer_address['state_name'];}?>" class="input-textbox" readonly>
					</div>
					<div class="form-group half-width">
						<label>City Name</label>
						<input type="text" value="<?php if(isset($custumer_address['city_name'])){ echo $custumer_address['city_name'];}?>" class="input-textbox" readonly>
					</div>
					<div class="form-group half-width">
						<label>Mobile Number</label>
						<input type="text" value="<?php if(isset($custumer_login['contact_number'])){ echo $custumer_login['contact_number'];}?>" class="input-textbox" readonly>
					</div>
					<!-- <button onclick="validateForm(this);" type="button" class="input-submitbtn"> Save Change</button>
					<button type="reset" class="input-submitbtn">Reset</button>
					<div class="sucessmsg" id="sucessmsg" style="display:none;"></div>
					<div class="error12msg" id="error12msg" style="display:none;"></div> -->
				</form>
		      </div>
			</div>
		  </div>
		</div>
	  </section>
	  <div class="clrfix"></div>			 
	</div>
	<!-- end Container -->