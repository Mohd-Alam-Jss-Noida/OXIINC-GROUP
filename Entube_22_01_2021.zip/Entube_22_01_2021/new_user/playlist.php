			<?Php $this->load->view('new_user/channel_header');?>
			<!-- Tab panes -->
			<div class="tab-content">
				<!-- Start Playlist Tab -->
				<div role="tabpanel" class="">
					<div class="tab-container fwd">
						<div class="tab-title">Created Playlist</div>
						<!-- <div class="dropdown video-login-popup video-login-popup2">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
							<ul class="dropdown-menu">
								<li><a href="#">Most popular</a></li>
								<li><a href="#">Date added (oldest)</a></li>
								<li><a href="#">Date added (newest)</a></li>
							</ul>
						</div> -->
						<ul class="list-inline video-list">
							<?php if(isset($playlist_details) && !empty($playlist_details)) foreach ($playlist_details as $value){
								$query_count = $this->db->query('SELECT video_id FROM playlist_video_select WHERE playlistname_id = '.$value['ID'].' GROUP BY video_id ORDER BY video_id DESC');
								//echo "<pre>";print_r($query_count);die();
								$row_photo = $query_count->result_array();
								$playlist_count = $query_count->num_rows();
								if ($playlist_count > 0){
									$video_query=$this->db->query('SELECT ID, picture FROM add_video WHERE ID = '.$row_photo[0]['video_id'].' AND status = 1');
									$photo = $video_query->result_array();
									//echo "<pre>";print_r($photo);die();
									if($photo){
										if($photo[0]['picture']){
											$video_image = $photo[0]['picture'];
										} else{
											$video_image = 'default_video_image.jpg';
										}
										?>
										<li>
											<a href="<?php echo base_url('Entube/playlist_video/'.$value['ID']."/".$photo[0]['ID']);?>" class="item-containt-col">
												<div class="video-img-col video-img-block">
														<div class="playlist-text" style="background-image: url('<?php echo base_url("uploads/product/$video_image")?>');">
														<div class="playlist-col">
															<h4><?php echo $playlist_count; ?></h4>
															<img src="<?php echo base_url('black/img/play.png'); ?>" style="width: 20px"/>
														</div>
													</div>
													<div class="play-all-txt">
														<i class="fas fa-play-circle"></i> 
														<span>Play All</span>
													</div>
													<div class="video-overlay"></div>
												</div>
												<div class="video-containt-col">
													<div class="video-title" ><?php echo $value['playlistname']; ?></div>
												</div>
											</a>     
										</li>
										<?php
									}
								}
								else{
									if($this->session->userdata('entube_customer_logged_in')){
							            $user_id_upload = $this->session->userdata('username');
							        }elseif($this->session->userdata('logged_in')){
							            $user_id_upload = $this->session->userdata('id');
							        }else{
							        	$user_id_upload = "0";
							        }
							        if ($user_id_upload == $this->uri->segment(3)) {
							        	$video_image = 'default_video_image.jpg';
							        	?>
										<li>
											<a href="javascript:void(0);" class="item-containt-col">
												<div class="video-img-col video-img-block">
													<div class="playlist-text" style="background-image: url('<?php echo base_url("uploads/product/$video_image")?>');">
														<div class="playlist-col">
															<h4>No videos</h4>
															<img src="<?php echo base_url('black/img/play.png'); ?>" style="width: 20px"/>
														</div>
													</div>
													<div class="play-all-txt">
														<i class="fas fa-play-circle"></i> 
														<span>Play All</span>
													</div>
													<div class="video-overlay"></div>
												</div>
												<div class="video-containt-col">
													<div class="video-title" ><?php echo $value['playlistname']; ?></div>
												</div>
											</a>     
										</li>
									<?php
									}
								}
							} else{ ?>
								<p class="text-center">This channel has no playlists.</p>
							<?php } ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->

