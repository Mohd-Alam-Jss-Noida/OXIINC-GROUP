		<!-- jQuery -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="<?php echo base_url('new_user_assets/js/bootstrap.min.js');?>"></script>

		<!-- Fontawesome -->
		<script defer src="<?php echo base_url('new_user_assets/js/fontawesome/all.js');?>"></script>
		<script defer src="<?php echo base_url('new_user_assets/js/fontawesome/brands.js');?>"></script>
		<script defer src="<?php echo base_url('new_user_assets/js/fontawesome/solid.js');?>"></script>
		<script defer src="<?php echo base_url('new_user_assets/js/fontawesome/fontawesome.js');?>"></script>
		
		<!-- Scrollbar Script -->
		<script defer src="<?php echo base_url('new_user_assets/js/mCustomScrollbar.concat.min.js');?>"></script>
		<!-- Datepicker Script --> 
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
	    <!-- Data Table Script -->
	    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.js"></script>
		<!-- Add Tag Script -->
	    <script defer src="<?php echo base_url('new_user_assets/js/add-tag.js');?>"></script>
		
		<!-- AUTOCOMPLETE -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>

		<script defer src="<?php echo base_url('new_user_assets/js/common-script.js');?>"></script>
		<script type="text/javascript">
			$(function () {
				$("#datepicker").datepicker({ 
					autoclose: true, 
					todayHighlight: true
				}).datepicker('update', new Date());

				$("#datepicker2").datepicker({ 
					autoclose: true, 
					todayHighlight: true
				}).datepicker('update', new Date());
			});

			$('table').DataTable();

			/*ADD BY MOHD ALAM ALERT MAEEAGE HIDE AFTER 3 SECOND JAVA SCRIPT CODE*/
		    setTimeout(function() {
				$('#flash_msg').fadeOut();
			}, 3000 );
		</script>
	
		<script type="text/javascript">
			if (jQuery('input#auto_search').length > 0) {
				jQuery('input#auto_search').typeahead({
					source: function(request, response){
						jQuery.ajax({
							url: '<?php echo base_url('Entube/autocomplete_search?search_data=');?>'+ request,
							contentType: 'application/json; charset=utf-8',
							dataType: "json",
							type: "GET",
							success: function(data){
								var resp = $.map(data,function(obj){
									return obj.Video_Title;
								});
								response(resp);
							}
						});
					},
					updater: function(obj){
						window.location.href = '<?php echo base_url("watch/search/"); ?>'+obj;
					}
				});
			}
		</script>
	</div>
</body>
</html>