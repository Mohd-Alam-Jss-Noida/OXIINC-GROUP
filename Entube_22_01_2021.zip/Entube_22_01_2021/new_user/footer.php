	<!-- Start Footer -->
	<footer>
		<a href="#" class="cd-top"><i class="fas fa-angle-up"></i></a>
		<div class="row">
			<div class="container-fluid">
				<div class="col-left">
					<span>&copy; Design and Developed by <a href="https://www.oxiincgroup.com/" target="_blank">Oxiincgroup.com</a></span>
					<span>&copy; 2015- 2020 Erocketmall Online Asia Limited. All Rights Reserved</span>
				</div>
				<div class="col-right">
					<ul class="list-inline social-media-links">
						<li><a href="https://www.facebook.com/myoxiinc/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
						<li><a href="https://twitter.com/myoxiinc" target="_blank"><i class="fab fa-twitter"></i></a></li>
						<li><a href="https://www.linkedin.com/in/oxiinc-health-care-company-pvt-ltd-b00720117/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
						<li><a href="https://www.youtube.com/channel/UCim_GlgyKZ2aJF7KhUEE3Gw/" target="_blank"><i class="fab fa-youtube"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!-- End Footer -->
