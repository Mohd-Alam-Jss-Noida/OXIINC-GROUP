<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.entube.in/black/img/logoo/iconn.png">
	<!-- Css -->
	<link href="<?php echo base_url('new_user_assets/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
	<!-- Fontawesome -->
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/all.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/fontawesome.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/brands.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/fontawesome/solid.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/animate.css');?>" rel="stylesheet">
	<!-- Owlcarousel -->
	<link rel="stylesheet" href="<?php echo base_url('new_user_assets/css/owlcarousel/owl.carousel.min.css');?>">
	<!-- Scrollbar Css -->
	<link rel="stylesheet" href="<?php echo base_url('new_user_assets/css/mCustomScrollbar.css');?>">

	<link href="<?php echo base_url('new_user_assets/css/common-style.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('new_user_assets/css/home.css');?>" rel="stylesheet">
</head>
<body>
	<div id="main-page-wrapper">
		<!-- Start Header -->
		<?Php $this->load->view('new_user/header'); ?>
		<!-- End Header -->
		
		<!-- Start Container -->
		<div class="main-wrapper">
			<!-- Banner Section -->
			<div class="banner-section large-devise-screen-home-banner">
				<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
					<?php if(isset($banner) && !empty($banner)) foreach ($banner as $key => $value) { ?>
						<li data-target="#carousel-example-generic" data-slide-to="<?php echo $key;?>" <?php if($key == 0) { ?> class="active" <?php } ?>>
							<span class="item-no"><?php echo $key+1;?></span>
							<span class="item-title"><?php echo $value['banner_name'];?></span>
						</li>
					<?php } ?>
					</ol>
					<div class="carousel-inner" role="listbox">
						<?php if(isset($banner) && !empty($banner)) foreach ($banner as $key => $value) { ?>
						<div class="item <?php if($key == 0) { ?> active <?php } ?>">
							<img src="<?php echo base_url().'uploads/banner/'.$value['banner_Picture'];?>" class="img-responsive" alt="">
						</div>
						<?php } ?>
					</div>

					<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
			<!-- RECOMMENDED Videos Section -->
			<?php if(sizeof($recommended)>'0') {  ?>
			<section class="home-section-01 home-video-slider">
				<div class="row">
					<div class="container-fluid large-devise-screen">
						<h2 class="headding-01">Recommended</h2>
						<div class="owl-carousel owl-theme">
							<?php
							if(isset($recommended) && !empty($recommended)) foreach ($recommended as $key => $value) {
	                            if($value['channel_name']) {
					          		$channel_name = $value['channel_name'];
	                            } elseif ($value['user_id']) {
	                            	$channel_name = $value['user_id'];
	                            } else{
	                            	$channel_name = OXIINC_CHANNEL;
	                            }

	                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

	                            if($value['channel_logo']) {
	                            	$channel_logo = $value['channel_logo'];
	                            } elseif ($channel_name == OXIINC_CHANNEL) {
	                            	$channel_logo = 'oxiinc-digital-icon.png';
	                            } else{
	                            	$channel_logo = 'channel-logo.jpg';
	                            }
								?>
								<div class="item">
									<div class="item-containt-col">
										<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
											<img src="<?php echo $video_image ;?>" class="home-video-item-img" alt="" />
											<i class="fas fa-play-circle"></i>
											<div class="video-overlay"></div>
										</a>
										<div class="video-containt-col">
											<div class="chanel-img-col">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
													<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
												</a>
											</div>
											<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo character_limiter($value['Video_Title'], CHAR_LIMIT);?></a>
											<div class="video-channel">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name;?></a> <i class="fas fa-check-circle"></i>
											</div>
											<div class="video-views">
												<span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
												<span><i class="far fa-calendar-alt"></i>
													<?php
									                    $FromDate = new DateTime(date("Y-m-d H:i:s"));
									                    $ToDate   = new DateTime($value['datatime']);
									                    $Interval = $FromDate->diff($ToDate);
									                    $Difference["Hours"] = $Interval->h;
									                    $Difference["Weeks"] = floor($Interval->d/7);
									                    $Difference["Days"] = $Interval->d % 7;
									                    $Difference["Months"] = $Interval->m;
									                    $Difference["minute"] = $Interval->i;
									                    $Difference["second"] = $Interval->s;
									                    $Difference["Year"] = $Interval->y;
									                    if($Difference["Year"]){
									                    echo $Difference["Year"]." "."Year";
									                    }else
									                    if($Difference["Months"]){
									                    echo $Difference["Months"]." "."Months";
									                    }else
									                    if($Difference["Weeks"]){
									                    echo $Difference["Weeks"]." "."Weeks";
									                    }else
									                    if($Difference["Days"]){
									                    echo $Difference["Days"]." "."Days";
									                    }else
									                    if($Difference["Hours"]){
									                    echo $Difference["Hours"]." "."Hours";
									                    }else
									                    if($Difference["minute"]){
									                    echo $Difference["minute"]." "."Minute";
									                    }else
									                    if($Difference["second"]){
									                    echo $Difference["second"]." "."Second";
									                    }
									                    echo " "."ago";
									                ?>
												</span>
											</div>
										</div>
									</div>
								</div>
								<?php
							}
							?>
						</div>
						<hr>
					</div>
				</div>
			</section>
			<?php } ?>

			<!-- RECENTLY UPLOADED Videos Section -->
			<?php if(sizeof($recently_uploaded)>'0') {  ?>
			<section class="home-section-01 home-video-slider">
				<div class="row">
					<div class="container-fluid large-devise-screen">
						<h2 class="headding-01">Recently Uploaded</h2>
						<div class="owl-carousel owl-theme">
							<?php
							if(isset($recently_uploaded) && !empty($recently_uploaded)) foreach ($recently_uploaded as $key => $value) {
	                            if($value['channel_name']) {
					          		$channel_name = $value['channel_name'];
	                            } elseif ($value['user_id']) {
	                            	$channel_name = $value['user_id'];
	                            } else{
	                            	$channel_name = OXIINC_CHANNEL;
	                            }

	                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

	                            if($value['channel_logo']) {
	                            	$channel_logo = $value['channel_logo'];
	                            } elseif ($channel_name == OXIINC_CHANNEL) {
	                            	$channel_logo = 'oxiinc-digital-icon.png';
	                            } else{
	                            	$channel_logo = 'channel-logo.jpg';
	                            }
								?>
								<div class="item">
									<div class="item-containt-col">
										<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
											<img src="<?php echo $video_image ;?>" class="home-video-item-img" alt="" />
											<i class="fas fa-play-circle"></i>
											<div class="video-overlay"></div>
										</a>
										<div class="video-containt-col">
											<div class="chanel-img-col">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
													<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
												</a>
											</div>
											<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo character_limiter($value['Video_Title'], CHAR_LIMIT);?></a>
											<div class="video-channel">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name;?></a> <i class="fas fa-check-circle"></i>
											</div>
											<div class="video-views">
												<span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
												<span><i class="far fa-calendar-alt"></i>
													<?php
									                    $FromDate = new DateTime(date("Y-m-d H:i:s"));
									                    $ToDate   = new DateTime($value['datatime']);
									                    $Interval = $FromDate->diff($ToDate);
									                    $Difference["Hours"] = $Interval->h;
									                    $Difference["Weeks"] = floor($Interval->d/7);
									                    $Difference["Days"] = $Interval->d % 7;
									                    $Difference["Months"] = $Interval->m;
									                    $Difference["minute"] = $Interval->i;
									                    $Difference["second"] = $Interval->s;
									                    $Difference["Year"] = $Interval->y;
									                    if($Difference["Year"]){
									                    echo $Difference["Year"]." "."Year";
									                    }else
									                    if($Difference["Months"]){
									                    echo $Difference["Months"]." "."Months";
									                    }else
									                    if($Difference["Weeks"]){
									                    echo $Difference["Weeks"]." "."Weeks";
									                    }else
									                    if($Difference["Days"]){
									                    echo $Difference["Days"]." "."Days";
									                    }else
									                    if($Difference["Hours"]){
									                    echo $Difference["Hours"]." "."Hours";
									                    }else
									                    if($Difference["minute"]){
									                    echo $Difference["minute"]." "."Minute";
									                    }else
									                    if($Difference["second"]){
									                    echo $Difference["second"]." "."Second";
									                    }
									                    echo " "."ago";
									                ?>
												</span>
											</div>
										</div>
									</div>
								</div>
							<?php
							}
							?>
						</div>
					</div>
				</div>
			</section>
			<?php } ?>

			<!-- YOU MAY LIKE Videos Section -->
			<?php if(sizeof($ip_recommended)>'0') {  ?>
			<section class="home-section-01 home-video-slider">
				<div class="row">
					<div class="container-fluid large-devise-screen">
						<h2 class="headding-01">You May Like</h2>
						<div class="owl-carousel owl-theme">
							<?php
							if(isset($ip_recommended) && !empty($ip_recommended)) foreach ($ip_recommended as $key => $value) {
	                            if($value['channel_name']) {
					          		$channel_name = $value['channel_name'];
	                            } elseif ($value['user_id']) {
	                            	$channel_name = $value['user_id'];
	                            } else{
	                            	$channel_name = OXIINC_CHANNEL;
	                            }

	                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

	                            if($value['channel_logo']) {
	                            	$channel_logo = $value['channel_logo'];
	                            } elseif ($channel_name == OXIINC_CHANNEL) {
	                            	$channel_logo = 'oxiinc-digital-icon.png';
	                            } else{
	                            	$channel_logo = 'channel-logo.jpg';
	                            }
								?>
								<div class="item">
									<div class="item-containt-col">
										<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
											<img src="<?php echo $video_image ;?>" class="home-video-item-img" alt="" />
											<i class="fas fa-play-circle"></i>
											<div class="video-overlay"></div>
										</a>
										<div class="video-containt-col">
											<div class="chanel-img-col">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
													<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
												</a>
											</div>
											<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo character_limiter($value['Video_Title'], CHAR_LIMIT);?></a>
											<div class="video-channel">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name;?></a> <i class="fas fa-check-circle"></i>
											</div>
											<div class="video-views">
												<span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
												<span><i class="far fa-calendar-alt"></i>
													<?php
									                    $FromDate = new DateTime(date("Y-m-d H:i:s"));
									                    $ToDate   = new DateTime($value['datatime']);
									                    $Interval = $FromDate->diff($ToDate);
									                    $Difference["Hours"] = $Interval->h;
									                    $Difference["Weeks"] = floor($Interval->d/7);
									                    $Difference["Days"] = $Interval->d % 7;
									                    $Difference["Months"] = $Interval->m;
									                    $Difference["minute"] = $Interval->i;
									                    $Difference["second"] = $Interval->s;
									                    $Difference["Year"] = $Interval->y;
									                    if($Difference["Year"]){
									                    echo $Difference["Year"]." "."Year";
									                    }else
									                    if($Difference["Months"]){
									                    echo $Difference["Months"]." "."Months";
									                    }else
									                    if($Difference["Weeks"]){
									                    echo $Difference["Weeks"]." "."Weeks";
									                    }else
									                    if($Difference["Days"]){
									                    echo $Difference["Days"]." "."Days";
									                    }else
									                    if($Difference["Hours"]){
									                    echo $Difference["Hours"]." "."Hours";
									                    }else
									                    if($Difference["minute"]){
									                    echo $Difference["minute"]." "."Minute";
									                    }else
									                    if($Difference["second"]){
									                    echo $Difference["second"]." "."Second";
									                    }
									                    echo " "."ago";
									                ?>
												</span>
											</div>
										</div>
									</div>
								</div>
							<?php
							}
							?>
						</div>
					</div>
				</div>
			</section>
			<?php } ?>

			<!-- MOST VIEWED Videos Section -->
			<?php if(sizeof($most_viewed)>'0') {  ?>
			<section class="home-section-01 home-video-slider">
				<div class="row">
					<div class="container-fluid large-devise-screen">
						<h2 class="headding-01">Most Viewed</h2>
						<div class="owl-carousel owl-theme">
							<?php
							if(isset($most_viewed) && !empty($most_viewed)) foreach ($most_viewed as $key => $value) {
	                            if($value['channel_name']) {
					          		$channel_name = $value['channel_name'];
	                            } elseif ($value['user_id']) {
	                            	$channel_name = $value['user_id'];
	                            } else{
	                            	$channel_name = OXIINC_CHANNEL;
	                            }

	                            $video_image = (isset($value['picture']) && !empty($value['picture']) && file_exists('uploads/product/'.$value['picture'])) ? base_url('uploads/product/'.$value['picture']) : base_url('uploads/product/default_video_image.jpg');

	                            if($value['channel_logo']) {
	                            	$channel_logo = $value['channel_logo'];
	                            } elseif ($channel_name == OXIINC_CHANNEL) {
	                            	$channel_logo = 'oxiinc-digital-icon.png';
	                            } else{
	                            	$channel_logo = 'channel-logo.jpg';
	                            }
								?>
								<div class="item">
									<div class="item-containt-col">
										<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-img-col">
											<img src="<?php echo $video_image ;?>" class="home-video-item-img" alt="" />
											<i class="fas fa-play-circle"></i>
											<div class="video-overlay"></div>
										</a>
										<div class="video-containt-col">
											<div class="chanel-img-col">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>">
													<img src="<?php echo base_url("uploads/customer_channel_logo/".$channel_logo);?>" alt=""/>
												</a>
											</div>
											<a href="<?php echo base_url("watch/$channel_name/".$value['ID']); ?>" class="video-title"><?php echo character_limiter($value['Video_Title'], CHAR_LIMIT);?></a>
											<div class="video-channel">
												<a href="<?php echo base_url("Entube_channel/channel/".$value['user_id']) ?>"><?php echo $channel_name;?></a> <i class="fas fa-check-circle"></i>
											</div>
											<div class="video-views">
												<span><i class="far fa-eye"></i><?php echo ($value['view'] > 0) ? $value['view']." views" : "0 view"; ?></span>
												<span><i class="far fa-calendar-alt"></i>
													<?php
									                    $FromDate = new DateTime(date("Y-m-d H:i:s"));
									                    $ToDate   = new DateTime($value['datatime']);
									                    $Interval = $FromDate->diff($ToDate);
									                    $Difference["Hours"] = $Interval->h;
									                    $Difference["Weeks"] = floor($Interval->d/7);
									                    $Difference["Days"] = $Interval->d % 7;
									                    $Difference["Months"] = $Interval->m;
									                    $Difference["minute"] = $Interval->i;
									                    $Difference["second"] = $Interval->s;
									                    $Difference["Year"] = $Interval->y;
									                    if($Difference["Year"]){
									                    echo $Difference["Year"]." "."Year";
									                    }else
									                    if($Difference["Months"]){
									                    echo $Difference["Months"]." "."Months";
									                    }else
									                    if($Difference["Weeks"]){
									                    echo $Difference["Weeks"]." "."Weeks";
									                    }else
									                    if($Difference["Days"]){
									                    echo $Difference["Days"]." "."Days";
									                    }else
									                    if($Difference["Hours"]){
									                    echo $Difference["Hours"]." "."Hours";
									                    }else
									                    if($Difference["minute"]){
									                    echo $Difference["minute"]." "."Minute";
									                    }else
									                    if($Difference["second"]){
									                    echo $Difference["second"]." "."Second";
									                    }
									                    echo " "."ago";
									                ?>
												</span>
											</div>
										</div>
									</div>
								</div>
							<?php
							}
							?>
						</div>
					</div>
				</div>
			</section>
			<?php } ?>
		</div>
		<!-- End Container -->

		<!-- Start Footer -->
		<?php $this->load->view('new_user/footer'); ?>

		<!-- jQuery -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<!-- <script src="js/bootstrap.min.js"></script> -->
		<script src="<?php echo base_url('js/bootstrap.min.js'); ?>"></script>
		<!-- Fontawesome -->
		<script src="<?php echo base_url('new_user_assets/js/fontawesome/all.js'); ?>"></script>
		<script src="<?php echo base_url('new_user_assets/js/fontawesome/brands.js'); ?>"></script>
		<script src="<?php echo base_url('new_user_assets/js/fontawesome/solid.js'); ?>"></script>
		<script src="<?php echo base_url('new_user_assets/js/fontawesome/fontawesome.js'); ?>"></script>
		<!-- owlcarousel -->
		<script src="<?php echo base_url('new_user_assets/js/owlcarousel/owl.carousel.js'); ?>"></script>
		<!-- Scrollbar Script -->
		<script src="<?php echo base_url('new_user_assets/js/mCustomScrollbar.concat.min.js'); ?>"></script>
		
		<!-- AUTOCOMPLETE -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
		
		<script src="<?php echo base_url('new_user_assets/js/common-script.js'); ?>"></script>
		<script src="<?php echo base_url('new_user_assets/js/home.js'); ?>"></script>
		
		<script type="text/javascript">
			if (jQuery('input#auto_search').length > 0) {
				jQuery('input#auto_search').typeahead({
					source: function(request, response){
						jQuery.ajax({
							url: '<?php echo base_url('Entube/autocomplete_search?search_data=');?>'+ request,
							contentType: 'application/json; charset=utf-8',
							dataType: "json",
							type: "GET",
							success: function(data){
								var resp = $.map(data,function(obj){
									return obj.Video_Title;
								});
								response(resp);
							}
						});
					},
					updater: function(obj){
						window.location.href = '<?php echo base_url("watch/search/"); ?>'+obj;
					}
				});
			}
		</script>
		<!-- End Footer -->
	</div>
</body>
</html>