    <?php
        if($this->session->userdata('entube_customer_logged_in')){
            $user_id = $this->session->userdata('username');
            if($this->session->userdata('username') == $this->uri->segment(3)){
                $channel_image = $this->session->userdata('profileImage');
                $channel_name = $this->session->userdata('name');
            }
            else{
                $channel_image = base_url('uploads/customer_channel_logo/channel-logo.jpg');
                $channel_name = $this->uri->segment(3);
            }
            
        } elseif($this->session->userdata('logged_in')){
            $user_id = $this->session->userdata('id');
            $channel_image = base_url('uploads/customer_channel_logo/channel-logo.jpg');
            $channel_name = DEFAULT_CHANNEL;
        } else{
            $user_id = '';
            $channel_image = base_url('uploads/customer_channel_logo/channel-logo.jpg');
            $channel_name = $this->uri->segment(3);
        }
        $channel_details = $this->Entube_model->get_channel_data($this->uri->segment(3));
        //echo "<pre>";print_r($channel_details);die();

        $cha_logo = (isset($channel_details['channel_logo']) && !empty($channel_details['channel_logo']) && file_exists('uploads/customer_channel_logo/'.$channel_details['channel_logo'])) ? base_url('uploads/customer_channel_logo/'.$channel_details['channel_logo']) : $channel_image;

        $cha_banner= (isset($channel_details['channel_banner']) && !empty($channel_details['channel_banner']) && file_exists('uploads/customer_channel_banner/'.$channel_details['channel_banner'])) ? base_url('uploads/customer_channel_banner/'.$channel_details['channel_banner']) : base_url('assets/entub.jpg');

        $cha_name = (isset($channel_details['channel_name']) && !empty($channel_details['channel_name'])) ? $channel_details['channel_name'] : $channel_name;
    ?>
    <!-- Start Container -->
    <div class="main-wrapper">
        <section class="video-detail-page">
            <div class="single-channel-image">
                <img src="<?php echo $cha_banner;?>" class="img-fluid" alt="" />
                <div class="social-media-links-col">
                   <div class="channel-name">Oxiinc Group</div>
                    <ul class="list-inline">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        <div class="row">
            <div class="container-fluid large-devise-screen">
              <div class="my-channel-section-01">
                <div id="subscribe_channel_success" class="success_message" style="display:none; margin: 0px !important;"></div>
                <div id="subscribe_channel_error" class="error_message" style="display:none; margin: 0px !important;"></div>
                <div class="block-01 fwd">
                    <div class="left-col">
                        <img src="<?php echo $cha_logo;?>" class="img-col" alt=""/>
                        <h3><?php echo $cha_name ;?></h3>
                    </div>
                    <div class="right-col" id="refresh_subscribe">
                        <?php
                        if($this->session->userdata('entube_customer_logged_in') || $this->session->userdata('logged_in')){
                            if($user_id == $this->uri->segment(3)){ ?>
                                <a href="<?php echo site_url('Entube_channel/entube_studio/'.$this->uri->segment(3))?>" class="cust-channel-btn">Entube Studio</a>
                                <a href="<?php echo site_url('Entube_channel/customise_channel/'.$this->uri->segment(3))?>" class="cust-channel-btn">Customize Channel</a>
                                <?php
                            }
                            else{
                                $channel_count = $this->Model->CountWhereRecord('subscribe_channel',array('channel_id'=>$this->uri->segment(3), 'my_id'=>$user_id));
                                if($channel_count > 0){ ?>
                                    <a href="javascript:void(0);" class="cust-channel-btn" id="un_subscribe_disable" onclick="un_subscribe_channel('<?php echo $this->uri->segment(3);?>', '<?php echo $user_id;?>');" style="background: linear-gradient(135deg,#ff253a 0%,#ff8453 100%);">Un-Subscribed</a>
                                    <?php
                                }
                                else{ ?>
                                    <a href="javascript:void(0);" class="cust-channel-btn" id="subscribe_disable" onclick="subscribe_channel('<?php echo $this->uri->segment(3);?>', '<?php echo $user_id;?>');">Subscrib</a>
                                    <?php
                                }
                            }
                        }
                        else{ ?>
                            <a href="javascript:void(0);" class="cust-channel-btn" data-toggle="modal" data-target="#EPanelistloginModal">Subscribe</a>
                            <?php
                        } ?>
                    </div>
                </div>

                <div class="block-02 fwd">
                    <div class="scroller scroller-left"><i class="glyphicon glyphicon-chevron-left"></i></div>
                    <div class="scroller scroller-right"><i class="glyphicon glyphicon-chevron-right"></i></div>
                    <!-- Nav tabs -->
                    <div class="tab-wrapper">
                        <ul class="nav nav-tabs list" role="tablist">
                            <li<?php if ($this->uri->segment(2) == 'channel') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/channel/'.$this->uri->segment(3))?>">Home</a></li>
                            <li<?php if ($this->uri->segment(2) == 'videos') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/videos/'.$this->uri->segment(3))?>">Videos</a></li>
                            <li<?php if ($this->uri->segment(2) == 'playlist') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/playlist/'.$this->uri->segment(3))?>">Playlist</a></li>
                            <li<?php if ($this->uri->segment(2) == 'channels') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/channels/'.$this->uri->segment(3))?>">Channels</a></li>
                            <li<?php if ($this->uri->segment(2) == 'discussion') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/discussion/'.$this->uri->segment(3))?>">Discussion</a></li>
                            <li<?php if ($this->uri->segment(2) == 'channel_about') { ?> class="active"<?php } ?>><a href="<?php echo site_url('Entube_channel/channel_about/'.$this->uri->segment(3))?>">About</a></li>
                        </ul>
                    </div>
                    <!-- SUBSCRIBE AND UN-SUBSCRIBE JAVASCRIPT CODE -->
                    <script type="text/javascript">
                        function subscribe_channel(channel_id='', my_id=''){
                            var to_subs = confirm('Do you want to Subscribe this channel.');
                            if (!to_subs){
                                return false;
                            }
                            if(channel_id == "" || my_id == ""){
                                alert("FUNCTION PARAMETER NULL NOT ACCEPTED.");
                                $("#subscribe_channel_error").css({"display": "block"}).html("FUNCTION PARAMETER NULL NOT ACCEPTED.");
                                return false;
                            }
                            else {
                                var data = {};
                                data.report = {};
                                data.report.value_info = channel_id;
                                data.report.my_id = my_id;
                                var q = JSON.stringify(data);
                                jQuery.ajax({
                                    url: "<?php echo site_url('Customer_login_page/Subscribe_channel');?>",
                                    type: "POST",
                                    data: {'jsonObj' : q},
                                    dataType:"json",
                                    cache: false,
                                    beforeSend: function(){
                                        document.getElementById("subscribe_disable").disabled = true;
                                        $("#subscribe_disable").text('Sending .....');
                                    },
                                    complete: function(){
                                        $("#subscribe_disable").text('Subscribe').prop('disabled', false);
                                    },
                                    success: function(res){
                                        //alert(res.status);
                                        if (res.status) {
                                            $("#refresh_subscribe").load(" #refresh_subscribe");
                                            $('#subscribe_channel_error').css('display','none');
                                            $('#subscribe_channel_success').css('display','block').html('Subscribe channel successfully.');
                                            setTimeout(function() {
                                                $('#subscribe_channel_success').fadeOut();
                                            }, 5000 );
                                        }
                                        else{
                                            $('#subscribe_channel_error').css('display','block').html('Subscribe channel failed Please try again.');
                                        }
                                    },
                                    error: function () {
                                        $('#subscribe_channel_error').css('display','block').html('Subscribe channel failed Please try again.');
                                    }
                                });
                            }
                        }

                        function un_subscribe_channel(channel_id='', my_id=''){
                            var un_sub = confirm('Do you want to un-subscribe this channel.');
                            if (!un_sub){
                                return false;
                            }
                            if(channel_id == "" || my_id == ""){
                                alert("FUNCTION PARAMETER NULL NOT ACCEPTED.");
                                $("#subscribe_channel_error").css({"display": "block"}).html("FUNCTION PARAMETER NULL NOT ACCEPTED.");
                                return false;
                            }
                            else {
                                var data = {};
                                data.report = {};
                                data.report.value_info = channel_id;
                                data.report.my_id = my_id;
                                var q = JSON.stringify(data);
                                jQuery.ajax({
                                    url: "<?php echo site_url('Customer_login_page/Subscribe_channel_after');?>",
                                    type: "POST",
                                    data: {'jsonObj' : q},
                                    dataType:"json",
                                    cache: false,
                                    beforeSend: function(){
                                        $("#un_subscribe_disable").text('Sending .....').prop('disabled', true);
                                    },
                                    complete: function(){
                                        $("#un_subscribe_disable").text('Un-Subscribe').prop('disabled', false);
                                    },
                                    success: function(res){
                                        //alert(res.status);
                                        if (res.status) {
                                            $("#refresh_subscribe").load(" #refresh_subscribe");
                                            $('#subscribe_channel_error').css('display','none');
                                            $('#subscribe_channel_success').css('display','block').html('Un-subscribe channel successfully.');
                                            setTimeout(function() {
                                                $('#subscribe_channel_success').fadeOut();
                                            }, 5000 );
                                        }
                                        else{
                                            $('#subscribe_channel_error').css('display','block').html('Un-subscribe channel failed Please try again.');
                                        }
                                    },
                                    error: function () {
                                        $('#subscribe_channel_error').css('display','block').html('Un-subscribe channel failed Please try again.');
                                    }
                                });
                            }
                        }
                    </script>