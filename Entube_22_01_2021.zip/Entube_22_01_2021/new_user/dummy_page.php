	<!-- Start Container -->
	<div class="main-wrapper">
		<div class="main-title myvws-section-01">
			<h2 class="headding-01">Upload Video</h2>
		</div>
		<div class="login-form-block">
			<?php if($this->session->flashdata('msg')) { ?>
				<h2 style="text-align: center;"><?php echo $this->session->flashdata('msg');?></h2>
			<?php } ?>
			<form name="myForm" action="<?php echo base_url("Entube_channel/dummy_upload_video"); ?>" method="post" enctype="multipart/form-data">
				<div class="form-group half-width">
					<input type="file" name="video_file" id="video_file" autocomplete="off" />
				</div>
				<div class="form-group full-width-col center-align-btn">
					<button type="submit" name="submit" value="submit" class="input-submitbtn" tabindex="11">Sign in</button>
				</div>
			</form>
		</div>
	</div>
	<!-- end Container -->