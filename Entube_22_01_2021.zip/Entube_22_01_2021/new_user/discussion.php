<?Php $this->load->view('new_user/channel_header');?>
<!-- Tab panes -->
<div class="tab-content">
	<!-- Start Discussion Tab -->
	<div role="tabpanel" class="">
		<div class="tab-container fwd">
			<div class="containt-block">
				<?php if($this->session->flashdata('msg')) { ?>
					<div id="flash_msg" class="success_message"><?php echo $this->session->flashdata('msg');?></div>
                <?php } ?>
				<div class="col-left fwd">
					<span><?php echo (isset($discussion_count) && !empty($discussion_count)) ? $discussion_count." Comments" : "0 Comment" ?></span>
				</div>
				<div class="col-left space-left col-3-full">
					<?php if($custumer_details['photo']){ ?>
						<img src="<?php echo base_url("uploads/Customer_pan/".$custumer_details['photo']);?>" class="video-user-icon" alt=""/>
					<?php } elseif($this->session->userdata('entube_customer_logged_in')){ ?>
						<img src="<?php echo $this->session->userdata('profileImage');?>" class="video-user-icon" alt=""/>
					<?php } else{ ?>
						<img src="<?php echo base_url('new_user_assets/images/chanel-img.jpg');?>" class="video-user-icon" alt="" />
					<?php } ?>
					<form class="form-horizontal" action="<?php echo base_url('Entube_channel/insert_channel_discussion/'.$this->uri->segment(3))?>" method="POST" onsubmit="return discussion_validation();">
						<textarea class="video-textareabox" name="cha_discussion" id="cha_discussion" placeholder="Add a public comment..." rows="2" style="resize:none;"></textarea>
						<button type="reset" class="video-submitbtn">Cancel</button>
						<?php if(($this->session->userdata('entube_customer_logged_in')) || ($this->session->userdata('logged_in'))){ ?>
							<button type="submit" class="video-submitbtn">Comment</button>
						<?php }else{ ?>
							<button type="button" class="video-submitbtn" data-toggle="modal" data-target="#EPanelistloginModal">Comment</button>
						<?php } ?>
						<div id="discussion_error_msg" class="error_message" style="display:none; width: 80% !important;"></div>
					</form>    
				</div>
				<?php if(isset($discussion_details) && !empty($discussion_details)) foreach ($discussion_details as $key=>$value){
					
					$sql_query = $this->db->query('SELECT id, photo, channel_name, user_name, last_name FROM custumer_login WHERE id = "'.$value['comment_id'].'" AND status = 1');
		            $sql_query1 = $this->db->query('SELECT id, channel_name FROM custumer_channel WHERE user_id = "'.$value['comment_id'].'" AND status = 1');
		            $custumer_details = $sql_query->result_array();
					$channel_details = $sql_query1->result_array();
					?>
					<div class="col-left space-left user-comment-col">
					<?php
						if($custumer_details){
							if($custumer_details[0]['photo']){ ?>
								<img src="<?php echo base_url("uploads/Customer_pan/".$custumer_details[0]['photo']);?>" class="video-user-icon2" alt=""/>
							<?php }
						} elseif($this->session->userdata('entube_customer_logged_in')){ ?>
							<img src="<?php echo $this->session->userdata('profileImage');?>" class="video-user-icon2" alt=""/>
						<?php }
						else{ ?>
							<img src="<?php echo base_url('new_user_assets/images/chanel-img.jpg');?>" class="video-user-icon2" alt="" />
						<?php }
						if($channel_details && ($channel_details[0]['channel_name'])) { ?>
                        	<a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $channel_details[0]['channel_name'];?></span></a>
                        <?php }
                        elseif ($custumer_details && ($custumer_details[0]['channel_name'])) { ?>
                            <a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $custumer_details[0]['channel_name'];?></span></a>
                        <?php }
                        elseif ($custumer_details && ($custumer_details[0]['user_name'])) { ?>
                            <a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $custumer_details[0]['user_name']." ".$custumer_details[0]['last_name'];?></span></a>
                        <?php }
                        elseif ($this->session->userdata('name')) { ?>
                            <a href="<?php echo base_url("Entube_channel/channel/".$this->uri->segment(3));?>"><span class="title-05 fwd"><?php echo $this->session->userdata('name');?></span></a>
                        <?php }
                        else{ ?>
                            <span class="title-05 fwd"><?php echo "OXIINC GROUP";?></span>
                        <?php }
                    	?>
						<span class="title-06 fwd"><?php echo $value['discussion']?></span>
						<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
						<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
					</div>
				<?php } else{ ?>
			  		<p class="text-center">This channel has no discussion.</p>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	function discussion_validation(argument) {
		var cha_discussion = $.trim($("#cha_discussion").val());
        if(cha_discussion == ""){
        	$("#discussion_error_msg").css({"display": "block"}).html("Please enter your channel discussion");
        	return false;
        }
	}
</script>