<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
//$route['default_controller'] = 'welcome';

// CLIENT SIDE
$route['default_controller'] = 'Enews';
$route['view'] = 'home/view';
$route['search'] = 'home/search';
$route['news_list_front'] = 'home/news_list_front';
$route['about'] = 'home/about';
$route['contact'] = 'home/contact';
$route['privacy_policy'] = 'home/privacy_policy';
$route['terms_conditions'] = 'home/terms_conditions';
$route['logout'] = 'home/logout';
$route['temp_front_session/(:any)/(:any)'] = 'home/temp_front_session/$1/$2';
$route['view_list/(:any)/(:any)/(:any)'] = 'home/view_list/$1/$2/$3';


//Feed Controller
$route['rss'] = 'home/rss_feed';
$route['feed'] = 'feed/index';
$route['all_feed/(:any)'] = 'feed/all_feed/$1';


// CLIENT SIDE - TEST
$route['post'] = 'home/post';

// ADMIN SIDE
$route['dashboard'] = 'enms/dashboard';
$route['add_category'] = 'enms/add_category';
$route['edit_category'] = 'enms/edit_category';
$route['category_view'] = 'enms/category_view';
$route['category_list'] = 'enms/category_list';
$route['add_sub_category'] = 'enms/add_sub_category';
$route['edit_sub_category'] = 'enms/edit_sub_category';
$route['sub_category_view'] = 'enms/sub_category_view';
$route['sub_category_list'] = 'enms/sub_category_list';
$route['add_sub_category_section'] = 'enms/add_sub_category_section';
$route['edit_sub_category_section'] = 'enms/edit_sub_category_section';
$route['sub_category_section_view'] = 'enms/sub_category_section_view';
$route['sub_category_section_list'] = 'enms/sub_category_section_list';
$route['add_news'] = 'enms/add_news';
$route['edit_news'] = 'enms/edit_news';
$route['news_view'] = 'enms/news_view';
$route['news_list'] = 'enms/news_list';
$route['comment_list'] = 'enms/comment_list';
$route['enquiry'] = 'enms/enquiry';
$route['profile'] = 'enms/profile';
$route['setting'] = 'enms/setting';
$route['password'] = 'enms/password';
$route['add_about_us'] = 'enms/add_about_us';
$route['about_us_list'] = 'enms/about_us_list';
$route['edit_about_us'] = 'enms/edit_about_us';
$route['add_privacy_policy'] = 'enms/add_privacy_policy';
$route['privacy_policy_list'] = 'enms/privacy_policy_list';
$route['edit_privacy_policy'] = 'enms/edit_privacy_policy';
$route['add_terms_conditions'] = 'enms/add_terms_conditions';
$route['terms_conditions_list'] = 'enms/terms_conditions_list';
$route['edit_terms_conditions'] = 'enms/edit_terms_conditions';
$route['admin_logout'] = 'enms/admin_logout';
$route['temp_session/(:any)/(:any)'] = 'enms/temp_session/$1/$2';

// ADMIN SIDE - TEST
$route['test'] = 'enms/test';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
