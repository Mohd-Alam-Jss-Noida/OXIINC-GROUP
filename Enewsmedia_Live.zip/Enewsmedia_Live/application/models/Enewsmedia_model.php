<?php
Class Enewsmedia_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function check_login($data)
    {
        $this->db->save_queries = true;
        $email = $data['email'];
        $password = md5($data['password']);
        $where = array('email' => $email, 'password'=>$password);
        $result = $this->db->select('*')
                           ->from('admin')
                           ->where($where)
                           ->get();
        $this->db->last_query();
        $count = $result->num_rows();
        if($count == 0)
        {
            $ajax_request = array('status' => 'error', 'message' => 'Invaild Email or Password');
        }
        else
        {
            $row = $result->row_array();
            $id = $row['id'];
            $status = $row['status'];
            if($status=='0')
            {
                $ajax_request = array('status' => 'error', 'message' => 'Account has been blocked');
            }
            else
            {
                $newdata = array(
                    'id'=>$row['id'],
                    'name'=>$row['name'],
                    'email'=>$row['email'],
                    'status'=>$row['status'],
                    'admin_logged_in'=>TRUE
                );
                $this->session->set_userdata($newdata);
                $ajax_request = array('status' => 'success', 'id' => $row['id']);
            }
        }
        //echo "<pre> +++ "; print_r($ajax_request); echo "</pre>"; die();
        return json_encode($ajax_request);
    }

    function insert_table_data($table, $data)
    {
        $this->db->save_queries = true;
        $this->db->protect_identifiers($table, FALSE);
        $this->db->insert($table, $data);
        $this->db->protect_identifiers($table, TRUE);
        unset($data);
        $last_insert_id = $this->db->insert_id();
        $ajax_request = array('status' => 'success', 'last_id' => $last_insert_id);
        echo json_encode($ajax_request);
    }

    function insert_comment_data($data)
    {
        $this->db->save_queries = true;
        $this->db->protect_identifiers('comment', FALSE);
        $this->db->insert('comment', $data);
        $this->db->protect_identifiers('comment', TRUE);
        unset($data);
        $last_insert_id = $this->db->insert_id();
        $ajax_request = array('status' => 'success', 'last_id' => $last_insert_id);
        echo json_encode($ajax_request);
    }

    function fetch_category_data()
    {
        $query = $this->db->select('*')
               ->from('category')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        return $query->result_array();
    }

    function fetch_all_data_front()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('news')
               ->limit(4)
               //->or_where('status', '1')
               ->group_by('cat_id')
               ->having('sub_cat_id <> 0')
               ->limit(4)               
               ->order_by('sequence')
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
            $pass_data[$x]['sub_category_data'] = $this->fetch_all_news_sub_category_data($result[$x]['cat_id']);
        }
        return $pass_data;
    }

    function fetch_all_category_data_front()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('news')
               ->or_where('status', '1')
               ->group_by('cat_id')
               ->order_by('sequence')
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
        }
        return $pass_data;
    }

    function all_feed_categories(){
      //$finalArr = array();
      $feedArr = array(array('cat_name' => 'national', 'image' => 'national.png'),array('cat_name' => 'international', 'image' => 'international.png'), array('cat_name' => 'bollywood', 'image' => 'bollywood.png'), array('cat_name' => 'sports', 'image' => 'sport.png'), array('cat_name' => 'jeevan_mantra', 'image' => 'jeevan-mantra.png'), array('cat_name' => 'business', 'image' => 'bussiness.png'), array('cat_name' => 'auto', 'image' => 'atuo.png'), array('cat_name' => 'happy_life', 'image' => 'happy-life.png'));
      return $feedArr;
    }
//Code for news feed
    function rss_feed(){
      $final_arr = array();
      $feedArr = array('1061' => 'national', '1125' => 'international','11215' => 'bollywood', '1053' => 'sports','3379' => 'jeevan_mantra', '1051' => 'business','10711' => 'auto', '7911' => 'happy_life');
      $dir = date("Y-m-d");
      //$dir = "2020-07-02";
      //$file_name = date("20200702");
      $file_name = date("Ymd");
      foreach ($feedArr as $key => $value) {
        $new_arr = array();
        $file = DOCROOT_PATH. "/data/".$dir."/rss_feed_".$value."_".$file_name.".xml";
        $arrReturn = array();
        if (file_exists($file)) {
        $xmlfile = file_get_contents($file);
        $ob = simplexml_load_string($xmlfile) or die("Failed to load");
        //$ob= simplexml_load_file($xmlfile);
        $json  = json_encode($ob);
        $new_arr = json_decode($json, true);
        $final_arr[$value] = array_slice($new_arr['item'], 0, 10, true);   // returns first 10 elements
        } else {
            $final_arr = json_decode("File does't exists for this feed", true);
        }
      }
      //echo "<pre>";
      //print_r($final_arr); exit();
      
      return $final_arr;
    }

    //view all data
    function all_rss_feed_of_category($category){
        $finalArr = array();
        $dir = date("Y-m-d");
        //$dir = "2020-07-02";
        //$file_name = date("20200702");
        $file_name = date("Ymd");
      
        $file = DOCROOT_PATH . "/data/".$dir."/rss_feed_".$category."_".$file_name.".xml";
        $arrReturn = array();
        if (file_exists($file)) {
          $xmlfile = file_get_contents($file);
          $ob= simplexml_load_string($xmlfile);
          $json  = json_encode($ob);
          $finalArr = json_decode($json, true);
        } else {
            $finalArr = json_decode("File does't exists for this feed", true);
        }
        
      //echo "<pre>";
      //print_r($finalArr); 
      //exit();
      
      return $finalArr;
    }

    function corona_updates(){
      $final_arr = array();
      $previos_date = date('Ymd',strtotime("-1 days"));
      $file = DOCROOT_PATH . "/data/corona_update_".$previos_date.".json";
      $arrReturn = array();
      if (file_exists($file)) {
          $strFileContents = file_get_contents($file);
          if ($strFileContents == '') {
            $api = 'https://api.covid19api.com/total/country/india';
            $result = file_get_contents($api);
            $output_file = fopen($file, "w") or die('Could not open file');
            fwrite($output_file, $result);
            fclose($output_file);
            $arrReturn = $this->corona_updates(true);
          } else {
            $arrReturn = json_decode($strFileContents, true);
            $final_arr = end($arrReturn);
              return $final_arr;
          }
      } else {
          $api = 'https://api.covid19api.com/total/country/india';
          $result = file_get_contents($api);
          $output_file = fopen($file, "w") or die('Could not open file');
          fwrite($output_file, $result);
          fclose($output_file);
          $arrReturn = $this->corona_updates(true);
      }     
     
    }



    function fetch_all_news_sub_category_data($id)
    {
        $this->db->save_queries = true;
        $where = array('cat_id' => $id, 'status' => '1');
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('news')
               ->limit(3)
               ->order_by('sequence')
               ->where($where)
               ->get();
        $this->db->last_query();  //exit();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
        }
        return $pass_data;
      }


    function fetch_sub_category_data()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['details'] = $result[$x]['details'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['category_id']);
        }
        return $pass_data;
    }

    function fetch_sub_category_section_data()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category_section')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['details'] = $result[$x]['details'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_category_id']);
        }
        return $pass_data;
    }

    function fetch_news_listing($id, $sub_id_flag)
    {
        $this->db->save_queries = true;
        $pass_data = array();
        if($sub_id_flag == 1){
          $where = array('sub_cat_id' => $id, 'status' => '1');
        }else{
          $where = array('cat_id' => $id, 'status' => '1');
        }
        $query = $this->db->select('*')
               ->from('news')
               ->where($where)
               ->order_by('news_priority', 'ASC')
               ->get();
        $this->db->last_query();  
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_cat_id']);
        }
        //print_r($pass_data); exit();
        return $pass_data;
    }

    function search_news_data($keyword, $language)
    {
        $this->db->save_queries = true;
        $pass_data = array();
        if($language == 1){ //language = 1 for English 0 for Hindi
          $news_title = 'news_title';
          $news_desc = 'news_desc';
        }else{
          $news_title = 'news_hindi_title';
          $news_desc = 'news_hindi_desc';
        }
        $query = $this->db->select('*')
               ->from('news')
               ->like($news_title, $keyword)
               ->or_like($news_desc, $keyword)
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
            //$pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_cat_id']);
        }
        //print_r($pass_data); exit();
        return $pass_data;
    }

    function fetch_news_data()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('news')
               ->where('status', '1')
               //->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['news_priority'] = $result[$x]['news_priority'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_cat_id']);
        }
        //print_r($pass_data); exit();
        return $pass_data;
    }


    function fetch_about_us_data()
    {
        $query = $this->db->select('*')
               ->from('about_us')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query(); 
        return $query->result_array();
    }

    function fetch_about_us_data_front()
    {
        $query = $this->db->select('*')
               ->from('about_us')
               ->where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        return $query->result_array();
    }

    function fetch_privacy_policy_data()
    {
        $query = $this->db->select('*')
               ->from('privacy_policy')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        return $query->result_array();
    }

    function fetch_privacy_policy_data_front()
    {
        $query = $this->db->select('*')
               ->from('privacy_policy')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        return $query->result_array();
    }

    function fetch_terms_conditions_data_front()
    {
        $query = $this->db->select('*')
               ->from('terms_and_conditions')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        return $query->result_array();
    }

    function fetch_terms_conditions_data()
    {
        $query = $this->db->select('*')
               ->from('terms_and_conditions')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        return $query->result_array();
    }

    function fetch_comment_data()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('comment')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['email'] = $result[$x]['email'];
            $pass_data[$x]['comment'] = $result[$x]['comment'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['category_id']);
            $pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_category_id']);
            $pass_data[$x]['sub_category_hindi_name'] = $this->get_sub_category_hindi_name($result[$x]['sub_category_id']);
        }
        return $pass_data;
    }

    function fetch_enquiry_data()
    {
        $this->db->save_queries = true;
        $query = $this->db->select('*')
               ->from('enquiry')
               ->where('status', '0')
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query();
        return $query->result_array();
    }

    function fetch_comment_data_front()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('comment')
               ->limit(4)
               ->or_where('status', '1')
               ->order_by('id', 'DESC')
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['email'] = $result[$x]['email'];
            $pass_data[$x]['comment'] = $result[$x]['comment'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['category_id']);
            $pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_category_id']);
            $pass_data[$x]['sub_category_hindi_name'] = $this->get_sub_category_hindi_name($result[$x]['sub_category_id']);
            $pass_data[$x]['image'] = ($result[$x]['sub_category_id'] == '0') ? $this->check_db_image('category', $result[$x]['category_id']) : $this->check_db_image('sub_category', $result[$x]['sub_category_id']);
        }
        return $pass_data;
    }

    function fetch_category_data_front()
    {
        $this->db->save_queries = true;
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('category')
               ->where('status', '1')
               ->order_by('sequence')
               ->get();
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data[$x]['sub_category_details'] = $this->get_sub_category_data($result[$x]['id']);
        }
        return $pass_data;
    }

    function get_sub_category_data($id)
    {
        $this->db->save_queries = true;
        $where = array('category_id' => $id, 'status' => '1');
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->order_by('sequence')
               ->where($where)
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
        }
        return $pass_data;
    }

    function get_category_name($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('name')
               ->from('category')
               ->where($where)
               ->get();
        $row = $query->row_array();
        return $row['name'];
    }

    function get_category_hindi_name($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('hindi_name')
               ->from('category')
               ->where($where)
               ->get();
        $row = $query->row_array();
        return $row['hindi_name'];
    }

    function get_sub_category_name($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('name')
               ->from('sub_category')
               ->where($where)
               ->get();
        $row = $query->row_array();
        return $row['name'];
    }

    function get_sub_category_hindi_name($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('hindi_name')
               ->from('sub_category')
               ->where($where)
               ->get();
        $row = $query->row_array();
        return $row['hindi_name'];
    }

    function check_db_image($table, $id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('image')
               ->from($table)
               ->where($where)
               ->get();
          //echo $this->db->last_query(); exit();
        $row = $query->row_array();
        return $row['image'];
    }

    function check_db_counter($table, $id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('counter')
               ->from($table)
               ->where($where)
               ->get();
        $row = $query->row_array();
        return $row['counter'];
    }    

    function fetch_last_id($table)
    {
        $query = $this->db->select('id')
               ->from($table)
               ->order_by('id', 'DESC')
               ->get();
        $row = $query->row_array();
        return $row['id'];
    }

    function fetch_setting_data($value)
    {
        $query = $this->db->select('status')
               ->from('setting')
               ->like('name', $value)
               ->get();
        $row = $query->row_array();
        return $row['status'];
    }

    function category_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('category')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function about_us_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('about_us')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function privacy_policy_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('privacy_policy')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function terms_conditions_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('terms_and_conditions')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function get_all_category_details($id)
    {
        $this->db->save_queries = true;
        $where = array('category_id' => $id);
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->limit(4)
               ->where($where)
               ->get();
        $this->db->last_query();
        return $query->result_array();
    }

    function get_all_related_news($id)
    {
        $this->db->save_queries = true;
        $where = array('cat_id' => $id);
        $pass_data = array();
        $final_arr = array();
        $query = $this->db->select('*')
               ->from('news')
               ->limit(4)
               ->where($where)
               ->get();
        $this->db->last_query();
        $result = $query->result_array();
        //print_r($result); exit();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];

        }
        //print_r($pass_data); exit();

        return $pass_data;    
    }

    function get_recent_happenings_data()
    {
        $this->db->save_queries = true;
        $pass_data = $result = array();
        $query = $this->db->select('*')
               ->from('news')
               ->limit(3)
               ->order_by('created', 'DESC')
               ->get();
        $this->db->last_query();
        $count = $query->num_rows(); 
        $result = $query->result_array();   
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
            $pass_data[$x]['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_cat_id']);
            $pass_data[$x]['sub_category_hindi_name'] = $this->get_sub_category_hindi_name($result[$x]['sub_cat_id']);
            
        }
        return $pass_data;
    }

    function fetch_recent_data_front()
    {
        $this->db->save_queries = true;
        $pass_data = $result = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->limit(4)
               ->order_by('created', 'DESC')
               ->get();
        $this->db->last_query();
        $count = $query->num_rows(); 
        $result = $query->result_array();   
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['details'] = $result[$x]['details'];
            $pass_data[$x]['hindi_details'] = $result[$x]['hindi_details'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['category_id']);
        }
        return $pass_data;
    }

    function get_popular_data()
    {
        $this->db->save_queries = true;
        $pass_data = $result = array();
        $query = $this->db->select('*')
               ->from('news')
               ->limit(6)
               ->where('status', '1')
               ->order_by('counter', 'DESC')
               ->get();
        $this->db->last_query();
        $count = $query->num_rows(); 
        $result = $query->result_array();   
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['cat_id'];
            $pass_data[$x]['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data[$x]['name'] = $result[$x]['news_title'];
            $pass_data[$x]['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data[$x]['media_type'] = $result[$x]['media_type'];
            $pass_data[$x]['details'] = $result[$x]['news_desc'];
            $pass_data[$x]['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
        }
        return $pass_data;
    }

    function fetch_popular_data_front()
    {
        $this->db->save_queries = true;
        $pass_data = $result = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->limit(4)
               ->order_by('counter', 'DESC')
               ->get();
        $this->db->last_query();
        $count = $query->num_rows(); 
        $result = $query->result_array();   
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['details'] = $result[$x]['details'];
            $pass_data[$x]['hindi_details'] = $result[$x]['hindi_details'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['created'] = $result[$x]['created'];
            $pass_data[$x]['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data[$x]['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['category_id']);
        }
        return $pass_data;
    }

    function sub_category_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('sub_category')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function sub_category_section_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('sub_category_section')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function news_details($id)
    {
        $where = array('id' => $id);
        $query = $this->db->select('*')
               ->from('news')
               ->where($where)
               ->get();
        //return $query->result_array();
        return $query->row_array();
    }

    function fetch_all_sub_category_data($id)
    {
        $this->db->save_queries = true;
        $where = array('category_id' => $id, 'status' => '1');
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->order_by('sequence')
               ->where($where)
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data[$x]['id'] = $result[$x]['id'];
            $pass_data[$x]['category_id'] = $result[$x]['category_id'];
            $pass_data[$x]['name'] = $result[$x]['name'];
            $pass_data[$x]['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data[$x]['image'] = $result[$x]['image'];
            $pass_data[$x]['details'] = $result[$x]['details'];
            $pass_data[$x]['hindi_details'] = $result[$x]['hindi_details'];
            $pass_data[$x]['sequence'] = $result[$x]['sequence'];
            $pass_data[$x]['status'] = $result[$x]['status'];
            $pass_data[$x]['counter'] = $result[$x]['counter'];
            $pass_data[$x]['created'] = $result[$x]['created'];
        }
        return $pass_data;
      }

    function get_sub_category_details($id)
    {
        $this->db->save_queries = true;
        $where = array('id' => $id);
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category')
               ->where($where)
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data['id'] = $result[$x]['id'];
            $pass_data['category_id'] = $result[$x]['category_id'];
            $pass_data['name'] = $result[$x]['name'];
            $pass_data['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data['image'] = $result[$x]['image'];
            $pass_data['details'] = $result[$x]['details'];
            $pass_data['hindi_details'] = $result[$x]['hindi_details'];
            $pass_data['sequence'] = $result[$x]['sequence'];
            $pass_data['counter'] = $result[$x]['counter'];
            $pass_data['status'] = $result[$x]['status'];
            $pass_data['created'] = $result[$x]['created'];
            $pass_data['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['category_id']);
        }
        return $pass_data;
    }

    function get_sub_category_section_details($id)
    {
        $this->db->save_queries = true;
        $where = array('id' => $id);
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('sub_category_section')
               ->where($where)
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data['id'] = $result[$x]['id'];
            $pass_data['category_id'] = $result[$x]['category_id'];
            $pass_data['sub_category_id'] = $result[$x]['sub_category_id'];
            $pass_data['name'] = $result[$x]['name'];
            $pass_data['hindi_name'] = $result[$x]['hindi_name'];
            $pass_data['image'] = $result[$x]['image'];
            $pass_data['details'] = $result[$x]['details'];
            $pass_data['hindi_details'] = $result[$x]['hindi_details'];
            $pass_data['sequence'] = $result[$x]['sequence'];
            $pass_data['status'] = $result[$x]['status'];
            $pass_data['category_name'] = $this->get_category_name($result[$x]['category_id']);
            $pass_data['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['category_id']);
            $pass_data['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_category_id']);
            $pass_data['sub_category_hindi_name'] = $this->get_sub_category_hindi_name($result[$x]['sub_category_id']);
        }
        return $pass_data;
    }

    function get_news_details($id)
    {
        $this->db->save_queries = true;
        $where = array('id' => $id);
        $pass_data = array();
        $query = $this->db->select('*')
               ->from('news')
               ->where($where)
               ->get();
        $this->db->last_query(); 
        $result = $query->result_array();
        for($x = 0; $x < count($result); $x++)
        {
            $pass_data['id'] = $result[$x]['id'];
            $pass_data['category_id'] = $result[$x]['cat_id'];
            $pass_data['sub_category_id'] = $result[$x]['sub_cat_id'];
            $pass_data['name'] = $result[$x]['news_title'];
            $pass_data['hindi_name'] = $result[$x]['news_hindi_title'];
            $pass_data['image'] = $result[$x]['image'];
            $pass_data['video_thumb_img'] = $result[$x]['video_thumb_img'];
            $pass_data['media_type'] = $result[$x]['media_type'];
            $pass_data['details'] = $result[$x]['news_desc'];
            $pass_data['hindi_details'] = $result[$x]['news_hindi_desc'];
            $pass_data['sequence'] = $result[$x]['sequence'];
            $pass_data['status'] = $result[$x]['status'];
            $pass_data['created'] = $result[$x]['created'];
            $pass_data['category_name'] = $this->get_category_name($result[$x]['cat_id']);
            $pass_data['category_hindi_name'] = $this->get_category_hindi_name($result[$x]['cat_id']);
            $pass_data['sub_category_name'] = $this->get_sub_category_name($result[$x]['sub_cat_id']);
            $pass_data['sub_category_hindi_name'] = $this->get_sub_category_hindi_name($result[$x]['sub_cat_id']);
        }
        return $pass_data;
    }

    function category_count()
    {
        $query = $this->db->select('*')
               ->from('category')
               ->where('status', '0')
               ->or_where('status', '1')
               ->get();
        return $query->num_rows();
    }

    function sub_category_count()
    {
        $query = $this->db->select('*')
               ->from('sub_category')
               ->where('status', '0')
               ->or_where('status', '1')
               ->get();
        return $query->num_rows();
    }

    function sub_category_section_count()
    {
        $query = $this->db->select('*')
               ->from('sub_category_section')
               ->where('status', '0')
               ->or_where('status', '1')
               ->get();
        return $query->num_rows();
    }

    function comment_count_admin()
    {
        $query = $this->db->select('*')
               ->from('comment')
               ->where('status', '0')
               ->or_where('status', '1')
               ->get();
        return $query->num_rows();
    }

    function comment_count($column, $id)
    {
        $where = array($column => $id);
        $query = $this->db->select('*')
               ->from('comment')
               ->where($where)
               ->where('status', '1')
               ->get();
        $this->db->last_query();
        return $query->num_rows();
    }

    function setting_count($value)
    {
        $where = array('name' => $value);
        $query = $this->db->select('*')
               ->from('setting')
               ->where($where)
               ->get();
        $this->db->last_query();
        return $query->num_rows();
    }

    public function change_status($table, $set, $where)
    {
        $this->db->update($table, $set, $where);
        //echo $this->db->last_query(); exit();

        $ajax_request = array('status' => 'success');
        echo json_encode($ajax_request);
    }

    function check_old_password($data)
    {
        $this->db->save_queries = true;
        $id = $data['id'];
        $password = $data['password'];
        $where = array('id' => $id, 'password' => $password);
        $result = $this->db->select('*')
               ->from('admin')
               ->where($where)
               ->get();
        return $result->num_rows();
    }
}