<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feed extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('enewsmedia_model', 'enmm');
	}

	public function index()
	{
		$data = array();
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['news_info'] = 0;
		$data['recent_happenings'] = $this->enmm->get_recent_happenings_data();
		$data['load_page']='feed_detail';
        $this->load->view('load_page', $data);
	}

	function save_data(){
		$data = array();
		$cat_name = $title = $image = $description = '';
		$cat_name = $this->input->post('cat_name');
		$title = $this->input->post('title');
		$image = $this->input->post('image');
		$description = $this->input->post('desciption');
		$created = $this->input->post('created');		
		$temp_session = $this->session->userdata('title');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('cat_name','title','image','description' );
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
	        $data['cat_name'] = $cat_name;
	        $data['title'] = $title;
	        $data['image'] = $image;
	        $data['description'] = $description;
	        $data['created'] = $created;
	        $this->session->set_userdata($data);
		}
		else
		{
	        $data['cat_name'] = $cat_name;
			$data['title'] = $title;
	        $data['image'] = $image;
	        $data['description'] = $description;
	        $data['created'] = $created;
	        $this->session->set_userdata($data);
		}
		$ajax_request = array('status' => 'success');
        echo json_encode($ajax_request);
	}

	function all_feed()
	{
		$data = array();
	    $cat_name = $this->uri->segment(2);
	    $this->session->set_userdata('cat_name', $cat_name);
	    //print_r($this->session->userdata()); exit();
	    $data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
	    $data['feed_data'] = $this->enmm->all_rss_feed_of_category($cat_name);
		//print_r($data['feed_data']); exit();
		$data['load_page']='all_feed';
		$this->load->view('load_page', $data);		
	}

}