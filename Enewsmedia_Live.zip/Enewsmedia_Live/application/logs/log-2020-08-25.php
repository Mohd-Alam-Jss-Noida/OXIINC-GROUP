<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-25 00:33:29 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 00:43:59 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 00:54:54 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 00:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 01:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 01:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 01:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 03:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 03:24:51 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2020-08-25 03:39:54 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 05:46:14 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 05:50:00 --> 404 Page Not Found: Tag/dream
ERROR - 2020-08-25 06:14:43 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 07:33:13 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 08:52:48 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 10:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 10:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 13:12:24 --> 404 Page Not Found: %0A%09%09%20https:/www.bhaskar.com
ERROR - 2020-08-25 13:58:54 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2020-08-25 13:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 15:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 15:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 15:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 16:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-08-25 16:05:38 --> 404 Page Not Found: Images/news
