		<?php //echo "<pre>"; print_r($menu_data); echo "</pre>"; ?>
		<!-- Footer Start -->
		<div class="ts-footer">
			<div class="container">
				<div class="row ts-gutter-30 justify-content-lg-between justify-content-center">
					<div class="col-lg-3 col-md-4">
						<div class="footer-widtet post-widget">
							<div class="widget-content">
								<div class="footer-ads">
									<ul>
										<li class="post-title" id="footer_title_style"><a href="<?php echo base_url('about'); ?>"><?php if($website_language == '0') { echo "हमारे बारे में"; } else { echo "About Us"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="<?php echo base_url('contact'); ?>"><?php if($website_language == '0') { echo "संपर्क करें"; } else { echo "Contact Us"; } ?>
										</a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "हमारे साथ विज्ञापन"; } else { echo "Advertise With Us"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "शिकायत निवारण"; } else { echo "Complaint Redressal"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "निवेशक"; } else { echo "Investors"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "हमें परवाह है"; } else { echo "We Care"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="<?php echo base_url('privacy_policy'); ?>"><?php if($website_language == '0') { echo "गोपनीयता नीति"; } else { echo "Privacy Policy"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="<?php echo base_url('terms_conditions'); ?>"><?php if($website_language == '0') { echo "नियम एवं शर्तें"; } else { echo "Terms & Conditions"; } ?></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div> 
					<div class="col-lg-3 col-md-4">
						<div class="footer-widtet">
							<h3 class="widget-title"><span><?php if($website_language == '0') { echo "सूची"; } else { echo "SECTIONS"; } ?></span></h3>
							<div class="widget-content">
								<div class="row">
									<?php
										foreach($menu_data as $key => $value)
										{
											?>
											<div class="col-sm-4">
												<ul>
													<li class="post-title" id="footer_title_style"><a href="#" onclick="view_details('<?php echo $menu_data[$key]['id']; ?>', 'category')"><?php if($website_language == '0') { echo $menu_data[$key]['hindi_name']; } else { echo $menu_data[$key]['name']; } ?></a></li>
												</ul>
											</div>
											<?php
										}
									?>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-4">
						<div class="footer-widtet">
							<h3 class="widget-title"><span><?php if($website_language == '0') { echo "हमसे जुडे"; } else { echo "CONNECT WITH US"; } ?></span></h3>
							<div class="widget-content">
								<ul class="ts-social">
									<li><a href="https://www.facebook.com/Erocketmallonlineasialtd/" target="_blank"><i class="fa fa-facebook"></i></a></li>
									<li><a href="https://twitter.com/myoxiinc" target="_blank"><i class="fa fa-twitter"></i></a></li>
									<li><a href="https://www.youtube.com/channel/UCim_GlgyKZ2aJF7KhUEE3Gw" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
									<li><a href="https://www.linkedin.com/in/oxiinc-health-care-company-pvt-ltd-b00720117/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
									<!-- <li><a href="#"><i class="fa fa-rss"></i></a></li> -->
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="row ts-gutter-30 justify-content-lg-between justify-content-center">
					<div class="col-lg-3 col-md-4">
						<div class="footer-widtet post-widget">
							<h3 class="widget-title"><span><?php if($website_language == '0') { echo "शिक्षा"; } else { echo "EDUCATION"; } ?></span></h3>
							<div class="widget-content">
								<div class="footer-ads">
									<ul>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "वसंत घाटी"; } else { echo "Vasant Valley"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "ऑनलाइन पाठ्यक्रम"; } else { echo "Online Courses"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "शिक्षा"; } else { echo "Education"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "नए पाठ्यक्रम"; } else { echo "New Courses"; } ?></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-4">
						<div class="footer-widtet post-widget">
							<h3 class="widget-title"><span><?php if($website_language == '0') { echo "अंशदान"; } else { echo "SUBSCRIPTION"; } ?></span></h3>
							<div class="widget-content">
								<div class="footer-ads">
									<ul>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "कॉस्मोपॉलिटन"; } else { echo "Cosmopolitan"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "प्रेम सूत्र"; } else { echo "Love Sutras"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "पढ़ने वाले का संग्रह"; } else { echo "Reader Digest"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "समय"; } else { echo "Time"; } ?></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-4">
						<div class="footer-widtet post-widget">
							<h3 class="widget-title"><span><?php if($website_language == '0') { echo "आयोजन"; } else { echo "EVENTS"; } ?></span></h3>
							<div class="widget-content">
								<div class="footer-ads">
									<ul>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "साहित्य एनुश्मिया"; } else { echo "Sahitya Enewsmedia"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "साहित्य कार्यसूची"; } else { echo "Agenda Enewsmedia"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "निर्वाचिका सभा कार्यसूची"; } else { echo "Conclave Enewsmedia"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "महिला सम्मेलन एनुश्मिया"; } else { echo "Women’s Summit Enewsmedia"; } ?></a></li>
										<li class="post-title" id="footer_title_style"><a href="#"><?php if($website_language == '0') { echo "युवा सम्मेलन एनुश्मिया"; } else { echo "Youth’s Summit Enewsmedia"; } ?></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="ts-copyright">
			<div class="container">
				<div class="row align-items-center justify-content-between">
					<div class="col-12 text-center">
						<div class="copyright-content text-light">
							<!-- <p>&copy; All Rights Reserved. Powered by EROCKETMALL ONLINE ASIA LIMITED</p> -->
							<p>&copy; Design and Developed by <a href="https://www.oxiincgroup.com/" target="_blank">OXIINCGROUP.COM</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="top-up-btn">
			<div class="backto" style="display: block;"> 
				<a href="#" class="icon icon-arrow-up" aria-hidden="true"></a>
			</div>
		</div>
		<center style="background-color: #222222; padding: 5px;"><span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=auj0sgespvsNRoYrmA2tYmoOrZv3FYZHUygn6YeAhLskKWluKAf1neHmRkNp"></script></span></center>
		<!-- Footer End -->
		<!-- initialize jQuery Library -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.js"></script>
		<!-- Popper Jquery -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/popper.min.js"></script>
		<!-- Bootstrap jQuery -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/bootstrap.min.js"></script>
		<!-- magnific-popup -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.magnific-popup.min.js"></script>
		<!-- Owl Carousel -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/owl.carousel.min.js"></script>
		<!-- Color box -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.colorbox.js"></script>
		<!-- Template custom -->
		<script src="<?php echo ASSET_URL; ?>/assets/js/custom.js"></script>
	</body>
</html>