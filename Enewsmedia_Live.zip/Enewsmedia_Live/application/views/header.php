<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Enewsmedia - The Power Of Information</title>
		<!-- Mobile Specific Metas -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    	<meta name="title" content="Enewsmedia - The Power Of Information" >
		<meta name="description" content="Enewsmedia.in provides latest news around the world. ">
		<meta name="keywords" content="enewsmedia.in,weather,food,agriculture,technology,bollywood,cricket,videos,photos,corona,politics and live news coverage and exclusive breaking news from india" >
		<meta property="og:description" content="Enewsmedia.in provides latest news around the world." />
        <meta property="og:title" content="Enewsmedia - The Power Of Information" />
        <meta property="og:image" content="<?php echo ASSET_URL; ?>/assets/images/logos/logo.png" />
        <meta property="og:url" content="<?php echo base_url(); ?>" /> 

		<!--Favicon-->
		<link rel="shortcut icon" href="<?php echo ASSET_URL; ?>/assets/images/favicon.png" type="image/x-icon">
		<link rel="icon" href="<?php echo ASSET_URL; ?>/assets/images/favicon.png" type="image/x-icon">
		<!-- Bootstrap -->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/bootstrap.min.css">
		<!-- IconFont -->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/iconfonts.css">
		<!-- FontAwesome -->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/font-awesome.min.css">
		<!-- Owl Carousel -->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/owl.theme.default.min.css">
		<!-- magnific -->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/magnific-popup.css">
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/animate.css">
		<!-- Template styles-->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/style.css">
		<!-- Responsive styles-->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/responsive.css">
		<!-- Colorbox -->
		<link rel="stylesheet" href="<?php echo ASSET_URL; ?>/assets/css/colorbox.css">
        <!-- Facebook/LinkedIn Share -->
        
	</head>
	<body>	
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v7.0&appId=693216931533242&autoLogAppEvents=1" nonce="ApQFXM7C"></script>	
	<!-- <div class="trending-bar trending-light d-md-block">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-md-9 text-center text-md-left">
					<p class="trending-title"><i class="tsicon fa fa-bolt"></i> Trending Now</p>
					<div id="trending-slide" class="owl-carousel owl-theme trending-slide">
						<div class="item">
						   <div class="post-content">
						      <h2 class="post-title title-small">
						         <a href="#">The best MacBook Pro alternatives in 2017 for Apple users</a>
						      </h2>
						   </div>
						</div>
						<div class="item">
						   <div class="post-content">
						      <h2 class="post-title title-small">
						         <a href="#">Soaring through Southern Patagonia with the Premium Byrd drone</a>
						      </h2>
						   </div>
						</div>
						<div class="item">
						   <div class="post-content">
						      <h2 class="post-title title-small">
						         <a href="#">Super Tario Run isn’t groundbreaking, but it has Mintendo charm</a>
						      </h2>
						   </div>
						</div>
					</div>
				</div>
				<div class="col-md-3 text-md-right text-center">
					<div class="ts-date">
						<i class="fa fa-calendar-check-o"></i>May 29, 2017
					</div>
				</div>
			</div>
		</div>
	</div> -->
	<header id="header" class="header">
		<div class="container">
			<div class="row align-items-center justify-content-between">
				<div class="col-md-3 col-sm-12">
					<div class="logo">
						 <a href="<?php echo base_url(); ?>">
							<img src="<?php echo ASSET_URL; ?>/assets/images/logos/logo.png" alt="">
						 </a>
					</div> 
				</div>
				<div class="col-md-8 col-sm-12 header-right">
					<div class="ad-banner float-right">
						<a href="#">
							<img src="<?php echo ASSET_URL; ?>/assets/images/banner-image/image1.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>
	</header>
