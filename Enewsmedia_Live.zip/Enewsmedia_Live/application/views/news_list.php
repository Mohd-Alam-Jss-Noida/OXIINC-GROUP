	<?php
	$menu_category_name = isset($category_data['category_name']) && !empty($category_data['category_name']) ? $category_data['category_name'] : $category_data['name'];
	$menu_category_hindi_name = isset($category_data['category_hindi_name']) && !empty($category_data['category_hindi_name']) ? $category_data['category_hindi_name'] : $category_data['hindi_name'];
	$menu_sub_category_name = isset($category_data['name']) && !empty($category_data['name']) ? $category_data['name'] : '';
	$menu_sub_category_hindi_name = isset($category_data['hindi_name']) && !empty($category_data['hindi_name']) ? $category_data['hindi_name'] : '';
		
	$no_image_path = ASSET_URL. "/assets/news/".''."no_image.png";

	//print_r($category_data); exit();
	?>
	
	<style>
    	/*.address_color
    	{
    		background: linear-gradient(20deg, #f84270 0%, #fe803b 100%)!important;padding: 19px;color:white;
        }*/

        .address_color
        {
        	background: #171616 !important;
    		padding: 19px;
    		color: white;
		}
    </style>
	<div class="gap-30"></div>

	<?php
		//echo "<pre> --- RECENT --- "; print_r($recent_data); echo "</pre>";
		//echo "<pre> --- POPULAR --- "; print_r($popular_data); echo "</pre>";
		//echo "<pre> --- COMMENT ---"; print_r($comment_data); echo "</pre>";
	?>

	<div class="gap-30"></div>

	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li>
							<i class="fa fa-home"></i>
								<a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a>
							<i class="fa fa-angle-right"></i>
						</li>
						<li><?php if($website_language == '0') { echo $menu_category_hindi_name; } else { echo $menu_category_name; } ?></li>
						<li <?php if((isset($menu_sub_category_hindi_name) && !empty($menu_sub_category_hindi_name)) && $sub_id_flag == 1) {} else { ?> style="display: none;" <?php } ?>><i class="fa fa-angle-right"></i>
							<?php if($website_language == '0') { echo $menu_sub_category_hindi_name; } else { echo $menu_sub_category_name; } ?>
						</li>
					</ol>		
				</div>
			</div>
		</div>
	</div>
	
<section class="main-content category-layout-1 pt-0">
		<br>
		<div class="container">
	<div class="tab-pane animated fadeInRight" id="post_tab_b">
		<div class="list-post-block">
			<ul class="list-post">
				<?php foreach($news_listing as $key => $value) { 
					$show_image = isset($news_listing[$key]['image']) ? ASSET_URL."/assets/news/".''.$news_listing[$key]['image'] : $no_image_path;
					$video_thumb_img = isset($news_listing[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$news_listing[$key]['video_thumb_img'] : $no_image_path;
					//echo "here";
					//print_r($news_listing[$key]); 
					//print_r($news_listing); exit();
					?>
				<li>
					<?php if(isset($news_listing[$key]['media_type']) && $news_listing[$key]['media_type'] == 'video') {
					 ?>
						<div class="post-block-style media">
						<div class="post-thumb">
							<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="" style="height: -webkit-fill-available;">
							<a class="popup cboxElement" href="<?php echo $show_image; ?>">
								<div class="video-icon">
									<i class="fa fa-play"></i>
								</div>
							</a>
						</div><!-- Post thumb end -->

						<div class="post-content media-body">
							<div class="grid-category">
								<a class="post-cat travel-color" href="#"><?php if($website_language == '0') { echo $menu_sub_category_hindi_name; } else { echo $menu_sub_category_name; } ?></a>
							</div>
							<h2 class="post-title">
								<a href="#" onclick="view_details('<?php echo $news_listing[$key]['id']; ?>', 'news')">
									<?php if($website_language == '0') { echo (strlen($news_listing[$key]['hindi_name']) > 50) ? substr($news_listing[$key]['hindi_name'], 0, 50).' '."..." : $news_listing[$key]['hindi_name']; } else { echo (strlen($news_listing[$key]['name']) > 50) ? substr($news_listing[$key]['name'], 0, 50).' '."..." : $news_listing[$key]['name']; } ?></a>
							</h2>
							<div class="post-meta mb-7">
								<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($news_listing[$key]['created']) && !empty($news_listing[$key]['created']) ? date('d F, Y', strtotime($news_listing[$key]['created'])) : ''; ?></span>								
							</div>
							</div><!-- Post content end -->
					</div><!-- Post block style end -->
					<?php } else { ?>
					<div class="post-block-style media">
						<div class="post-thumb">
							<a href="#">
								<img class="img-fluid" src="<?php echo $show_image; ?>" alt="">
							</a>
						</div><!-- Post thumb end -->

						<div class="post-content media-body">
							<div class="grid-category">
								<a class="post-cat travel-color" href="#"><?php if($website_language == '0') { echo $menu_sub_category_hindi_name; } else { echo $menu_sub_category_name; } ?></a>
							</div>
							<h2 class="post-title">
								<a href="#" onclick="view_details('<?php echo $news_listing[$key]['id']; ?>', 'news')">
									<?php if($website_language == '0') { echo (strlen($news_listing[$key]['hindi_name']) > 50) ? substr($news_listing[$key]['hindi_name'], 0, 50).' '."..." : $news_listing[$key]['hindi_name']; } else { echo (strlen($news_listing[$key]['name']) > 50) ? substr($news_listing[$key]['name'], 0, 50).' '."..." : $news_listing[$key]['name']; } ?></a>
							</h2>
							<div class="post-meta mb-7">
								<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($news_listing[$key]['created']) && !empty($news_listing[$key]['created']) ? date('d F, Y', strtotime($news_listing[$key]['created'])) : ''; ?></span>								
							</div>
							</div><!-- Post content end -->
					</div><!-- Post block style end -->
				<?php } ?>
				</li><!-- Li 1 end -->	
				<?php } ?>			
			</ul><!-- List post end -->
		</div>
	</div>
</div>
</section>
	<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.js"></script>
