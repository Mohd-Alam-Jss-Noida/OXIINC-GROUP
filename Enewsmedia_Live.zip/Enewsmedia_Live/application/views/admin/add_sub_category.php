
	            <!-- center part  -->
	            <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-dot-circle-o"></i>
                                    </div>
                                    <div>
                                        Add Sub Category
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <?php //echo "<pre>"; print_r($category); echo "</pre>"; ?>
                            <!-- <form action="" enctype="multipart/form-data"> -->
                                <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                    <div class="main-card mb-3 card">
                                        <div class="card-body">
                                            <center>
                                                <label id="sub_category_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                                <label id="sub_category_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                            </center>
                                            <div class="form-row">
                                                <div class="col-md-12">
                                                    <div class="position-relative form-group">
                                                        <label for="exampleEmail11" class="">Category *</label>
                                                        <select class="form-control" name="category" id="category" data-id="sub_category">
                                                            <option value="0">Select</option>
                                                            <?php
                                                                foreach ($category as $key => $value)
                                                                {
                                                                    ?>
                                                                    <option value="<?php echo $category[$key]['id']; ?>"><?php echo $category[$key]['name']; ?></option>
                                                                    <?php
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="position-relative form-group">
                                                        <label for="exampleCity" class="">Name *</label>
                                                        <input name="name" id="name" placeholder="Name" type="text" class="form-control" onKeyPress="return space_capital_small_alphabets(event)" data-id="sub_category">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="position-relative form-group">
                                                        <label for="exampleCity" class="">Hindi Name *</label>
                                                        <input name="hindi_name" id="hindi_name" placeholder="Name" type="text" class="form-control" onKeyPress="return space_capital_small_alphabets(event)" data-id="sub_category">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="position-relative form-group">
                                                        <label for="" class="">Photo *</label>
                                                        <input name="image[]" id="image" type="file" class="form-control" data-id="sub_category">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="position-relative form-group">
                                                        <label for="exampleCity" class="">Sequence</label>
                                                        <input name="sequence" id="sequence" placeholder="Sequence" type="text" class="form-control" onKeyPress="return numbers_only(event)" data-id="sub_category">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="exampleCity" class="">Details *</label>
                                                    <input name="details" id="details" type="text" class="form-control" data-id="sub_category">
                                                    <!-- <div class="divider"></div> -->
                                                </div>                                                
                                                <div class="col-md-12">
                                                    <label for="exampleCity" class="">Hindi Details *</label>
                                                    <textarea name="hindi_details" rows="4" id="hindi_details" class="form-control" data-id="sub_category"></textarea>
                                                </div>
                                            </div>
                                            <?php
                                                $sub_category_last_id = isset($sub_category_last_id) && !empty($sub_category_last_id) ? $sub_category_last_id + 1 : '1';
                                            ?>
                                            <input type="hidden" name="hid_last_id" id="hid_last_id" value="<?php echo $sub_category_last_id; ?>">
                                            <button class="mt-2 btn btn-primary" onclick="sub_category()">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            <!-- </form> -->
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
	            <!-- center part -->

                <!-- English To Hindi -->
                <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script> -->
                <script src="./assets/js/english_to_hindi.js"></script>
                <script type="text/javascript">
                    google.load("elements", "1", {packages: "transliteration"});
                </script> 
                <script>
                    function OnLoad()
                    {
                        var options = {
                            sourceLanguage:
                            google.elements.transliteration.LanguageCode.ENGLISH,
                            destinationLanguage:
                            [google.elements.transliteration.LanguageCode.HINDI],
                            shortcutKey: 'ctrl+g',
                            transliterationEnabled: true
                        };

                        var control = new google.elements.transliteration.TransliterationControl(options);
                        control.makeTransliteratable(["hindi_name"]);
                        control.makeTransliteratable(['hindi_details']);
                    }
                    google.setOnLoadCallback(OnLoad);
                </script>
                <!-- English To Hindi -->

                <!-- SUMMERNOTE -->
                <script src="./assets/js/jquery.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        $('#details').summernote();
                    });
                </script>
                <!-- SUMMERNOTE -->

                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("ADD SUB CATEGORY PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'sub_category')
                                { sub_category(); }
                            }
                        });
                    });

                    function text_box_empty(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        return false //disable key press
                    }
                
                    function space_capital_small_alphabets(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        if (unicode!=8) //if the key isn't the backspace key (which we should allow)
                        { 
                            if ((unicode<65||unicode>90) && (unicode<97||unicode>122) && (unicode!=32)) //if not a number
                                return false //disable key press
                        }
                    }

                    function numbers_only(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        if (unicode!=8) //if the key isn't the backspace key (which we should allow)
                        { 
                            if (unicode<48||unicode>57) //if not a number
                                return false //disable key press
                        }
                    }

                    function sub_category()
                    {
                        var chk=0;
                        var SubcategoryData = new FormData();
                        var category = $('#category').val();
                        var name = $('#name').val();
                        var hindi_name = $('#hindi_name').val();
                        var image = $('#image').val();
                        var sequence = $('#sequence').val();
                        var details = $('#details').summernote('code');
                        var hindi_details = $('#hindi_details').val();
                        var last_id = $('#hid_last_id').val();
                        var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif|\.bmp)$/i;

                        /// IMAGES
                        var image_selection_extension = true;
                        var image_document_selection = document.getElementById('image');
                        for(var i=0; i<image_document_selection.files.length; i++)
                        {
                          var fname = image_document_selection.files.item(i).name;
                          var ext = image_document_selection.files[i].name.split('.').pop();
                          if($.inArray(ext, ['gif','png','jpg','jpeg','bmp','pdf']) == -1)
                          {
                            //alert('not accepted file extension ' + fname);
                            image_selection_extension = false;
                          }
                        }

                        if(document.getElementById('category').value=='0')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please select category";
                            document.getElementById("category").focus();
                            chk=1;
                        }
                        else if(document.getElementById('name').value=='')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please enter name";
                            document.getElementById("name").focus();
                            chk=1;
                        }
                        else if(document.getElementById('hindi_name').value=='')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please enter hindi name";
                            document.getElementById("hindi_name").focus();
                            chk=1;
                        }
                        else if(document.getElementById('image').value=='')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please select image";
                            document.getElementById("image").focus();
                            chk=1;
                        }
                        else if(!allowedExtensions.exec(image))
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Photo extension must be .jpg/.jpeg/.png/.gif/.bmp only";
                            document.getElementById("image").focus();
                            chk=1;
                        }
                        /*else if(document.getElementById('sequence').value=='')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please enter sequence";
                            document.getElementById("sequence").focus();
                            chk=1;
                        }*/
                        else if(details=='<p><br></p>')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please enter details";
                            document.getElementById("details").focus();
                            chk=1;
                        }
                        else if(hindi_details=='')
                        {
                            document.getElementById('sub_category_msg').innerHTML="";
                            document.getElementById('sub_category_error').innerHTML="Please enter hindi details";
                            document.getElementById("hindi_details").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {
                            for(var i=0; i<image_document_selection.files.length; i++)
                            {
                                SubcategoryData.append("image", document.getElementById('image').files[i]);
                            }
                            var image_extension = image.split('.').pop();
                            var image_name = last_id + '.' + image_extension;
                            SubcategoryData.append("category", category);
                            SubcategoryData.append("name", name);
                            SubcategoryData.append("hindi_name", hindi_name);
                            SubcategoryData.append("image_name", image_name);
                            //SubcategoryData.append("image", document.getElementById('image').files.item(0).name);
                            SubcategoryData.append("details", details);
                            SubcategoryData.append("hindi_details", hindi_details);
                            SubcategoryData.append("sequence", sequence);
                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url('enms/insert_sub_category'); ?>',
                                data: SubcategoryData,
                                contentType: false,
                                cache: false,
                                processData: false,
                                success:function(data){
                                    //alert(data);
                                    var obj = JSON.parse(data);
                                    //alert(obj.status);
                                    //alert(obj.message);
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('sub_category_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('sub_category_error').innerHTML="";
                                        document.getElementById('sub_category_msg').innerHTML="<p>Sub category added successfully </p>";
                                        setTimeout(function(){                          
                                            var jump_sub_category_list_page = "<?php echo base_url('sub_category_list'); ?>";
                                            window.location = jump_sub_category_list_page;
                                        }, 1000);
                                    }
                                }
                            });
                        }
                    }
                </script>