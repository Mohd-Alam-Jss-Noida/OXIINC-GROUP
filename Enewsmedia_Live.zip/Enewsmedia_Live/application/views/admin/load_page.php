<?php
	$this->load->view('admin/header');
	$this->load->view('admin/menu');
	$this->load->view($load_page);
	$this->load->view('admin/footer');
?>