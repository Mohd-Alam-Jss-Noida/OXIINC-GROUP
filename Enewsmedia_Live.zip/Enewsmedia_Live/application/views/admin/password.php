
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-key"></i>
                                    </div>
                                    <div>
                                        Change Password
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <?php //echo "<pre>"; print_r($this->session); echo "</pre>"; ?>
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <center>
                                            <label id="password_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                            <label id="password_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                        </center>
                                        <div class="form-row">
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Old Password *</label>
                                                    <input name="old_password" id="old_password" placeholder="Password" type="password" class="form-control" onKeyPress="return avoid_space(event)" data-id="password">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">New Password *</label>
                                                    <input name="new_password" id="new_password" placeholder="Password" type="password" class="form-control" onKeyPress="return avoid_space(event)" data-id="password">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Confirm Password *</label>
                                                    <input name="confirm_password" id="confirm_password" placeholder="Password" type="password" class="form-control" onKeyPress="return avoid_space(event)" data-id="password">
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="hid_id" id="hid_id" value="<?php echo $this->session->userdata('id'); ?>">
                                        <button class="mt-2 btn btn-primary" onclick="password_validation()">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part -->

                <script src="./assets/js/jquery.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("CHANGE PASSWORD PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'password')
                                { password_validation(); }
                            }
                        });
                    });

                    function avoid_space(event)
                    {
                        var k = event ? event.which : window.event.keyCode;
                        if (k == 32) return false;
                    }

                    function password_validation()
                    {
                        var chk=0, passwordLength=5;
                        var password_check =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                        var old_password = $('#old_password').val();
                        var new_password = $('#new_password').val();
                        var encoded_new_password = window.btoa(new_password);
                        var confirm_password = $('#confirm_password').val();
                        var login_id = $('#hid_id').val();
                        var encoded_old_password = window.btoa(old_password);
                        var count_password = check_old_password(encoded_old_password, login_id);
                        var table = 'admin';

                        if(document.getElementById('old_password').value=='')
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="Please old password";
                            document.getElementById("old_password").focus();
                            chk=1;
                        }
                        else if(count_password == 0)
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="Old password you have entered is incorrect";
                            document.getElementById("old_password").focus();
                            chk=1;
                        }
                        else if(document.getElementById('new_password').value=='')
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="Please new password";
                            document.getElementById("new_password").focus();
                            chk=1;
                        }
                        else if(document.getElementById('new_password').value.length<=passwordLength)
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="New Password must be 6 character or more";
                            document.getElementById("new_password").focus();
                            chk=1;
                        }
                        else if(password_check.test(new_password) === false)
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="New Password contain at least one lowercase letter, one uppercase letter, one numeric digit and one special character";
                            document.getElementById("new_password").focus();
                            chk=1;
                        }
                        else if(document.getElementById('confirm_password').value=='')
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="Please confirm password";
                            document.getElementById("confirm_password").focus();
                            chk=1;
                        }
                        else if(new_password!=confirm_password)
                        {
                            document.getElementById('password_msg').innerHTML="";
                            document.getElementById('password_error').innerHTML="Confirm Password does not match to New Password";
                            document.getElementById("confirm_password").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {
                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url("enms/change_password"); ?>',
                                data:{id: login_id, password: encoded_new_password, table: table},
                                success:function(data){
                                    var obj = JSON.parse(data);
                                    /*alert(obj.status);
                                    alert(obj.last_id);
                                    alert(data);*/
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('password_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('password_error').innerHTML="";
                                        document.getElementById('password_msg').innerHTML="Password successfully updated";
                                    }
                                }
                            });
                        }
                    }

                    function check_old_password(old_password, login_id)
                    {
                        // CHECK PASSWORD
                        var obj;
                        $.ajax({
                            type:'POST',
                            url:'<?php echo base_url('enms/check_old_password'); ?>',
                            async: false,
                            data:{id: login_id, password: old_password},
                            success:function(data){
                                //alert(data);
                                obj = data;
                            }
                        });
                        return obj;
                    }
                </script>