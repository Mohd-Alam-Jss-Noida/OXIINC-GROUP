
	            <!-- center part  -->
	            <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-dot-circle-o"></i>
                                    </div>
                                    <div>
                                        Sub Category Details
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="page-title-actions">
                                    <a href="<?php echo base_url('sub_category_list'); ?>">
                                        <button type="button" data-toggle="tooltip" title="Back" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                                            <i class="fa fa-reply" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <?php //echo "<pre> --- SUB CATEGORY DETAILS --- "; print_r($sub_category_details); echo "</pre>"; ?>
                                        <div class="form-row">
                                            <div class="col-md-12" style="text-align: center;">
                                                <div class="position-relative form-group">
                                                    <?php
                                                        $image_path = "./assets/sub_category/".''.$sub_category_details['image'];
                                                        $no_image_path = "./assets/sub_category/".''."no_image.png";
                                                        $show_image = file_exists("./assets/sub_category/".''.$sub_category_details['image']) ? $image_path : $no_image_path;
                                                    ?>
                                                    <img src="<?php echo $show_image; ?>" style="height: 400px; width: 400px;">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Category</b></label> <br> 
                                                    <?php echo $sub_category_details['category_name']; ?> (<?php echo $sub_category_details['category_hindi_name']; ?>)
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Sub Category</b></label> <br> 
                                                    <?php echo $sub_category_details['name']; ?> (<?php echo $sub_category_details['hindi_name']; ?>)
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Status</b></label> <br> 
                                                    <?php echo ($sub_category_details['status'] == '1') ? 'Avtive' : 'Block'; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-12" style="text-align: justify;">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Details</b></label> <br> 
                                                    <?php echo $sub_category_details['details']; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-12" style="text-align: justify;">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Hindi Details</b></label> <br> 
                                                    <?php echo $sub_category_details['hindi_details']; ?>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
	            <!-- center part  -->

                <script src="./assets/js/jquery.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("VIEW SUB CATEGORY PAGE");
                    });
                </script>