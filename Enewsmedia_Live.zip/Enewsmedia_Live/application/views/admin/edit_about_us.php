
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-circle"></i>
                                    </div>
                                    <div>
                                        Edit About Us
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="page-title-actions">
                                    <a href="<?php echo base_url('about_us_list'); ?>">
                                        <button type="button" data-toggle="tooltip" title="Back" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                                            <i class="fa fa-reply" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <?php //echo "<pre> --- ABOUT US --- "; print_r($about_us_data); echo "</pre>"; ?>
                                        <center>
                                            <label id="about_us_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                            <label id="about_us_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                        </center>
                                        <div class="form-row">
                                            <div class="col-md-6">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class="">Title *</label>
                                                    <input name="title" id="title" placeholder="Title" type="text" class="form-control" onKeyPress="return space_capital_small_alphabets(event)" data-id="about_us" value="<?php echo $about_us_data['title']; ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Hindi Title *</label>
                                                    <input name="hindi_title" id="hindi_title" placeholder="Hindi Title" type="text" class="form-control" data-id="about_us" value="<?php echo $about_us_data['hindi_title']; ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Details *</label> 
                                                    <div id="details"><?php echo $about_us_data['details']; ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <br>
                                                <label for="exampleCity" class="">Hindi Details *</label>
                                                <textarea name="hindi_details" rows="4" id="hindi_details" class="form-control" data-id="about_us"><?php echo $about_us_data['hindi_details']; ?></textarea>
                                            </div>
                                            <div class="col-md-12">
                                                <br>
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Status</label>
                                                    <select class="form-control" name="status" id="status">
                                                        <option value="0" <?php if($about_us_data['status'] == '0') { ?> selected="selected" <?php } ?>>Block</option>
                                                        <option value="1" <?php if($about_us_data['status'] == '1') { ?> selected="selected" <?php } ?>>Active</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="hid_id" id="hid_id" value="<?php echo $about_us_data['id']; ?>">
                                        <button class="mt-2 btn btn-primary" onclick="edit_about_us()">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part  -->

                <!-- English To Hindi -->
                <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script> -->
                <script src="./assets/js/english_to_hindi.js"></script>
                <script type="text/javascript">
                    google.load("elements", "1", {packages: "transliteration"});
                </script> 
                <script>
                    function OnLoad()
                    {
                        var options = {
                            sourceLanguage:
                            google.elements.transliteration.LanguageCode.ENGLISH,
                            destinationLanguage:
                            [google.elements.transliteration.LanguageCode.HINDI],
                            shortcutKey: 'ctrl+g',
                            transliterationEnabled: true
                        };

                        var control = new google.elements.transliteration.TransliterationControl(options);
                        control.makeTransliteratable(['hindi_details']);
                        control.makeTransliteratable(['hindi_title']);
                    }
                    google.setOnLoadCallback(OnLoad);
                </script>
                <!-- English To Hindi -->

                <!-- SUMMERNOTE -->
                <script src="./assets/js/jquery.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        $('#details').summernote();
                    });
                </script>
                <!-- SUMMERNOTE -->

                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("EDIT ABOUT US PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'about_us')
                                { edit_about_us(); }
                            }
                        });
                    });
                
                    function space_capital_small_alphabets(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        if (unicode!=8) //if the key isn't the backspace key (which we should allow)
                        { 
                            if ((unicode<65||unicode>90) && (unicode<97||unicode>122) && (unicode!=32)) //if not a number
                                return false //disable key press
                        }
                    }

                    function edit_about_us()
                    {
                        var chk=0;
                        var CategoryData = new FormData();
                        var id = $('#hid_id').val();
                        var title = $('#title').val();
                        var hindi_title = $('#hindi_title').val();
                        var details = $('#details').summernote('code');
                        var hindi_details = $('#hindi_details').val();
                        var status = $('#status').val();
                        var table = 'about_us';

                        if(document.getElementById('title').value=='')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter title";
                            document.getElementById("title").focus();
                            chk=1;
                        }
                        if(document.getElementById('hindi_title').value=='')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter hindi title";
                            document.getElementById("hindi_title").focus();
                            chk=1;
                        }
                        else if(details=='<p><br></p>')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter details";
                            document.getElementById("summernote").focus();
                            chk=1;
                        }
                        else if(hindi_details=='')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter hindi details";
                            document.getElementById("hindi_details").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {

                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url('enms/edit_about_us_details'); ?>',
                                data:{id: id, title: title, hindi_title: hindi_title, details: details, hindi_details: hindi_details, status: status, table: table},
                                success:function(data){
                                    //alert(data)
                                    var obj = JSON.parse(data);
                                    //alert(obj.status);
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('about_us_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('about_us_error').innerHTML="";
                                        document.getElementById('about_us_msg').innerHTML="About us details updated successfully";
                                        setTimeout(function(){
                                            var jump_about_us_list_page = "<?php echo base_url('about_us_list'); ?>";
                                            window.location = jump_about_us_list_page;
                                        }, 1000);
                                    }
                                }
                            });
                            



                        }
                    }

                </script>