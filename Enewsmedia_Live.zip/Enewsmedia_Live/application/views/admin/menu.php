				<!-- menu  -->
	            <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="app-header__mobile-menu">
                        <div>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
                    </div>    <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <ul class="vertical-nav-menu">
                                <li class="app-sidebar__heading">Dashboard</li>
                                <li>
                                    <a href="<?php echo base_url('dashboard'); ?>" <?php if($this->uri->segment(1) == 'dashboard') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-home"></i>
                                        Dashboard
                                    </a>
                                </li>
                                <li class="app-sidebar__heading">Menu</li>
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_category' || $this->uri->segment(1) == 'category_list' || $this->uri->segment(1) == 'edit_category' || $this->uri->segment(1) == 'category_view') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-circle"></i>
                                        Menu
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_category'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('category_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_sub_category' || $this->uri->segment(1) == 'sub_category_list' || $this->uri->segment(1) == 'edit_sub_category' || $this->uri->segment(1) == 'sub_category_view') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-dot-circle-o"></i>
                                        Sub Menu
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_sub_category'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('sub_category_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_sub_category_section' || $this->uri->segment(1) == 'sub_category_section_list' || $this->uri->segment(1) == 'edit_sub_category_section' || $this->uri->segment(1) == 'sub_category_section_view') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-circle-o"></i>
                                        Menu of Sub Menu
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_sub_category_section'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('sub_category_section_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="app-sidebar__heading">Page</li>
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_news' || $this->uri->segment(1) == 'news_list' || $this->uri->segment(1) == 'edit_news') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-font"></i>
                                        News
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_news'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('news_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_about_us' || $this->uri->segment(1) == 'about_us_list' || $this->uri->segment(1) == 'edit_about_us') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-font"></i>
                                        About Us
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_about_us'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('about_us_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_privacy_policy' || $this->uri->segment(1) == 'privacy_policy_list' || $this->uri->segment(1) == 'edit_privacy_policy') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-pinterest-square"></i>
                                        Privacy Policy
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_privacy_policy'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('privacy_policy_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" <?php if($this->uri->segment(1) == 'add_terms_conditions' || $this->uri->segment(1) == 'terms_conditions_list' || $this->uri->segment(1) == 'edit_terms_conditions') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-tumblr"></i>
                                        Terms & Conditions
                                        <i class="metismenu-state-icon fa fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url('add_terms_conditions'); ?>">
                                                <i class="metismenu-icon"></i>
                                                Add
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url('terms_conditions_list'); ?>">
                                                <i class="metismenu-icon"></i>
                                                View
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('comment_list'); ?>" <?php if($this->uri->segment(1) == 'comment_list') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-comments"></i>
                                        Comment
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('enquiry'); ?>" <?php if($this->uri->segment(1) == 'enquiry') { ?> class="mm-active" <?php }  ?>>
                                        <i class="metismenu-icon fa fa-question"></i>
                                        Enquiry
                                    </a>
                                </li>                                
                            </ul>
                        </div>
                    </div>
                </div>

	            <!-- menu  -->