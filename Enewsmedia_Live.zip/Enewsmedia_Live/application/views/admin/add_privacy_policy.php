
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-pinterest-square"></i>
                                    </div>
                                    <div>
                                        Add Privacy Policy
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <!-- <form action="" enctype="multipart/form-data"> -->
                                <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                    <div class="main-card mb-3 card">
                                        <div class="card-body">
                                            <center>
                                                <label id="privacy_policy_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                                <label id="privacy_policy_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                            </center>
                                            <div class="form-row">
                                                <div class="col-md-12">
                                                    <label for="exampleCity" class="">Details *</label>
                                                    <input name="summernote" id="summernote" type="text" class="form-control" data-id="privacy_policy">
                                                    <!-- <div class="divider"></div> -->
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="exampleCity" class="">Hindi Details *</label>
                                                    <textarea name="hindi_details" rows="4" id="hindi_details" class="form-control" data-id="privacy_policy"></textarea>
                                                </div>
                                            </div>
                                            <button class="mt-2 btn btn-primary" onclick="privacy_policy()">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            <!-- </form> -->
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part -->

                <!-- English To Hindi -->
                <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script> -->
                <script src="./assets/js/english_to_hindi.js"></script>
                <script type="text/javascript">
                    google.load("elements", "1", {packages: "transliteration"});
                </script> 
                <script>
                    function OnLoad()
                    {
                        var options = {
                            sourceLanguage:
                            google.elements.transliteration.LanguageCode.ENGLISH,
                            destinationLanguage:
                            [google.elements.transliteration.LanguageCode.HINDI],
                            shortcutKey: 'ctrl+g',
                            transliterationEnabled: true
                        };

                        var control = new google.elements.transliteration.TransliterationControl(options);
                        control.makeTransliteratable(['hindi_details']);
                    }
                    google.setOnLoadCallback(OnLoad);
                </script>
                <!-- English To Hindi -->

                <script src="./assets/js/jquery.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        $('#summernote').summernote();
                    });
                </script>

                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("ADD PRIVACY POLICY PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'privacy_policy')
                                { privacy_policy(); }
                            }
                        });
                    });

                    function privacy_policy()
                    {
                        var chk=0;
                        //var summernote = $('#summernote').val();
                        var summernote = $('#summernote').summernote('code');
                        var hindi_details = $('#hindi_details').val();

                        if(summernote=='<p><br></p>')
                        {
                            document.getElementById('privacy_policy_msg').innerHTML="";
                            document.getElementById('privacy_policy_error').innerHTML="Please enter details";
                            document.getElementById("summernote").focus();
                            chk=1;
                        }
                        else if(hindi_details=='')
                        {
                            document.getElementById('privacy_policy_msg').innerHTML="";
                            document.getElementById('privacy_policy_error').innerHTML="Please enter hindi details";
                            document.getElementById("hindi_details").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {
                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url('enms/insert_privacy_policy'); ?>',
                                data:{details: summernote, hindi_details: hindi_details},
                                success:function(data){
                                    //alert(data)
                                    var obj = JSON.parse(data);
                                    //alert(obj.status);
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('privacy_policy_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('privacy_policy_error').innerHTML="";
                                        document.getElementById('privacy_policy_msg').innerHTML="Privacy policy details added successfully";
                                        setTimeout(function(){
                                            var jump_privacy_policy_list_page = "<?php echo base_url('privacy_policy_list'); ?>";
                                            window.location = jump_privacy_policy_list_page;
                                        }, 1000);
                                    }
                                }
                            });
                        }
                    }
                </script>