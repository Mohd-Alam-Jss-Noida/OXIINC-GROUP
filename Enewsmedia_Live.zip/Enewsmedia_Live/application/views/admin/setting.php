
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-cog"></i>
                                    </div>
                                    <div>
                                        Setting
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                            </div>
                        </div>    
                        <div class="tab-content">
                            <?php
                                //echo "<pre>"; print_r($this->session); echo "</pre>";
                                //echo $website_language_data;
                            ?>
                            <div class="main-card mb-3 card">
                                <div class="card-body">
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <h5 class="card-title">Website Language</h5>
                                            <div class="position-relative form-group" style="padding-left: 20px;">
                                                <input name="website_language" id="website_language" type="radio" value="0" class="form-check-input" onclick="set_setting('website_language', this.value)" <?php if($website_language_data == '0') { ?> checked="checked" <?php } ?>>
                                                <label for="exampleCheck" class="form-check-label">Hindi</label>
                                                &nbsp; &nbsp; &nbsp;
                                                <input name="website_language" id="website_language" type="radio" value="1" class="form-check-input" onclick="set_setting('website_language', this.value)" <?php if($website_language_data == '1') { ?> checked="checked" <?php } ?>>
                                                <label for="exampleCheck" class="form-check-label">English</label>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label id="website_language_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                            <label id="website_language_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part -->

                <script src="./assets/js/jquery.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("SETTING PAGE");
                    });

                    function set_setting(name, status)
                    {
                         $.ajax({
                            type:'POST',
                            url:'<?php echo base_url('enms/set_setting'); ?>',
                            data:{name: name, status: status},
                            success:function(data){
                                //alert(data)
                                var obj = JSON.parse(data);
                                //alert(obj.status);
                                if(obj.status == 'error')
                                {
                                    document.getElementById('website_language_error').innerHTML=obj.message;
                                }
                                if(obj.status == 'success')
                                {
                                    document.getElementById('website_language_error').innerHTML="";
                                    document.getElementById('website_language_msg').innerHTML="website language change successfully";
                                    setTimeout(function(){
                                        var jump_setting_page = "<?php echo base_url('setting'); ?>";
                                        window.location = jump_setting_page;
                                    }, 1000);
                                }
                            }
                        });

                    }
                </script>