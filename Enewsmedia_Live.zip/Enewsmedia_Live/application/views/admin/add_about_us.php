
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-font"></i>
                                    </div>
                                    <div>
                                        Add About Us
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <!-- <form action="" enctype="multipart/form-data"> -->
                                <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                    <div class="main-card mb-3 card">
                                        <div class="card-body">
                                            <center>
                                                <label id="about_us_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                                <label id="about_us_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                            </center>
                                            <div class="form-row">
                                                <div class="col-md-6">
                                                    <div class="position-relative form-group">
                                                        <label for="exampleCity" class="">Title *</label>
                                                        <input name="title" id="title" placeholder="Title" type="text" class="form-control" onKeyPress="return space_capital_small_alphabets(event)" data-id="about_us">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="position-relative form-group">
                                                        <label for="exampleCity" class="">Hindi Title *</label>
                                                        <input name="hindi_title" id="hindi_title" placeholder="Hindi Title" type="text" class="form-control" data-id="about_us">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="exampleCity" class="">Details *</label>
                                                    <input name="details" id="details" type="text" class="form-control" data-id="about_us">
                                                    <!-- <div class="divider"></div> -->
                                                </div>
                                                <div class="col-md-12">
                                                    <br>
                                                    <label for="exampleCity" class="">Hindi Details *</label>
                                                    <textarea name="hindi_details" rows="4" id="hindi_details" class="form-control" data-id="about_us"></textarea>
                                                </div>
                                            </div>
                                            <button class="mt-2 btn btn-primary" onclick="about_us()">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            <!-- </form> -->
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part -->

                <!-- English To Hindi -->
                <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script> -->
                <script src="./assets/js/english_to_hindi.js"></script>
                <script type="text/javascript">
                    google.load("elements", "1", {packages: "transliteration"});
                </script> 
                <script>
                    function OnLoad()
                    {
                        var options = {
                            sourceLanguage:
                            google.elements.transliteration.LanguageCode.ENGLISH,
                            destinationLanguage:
                            [google.elements.transliteration.LanguageCode.HINDI],
                            shortcutKey: 'ctrl+g',
                            transliterationEnabled: true
                        };

                        var control = new google.elements.transliteration.TransliterationControl(options);
                        control.makeTransliteratable(['hindi_details']);
                        control.makeTransliteratable(['hindi_title']);
                    }
                    google.setOnLoadCallback(OnLoad);
                </script>
                <!-- English To Hindi -->

                <script src="./assets/js/jquery.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("ADD ABOUT US PAGE");
                        $('#details').summernote();
                    });
                </script>

                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("ADD ABOUT US PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'about_us')
                                { about_us(); }
                            }
                        });
                    });

                    function space_capital_small_alphabets(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        if (unicode!=8) //if the key isn't the backspace key (which we should allow)
                        { 
                            if ((unicode<65||unicode>90) && (unicode<97||unicode>122) && (unicode!=32)) //if not a number
                                return false //disable key press
                        }
                    }

                    function about_us()
                    {
                        var chk=0;
                        var title = $('#title').val();
                        var hindi_title = $('#hindi_title').val();
                        var details = $('#details').summernote('code');
                        var hindi_details = $('#hindi_details').val();

                        if(document.getElementById('title').value=='')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter title";
                            document.getElementById("title").focus();
                            chk=1;
                        }
                        else if(document.getElementById('hindi_title').value=='')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter hindi title";
                            document.getElementById("hindi_title").focus();
                            chk=1;
                        }
                        else if(details=='<p><br></p>')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter details";
                            document.getElementById("details").focus();
                            chk=1;
                        }
                        else if(hindi_details=='')
                        {
                            document.getElementById('about_us_msg').innerHTML="";
                            document.getElementById('about_us_error').innerHTML="Please enter hindi details";
                            document.getElementById("hindi_details").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {
                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url('enms/insert_about_us'); ?>',
                                data:{title: title, hindi_title: hindi_title, details: details, hindi_details: hindi_details},
                                success:function(data){
                                    //alert(data)
                                    var obj = JSON.parse(data);
                                    //alert(obj.status);
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('about_us_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('about_us_error').innerHTML="";
                                        document.getElementById('about_us_msg').innerHTML="About us details added successfully";
                                        setTimeout(function(){
                                            var jump_about_us_list_page = "<?php echo base_url('about_us_list'); ?>";
                                            window.location = jump_about_us_list_page;
                                        }, 1000);
                                    }
                                }
                            });
                        }
                    }
                </script>