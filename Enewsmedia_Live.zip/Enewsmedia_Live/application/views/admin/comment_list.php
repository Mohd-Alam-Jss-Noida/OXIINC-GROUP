
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-comments"></i>
                                    </div>
                                    <div>
                                        View Comment
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <div>
                                            <?php //echo "<pre>"; print_r($this->session); echo "</pre>"; ?>
                                            <?php //echo "<pre>"; print_r($comment_data); echo "</pre>"; ?>
                                            <table style="width: 100%;" id="example" class="table table-hover table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>Category</th>
                                                        <th>Sub Category</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Comment</th>
                                                        <th>Created</th>
                                                        <th>Status</th>
                                                        <!-- <th>View</th>
                                                        <th>Edit</th> -->
                                                        <th>Delete</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $serial_number = 1;
                                                        foreach($comment_data as $key => $value)
                                                        {
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $serial_number; ?></td>
                                                                <td><?php echo $comment_data[$key]['category_name']; ?> (<?php echo $comment_data[$key]['category_hindi_name']; ?>)</td>
                                                                <td>
                                                                    <?php
                                                                        if($comment_data[$key]['sub_category_name'] != '')
                                                                        {
                                                                            echo $comment_data[$key]['sub_category_name']; ?> (<?php echo $comment_data[$key]['sub_category_hindi_name']; ?>) <?php
                                                                        }
                                                                    ?>
                                                                </td>
                                                                <td><?php echo $comment_data[$key]['name']; ?></td>
                                                                <td><?php echo $comment_data[$key]['email']; ?></td>
                                                                <td><?php echo $comment_data[$key]['comment']; ?></td>
                                                                <td>
                                                                    <?php echo date('d F, Y', strtotime($comment_data[$key]['created'])); ?> @ <?php echo date('h:i A', strtotime($comment_data[$key]['created'])); ?>
                                                                </td>
                                                                <td>
                                                                    <?php
                                                                        if($comment_data[$key]['status'] == '1')
                                                                        {
                                                                            ?>
                                                                            <a href="#" onclick="change_status('comment', <?php echo $comment_data[$key]['id']; ?>, '0', 'status')" style="cursor: pointer;">Active</a>
                                                                            <?php
                                                                        }
                                                                        else
                                                                        {
                                                                            ?>
                                                                            <a href="#" onclick="change_status('comment', <?php echo $comment_data[$key]['id']; ?>, '1', 'status')" style="cursor: pointer;">Block</a>
                                                                            <?php
                                                                        }
                                                                    ?>
                                                                </td>
                                                                <!-- <td>
                                                                    <i class="fa fa-eye" aria-hidden="true" style="cursor: pointer;" onclick="edit_category('<?php //echo $comment_data[$key]['id']; ?>', 'category_view')"></i>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-pencil" aria-hidden="true" style="cursor: pointer;" onclick="edit_category('<?php //echo $comment_data[$key]['id']; ?>', 'category')"></i>
                                                                </td> -->
                                                                <td>
                                                                    <i class="fa fa-trash" aria-hidden="true" onclick="change_status('comment', <?php echo $comment_data[$key]['id']; ?>, '2', 'delete')" style="cursor: pointer;"></i>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                            $serial_number++;
                                                        }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <div class="divider"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part  -->

                <!-- <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <script src="./assets/admin/scripts/main.87c0748b313a1dda75f5.js"></script> -->
                
                <script type="text/javascript" src="./assets/admin/scripts/main.87c0748b313a1dda75f5.js"></script>
                <script src="./assets/js/jquery.js"></script>
                <script src="./assets/admin/scripts/main.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("VIEW COMMENT");
                    });

                    function edit_category(id, page)
                    {
                        //alert(id);
                        window.location = "<?php echo base_url('temp_session'); ?>/" + id + "/" + page;
                    }

                    function change_status(table, id, status, msg)
                    {
                        /*alert(table);
                        alert(id);
                        alert(status);
                        alert(msg);*/
                        if(msg == 'status')
                        {
                            var x = confirm("Are you sure you want to change status?");
                        }
                        if(msg == 'delete')
                        {
                            var x = confirm("Are you sure you want to delete?");
                        }
                        if(x)
                        {
                            //return true;
                            $.ajax({
                                url: "<?php echo base_url('enms/change_status'); ?>",
                                type: "POST",
                                data:{table: table, id: id, status: status},
                                dataType:"text",
                                success: function(data){
                                    var jump_comment_list_page = "<?php echo base_url('comment_list'); ?>";
                                    window.location = jump_comment_list_page;
                                }
                            });
                        }
                        else
                        {
                            return false;
                        }
                    }
                </script>