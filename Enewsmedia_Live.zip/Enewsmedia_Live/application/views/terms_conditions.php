	<div class="gap-30"></div>

	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a></li>
						<li><i class="fa fa-angle-right"></i><?php if($website_language == '0') { echo "नियम एवं शर्तें"; } else { echo "Terms & Conditions"; } ?></li>
					</ol>		
				</div>
			</div>
		</div>
	</div>

	<section class="main-content category-layout-2 pt-0">
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-12">
					<?php //echo "<pre>"; print_r($terms_conditions); echo "</pre>"; ?>
					<div class="row">
						<div class="col-12">
							<div class="author-box d-flex mt-0">
								<div class="author-info" style="text-align: justify;">
									<?php
										foreach ($terms_conditions as $key => $value)
										{
											echo ($website_language == '0') ? $terms_conditions[$key]['hindi_details'] : $terms_conditions[$key]['details'];
										}
									?>
								</div>
							</div>
						</div>
					</div>
					<div class="gap-50"></div>
				</div>
			</div>
		</div>
	</section>