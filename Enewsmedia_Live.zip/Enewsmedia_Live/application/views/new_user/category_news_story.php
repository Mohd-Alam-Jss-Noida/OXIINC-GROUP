            <!-- START CONTAINER -->
            <div class="main-wrapper">
                <!-- Breadcrumb Section -->
                <section class="breadcrumb-section fwd">
                    <div class="container">
                        <ol class="breadcrumb">
                            <li><a href="<?php echo base_url('Enews'); ?>"><?php echo ($website_language == '0') ? "होम" : "Home";?></a></li>
                            <li class="active"><?php echo ucfirst(str_replace('_', ' ', $category_news_details['cat_name'])); ?></li>
                            <li class="active"><?php echo character_limiter($category_news_details['title'], CHAR_LIMIT);?></li>
                        </ol>
                    </div>
                </section>
                <div class="clrfix"></div>
                <!-- News Details Section -->
                <section class="home-section-01 home-section-02 news-list-section news-details-section fwd">
                    <div class="container">
                        <div class="left-col">
                            <!-- News Details Block -->
                            <?php
                            if(isset($category_news_details) && !empty($category_news_details)){ ?>
                                <div class="news-details-block fwd">
                                    <h2 class="headding-04"><?php echo $category_news_details['title']; ?></h2>
                                    <div class="headding-03">
                                        <span><i class="fa fa-clock"></i> <?php echo $category_news_details['pubDate']; ?></span>
                                    </div>
                                    <img src="<?php echo $category_news_details['image']; ?>" class="news-img" alt=""/>
                                    <p style="text-align: justify;"><?php echo $category_news_details['description']; ?></p>
                                </div>
                                <?php
                            }
                            ?>
                            <!-- Related News Block -->
                            <div class="latest-articles-block fwd">
                                <h2 class="headding-01"><?php echo ($website_language == '0') ? "सम्बंधित खबर" : "Related News";?></h2>
                                <ul class="list-inline articles-list">
                                    <?php
                                    //echo "<pre>";print_r($related_news);die();
                                    if(isset($related_news) && !empty($related_news)) foreach($related_news as $key => $value){
                                        $cat_name = $this->session->userdata('cat_name');
                                        $title = isset($value['@attributes']['title']) && !empty($value['@attributes']['title']) ? $value['@attributes']['title'] : '';
                                        $description = isset($value['@attributes']['description']) && !empty($value['@attributes']['description']) ? $value['@attributes']['description'] : '';
                                        $image = isset($value['@attributes']['image']) && !empty($value['@attributes']['image']) ? $value['@attributes']['image'] : '';
                                        $pubDate = isset($value['@attributes']['pubDate']) && !empty($value['@attributes']['pubDate']) ? date('d F, Y', strtotime($value['@attributes']['pubDate'])) : '';
                                        ?>
                                        <li class="equal-height-col">
                                            <a href="javascript:void(0);" id="cat_news_<?php echo $key; ?>" onclick="category_news_details('<?php echo $key; ?>')" data-cat_name="<?php echo $cat_name; ?>" data-title="<?php echo $title; ?>" data-description="<?php echo $description; ?>" data-image="<?php echo $image; ?>" data-pubDate="<?php echo $pubDate; ?>">
                                                <div class="img-col fwd">
                                                    <img src="<?php echo $image; ?>" class="img-responsive" alt=""/>
                                                    <div class="overlay-col"></div>
                                                </div>
                                                <div class="containt-col fwd">
                                                    <h3 class="headding-02"><?php echo character_limiter($title, CHAR_LIMIT);?></h3>
                                                    <div class="headding-03"><?php echo $pubDate; ?></div>
                                                </div>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
                            <!-- Leave Comment Block -->
                            <div class="leave-comment-block fwd">
                                <h2 class="headding-01">Leave Comment</h2>
                                <form class="login-form-col">
                                    <div class="form-group">
                                        <input type="text" class="input-textbox" id="InputYourName" placeholder="Your Name">
                                        <div class="errormsg" style="display:none;">Please Enter Your Name</div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="input-textbox" id="InputYourEmail" placeholder="Your Email">
                                        <div class="errormsg" style="display:none;">Please Enter Your Email</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="input-textbox input-textarea" placeholder="Your Comment"></textarea>
                                        <div class="errormsg" style="display:none;">Please Enter Your Comment</div>
                                    </div>
                                    <div class="form-group align-center">
                                        <button type="submit" class="submit-btn">Post Comment</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="right-col">
                            <!-- Stay Connected Block -->
                            <div class="stay-connected-block fwd">
                                <h2 class="headding-01">Stay Connected</h2>
                                <ul class="list-unstyled social-media-links">
                                    <li><a class="facebook-btn" href="#" target="_blank"><i class="fab fa-facebook-f"></i>Facebook</a></li>
                                    <li><a class="twitter-btn" href="#" target="_blank"><i class="fab fa-twitter"></i>Twitter</a></li>
                                    <li><a class="linkedin-btn" href="#" target="_blank"><i class="fab fa-linkedin-in"></i>Linkedin</a></li>
                                    <li><a class="youtube-btn" href="#" target="_blank"><i class="fab fa-youtube"></i>Youtube</a></li>
                                </ul>
                            </div>
                            <!-- Recent Happenings Block -->
                            <div class="recent-happenings-block fwd">
                                <h2 class="headding-01"><?php echo ($website_language == '0') ? "हाल ही में हुआ" : "Recent Happenings";?></h2>
                                <ul class="list-unstyled recent-news-list">
                                    <?php
                                    //echo "<pre>";print_r($recent_happenings);die();
                                    if(isset($recent_happenings) && !empty($recent_happenings)) foreach($recent_happenings as $key => $value){
                                        $show_image = (isset($value['image']) && !empty($value['image']) && file_exists("assets/news/".$value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
                                        $table_name = 'news';
                                        ?>
                                        <li>
                                            <a href="javascript:void(0);" class="item-col" onclick="view_details('<?php echo $value['id']; ?>', '<?php echo $table_name; ?>', '<?php echo $value['category_id']; ?>')">
                                                <div class="img-col">
                                                    <img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="containt-col">
                                                    <h3><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
                                                    <div class="date-txt">Music - <?php echo date('d F, Y', strtotime($value['created'])); ?></div>
                                                </div>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
                            <!-- Subscribe Block -->
                            <div class="subscribe-block fwd">
                                <h2>Subscribe</h2>
                                <p>Get all latest content deliverd to your email a few times a month</p>
                                <form class="subscribe-form fwd">
                                    <input type="email" class="input-textbox" id="InputEmail" placeholder="Email">
                                    <button type="submit" class="submit-btn"><i class="fas fa-arrow-right"></i></button>
                                </form>
                            </div>
                            <!-- Tags Block -->
                            <div class="tags-block fwd">
                                <h2 class="headding-01">Tags</h2>
                                <ul class="list-inline tags-links">
                                    <li><a href="#">Fashion</a></li>
                                    <li><a href="#">Lifestyle</a></li>
                                    <li><a href="#">Denim</a></li>
                                    <li><a href="#">Streetstyle</a></li>
                                    <li><a href="#">Crafts</a></li>
                                    <li><a href="#">Magzine</a></li>
                                    <li><a href="#">News</a></li>
                                    <li><a href="#">Blogs</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="clrfix"></div>
            </div>
            <!-- END CONTAINER -->

