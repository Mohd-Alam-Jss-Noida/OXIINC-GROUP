			<!-- START CONTAINER -->
			<div class="main-wrapper">
				<!-- Breadcrumb Section -->
				<section class="breadcrumb-section fwd">
					<div class="container">
						<ol class="breadcrumb">
							<li><a href="<?php echo base_url('Enews'); ?>"><?php echo ($website_language == '0') ? "होम" : "Home";?></a></li>
							<?php
							if($sub_id_flag == 1){ ?>
								<li><?php echo ($website_language == '0') ? $category_data['category_hindi_name'] : $category_data['category_name'];?></li>
								<?php
							}
							?>
							<li class="active"><?php echo ($website_language == '0') ? $category_data['hindi_name'] : $category_data['name'];?></li>
						</ol>
					</div>
				</section>
				<div class="clrfix"></div>

				<!-- Corona Updates Section -->
				<?php
				$category_name = ($website_language == '0') ? $category_data['hindi_name'] : $category_data['name'];
				if($category_name == "Corona" ||  $category_name == "कोरोना"){
					if(isset($corona_count) && !empty($corona_count)){ ?>
						<section class="home-section-01 home-section-02 news-list-section corona-updates-section-01 fwd">
							<div class="container">
								<div class="contact-section-01 fwd">
									<h1 class="inner-main-headding"><span>Corona</span> Updates</h1>
									<div class="containt-col equal-height-col">
										<h4>COVID-19 INDIA</h4>
										<div class="text-title">
											<span>as on : <?php echo date('d F, Y', strtotime($corona_count['Date'])); ?></span>
											<span>(GMT+5:30)</span>
										</div>
									</div>
									<div class="containt-col equal-height-col">
										<i class="fas fa-users icon-col"></i>
										<h4><?php echo $corona_count['Confirmed']; ?></h4>
										<div class="text-title">Total Patients</div>
									</div>
									<div class="containt-col equal-height-col">
										<i class="fas fa-users icon-col"></i>
										<h4><?php echo $corona_count['Active']; ?></h4>
										<div class="text-title">Active Patients</div>
									</div>
									<div class="containt-col equal-height-col">
										<i class="fas fa-users icon-col"></i>
										<h4><?php echo $corona_count['Deaths']; ?></h4>
										<div class="text-title">Death</div>
									</div>
									<div class="containt-col equal-height-col">
										<i class="fas fa-users icon-col"></i>
										<h4><?php echo $corona_count['Recovered']; ?></h4>
										<div class="text-title">Discharge</div>
									</div>
								</div>
							</div>
						</section>
						<p>&nbsp;</p>
						<?php
					}
				}
				?>
				<div class="clrfix"></div>

				<!-- News List Section -->
				<section class="home-section-01 home-section-02 news-list-section fwd">
					<div class="container">
						<div class="left-col">
							<!-- International Articles Block -->
							<div class="latest-articles-block fwd">
								<h2 class="headding-01"><?php echo ($website_language == '0') ? $category_data['hindi_name'] : $category_data['name'];?> Articles</h2>
								<ul class="list-inline articles-list">
									<?php
									//echo "<pre>";print_r($news_listing);die();
									if(isset($news_listing) && !empty($news_listing)) foreach($news_listing as $key => $value){
										$show_image = (isset($value['image']) && !empty($value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
										?>
										<li class="equal-height-col">
											<a href="javascript:void(0);" class="item-col fwd" onclick="view_details('<?php echo $value['id']; ?>', 'news', '<?php echo $value['category_id']; ?>')">
												<div class="img-col fwd">
													<img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
													<div class="overlay-col"></div>
												</div>
												<div class="containt-col fwd">
													<h3 class="headding-02"><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
													<div class="headding-03">by John Alvarado - <?php echo date('d F, Y', strtotime($value['created'])); ?></div>
												</div>
											</a>
										</li>
										<?php
									}
									?>
								</ul>
							</div>
						</div>
						<div class="right-col">
							<!-- Stay Connected Block -->
							<div class="stay-connected-block fwd">
								<h2 class="headding-01">Stay Connected</h2>
								<ul class="list-unstyled social-media-links">
									<li><a class="facebook-btn" href="#" target="_blank"><i class="fab fa-facebook-f"></i>Facebook</a></li>
									<li><a class="twitter-btn" href="#" target="_blank"><i class="fab fa-twitter"></i>Twitter</a></li>
									<li><a class="linkedin-btn" href="#" target="_blank"><i class="fab fa-linkedin-in"></i>Linkedin</a></li>
									<li><a class="youtube-btn" href="#" target="_blank"><i class="fab fa-youtube"></i>Youtube</a></li>
								</ul>
							</div>
							<div class="recent-happenings-block fwd">
                                <h2 class="headding-01"><?php echo ($website_language == '0') ? "हाल ही में हुआ" : "Recent Happenings";?></h2>
                                <ul class="list-unstyled recent-news-list">
                                    <?php
                                    //echo "<pre>";print_r($recent_happenings);die();
                                    if(isset($recent_happenings) && !empty($recent_happenings)) foreach($recent_happenings as $key => $value){
                                        $show_image = (isset($value['image']) && !empty($value['image']) && file_exists("assets/news/".$value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
                                        ?>
                                        <li>
                                            <a href="javascript:void(0);" class="item-col" onclick="view_details('<?php echo $value['id']; ?>', 'news', '<?php echo $value['category_id']; ?>')">
                                                <div class="img-col">
                                                    <img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="containt-col">
                                                    <h3><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
                                                    <div class="date-txt">Music - <?php echo date('d F, Y', strtotime($value['created'])); ?></div>
                                                </div>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
							<!-- Subscribe Block -->
							<div class="subscribe-block fwd">
								<h2>Subscribe</h2>
								<p>Get all latest content deliverd to your email a few times a month</p>
								<form class="subscribe-form fwd">
									<input type="email" class="input-textbox" id="InputEmail" placeholder="Email">
									<button type="submit" class="submit-btn"><i class="fas fa-arrow-right"></i></button>
								</form>
							</div>
							<!-- Tags Block -->
							<div class="tags-block fwd">
								<h2 class="headding-01">Tags</h2>
								<ul class="list-inline tags-links">
									<li><a href="#">Fashion</a></li>
									<li><a href="#">Lifestyle</a></li>
									<li><a href="#">Denim</a></li>
									<li><a href="#">Streetstyle</a></li>
									<li><a href="#">Crafts</a></li>
									<li><a href="#">Magzine</a></li>
									<li><a href="#">News</a></li>
									<li><a href="#">Blogs</a></li>
								</ul>
							</div>
						</div>
					</div>
				</section>
				<div class="clrfix"></div>
			</div>
			<!-- END CONTAINER -->
