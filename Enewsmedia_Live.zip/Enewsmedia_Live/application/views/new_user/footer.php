			<!-- START FOOTER -->
			<footer>
				<div class="foot-block-01 fwd">
					<div class="container">
						<div class="foot-default-col foot-col-01">
							<a href="<?php echo base_url('Enews');?>" class="foot-logo"><img src="<?php echo base_url('assets/new_user_assets/images/foot-logo.png');?>" class="img-responsive" alt="Enewsmedia"/></a>
							<p>The power of Information - Get latest trending 24 Hour News Source only at www.enewsmedia.in</p>
							<p>Enewsmedia.in  provides latest news from India and the world. Get today's news headlines from Weather, Food, Agriculture, Technology, Bollywood, Cricket, Videos, Photos, Corona, Politics live news coverage and exclusive breaking news from India.</p>
							<p>Any questions? Call us on 022 68732700</p>
							<div class="social-media-col">
								<ul class="list-inline top-social-media">
									<li><a href="https://www.facebook.com/Erocketmallonlineasialtd/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="https://twitter.com/myoxiinc/" target="_blank"><i class="fab fa-twitter"></i></a></li>
									<li><a href="https://in.linkedin.com/company/oxiinc-group/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
									<li><a href="https://www.instagram.com/oxiinc_group/" target="_blank"><i class="fab fa-instagram"></i></a></li>
									<li><a href="https://www.youtube.com/channel/UCim_GlgyKZ2aJF7KhUEE3Gw/" target="_blank"><i class="fab fa-youtube"></i></a></li>
								</ul>
							</div>
						</div>
						<?php
						//echo "<pre>";print_r($popular);die();
						if(isset($popular) && !empty($popular)){
							shuffle($popular);
							$popular = array_slice($popular, 0, 4, true);// returns first 4 elements
							?>
							<div class="foot-default-col foot-col-02">
								<h2><?php echo ($website_language == '0') ? "लोकप्रिय" : "Most Popular";?></h2>
								<ul class="list-unstyled">
									<?php
									foreach($popular as $key => $value){
										$show_image = (isset($value['image']) && !empty($value['image']) && file_exists("assets/news/".$value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
										$table_name = 'news';
										?>
										<li>
											<a href="javascript:void(0);" class="item-col" onclick="view_details('<?php echo $value['id']; ?>', '<?php echo $table_name; ?>', '<?php echo $value['category_id']; ?>')">
												<div class="img-col">
													<img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
												</div>
												<div class="containt-col">
													<h3><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
													<div class="date-txt"><?php echo date('d F, Y', strtotime($value['created'])); ?></div>
												</div>
											</a>
										</li>
										<?php
									}
									?>
								</ul>
							</div>
							<?php
						}
						?>
						<?php
						//echo "<pre>";print_r($menu_data);die();
						if(isset($menu_data) && !empty($menu_data)){ ?>
							<div class="foot-default-col foot-col-03">
								<h2><?php echo ($website_language == '0') ? "सब वर्ग" : "All Categories";?></h2>
								<ul class="list-unstyled links-col">
									<?php
									foreach($menu_data as $key => $value){ ?>
										<li <?php if(isset($menu_id) && !empty($menu_id) && $menu_id == $value['id']){ ?> class="active" <?php } ?>><a href="javascript:void(0);" onclick="view_list('<?php echo $value['id']; ?>', 'category', 0, '<?php echo $value['id']?>')"><?php echo ($website_language == '0') ? $value['hindi_name'] : $value['name'];?></a>
										</li>
										<?php
									}
									?>
								</ul>
							</div>
							<?php
						}
						?>
					</div>
				</div>
				<div class="foot-block-02 fwd">
					<div class="container">
						<div class="copy-right-txt">
							&copy; Design and Developed by <a href="https://www.oxiincgroup.com/" target="_blank">Oxiincgroup.com</a>
						</div>
					</div>
				</div>
			</footer>
			<div class="clrfix"></div>
			<!-- START FOOTER -->

			<!-- jQuery -->
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
			<script src="<?php echo base_url('assets/new_user_assets/js/bootstrap.min.js');?>"></script>
			<!-- Fontawesome -->
			<script defer src="<?php echo base_url('assets/new_user_assets/js/fontawesome/all.js');?>"></script>
			<script defer src="<?php echo base_url('assets/new_user_assets/js/fontawesome/brands.js');?>"></script>
			<script defer src="<?php echo base_url('assets/new_user_assets/js/fontawesome/solid.js');?>"></script>
			<script defer src="<?php echo base_url('assets/new_user_assets/js/fontawesome/fontawesome.js');?>"></script>
			<script defer src="<?php echo base_url('assets/new_user_assets/js/menu.js');?>"></script>
			<!-- Owlcarousel -->
			<script src="<?php echo base_url('assets/new_user_assets/js/owlcarousel/owl.carousel.js');?>"></script>
			<script src="<?php echo base_url('assets/new_user_assets/js/custom-script.js');?>"></script>
		</div>
	</body>
</html>