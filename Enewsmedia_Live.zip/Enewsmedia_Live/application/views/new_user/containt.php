<?Php
/*START HEADER*/
$this->load->view('new_user/header');
/*END HEADER*/

//START CONTAINER
$this->load->view('new_user/'.$main_containt);
//END CONTAINER

//START FOOTER
$this->load->view('new_user/footer'); 
//END FOOTER
?>