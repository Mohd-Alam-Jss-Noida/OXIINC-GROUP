<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title><?php echo (isset($title) && !empty($title)) ? $title : 'Enewsmedia - The Power Of Information';?></title>
		<!-- Mobile Specific Metas -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    	<meta name="title" content="Enewsmedia - The Power Of Information" />
		<meta name="description" content="Enewsmedia.in provides latest news around the world." />
		<meta name="keywords" content="enewsmedia.in,weather,food,agriculture,technology,bollywood,cricket,videos,photos,corona,politics and live news coverage and exclusive breaking news from india" />
		<meta property="og:description" content="Enewsmedia.in provides latest news around the world." />
        <meta property="og:title" content="Enewsmedia - The Power Of Information" />
        <meta property="og:image" content="<?php echo base_url('assets/images/logos/logo.png'); ?>" />
        <meta property="og:url" content="<?php echo base_url('Enews'); ?>" />

        <!--Favicon-->
		<link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.png'); ?>" type="image/x-icon">
		<link rel="icon" href="<?php echo base_url('assets/images/favicon.png'); ?>" type="image/x-icon">

		<!-- Css -->
		<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/bootstrap.min.css');?>" rel="stylesheet">
		<!-- Fontawesome -->
		<link href="<?php echo base_url('assets/new_user_assets/css/fontawesome/all.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/fontawesome/fontawesome.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/fontawesome/brands.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/fontawesome/solid.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/animate.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/menu.css');?>" rel="stylesheet">
		<!-- Owlcarousel -->
		<link rel="stylesheet" href="<?php echo base_url('assets/new_user_assets/css/owlcarousel/owl.carousel.min.css');?>">
		<link href="<?php echo base_url('assets/new_user_assets/css/custom-style.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/new_user_assets/css/custom-responsive.css');?>" rel="stylesheet">
	</head>
	<body>
		<div id="main-page-wrapper">
			
			<!-- START HEADER -->
			<header>
			  <div class="head-block-01 fwd">
			    <div class="container">
				  <div class="top-links">
				    <div class="date-txt"><?php echo date("l, d F, Y h:i:s A"); ?></div>
					<ul class="list-inline links-col">
					  <li><a href="#">About</a></li>
					  <li><a href="#">Contact</a></li>
					  <li><a href="#">Sign Up</a></li>
					  <li><a href="#">Login</a></li>
					</ul>
				  </div>
				  <div class="social-media-col">
				    <ul class="list-inline top-social-media">
					<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
					<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
					<li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
					<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
					<li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
			        </ul>
				  </div>
				</div>
			  </div>
			  
			  <div class="head-block-02 fwd">
			    <div class="container">
				  <a href="<?php echo base_url(); ?>" class="logo-col"><img src="<?php echo base_url('assets/new_user_assets/images/logo.png');?>" class="img-responsive" alt="Enewsmedia"/></a>
				  <div class="advertisement-banner">
				    <img src="<?php echo base_url('assets/new_user_assets/images/advertisement-banner.jpg');?>" class="img-responsive" alt=""/>
				  </div>
				  <nav id='cssmenu' class="fwd">
					<div id="head-mobile"></div>
					<div class="button"></div>
					<ul class="nav-main-ul">
						<li <?php if(isset($menu_id) && !empty($menu_id) && $menu_id == 'Home'){ ?> class="active" <?php } ?>><a href="<?php echo base_url();?>"><?php echo ($website_language == '0') ? "होम" : "Home";?></a></li>
						<?php
						$sub_menu = array();
						if(isset($menu_data) && !empty($menu_data)) foreach($menu_data as $key => $value){
							$sub_menu = $value['sub_category_details'];
							if(isset($sub_menu) && !empty($sub_menu)){ ?>
								<li <?php if(isset($menu_id) && !empty($menu_id) && $menu_id == $value['id']){ ?> class="active" <?php } ?>><a href="javascript:void(0);"><?php echo ($website_language == '0') ? $value['hindi_name'] : $value['name'];?></a>
									<ul>
										<?php
										foreach($sub_menu as $sub_menu_key => $sub_menu_value){ ?>
											<li><a href="javascript:void(0);" onclick="view_list('<?php echo $sub_menu_value['id']; ?>', 'sub_category', 1, '<?php echo $value['id']?>')"><?php echo ($website_language == '0') ? $sub_menu_value['hindi_name'] : $sub_menu_value['name'];?></a>
											</li>
											<?php
										}
										?>
									</ul>
								</li>
								<?php
							}
							else{ ?>
								<li <?php if(isset($menu_id) && !empty($menu_id) && $menu_id == $value['id']){ ?> class="active" <?php } ?>><a href="javascript:void(0);" onclick="view_list('<?php echo $value['id']; ?>', 'category', 0, '<?php echo $value['id']?>')"><?php echo ($website_language == '0') ? $value['hindi_name'] : $value['name'];?></a>
								</li>
								<?php
							}
						}
						?>
					</ul>
				  </nav>
				  <div class="mb-link-btn"><i class="fa fa-ellipsis-v fa-w-6"></i></div>
				  <div class="search-btn-click"><i class="fas fa-search"></i></div>
				  <div class="search-col">
				    <form action="<?php echo base_url('Enews/search');?>">
					  <input type="text" name="s" id="searchInput" class="input-textbox" placeholder="Search latest news" autocomplete="off" required>
					  <button type="submit" class="submit-btn"><i class="fas fa-search"></i></button>
				    </form>
				  </div>
				</div>
			  </div>
			</header>
			<div class="clrfix"></div>
			<!-- END HEADER -->

			<script type="text/javascript">
				function view_list(id, page,sub_cat_id_flag, menu_id){
					//alert(menu_id);exit();
					window.location = "<?php echo base_url('Enews/view_list/'); ?>" + id + "/" + page + "/" + sub_cat_id_flag + "/" + menu_id;
				}

				function view_details(id, page, menu_id) {
			        window.location = "<?php echo base_url('Enews/view_details/'); ?>" + id + "/" + page + "/" + menu_id;
			    }

			    function category_news(category){
			    	window.location = "<?php echo base_url('Enews/category_news/'); ?>" + category;
			    }
    
    			function category_news_details(id){
			    	var cat_name 		= $.trim($('#cat_news_'+id).attr("data-cat_name"));
			    	var title 			= $.trim($('#cat_news_'+id).attr("data-title"));
			    	var description 	= $.trim($('#cat_news_'+id).attr("data-description"));
			    	var image 			= $.trim($('#cat_news_'+id).attr("data-image"));
			    	var pubDate 		= $.trim($('#cat_news_'+id).attr("data-pubDate"));
			    	//alert(description);exit();
			    	if(cat_name != "" && title != "" && description != "" && image != "" && pubDate != ""){
				    	$.ajax({
				    		url:'<?php echo base_url('Enews/category_news_details'); ?>',
				    		type:'POST',
				    		data:{cat_name: cat_name,title: title, description: description, image: image, pubDate:pubDate},
				    		dataType:"text",
	        				cache: false,
				    		success:function(data){
				  				//alert(data)
					          	if(data == 1){
					          		window.location = "<?php echo base_url('Enews/category_news_story'); ?>";
					          	}
					          	if(data == 0){
					          		alert("Something went wrong please try again. Thank You.");
					          		return false;
					          	}
				          	}
				      	});
				    }      
			    }
			</script>

