			<!-- START CONTAINER -->
			<div class="main-wrapper">
				<!-- Breaking News Section -->
				<section class="breaking-news-section fwd">
					<div class="container">
						<div class="news-col">
							<div class="title-txt">Just In</div>
							<marquee class="news-scroll" behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"> <a href="<?php echo base_url('Enews');?>">Enewsmedia.in  provides latest news from India and the world. Get today's news headlines from Weather, Food, Agriculture, Technology, Bollywood, Cricket, Videos, Photos, Corona, Politics live news coverage and exclusive breaking news from India.</a></marquee>
						</div>
						<!--<div class="search-col">
							<form>
							  <input type="text" class="input-textbox" id="InputSearch" placeholder="Search">
							<button type="submit" class="submit-btn"><i class="fas fa-search"></i></button>
							</form>
							</div>-->
					</div>
				</section>
				<div class="clrfix"></div>
				<!-- Banner Section -->
				<section class="banner-section fwd">
					<div class="container">
						<?php
						if(isset($feed_data_national) && !empty($feed_data_national)){
							$image_url = $feed_data_national['@attributes']['image'];
						    $headers = @get_headers($image_url);
						    if($headers && strpos($headers[0], '200')){
						    	$image_url = $image_url;
						    }
						    else{
						    	$image_url = base_url('assets/new_user_assets/images/post-01.jpg');
						    }
							?>
							<div class="left-col equal-height-col">
								<div class="img-col">
									<div class="overlay-col"></div>
									<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
									<div class="banner-containt-col">
										<a href="javascript:void(0);" class="title-col" onclick="category_news('<?php echo $category_name[1061];?>')"><?php echo ucfirst($category_name[1061]);?></a>
										<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1061]; ?>" onclick="category_news_details('<?php echo $category_name[1061]; ?>')" data-cat_name="<?php echo $category_name[1061]; ?>" data-title="<?php echo $feed_data_national['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_data_national['@attributes']['description'])); ?>" data-image="<?php echo $feed_data_national['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_data_national['@attributes']['pubDate']; ?>"><h2><?php echo character_limiter($feed_data_national['@attributes']['title'], CHAR_LIMIT);?></h2>
										</a>
										<div class="date-txt"><?php echo $feed_data_national['@attributes']['pubDate'];?></div>
									</div>
								</div>
							</div>
							<?php
						}
						?>
						<div class="right-col equal-height-col">
							<?php
							if(isset($feed_data_international) && !empty($feed_data_international)){
								$image_url = $feed_data_international['@attributes']['image'];
							    $headers = @get_headers($image_url);
							    if($headers && strpos($headers[0], '200')){
							    	$image_url = $image_url;
							    }
							    else{
							    	$image_url = base_url('assets/new_user_assets/images/post-02.jpg');
							    }
								?>
								<div class="img-col">
									<div class="overlay-col"></div>
									<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
									<div class="banner-containt-col">
										<a href="javascript:void(0);" class="title-col" onclick="category_news('<?php echo $category_name[1125];?>')"><?php echo ucfirst($category_name[1125]);?></a>
										<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125]; ?>" onclick="category_news_details('<?php echo $category_name[1125]; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $feed_data_international['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_data_international['@attributes']['description'])); ?>" data-image="<?php echo $feed_data_international['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_data_international['@attributes']['pubDate']; ?>"><h2><?php echo character_limiter($feed_data_international['@attributes']['title'], CHAR_LIMIT);?></h2>
										</a>
										<div class="date-txt"><?php echo $feed_data_international['@attributes']['pubDate'];?></div>
									</div>
								</div>
								<?php
							}
							if(isset($feed_data_bollywood) && !empty($feed_data_bollywood)){
								$image_url = $feed_data_bollywood['@attributes']['image'];
							    $headers = @get_headers($image_url);
							    if($headers && strpos($headers[0], '200')){
							    	$image_url = $image_url;
							    }
							    else{
							    	$image_url = base_url('assets/new_user_assets/images/post-03.jpg');
							    }
								?>
								<div class="img-col half-width-col">
									<div class="overlay-col"></div>
									<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
									<div class="banner-containt-col">
										<a href="javascript:void(0);" class="title-col" onclick="category_news('<?php echo $category_name[11215];?>')"><?php echo ucfirst($category_name[11215]);?></a>
										<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215]; ?>" onclick="category_news_details('<?php echo $category_name[11215]; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $feed_data_bollywood['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_data_bollywood['@attributes']['description'])); ?>" data-image="<?php echo $feed_data_bollywood['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_data_bollywood['@attributes']['pubDate']; ?>"><h2><?php echo character_limiter($feed_data_bollywood['@attributes']['title'], CHAR_LIMIT);?></h2>
										</a>
										<div class="date-txt"><?php echo $feed_data_bollywood['@attributes']['pubDate'];?></div>
									</div>
								</div>
								<?php
							}
							if(isset($feed_data_sports) && !empty($feed_data_sports)){
								$image_url = $feed_data_sports['@attributes']['image'];
							    $headers = @get_headers($image_url);
							    if($headers && strpos($headers[0], '200')){
							    	$image_url = $image_url;
							    }
							    else{
							    	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
							    }
								?>
								<div class="img-col half-width-col">
									<div class="overlay-col"></div>
									<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
									<div class="banner-containt-col">
										<a href="javascript:void(0);" class="title-col" onclick="category_news('<?php echo $category_name[1053];?>')"><?php echo ucfirst($category_name[1053]);?></a>
										<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1053]; ?>" onclick="category_news_details('<?php echo $category_name[1053]; ?>')" data-cat_name="<?php echo $category_name[1053]; ?>" data-title="<?php echo $feed_data_sports['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_data_sports['@attributes']['description'])); ?>" data-image="<?php echo $feed_data_sports['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_data_sports['@attributes']['pubDate']; ?>"><h2><?php echo character_limiter($feed_data_sports['@attributes']['title'], CHAR_LIMIT);?></h2>
										</a>
										<div class="date-txt"><?php echo $feed_data_sports['@attributes']['pubDate'];?></div>
									</div>
								</div>
								<?php
							}
							?>
						</div>
					</div>
				</section>
				<div class="clrfix"></div>

				<!-- Corona Updates Section -->
				<?php
				if(isset($corona_count) && !empty($corona_count)){ ?>
					<section class="home-section-01 home-section-02 news-list-section corona-updates-section-01 fwd">
						<div class="container">
							<div class="contact-section-01 fwd">
								<h2 class="headding-01">Corona Updates</h2>
								<div class="containt-col equal-height-col">
									<h4>COVID-19 INDIA</h4>
									<div class="text-title">
										<span>as on : <?php echo date('d F, Y', strtotime($corona_count['Date'])); ?></span>
										<span>(GMT+5:30)</span>
									</div>
								</div>
								<div class="containt-col equal-height-col">
									<i class="fas fa-users icon-col"></i>
									<h4><?php echo $corona_count['Confirmed']; ?></h4>
									<div class="text-title">Total Patients</div>
								</div>
								<div class="containt-col equal-height-col">
									<i class="fas fa-users icon-col"></i>
									<h4><?php echo $corona_count['Active']; ?></h4>
									<div class="text-title">Active Patients</div>
								</div>
								<div class="containt-col equal-height-col">
									<i class="fas fa-users icon-col"></i>
									<h4><?php echo $corona_count['Deaths']; ?></h4>
									<div class="text-title">Death</div>
								</div>
								<div class="containt-col equal-height-col">
									<i class="fas fa-users icon-col"></i>
									<h4><?php echo $corona_count['Recovered']; ?></h4>
									<div class="text-title">Discharge</div>
								</div>
							</div>
						</div>
					</section>
					<?php
				}
				?>
				<div class="clrfix"></div>

				<!-- Home All Categories Section -->
				<section class="home-categories-section fwd">
					<div class="container">
						<h2 class="headding-01"><?php echo ($website_language == '0') ? "सब वर्ग" : "All Categories";?></h2>
						<div class="owl-carousel owl-theme">
							<?php
							if(isset($all_feed_categories) && !empty($all_feed_categories)) foreach ($all_feed_categories as $key => $value){
								$show_image = (isset($value['image']) && !empty($value['image'])) ? base_url('assets/feed/'.$value['image']) : base_url('assets/feed/no_image.png');
								?>
								<div class="item">
									<a href="javascript:void(0);" class="img-col" onclick="category_news('<?php echo $value['cat_name'];?>')">
										<div class="overlay-col"></div>
										<img src="<?php echo $show_image; ?>" class="img-responsive" alt="">
										<div class="containt-col">
											<div class="title-col"><?php echo $value['cat_name']; ?></div>
										</div>
									</a>
								</div>
								<?php
							}
							?>
						</div>
					</div>
				</section>
				<div class="clrfix"></div>
				<!-- Home Section-01 -->
				<section class="home-section-01 fwd">
					<div class="container">
						<div class="left-col">
							<!-- Entertainment Block -->
							<?php
							if(isset($feed_bollywood) && !empty($feed_bollywood)){
								shuffle($feed_bollywood);
								//echo "<pre>";print_r($feed_bollywood);die();
								?>
								<div class="entertainment-block fwd">
									<h2 class="headding-01">Entertainment <a href="javascript:void(0);" class="view-all-link" onclick="category_news('<?php echo $category_name[11215];?>')">View all <i class="fas fa-caret-right"></i></a></h2>
									<div class="tab-wrapper-col">
										<ul class="nav nav-tabs" role="tablist">
											<li role="presentation" class="active"><a href="#allentertainment" aria-controls="allentertainment" role="tab" data-toggle="tab">All</a></li>
											<li role="presentation"><a href="#celebrity" aria-controls="celebrity" role="tab" data-toggle="tab">Celebrity</a></li>
											<li role="presentation"><a href="#movies" aria-controls="movies" role="tab" data-toggle="tab">Movies</a></li>
											<li role="presentation"><a href="#music" aria-controls="music" role="tab" data-toggle="tab">Music</a></li>
											<li role="presentation"><a href="#games" aria-controls="games" role="tab" data-toggle="tab">Bollywood Gossip</a></li>
										</ul>
										<div class="tab-content">
											<div role="tabpanel" class="tab-pane fade in active" id="allentertainment">
												<div class="left-col">
													<?php
													$image_url = $feed_bollywood[0]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_0'; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_0'; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $feed_bollywood[0]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_bollywood[0]['@attributes']['description'])); ?>" data-image="<?php echo $feed_bollywood[0]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_bollywood[0]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_bollywood[0]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_bollywood[0]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_bollywood) && !empty($feed_bollywood)){
															$allentertainment = array_slice($feed_bollywood, 1, 3, true);
															foreach($allentertainment as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="celebrity">
												<div class="left-col">
													<?php
													$image_url = $feed_bollywood[4]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_4'; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_4'; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $feed_bollywood[4]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_bollywood[4]['@attributes']['description'])); ?>" data-image="<?php echo $feed_bollywood[4]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_bollywood[4]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_bollywood[4]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_bollywood[4]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_bollywood) && !empty($feed_bollywood)){
															$celebrity = array_slice($feed_bollywood, 5, 3, true);
															foreach($celebrity as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="movies">
												<div class="left-col">
													<?php
													$image_url = $feed_bollywood[8]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_8'; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_8'; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $feed_bollywood[8]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_bollywood[8]['@attributes']['description'])); ?>" data-image="<?php echo $feed_bollywood[8]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_bollywood[8]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_bollywood[8]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_bollywood[8]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_bollywood) && !empty($feed_bollywood)){
															$movies = array_slice($feed_bollywood, 9, 3, true);
															foreach($movies as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="music">
												<div class="left-col">
													<?php
													$image_url = $feed_bollywood[12]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_12'; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_12'; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $feed_bollywood[12]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_bollywood[12]['@attributes']['description'])); ?>" data-image="<?php echo $feed_bollywood[12]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_bollywood[12]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_bollywood[12]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_bollywood[12]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_bollywood) && !empty($feed_bollywood)){
															$music = array_slice($feed_bollywood, 13, 3, true);
															foreach($music as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="games">
												<div class="left-col">
													<?php
													$image_url = $feed_bollywood[16]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_16'; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_16'; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $feed_bollywood[16]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_bollywood[16]['@attributes']['description'])); ?>" data-image="<?php echo $feed_bollywood[16]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_bollywood[16]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_bollywood[16]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_bollywood[16]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_bollywood) && !empty($feed_bollywood)){
															$games = array_slice($feed_bollywood, 17, 3, true);
															foreach($games as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[11215].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[11215].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[11215]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php
							}
							?>
							<!-- Business Block -->
							<?php
							if(isset($feed_business) && !empty($feed_business)){
								$feed_business = array_slice($feed_business, 0, 16, true);// returns first 16 elements
								shuffle($feed_business);
								//echo "<pre>";print_r($feed_business);die();
								?>
								<div class="entertainment-block business-block fwd">
									<h2 class="headding-01">Business <a href="javascript:void(0);" class="view-all-link" onclick="category_news('<?php echo $category_name[1051];?>')">View all <i class="fas fa-caret-right"></i></a></h2>
									<div class="tab-wrapper-col">
										<ul class="nav nav-tabs" role="tablist">
											<li role="presentation" class="active"><a href="#allbusiness" aria-controls="allbusiness" role="tab" data-toggle="tab">All</a></li>
											<li role="presentation"><a href="#finance" aria-controls="finance" role="tab" data-toggle="tab">Finance</a></li>
											<li role="presentation"><a href="#moneymarkets" aria-controls="moneymarkets" role="tab" data-toggle="tab">Money & Markets</a></li>
											<li role="presentation"><a href="#smallbusiness" aria-controls="smallbusiness" role="tab" data-toggle="tab">Small Business</a></li>
										</ul>
										<div class="tab-content">
											<div role="tabpanel" class="tab-pane fade in active" id="allbusiness">
												<div class="left-col">
													<?php
													$image_url = $feed_business[0]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_0'; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_0'; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $feed_business[0]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_business[0]['@attributes']['description'])); ?>" data-image="<?php echo $feed_business[0]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_business[0]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_business[0]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_business[0]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_business) && !empty($feed_business)){
															$allbusiness = array_slice($feed_business, 1, 3, true);
															foreach($allbusiness as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="finance">
												<div class="left-col">
													<?php
													$image_url = $feed_business[4]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_4'; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_4'; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $feed_business[4]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_business[4]['@attributes']['description'])); ?>" data-image="<?php echo $feed_business[4]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_business[4]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_business[4]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_business[4]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_business) && !empty($feed_business)){
															$finance = array_slice($feed_business, 5, 3, true);
															foreach($finance as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="moneymarkets">
												<div class="left-col">
													<?php
													$image_url = $feed_business[8]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_8'; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_8'; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $feed_business[8]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_business[8]['@attributes']['description'])); ?>" data-image="<?php echo $feed_business[8]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_business[8]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_business[8]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_business[8]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_business) && !empty($feed_business)){
															$moneymarkets = array_slice($feed_business, 9, 3, true);
															foreach($moneymarkets as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="smallbusiness">
												<div class="left-col">
													<?php
													$image_url = $feed_business[12]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_12'; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_12'; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $feed_business[12]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_business[12]['@attributes']['description'])); ?>" data-image="<?php echo $feed_business[12]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_business[12]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_business[12]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_business[12]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_business) && !empty($feed_business)){
															$smallbusiness = array_slice($feed_business, 13, 3, true);
															foreach($smallbusiness as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1051].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1051].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1051]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php
							}
							?>
							<!-- International Block -->
							<?php
							if(isset($feed_international) && !empty($feed_international)){
								$feed_international = array_slice($feed_international, 0, 16, true);// returns first 16 elements
								shuffle($feed_international);
								//echo "<pre>";print_r($feed_international);die();
								?>
								<div class="entertainment-block travel-block fwd">
									<h2 class="headding-01">International <a href="javascript:void(0);" class="view-all-link" onclick="category_news('<?php echo $category_name[1125];?>')">View all <i class="fas fa-caret-right"></i></a></h2>
									<div class="tab-wrapper-col">
										<ul class="nav nav-tabs" role="tablist">
											<li role="presentation" class="active"><a href="#alltravel" aria-controls="alltravel" role="tab" data-toggle="tab">All</a></li>
											<li role="presentation"><a href="#hotels" aria-controls="hotels" role="tab" data-toggle="tab">Hotels</a></li>
											<li role="presentation"><a href="#flight" aria-controls="flight" role="tab" data-toggle="tab">Flight</a></li>
											<li role="presentation"><a href="#culture" aria-controls="culture" role="tab" data-toggle="tab">Culture</a></li>
										</ul>
										<div class="tab-content">
											<div role="tabpanel" class="tab-pane fade in active" id="alltravel">
												<div class="left-col">
													<?php
													$image_url = $feed_international[0]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_0'; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_0'; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $feed_international[0]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_international[0]['@attributes']['description'])); ?>" data-image="<?php echo $feed_international[0]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_international[0]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_international[0]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_international[0]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_international) && !empty($feed_international)){
															$alltravel = array_slice($feed_international, 1, 3, true);
															foreach($alltravel as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="hotels">
												<div class="left-col">
													<?php
													$image_url = $feed_international[4]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_4'; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_4'; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $feed_international[4]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_international[4]['@attributes']['description'])); ?>" data-image="<?php echo $feed_international[4]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_international[4]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_international[4]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_international[4]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_international) && !empty($feed_international)){
															$hotels = array_slice($feed_international, 5, 3, true);
															foreach($hotels as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="flight">
												<div class="left-col">
													<?php
													$image_url = $feed_international[8]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_8'; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_8'; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $feed_international[8]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_international[8]['@attributes']['description'])); ?>" data-image="<?php echo $feed_international[8]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_international[8]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_international[8]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_international[8]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_international) && !empty($feed_international)){
															$flight = array_slice($feed_international, 9, 3, true);
															foreach($flight as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
											<div role="tabpanel" class="tab-pane fade" id="culture">
												<div class="left-col">
													<?php
													$image_url = $feed_international[12]['@attributes']['image'];
													$headers = @get_headers($image_url);
													if($headers && strpos($headers[0], '200')){
														$image_url = $image_url;
													}
													else{
														$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
													}
													?>
													<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_12'; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_12'; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $feed_international[12]['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $feed_international[12]['@attributes']['description'])); ?>" data-image="<?php echo $feed_international[12]['@attributes']['image']; ?>" data-pubDate="<?php echo $feed_international[12]['@attributes']['pubDate']; ?>">
														<div class="img-col fwd">
															<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
															<div class="overlay-col"></div>
														</div>
														<div class="containt-col fwd">
															<h3 class="headding-02"><?php echo character_limiter($feed_international[12]['@attributes']['title'], CHAR_LIMIT);?></h3>
															<div class="headding-03"><?php echo $feed_international[12]['@attributes']['pubDate'];?></div>
														</div>
													</a>
												</div>
												<div class="right-col">
													<ul class="list-unstyled tab-news-list">
														<?php
														if(isset($feed_international) && !empty($feed_international)){
															$culture = array_slice($feed_international, 13, 3, true);
															foreach($culture as $key => $value){
																$image_url = $value['@attributes']['image'];
																$headers = @get_headers($image_url);
																if($headers && strpos($headers[0], '200')){
																	$image_url = $image_url;
																}
																else{
																	$image_url = base_url('assets/new_user_assets/images/post-04.jpg');
																}
																?>
																<li>
																	<a href="javascript:void(0);" id="cat_news_<?php echo $category_name[1125].'_'.$key; ?>" onclick="category_news_details('<?php echo $category_name[1125].'_'.$key; ?>')" data-cat_name="<?php echo $category_name[1125]; ?>" data-title="<?php echo $value['@attributes']['title']; ?>" data-description="<?php echo trim(str_replace('"', ' ', $value['@attributes']['description'])); ?>" data-image="<?php echo $value['@attributes']['image']; ?>" data-pubDate="<?php echo $value['@attributes']['pubDate']; ?>">
																		<div class="img-col">
																			<img src="<?php echo $image_url;?>" class="img-responsive" alt=""/>
																		</div>
																		<div class="containt-col">
																			<h3><?php echo character_limiter($value['@attributes']['title'], CHAR_LIMIT);?></h3>
																			<div class="date-txt"><?php echo $value['@attributes']['pubDate'];?></div>
																		</div>
																	</a>
																</li>
																<?php
															}
														}
														?>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php
							}
							?>
						</div>
						<!-- Most Popular Block -->
						<?php
						//echo "<pre>";print_r($popular);die();
						if(isset($popular) && !empty($popular)){ ?>
							<div class="right-col">
								<div class="most-popular-block fwd">
									<h2 class="headding-01"><?php echo ($website_language == '0') ? "लोकप्रिय" : "Most Popular";?></h2>
									<ol class="">
										<?php
										foreach($popular as $key => $value){
											$table_name = 'news';
											?>
											<li>
												<a href="javascript:void(0);" onclick="view_details('<?php echo $value['id']; ?>', '<?php echo $table_name; ?>', '<?php echo $value['category_id']; ?>')"><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></a>
											</li>
											<?php
										}
										?>
									</ol>
								</div>
								<div class="advertisement-banner2 fwd">
									<img src="<?php echo base_url('assets/new_user_assets/images/advertisement-banner2.jpg');?>" class="img-responsive" alt=""/>
								</div>
							</div>
							<?php
						}
						?>
					</div>
				</section>
				<div class="clrfix"></div>
				<!-- Home Section-02 -->
				<section class="home-section-01 home-section-02 fwd">
					<div class="container">
						<div class="advertisement-banner">
							<img src="<?php echo base_url('assets/new_user_assets/images/advertisement-banner.jpg');?>" class="img-responsive" alt=""/>
						</div>
						<div class="left-col">
							<!-- Latest Articles Block -->
							<div class="latest-articles-block fwd">
								<h2 class="headding-01"><?php echo ($website_language == '0') ? "हमारी खबर" : "Our News";?></h2>
								<ul class="list-inline articles-list">
									<?php
                                    //echo "<pre>";print_r($all_categories_data);die();
									if(isset($all_categories_data) && !empty($all_categories_data)) foreach($all_categories_data as $key => $value){
										$show_image = (isset($value['image']) && !empty($value['image']) && file_exists("assets/news/".$value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
										$table_name = 'news';
										?>
										<li class="equal-height-col">
											<a href="javascript:void(0);" class="item-col fwd" onclick="view_details('<?php echo $value['id']; ?>', '<?php echo $table_name; ?>', '<?php echo $value['category_id']; ?>')">
												<div class="img-col fwd">
													<img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
												</div>
												<div class="containt-col fwd">
													<h3 class="headding-02"><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
													<div class="headding-03"><?php echo date('d F, Y', strtotime($value['created'])); ?></div>
												</div>
											</a>
										</li>
										<?php
									}
									?>
								</ul>
							</div>
						</div>
						<div class="right-col">
							<!-- Featured Videos Block -->
							<div class="video-block fwd">
								<h2 class="headding-01">Featured Videos</h2>
								<div class="img-col fwd">
									<img src="<?php echo base_url('assets/new_user_assets/images/featured-video-img-01.jpg');?>" class="img-responsive" alt=""/>
									<div class="overlay-col"></div>
									<div class="play-btn" data-toggle="modal" data-target="#FeaturedVideo1"><i class="fab fa-youtube"></i></div>
								</div>
								<div class="containt-col fwd">
									<h3 class="headding-02">Oxiinc Group Launched Bmkoin India's First Cryptocurrency.</h3>
									<div class="headding-03">Jul 5, 2020</div>
								</div>
								<!-- Video Modal -->
								<div class="modal fade" id="FeaturedVideo1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-body">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												<iframe width="100%" src="https://www.youtube.com/embed/eGp45FxrZ-k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- Subscribe Block -->
							<div class="subscribe-block fwd">
								<h2>Subscribe</h2>
								<p>Get all latest content deliverd to your email a few times a month</p>
								<form class="subscribe-form fwd">
									<input type="email" class="input-textbox" id="InputEmail" placeholder="Email">
									<button type="submit" class="submit-btn"><i class="fas fa-arrow-right"></i></button>
								</form>
							</div>
							<!-- Tags Block -->
							<div class="tags-block fwd">
								<h2 class="headding-01">Tags</h2>
								<ul class="list-inline tags-links">
									<li><a href="#">Fashion</a></li>
									<li><a href="#">Lifestyle</a></li>
									<li><a href="#">Denim</a></li>
									<li><a href="#">Streetstyle</a></li>
									<li><a href="#">Crafts</a></li>
									<li><a href="#">Magzine</a></li>
									<li><a href="#">News</a></li>
									<li><a href="#">Blogs</a></li>
								</ul>
							</div>
						</div>
					</div>
				</section>
				<div class="clrfix"></div>
			</div>
			<div class="clrfix"></div>
			<!-- END CONTAINER -->

