<style>
    	.address_color{
            background: #171616 !important;padding: 19px;color:white;
        }
</style><style>
	 
</style>

<div class="gap-30"></div>

	
	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li>
							<i class="fa fa-home"></i>
								<a href="#">Home</a>
							<i class="fa fa-angle-right"></i>
						</li>
						<li><a href="#">lifestyle</a></li>
						<li><i class="fa fa-angle-right"></i>Struggling to sell one..</li>
					</ol>		
				</div>
			</div><!-- row end -->
		</div><!-- container end -->
	</div>
	
	
	<section class="main-content category-layout-1 pt-0" style="margin-top: 20px">
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-12">
					  <div class="row" >
	                    <div class="col-lg-4">
	                    	<div class="contact-info-box">
								<div class="contact-info-box-content address_color text-center">
									<p><img src="./assets/images/address.jpg" width="50"></p>
									<h4 style="color:white">ADDRESS</h4>
									<p style="color:white">S6-2, Pinnacle Business Park,
		                        		Mahakali Caves Rd,
		                        		Shanti Nagar, Andheri East,
		                        		Mumbai, Maharashtra - 400093.</p>
								</div>
							</div>
	                    </div>  
	                    <div class="col-lg-4">
	                    	<div class="contact-info-box">
								<div class="contact-info-box-content address_color text-center">
									<p><img src="./assets/images/phone.jpg" width="50"></p>
									<h4 style="color:white">CALL US</h4>
									<p style="color:white">Phone: +91 8650307358</p><br><br>
								</div>
							</div>
	                        
	                    </div>
	                    <div class="col-lg-4">
	                    	<div class="contact-info-box">
								<div class="contact-info-box-content address_color text-center">
									<p><img src="./assets/images/email.jpg" width="50"></p>
									<h4 style="color:white">EMAIL</h4>
									<p style="color:white">
	                        				contact@ouropinion.in<br>
	                        				info@ouropinion.in <br>
	                        		</p><br>
								</div>
							</div>
	                    </div>
                	</div> <!-- end row -->
				</div><!-- col-lg-8 -->
				<div class="col-lg-12">
					<div class="row">
						<div class="col-lg-8">
							<h3>Contact Form</h3>
							<form id="contact-form" action="http://demo.themewinter.com/html/digiqole/contact-form.php" method="post">
						<div class="error-container"></div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label>Name</label>
								<input class="form-control form-control-name" name="name" id="name" placeholder="" type="text" required>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Email</label>
									<input class="form-control form-control-email" name="email" id="email" 
									placeholder="" type="email" required>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Subject</label>
									<input class="form-control form-control-subject" name="subject" id="subject" 
									placeholder="" required>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label>Message</label>
							<textarea class="form-control form-control-message" name="message" id="message" placeholder="" rows="10" required></textarea>
						</div>
						<div>
							<button class="btn btn-submit" type="submit">Send Message</button> 
						</div>
							</form>
						</div>
						<div class="col-lg-4">
							<div class="sidebar">
								<div class="sidebar-widget featured-tab post-tab mb-20">
							<ul class="nav nav-tabs">
								<li class="nav-item">
									<a class="nav-link animated active fadeIn" href="#post_tab_a" data-toggle="tab">
										<span class="tab-head">
											<span class="tab-text-title">Recent</span>					
										</span>
									</a>
								</li>
								<li class="nav-item">
									<a class="nav-link animated fadeIn" href="#post_tab_b" data-toggle="tab">
										<span class="tab-head">
											<span class="tab-text-title">Popular</span>					
										</span>
									</a>
								</li>
								<li class="nav-item">
									<a class="nav-link animated fadeIn" href="#post_tab_c" data-toggle="tab">
										<span class="tab-head">
											<span class="tab-text-title">Comments</span>					
										</span>
									</a>
								</li>
							</ul>
							<div class="gap-50 d-none d-md-block"></div>
							<div class="row">
								<div class="col-12">
									<div class="tab-content">
										<div class="tab-pane active animated fadeInRight" id="post_tab_a">
											<div class="list-post-block">
												<ul class="list-post">
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 1</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat tech-color" href="#">Tech</a>
																</div>
																<h2 class="post-title">
																	<a href="#">House last week that move would Inject</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
															</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 1 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 2</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat travel-color" href="#">Travel</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Zhang social media pop also known innocent</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 2 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 3</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat health-color" href="#">Health</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Jennifer Lopez expand her property collection</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 3 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 4</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat sports-color" href="#">Sports</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Santino loganne legan an year old resident</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 3 end -->
												</ul><!-- List post end -->
											</div>
										</div><!-- Tab pane 1 end -->
										<div class="tab-pane animated fadeInRight" id="post_tab_b">
											<div class="list-post-block">
												<ul class="list-post">
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 5</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat travel-color" href="#">Travel</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Zhang social media pop also known innocent</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 1 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 3</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat tech-color" href="#">Tech</a>
																</div>
																<h2 class="post-title">
																	<a href="#">House last week that move would Inject</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 2 end -->
												
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 1</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat sports-color" href="#">Sports</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Santino loganne legan an year old resident</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 3 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 1</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat health-color" href="#">Health</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Jennifer Lopez expand her property collection</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 4 end -->
												</ul><!-- List post end -->
											</div>
										</div><!-- Tab pane 2 end -->
										<div class="tab-pane animated fadeInRight" id="post_tab_c">
											<div class="list-post-block">
												<ul class="list-post">
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 1</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat tech-color" href="#">Tech</a>
																</div>
																<h2 class="post-title">
																	<a href="#">House last week that move would Inject</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
															</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 1 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 2</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat travel-color" href="#">Travel</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Zhang social media pop also known innocent</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 2 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 5</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat health-color" href="#">Health</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Jennifer Lopez expand her property collection</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 3 end -->
													<li>
														<div class="post-block-style media">
															<div class="post-thumb">
																<a href="#">
																	<img class="img-fluid" src="./assets/images/image3.png" alt="">
																</a>
																<span class="tab-post-count"> 1</span>
															</div><!-- Post thumb end -->
						
															<div class="post-content media-body">
																<div class="grid-category">
																	<a class="post-cat sports-color" href="#">Sports</a>
																</div>
																<h2 class="post-title">
																	<a href="#">Santino loganne legan an year old resident</a>
																</h2>
																<div class="post-meta mb-7">
																	<span class="post-date"><i class="fa fa-clock-o"></i> 29 July, 2020</span>
																</div>
																</div><!-- Post content end -->
														</div><!-- Post block style end -->
													</li><!-- Li 3 end -->
												</ul><!-- List post end -->
											</div>
										</div><!-- Tab pane 2 end -->
									</div><!-- tab content -->
								</div>
							</div>
								</div><!-- widget end -->
							</div>
						</div>
					</div>
				</div><!-- sidebar col end -->
			</div><!-- row end -->
		</div><!-- container end -->
	</section><!-- category-layout end -->

