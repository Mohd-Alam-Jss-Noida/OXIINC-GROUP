	<?php
		//print_r($this->session->userdata()); exit();
?>
	<div class="gap-30"></div>

	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li>
							<i class="fa fa-home"></i>
								<a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a>
							<i class="fa fa-angle-right"></i>
						</li>
						<li><?php echo $this->session->userdata('cat_name'); ?></li>
						</ol>		
				</div>
			</div>
		</div>
	</div>
	
	<section class="block-wrapper pb-lg-0" style="padding: 25px 0;">
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-8 col-md-12">
					<div class="single-post">
						<div class="post-header-area">
							<h2 class="post-title title-lg"><?php echo $this->session->userdata('title'); ?></h2>
							<ul class="post-meta">
								<!-- <li>
									<a href="#" class="post-cat fashion">Lifestyle</a>
								</li> -->
								<li class="post-author">
									<a href="#"><img src="<?php echo base_url();?>assets/images/news/e_author.png"><strong><?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></strong></a>
								</li>
								<li><i class="fa fa-clock-o"></i> <?php echo date('d F, Y', strtotime($this->session->userdata('created'))); ?></li>
								<li class="social-share">
									<i class="shareicon fa fa-share"></i>
									<ul class="social-list" style="min-width: 230px !important;">
										<li><a data-social="facebook" class="facebook fb-share-button" data-href="https://www.facebook.com/share.php?u=http%3A%2F%2Fenewsmedia.in%2F" data-title="<?php echo $this->session->userdata('title'); ?>" data-image="<?php echo $this->session->userdata('image'); ?>" target="_blank" rel="nofollow" style="color: #fff; font-size: 18px;"><i class="fa fa-facebook"></i></a>
										</li>
										<li><a data-social="twitter" class="twitter" href="https://twitter.com/intent/tweet?text=<?php echo $this->session->userdata('title'); ?>&url=<?php echo base_url(); ?>&hashtags=enewsmedia" style="color: #fff; font-size: 18px;" onclick="javascript:window.open(this.href,'_blank', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
										<li><a data-social="youtube" class="youtube" href="#" style="color: #fff; font-size: 18px;"><i class="fa fa-youtube-play"></i></a></li>
										<li><a data-social="linkedin" class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=http%3A%2F%2Fenewsmedia.in%2F&title=<?php echo $this->session->userdata('title'); ?>&summary=http%3A%2F%2Fenewsmedia.in%2F&source=Enewsmedia" style="color: #fff; font-size: 18px;" onclick="javascript:window.open(this.href,'_blank', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank"><i class="fa fa-linkedin"></i></a></li>
									</ul>
								</li>
							</ul>							
						</div>
						<div class="post-content-area">
							<div class="post-media mb-20" style="text-align: center;">
								<a href="<?php echo $this->session->userdata('image'); ?>" class="gallery-popup cboxElement">
									<img src="<?php echo $this->session->userdata('image'); ?>" class="img-fluid" alt="">
								</a>
							</div>
							<p style="text-align: justify;"><?php echo $this->session->userdata('description'); ?></p>
						</div>						
					</div>		
				</div>

				<div class="col-lg-4">
					<div class="sidebar">
						<div class="sidebar-widget social-widget">
							<h2 class="block-title">
								<span class="title-angle-shap"> <?php if($website_language == '0') { echo "सामाजिक"; } else { echo "Social"; } ?></span>
							</h2>
							<div class="sidebar-social">
								<ul class="ts-social-list style2">
									<li class="ts-facebook">
										<a href="#">
											<i class="tsicon fa fa-facebook"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "फेसबुक"; } else { echo "Facebook"; } ?></b>
												<span><?php if($website_language == '0') { echo "पसंद"; } else { echo "Likes"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-twitter">
										<a href="#">
											<i class="tsicon fa fa-twitter"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "ट्विटर"; } else { echo "Twitter"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-youtube">
										<a href="#">
											<i class="tsicon fa fa-youtube-play"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "यूट्यूब"; } else { echo "Youtube"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-rss">
										<a href="#">
											<i class="tsicon fa fa-linkedin"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "लिंक्डइन"; } else { echo "Linkdin"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="post-block-style clearfix" style="padding-bottom: 25px;">
							<h2 class="block-title">
								<?php //echo $recent_happenings; ?>
								<span class="title-angle-shap"><?php if($website_language == '0') { echo "हाल ही में हुआ"; } else { echo "Recent Happenings"; } ?></span>
							</h2>
						</div>
						<?php
							foreach($recent_happenings as $key => $value)
              {
              	$image_path = ASSET_URL."/assets/news/".''.$recent_happenings[$key]['image'];
			        $no_image_path = "./assets/news/".''."no_image.png";
			        $show_image = file_exists("./assets/news/".''.$recent_happenings[$key]['image']) ? $image_path : $no_image_path;
			        $video_thumb_img = file_exists("./assets/news/".''.$recent_happenings[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$recent_happenings[$key]['video_thumb_img'] : $no_image_path;

			        $table_name = 'news';
                            	?>
								<div class="post-block-style clearfix" style="padding-bottom: 25px;">
									<div class="post-thumb">
										<?php if(isset($recent_happenings[$key]['media_type']) && $recent_happenings[$key]['media_type'] == 'video') { ?>
												<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="">
												<a class="popup cboxElement" href="<?php echo $show_image; ?>">
													<div class="video-icon">
														<i class="fa fa-play"></i>
													</div>
												</a>
									<?php } else { ?>															
										<a href="#" onclick="view_details('<?php echo $recent_happenings[$key]['id']; ?>', '<?php echo $table_name; ?>')">
											<img class="img-fluid" src="<?php echo $show_image ;?>">
											<div class="grid-cat"><a class="post-cat" href="#"><?php if($website_language == '0') { echo $recent_happenings[$key]['category_hindi_name']; } else { echo $recent_happenings[$key]['category_name']; } ?></a></div>
										</a>
									<?php } ?>
									</div>
									<div class="post-content">
										<h2 class="post-title title-md">
											<a href="#" onclick="view_details('<?php echo $recent_happenings[$key]['id']; ?>', '<?php echo $table_name; ?>')">
												<?php if($website_language == '0') { echo (strlen($recent_happenings[$key]['hindi_name']) > 50) ? substr($recent_happenings[$key]['hindi_name'], 0, 40).' '."..." : $recent_happenings[$key]['hindi_name']; } else { echo (strlen($recent_happenings[$key]['name']) > 50) ? substr($recent_happenings[$key]['name'], 0, 40).' '."..." : $recent_happenings[$key]['name']; } ?>
											</a>
										</h2>
										<div class="post-meta mb-7">
											<span class="post-author"><a href="#"><i class="fa fa-user"></i> &nbsp; <?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></a></span>
											<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($recent_happenings[$key]['created']) && !empty($recent_happenings[$key]['created']) ? date('d F, Y', strtotime($recent_happenings[$key]['created'])) : ''; ?></span>
										</div>
									</div>
								</div>
              	<?php
              }
          ?>
						<div class="gap-10 d-none d-lg-block"></div>
					</div>
				</div>
			</div>
		</div>		
	</section>

	<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.js"></script>
	<script type="text/javascript">
  $(document).ready(function() {
      //alert("VIEW PAGE");
      $('.facebook').on('click', function(){
      	var href = $(this).attr("data-href");
      	var image = $(this).attr("data-image");
      	var title = $(this).attr("data-title");
      	$('meta[property="og\\:type"]').remove();
      	$('meta[property="og\\:description"]').remove();
      	$('meta[property="og\\:title"]').remove();
      	$('meta[property="og\\:image"]').remove();
      	socialShare(href,title,image);
      	//window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"
      	//
      });
    });

    function socialShare(openLink, shareTitle, shareImage){
    	$('head').append( '<meta property="og:type" content="website" />' );
    	$('head').append( '<meta property="og:description" content="'+shareTitle+'" />' );
    	$('head').append( '<meta property="og:title" content="'+shareTitle+'" />' );
    	$('head').append( '<meta property="og:image" content="'+shareImage+'" />' );

    	setTimeout(function(){
    		window.open(openLink,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
    		return false;
    		}, 1000);	 // 10000 = 10 SECONDS, 60000 = 1 MINUTES      	
    }            
</script>