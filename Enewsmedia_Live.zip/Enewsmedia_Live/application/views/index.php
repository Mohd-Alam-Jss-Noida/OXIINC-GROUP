
	<?php
	if(isset($_GET['data']) && $_GET['data'] == 1){
		//echo "<pre>"; print_r($menu_data); echo "</pre>";
		echo "<pre>"; print_r($all_categories_data); echo "</pre>";
		echo "<pre>"; print_r($feed_data); echo "</pre>"; 
		//echo "<pre>"; print_r($popular); echo "</pre>";
		exit();
	}
	?>

	<section class="featured-post-area no-padding">
		<div class="container mt-1">
		    <div class="row">
		        <div class="col-md-12">
		            <div class="d-flex justify-content-between align-items-center breaking-news bg-white">
		                <div class="d-flex flex-row flex-grow-1 flex-fill justify-content-center bg-danger py-2 text-white px-1 news"><span class="d-flex align-items-center">&nbsp;Breaking News</span></div>
		                <marquee class="news-scroll" behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"> <a href="#">Enewsmedia.in  provides latest news from India and the world. Get today's news headlines from Weather, Food, Agriculture, Technology, Bollywood, Cricket, Videos, Photos, Corona, Politics live news coverage and exclusive breaking news from India. </a> <!-- <span class="dot"></span> <a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut </a> <span class="dot"></span> <a href="#">Duis aute irure dolor in reprehenderit in voluptate velit esse </a> --> </marquee>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="gap-20"></div>
		<div class="container mt-2">
			<center><h2> Corona Updates</h2></center>
		    <div class="row">
		        <div class="four col-lg-4 col-md-12">
		            <div class="counter-box">
		                <h2>COVID-19 INDIA</h2>
		                <p style="color: #000;">as on : <?php echo date('d F, Y', strtotime($corona_count['Date'])); ?></p>
		                <p style="color: #000;">(GMT+5:30)</p>
		            </div>
		        </div>
		        <div class="four col-lg-2 col-md-6">
		            <div class="counter-box colored"> <i class="fa fa-group"></i> <span class="counter"><?php echo $corona_count['Confirmed']; ?></span>
		                <p>Total Patients</p>
		            </div>
		        </div>
		        <div class="four col-lg-2 col-md-6">
		            <div class="counter-box colored1"> <i class="fa fa-group"></i> <span class="counter"><?php echo $corona_count['Active']; ?></span>
		                <p>Active Patients</p>
		            </div>
		        </div>
		        <div class="four col-lg-2 col-md-6">
		            <div class="counter-box colored"> <i class="fa fa-group"></i> <span class="counter"><?php echo $corona_count['Deaths']; ?></span>
		                <p>Death </p>
		            </div>
		        </div>
		        <div class="four col-lg-2 col-md-6">
		            <div class="counter-box colored1"> <i class="fa fa-group"></i> <span class="counter"><?php echo $corona_count['Recovered']; ?></span>
		                <p>Discharge</p>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="gap-30"></div>
		<div class="container">
			<div class="row ts-gutter-20">
				<div class="col-lg-6 col-md-12 pad-r">
					<div class="owl-carousel owl-theme featured-slider h2-feature-slider">
						<?php
							foreach ($all_data as $key => $value)
							{
								$image_path = ASSET_URL."/assets/news/".''.$all_data[$key]['image'];
                $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
                if(isset($all_data[$key]['media_type']) && $all_data[$key]['media_type'] == 'video') {
        					$show_image = isset($all_data[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$all_data[$key]['video_thumb_img'] : $no_image_path;
        				}else{
        				    $show_image = isset($all_data[$key]['image']) ? $image_path : $no_image_path;
        				}                
								?>
								<div class="item post-overaly-style post-md" style="background-image:url(<?php echo $show_image; ?>)">
									<div class="featured-post">
										<a href="#" onclick="view_details('<?php echo $all_data[$key]['id']; ?>', 'news')" class="image-link">&nbsp;</a>
										<div class="overlay-post-content">
											<div class="post-content">
												<div class="grid-category">
													<a class="post-cat" href="<?php echo $all_data[$key]['id']; ?>"><?php if($website_language == '0') { echo $all_data[$key]['category_hindi_name']; } else { echo $all_data[$key]['category_name']; } ?></a>
												</div>
												<h2 class="post-title title-lg">
													<a href="#" onclick="view_details('<?php echo $all_data[$key]['id']; ?>', 'category')"><?php if($website_language == '0') { echo (strlen($all_data[$key]['hindi_name']) > 50) ? substr($all_data[$key]['hindi_name'], 0, 50).' '."..." : $all_data[$key]['hindi_name']; } else { echo (strlen($all_data[$key]['name']) > 50) ? substr($all_data[$key]['name'], 0, 50).' '."..." : $all_data[$key]['name']; } ?></a>
												</h2>
												<div class="post-meta">
													<ul>
														<!-- <li><i class="fa fa-user"></i> &nbsp; <?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></li> -->
														<li><i class="icon icon-clock"></i> &nbsp; <?php echo date('d F, Y', strtotime($all_data[$key]['created'])); ?></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php
							}
						?>
					</div>
				</div>
				
				<!-- VIDEO START -->
				<div class="col-lg-6 col-md-12 pad-r">
					<div class="post-overaly-style post-md">
						<div class="featured-post">
							<a href="#" class="image-link">&nbsp;</a>
							<div class="overlay-post-content">
								<div class="post-thumb">
									<img class="img-fluid" src="<?php echo base_url(); ?>assets/images/news/politics/woman123.jpg" alt="" style="height: -webkit-fill-available;">
									<a class="popup cboxElement" href="<?php echo ASSET_URL; ?>/assets/images/news/video/example.mp4">
										<div class="video-icon">
											<i class="fa fa-play"></i>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- VIDEO END -->

			</div>
		</div>
	</section>
	<section class="trending-slider pb-0">
		<div class="container">
			<div class="ts-grid-box">
				<h2 class="block-title">
					 <span class="title-angle-shap"><?php if($website_language == '0') { echo "सब वर्ग"; } else { echo "All Categories"; } ?></span>
				</h2>
				<div class="owl-carousel dot-style2" id="trending-slider">
					<?php
						foreach ($all_feed_categories as $key => $value)
						{ 
								$image_path = ASSET_URL. "/assets/feed/".''.$all_feed_categories[$key]['image'];
								$no_image_path = ASSET_URL. "/assets/feed/".''."no_image.png";
								$show_image = isset($all_feed_categories[$key]['image']) ? $image_path : $no_image_path;
							?>
							<div class="item post-overaly-style post-md" style="background-image:url(<?php echo $show_image; ?>)">
								<a href="#" class="image-link" onclick="view_all_feed('<?php echo $value['cat_name'];?>')">&nbsp;</a>
								<div class="overlay-post-content">
									<div class="post-content">
										<div class="grid-category">
											<a class="post-cat" href="#"><?php echo $value['cat_name']; ?></a>
										</div>
										<div class="post-meta">
										</div>
									</div>
								</div>
							</div>
						<?php
						}
					?>
				</div>
			</div>
		</div>
	</section>	
<?php 
	$feedArr = array('1061' => 'national', '1125' => 'international','11215' => 'bollywood', '1053' => 'sports','3379' => 'jeevan_mantra', '1051' => 'business','10711' => 'auto', '7911' => 'happy_life');
if(count($feed_data) > 1) {		
//echo "here"; 	print_r($feed_data);	
	foreach ($feedArr as $key => $value){	   ?>	
	<section class="trending-slider pb-0">					
		<div class="container">
			<div class="ts-grid-box">
				<div class="block-title"><h2><span class="title-angle-shap"><?php echo ucfirst(str_replace('_', ' ', $value)); ?></span></h2>
					<a href="#"><div class="view-all" onclick="view_all_feed('<?php echo $value;?>')">View All</div></a>
				</div>
				<!-- <h2 class="block-title">
					 <span class="title-angle-shap"><?php echo ucfirst(str_replace('_', ' ', $value)); ?></span>
				</h2>
				<a href="#"><div class="view-all" onclick="view_all_feed('<?php echo $value;?>')">View All</div></a> -->
				<div class="owl-carousel dot-style2" id="trending-slider">				
				<?php 
					if(isset($feed_data[$value]) && count($feed_data[$value]) > 1){
						$i=1;
						foreach ($feed_data[$value] as $k => $v)
						{	

							$no_image_feed_path = ASSET_URL. "/assets/news/".''."no_image.png";

							//$headers = @get_headers($this->_value);
							/*$file = $v['@attributes']['image'];
							$file_headers = @get_headers($file);
							if(strpos($file_headers[0],'200')===false)
							    $feed_image = $no_image_feed_path;
							else*/
							    $feed_image = $v['@attributes']['image'];

							?>
							<div class="item post-overaly-style post-md" style="background-image:url(<?php echo $feed_image; ?>)">
								<a href="#" id="<?php echo $key.'_'.$i;?>" onclick="feed_details('<?php echo $key.'_'.$i; ?>')" data-name="<?php echo ucfirst(str_replace('_', ' ', $value)); ?>" data-image="<?php echo $feed_image; ?>" data-title="<?php echo $v['@attributes']['title']; ?>" data-desciption="<?php echo $v['@attributes']['description']; ?>" data-created="<?php echo $v['@attributes']['pubDate']; ?>" class="image-link">
								<div class="overlay-post-content">
									<div class="post-content">
										<div class="grid-category">
											<a class="post-cat" href="#"><?php echo $value; ?></a>
										</div>
										<h2 class="post-title">
											<a href="<?php echo $v['@attributes']['link']; ?>" target="_blank"  ><?php echo (strlen($v['@attributes']['title']) > 50) ? substr($v['@attributes']['title'], 0, 50).' '."..." : $v['@attributes']['title'];  ?></a>
										</h2>
									</div>
								</div>
								</a>
							</div>						
				<?php $i++;
				}
			} ?>
				</div>
			</div>
		</div>
		<div class="gap-30"></div>
		</section>
		<?php
				} 
		} ?>
	<section class="trending-slider pb-0">
		<div class="container">
			<div class="ts-grid-box">
				<h2 class="block-title">
					 <span class="title-angle-shap"><?php if($website_language == '0') { echo "हमारी खबर"; } else { echo "Our News"; } ?></span>
				</h2>
				<div class="owl-carousel dot-style2" id="trending-slider">
					<?php
						foreach ($all_categories_data as $key => $value)
						{
							//if($all_categories_data)
							$image_path = ASSET_URL. "/assets/news/".''.$all_categories_data[$key]['image'];
              				$no_image_path = ASSET_URL. "/assets/news/".''."no_image.png";
        				if(isset($all_categories_data[$key]['media_type']) && $all_categories_data[$key]['media_type'] == 'video') {
        					$show_image = isset($all_categories_data[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$all_categories_data[$key]['video_thumb_img'] : $no_image_path;
        				}else{
        				    $show_image = isset($all_categories_data[$key]['image']) ? $image_path : $no_image_path;
        				}

        				$sub_id_flag = 0;
        				if(isset($all_categories_data[$key]['sub_category_id']) && $all_categories_data[$key]['sub_category_id'] != 0){
        					$sub_id_flag = 1;
        				}
						?>
							<div class="item post-overaly-style post-md" style="background-image:url(<?php echo $show_image; ?>)">
								<a href="#" class="image-link" onclick="view_list('<?php echo $all_categories_data[$key]['category_id']; ?>', 'news', '<?php echo $sub_id_flag; ?>')">&nbsp;</a>
								<div class="overlay-post-content">
									<div class="post-content">
										<div class="grid-category">
											<a class="post-cat" href="#"><?php if($website_language == '0') { echo $all_categories_data[$key]['category_hindi_name']; } else { echo $all_categories_data[$key]['category_name']; } ?></a>
										</div>
										<h2 class="post-title">
											<a href="#" onclick="view_list('<?php echo $all_categories_data[$key]['category_id']; ?>', 'news', '<?php echo $sub_id_flag; ?>')"><?php if($website_language == '0') { echo (strlen($all_categories_data[$key]['hindi_name']) > 50) ? substr($all_categories_data[$key]['hindi_name'], 0, 30).' '."..." : $all_categories_data[$key]['hindi_name']; } else { echo (strlen($all_categories_data[$key]['name']) > 50) ? substr($all_categories_data[$key]['name'], 0, 30).' '."..." : $all_categories_data[$key]['name']; } ?></a>
										</h2>
										<div class="post-meta">
											<ul>
												<!-- <li><i class="fa fa-user"></i> &nbsp; <?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></li> -->
											</ul>
										</div>
									</div>
								</div>
							</div>
						<?php
						}
					?>
				</div>
			</div>
		</div>
	</section>
	<section class="block-wrapper pb-lg-0">
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-8 col-md-12">
					<div class="block">
						<h2 class="block-title">
							<span class="title-angle-shap"> <?php if($website_language == '0') { echo "लोकप्रिय"; } else { echo "Popular"; } ?></span>
						</h2>
						<div class="row ts-gutter-30">
							<?php
								foreach ($popular as $key => $value)
								{
									$image_path = ASSET_URL."/assets/news/".''.$popular[$key]['image'];
                  $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
                  $show_image = isset($popular[$key]['image']) ? $image_path : $no_image_path;
									$video_thumb_img = isset($popular[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$popular[$key]['video_thumb_img'] : $no_image_path;

//print_r($popular);
									?>
									<div class="col-md-6 col-lg-4">
										<div class="post-block-style clearfix">
											<div class="post-thumb">
												<?php if(isset($popular[$key]['media_type']) && $popular[$key]['media_type'] == 'video') {
											 			?>
													<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="">
													<a class="popup cboxElement" href="<?php echo $show_image; ?>">
														<div class="video-icon">
															<i class="fa fa-play"></i>
														</div>
													</a>
											<?php } else { ?>			
												<a href="#" onclick="view_details('<?php echo $popular[$key]['id']; ?>', 'news')">
													<img class="img-fluid" src="<?php echo $show_image; ?>" alt="" />
												</a>
											<?php } ?>
												<div class="grid-cat">
													<a class="post-cat" href="#" onclick="view_details('<?php echo $popular[$key]['id']; ?>', 'news')"><?php if($website_language == '0') { echo $popular[$key]['category_hindi_name']; } else { echo $popular[$key]['category_name']; } ?></a>
												</div>
											</div>		
											<div class="post-content">
												<h2 class="post-title title-md">
													<a href="#" onclick="view_details('<?php echo $popular[$key]['id']; ?>', 'news')"><?php if($website_language == '0') { echo (strlen($popular[$key]['hindi_name']) > 50) ? substr($popular[$key]['hindi_name'], 0, 35).' '."..." : $popular[$key]['hindi_name']; } else { echo (strlen($popular[$key]['name']) > 50) ? substr($popular[$key]['name'], 0, 35).' '."..." : $popular[$key]['name']; } ?></a>
												</h2>
												<div class="post-meta mb-7">
													<!-- <span class="post-author"><a href="#"><i class="fa fa-user"></i>&nbsp; <?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></a></span> -->
													<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($popular[$key]['created']) && !empty($popular[$key]['created']) ? date('d F, Y', strtotime($popular[$key]['created'])) : ''; ?>
												</div>
												<!-- <p>The market won’t stop actress and singer....</p> -->
											</div>
										</div>
									</div>
									<?php
								}
							?>
						</div>
					</div>

					<div class="gap-20"></div>

					<div class="block">
						<div class="gap-30"></div>
						<div class="row">
							<?php
								foreach ($all_data as $key => $value)
								{
									$image_path = ASSET_URL."/assets/news/".''.$all_data[$key]['image'];
                  $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
                  $show_image = isset($all_data[$key]['image']) ? $image_path : $no_image_path;
                  $video_thumb_img = isset($all_data[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$all_data[$key]['video_thumb_img'] : $no_image_path;
                 if(isset($all_data[$key]['sub_category_data']) && !empty($all_data[$key]['sub_category_data']))
                 {
								?>
									<div class="col-md-6">
										<h2 class="block-title block-title-tech">
											<span class="title-angle-shap"> <?php if($website_language == '0') { echo $all_data[$key]['category_hindi_name']; } else { echo $all_data[$key]['category_name']; } ?> </span>
										</h2>
										<div class="list-post-block">
											<ul class="list-post">
												<li>
													<div class="post-block-style clearfix">
														<div class="post-thumb" id="post-thumb_new">
															<?php if(isset($all_data[$key]['media_type']) && $all_data[$key]['media_type'] == 'video') {
															 			?>
																	<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="" style="height: -webkit-fill-available;">
																	<a class="popup cboxElement" href="<?php echo $show_image; ?>">
																		<div class="video-icon">
																			<i class="fa fa-play"></i>
																		</div>
																	</a>
															<?php } else { ?>
															<a href="#" onclick="view_details('<?php echo $all_data[$key]['id']; ?>', 'news')">
																<img class="img-fluid" src="<?php echo $show_image; ?>" alt="" />
															</a>
														<?php } ?>
															<div class="grid-cat">
																<a class="post-cat" href="#"><?php if($website_language == '0') { echo $all_data[$key]['category_hindi_name']; } else { echo $all_data[$key]['category_name']; } ?></a>
															</div>
														</div>														
														<div class="post-content">
															<h2 class="post-title title-md">
																<a href="#" onclick="view_details('<?php echo $all_data[$key]['id']; ?>', 'news')"><?php if($website_language == '0') { echo (strlen($all_data[$key]['hindi_name']) > 150) ? substr($all_data[$key]['hindi_name'], 0, 120).' '."..." : $all_data[$key]['hindi_name']; } else { echo (strlen($all_data[$key]['name']) > 150) ? substr($all_data[$key]['name'], 0, 120).' '."..." : $all_data[$key]['name']; } ?></a>
															</h2>
															<div class="post-meta mb-7">
																<!-- <span class="post-author"><a href="#"><i class="fa fa-user"></i> &nbsp; <?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></a></span> -->
																<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($popular[$key]['created']) && !empty($popular[$key]['created']) ? date('d F, Y', strtotime($popular[$key]['created'])) : ''; ?></span>
															</div>
														</div>
													</div>
												</li>
												<?php
													foreach($all_data[$key]['sub_category_data'] as $sub_cat_key => $sub_cat_value)
													{
														if($sub_cat_key == '0' || $sub_cat_key == '1' || $sub_cat_key == '2')
														{
															$sub_category_image_path = ASSET_URL."/assets/news/".''.$all_data[$key]['sub_category_data'][$sub_cat_key]['image'];
															$sub_category_no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
															$sub_category_show_image = isset($all_data[$key]['sub_category_data'][$sub_cat_key]['image']) ? $sub_category_image_path : $sub_category_no_image_path;
															$video_thumb_img = isset($all_data[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$all_data[$key]['video_thumb_img'] : $no_image_path;

														?>
														<li>
															<div class="post-block-style media">
																<div class="post-thumb">
																	<?php if(isset($all_data[$key]['media_type']) && $all_data[$key]['media_type'] == 'video') {
															 			?>
																	<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="" style="height: -webkit-fill-available;">
																	<a class="popup cboxElement" href="<?php echo $sub_category_show_image; ?>">
																		<div class="video-icon">
																			<i class="fa fa-play"></i>
																		</div>
																	</a>
															<?php } else { ?>	
																	<a href="#" onclick="view_details('<?php echo $all_data[$key]['sub_category_data'][$sub_cat_key]['id']; ?>', 'news')">
																		<img class="img-fluid" src="<?php echo $sub_category_show_image; ?>" alt="">
																	</a>
																<?php } ?>
																</div>
																<div class="post-content media-body">
																	<h2 class="post-title">
																		<a href="#" onclick="view_details('<?php echo $all_data[$key]['sub_category_data'][$sub_cat_key]['id']; ?>', 'sub_category')"><?php if($website_language == '0') { echo (strlen($all_data[$key]['sub_category_data'][$sub_cat_key]['hindi_name']) > 50) ? substr($all_data[$key]['sub_category_data'][$sub_cat_key]['hindi_name'], 0, 40).' '."..." : $all_data[$key]['sub_category_data'][$sub_cat_key]['hindi_name']; } else { echo (strlen($all_data[$key]['sub_category_data'][$sub_cat_key]['name']) > 50) ? substr($all_data[$key]['sub_category_data'][$sub_cat_key]['name'], 0, 40).' '."..." : $all_data[$key]['sub_category_data'][$sub_cat_key]['name']; } ?></a>
																	</h2>
																	<div class="post-meta mb-7">
																		<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($all_data[$key]['sub_category_data'][$sub_cat_key]['created']) && !empty($all_data[$key]['sub_category_data'][$sub_cat_key]['created']) ? date('d F, Y', strtotime($all_data[$key]['sub_category_data'][$sub_cat_key]['created'])) : ''; ?></span>
																	</div>
																</div>
															</div>
														</li>
														<?php
														}
													}
												?>
											</ul>
										</div>
									</div>
								<?php
									}
								}
							?>
						</div>
					</div>	
				</div>
				<div class="col-lg-4">
					<div class="sidebar">
						<div class="sidebar-widget social-widget">
							<h2 class="block-title">
								<span class="title-angle-shap"> <?php if($website_language == '0') { echo "सामाजिक"; } else { echo "Social"; } ?></span>
							</h2>
							<div class="sidebar-social">
								<ul class="ts-social-list style2">
									<li class="ts-facebook">
										<a href="#">
											<i class="tsicon fa fa-facebook"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "फेसबुक"; } else { echo "Facebook"; } ?></b>
												<span><?php if($website_language == '0') { echo "पसंद"; } else { echo "Likes"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-twitter">
										<a href="#">
											<i class="tsicon fa fa-twitter"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "ट्विटर"; } else { echo "Twitter"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-youtube">
										<a href="#">
											<i class="tsicon fa fa-youtube-play"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "यूट्यूब"; } else { echo "Youtube"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-rss">
										<a href="#">
											<i class="tsicon fa fa-linkedin"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "लिंक्डइन"; } else { echo "Linkdin"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="post-block-style clearfix" style="padding-bottom: 25px;">
							<h2 class="block-title">
								<?php //echo $recent_happenings; ?>
								<span class="title-angle-shap"><?php if($website_language == '0') { echo "हाल ही में हुआ"; } else { echo "Recent Happenings"; } ?></span>
							</h2>
						</div>
						<?php
							foreach($recent_happenings as $key => $value)
                            {
                            	$image_path = ASSET_URL."/assets/news/".''.$recent_happenings[$key]['image'];
						        $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
						        $show_image = isset($recent_happenings[$key]['image']) ? $image_path : $no_image_path;
						        $video_thumb_img = isset($recent_happenings[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$recent_happenings[$key]['video_thumb_img'] : $no_image_path;
					
                            	?>
								<div class="post-block-style clearfix" style="padding-bottom: 25px;">
									<div class="post-thumb">
										<?php if(isset($recent_happenings[$key]['media_type']) && $recent_happenings[$key]['media_type'] == 'video') {
										 			?>
												<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="" >
												<a class="popup cboxElement" href="<?php echo $show_image; ?>">
													<div class="video-icon">
														<i class="fa fa-play"></i>
													</div>
												</a>
												<div class="grid-cat"><a class="post-cat" href="#"><?php if($website_language == '0') { echo $recent_happenings[$key]['category_hindi_name']; } else { echo $recent_happenings[$key]['category_name']; } ?></a></div>
										<?php } else { ?>							
										<a href="#" onclick="view_details('<?php echo $recent_happenings[$key]['id']; ?>', 'news')">
											<img class="img-fluid" src="<?php echo $show_image ;?>">
											<div class="grid-cat"><a class="post-cat" href="#"><?php if($website_language == '0') { echo $recent_happenings[$key]['category_hindi_name']; } else { echo $recent_happenings[$key]['category_name']; } ?></a></div>
										</a>
									<?php } ?>
									</div>
									<div class="post-content">
										<h2 class="post-title title-md">
											<a href="#" onclick="view_details('<?php echo $recent_happenings[$key]['id']; ?>', 'news')">
												<?php if($website_language == '0') { echo (strlen($recent_happenings[$key]['hindi_name']) > 50) ? substr($recent_happenings[$key]['hindi_name'], 0, 40).' '."..." : $recent_happenings[$key]['hindi_name']; } else { echo (strlen($recent_happenings[$key]['name']) > 50) ? substr($recent_happenings[$key]['name'], 0, 40).' '."..." : $recent_happenings[$key]['name']; } ?>
											</a>
										</h2>
										<div class="post-meta mb-7">
											<!-- <span class="post-author"><a href="#"><i class="fa fa-user"></i> &nbsp; <?php if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></a></span> -->
											<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($recent_happenings[$key]['created']) && !empty($recent_happenings[$key]['created']) ? date('d F, Y', strtotime($recent_happenings[$key]['created'])) : ''; ?></span>
										</div>
									</div>
								</div>
                            	<?php
                            }
                        ?>
						<div class="gap-10 d-none d-lg-block"></div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<div class="gap-50"></div>