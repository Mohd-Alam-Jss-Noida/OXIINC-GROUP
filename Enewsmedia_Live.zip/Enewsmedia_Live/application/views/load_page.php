<?php
	$this->load->view('header');
	$this->load->view('menu');
	$this->load->view($load_page);
	$this->load->view('footer');
?>