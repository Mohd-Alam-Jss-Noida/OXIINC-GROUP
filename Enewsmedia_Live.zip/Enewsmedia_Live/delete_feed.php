<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1');

function clean_up_files($dir1) {
  $list = array();
  // List of name of files inside 
  $files = glob($dir1.'/*');  
  // Deleting all the files in the list 
  foreach($files as $file) {     
      if(is_file($file))  {     
          // Delete the given file 
          $list[] = $file;
          unlink($file);  
      }
  }

  if(count($files) == count($list)){
    rmdir($dir1);
  }
  return $list;
}

// An example of how to use
for ($i=2; $i < 6; $i++) {
  $to = "amol.patil@oxiincgroup.com";
  $day = date('Y-m-d',strtotime("-$i days"));
  $dir = $_SERVER['DOCUMENT_ROOT']. "/data/".$day;
  //$dir = "/var/www/html/Oxiinc/enewsmedia/alpha/data/".$day;
  // Delete backups older than 5 days
  $deleted = clean_up_files($dir);
  $txt = count($deleted) . " Files deleted from " .$day. " directory:\n" .implode("\n", $deleted);
  //echo $txt;
  mail($to, "Backups cleanup", $txt);
}
?>