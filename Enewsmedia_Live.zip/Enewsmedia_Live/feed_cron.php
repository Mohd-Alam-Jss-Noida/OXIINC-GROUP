<?php
/*error_reporting(E_ALL);
ini_set('display_errors', '1');*/
/*if(1){
	$email_to = "rajesh@oxiincgroup.com,amol.patil@oxiincgroup.com";
	//$email_to = "amol.patil@oxiincgroup.com,amolpatil5424@gmail.com";
	$email_subject = "Cron On Enewsmedia started";
	$email_message = 'Cron On Enewsmedia started';
	$headers = "From: noreply@enewsmedia.in";
	@mail($email_to, $email_subject, $email_message, $headers);
}*/	
$feedArr = array('1061' => 'national', '1125' => 'international','11215' => 'bollywood', '1053' => 'sports','3379' => 'jeevan_mantra', '1051' => 'business','10711' => 'auto', '7911' => 'happy_life');
$dir = date("Y-m-d");
if( is_dir($dir) === false )
{
    mkdir($_SERVER['DOCUMENT_ROOT']."/data/".$dir);
}
$time_start = microtime(true);
foreach ($feedArr as $key => $value) {
	$rss_feed = simplexml_load_file("https://www.bhaskar.com/rss-feed/".$key."/");
	$domtree = new DOMDocument('1.0', 'UTF-8');
    /* create the root element of the xml tree */
    $node = $domtree->createElement("xml");
    $parnode = $domtree->appendChild($node);
    /* append it to the document created */
    header("Content-type: text/xml"); 
    if(!empty($rss_feed)) {
		$i=0;
		foreach ($rss_feed->channel->item as $feed_item) {
			//if($i>=2) break;	
			$imageArr = array_slice(explode(' ', $feed_item->description),0,7);
			$new_image = str_replace('"', '', str_replace('src="', '', $imageArr['6']));

			$desc = array_slice(explode(' ', $feed_item->description),8);
			$new_desc = strip_tags(implode(' ', str_replace('ltr">', '', str_replace('dir="', '', $desc))));
			
		  	$node = $domtree->createElement("item"); 
		  	$newnode = $parnode->appendChild($node);			  
		  	$newnode->setAttribute('pubDate', $feed_item->pubDate);
			$newnode->setAttribute('link', $feed_item->link);
			$newnode->setAttribute('title', $feed_item->title);
			$newnode->setAttribute('description', $new_desc);
			$newnode->setAttribute('image', $new_image);
			$i++;	
		}
		$domtree->formatOutput = TRUE;
		$temp = $domtree->save($_SERVER['DOCUMENT_ROOT']."/data/".$dir."/rss_feed_".$value."_".date("Ymd").".xml");
		$time_end = microtime(true); 
		$total_exec_time = round($time_end - $time_start , 4);

		if($temp){
			$msg = "Cron run succefully. It has taken ".$total_exec_time." Seconds to create xml of ".$value."\n";
			//echo $msg;
			$mail_temp = 1;
		}else{
			$msg = "No file saved for ".$value."\n";
			//echo $msg;
			$mail_temp = 1;
		}
		
	}else{
		$msg = "no feeds found for ".$value." on ". $dir;
		//echo "no feeds found for ".$value." on ". $dir;
	}
}	

if($mail_temp){
	$email_to = "rajesh@oxiincgroup.com,amol.patil@oxiincgroup.com";
	$email_subject = "Cron On Enewsmedia";
	$email_message = $msg;
	$headers = "From: noreply@enewsmedia.in";
	@mail($email_to, $email_subject, $email_message, $headers);
}	
?>