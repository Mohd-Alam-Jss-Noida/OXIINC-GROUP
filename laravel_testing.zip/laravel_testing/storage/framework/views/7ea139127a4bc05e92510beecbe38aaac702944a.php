<!DOCTYPE html>
<html>
<head>
	<title>This is Product List Page</title>
</head>
<body>
	<h2>This is Product List Page</h2>
</body>
</html><?php /**PATH /var/www/html/laravel_testing/resources/views/product_list.blade.php ENDPATH**/ ?>