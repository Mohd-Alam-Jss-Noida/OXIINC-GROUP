<!DOCTYPE html>
<html>
<head>
	<title>This is Profile Page</title>
</head>
<body>
	<h2>This is Profile Page:- <?php echo e($user); ?></h2>
</body>
</html><?php /**PATH /var/www/html/laravel_testing/resources/views/profile.blade.php ENDPATH**/ ?>