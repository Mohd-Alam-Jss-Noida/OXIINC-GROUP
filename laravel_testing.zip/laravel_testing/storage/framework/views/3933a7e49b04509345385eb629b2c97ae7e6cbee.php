<div>
	<h1>This is header Components.</h1>
</div><?php /**PATH /var/www/html/laravel_testing/resources/views/components/header.blade.php ENDPATH**/ ?>