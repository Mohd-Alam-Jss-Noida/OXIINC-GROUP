<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AboutController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('demo', function () {
    return view('demo');
});

Route::get("users", [UserController::class, "load_view"]);

Route::get("show/{name?}", [UserController::class, "user_show"]);

Route::get("user_list", [UserController::class, "user_list"]);

Route::view("product", "product_list");

Route::get("profile/{name?}", function($name = ''){
	return view("profile", ["user" => $name]);
});

Route::get("about", [AboutController::class, "about_us"]);