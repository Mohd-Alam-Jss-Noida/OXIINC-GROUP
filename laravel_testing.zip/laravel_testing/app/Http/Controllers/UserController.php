<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class UserController extends Controller
{
	public function load_view(){
		return view("user");
	}

	public function user_show($name = ''){
		return "This is my User Controller.<br> My Name is:- <b>$name</b>";
	}

	public function user_list(){
		$cars = array("Rajesh Sir", "Ashfak Khan", "Nilesh", "Dinesh", "Umair Khan");
		return view("user", ['car_name' => $cars]);
	}
}
