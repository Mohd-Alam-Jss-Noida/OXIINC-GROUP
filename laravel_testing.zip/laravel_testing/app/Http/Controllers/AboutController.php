<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller{

	public function about_us(){
		$emp_name = array('Rajesh Mishara', 'Asfak Khan', 'Suryabhan', 'MOHD ALAM', 'Zaitoon Shaikh');
		return view("about", ['emp_data' => $emp_name]);
	}
}
