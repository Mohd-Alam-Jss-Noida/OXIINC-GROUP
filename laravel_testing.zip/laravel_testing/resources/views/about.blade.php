<x-header />

<h4>This is about page.</h4>

<h4>{{ 10 * 20 }}</h4>

@for($i = 1; $i<=10; $i++)
<h4>{{ $i }}</h4>
@endfor

@foreach($emp_data as $data)
<h4>{{ $data }}</h4>
@endforeach