<!DOCTYPE html>
<html>
<head>
	<title>This is first demo laravel page</title>
</head>
<body>
	<h2>This is first demo laravel page.</h2>
	<h3>I am starting to learn larave.</h3>
</body>
</html>