<!DOCTYPE html>
<html>
<head>
	<title>This is Profile Page</title>
</head>
<body>
	<h2>This is Profile Page:- {{ $user }}</h2>
</body>
</html>