<x-header />
<?php
if(Request::is('users')){
	echo "This is load view page.";

} else if(Request::is('show')){
	echo "This is show page.";

} else if(Request::is('user_list')){
	echo "This is user list page.";
	echo "<pre>";print_r($car_name);
}
?>


	
