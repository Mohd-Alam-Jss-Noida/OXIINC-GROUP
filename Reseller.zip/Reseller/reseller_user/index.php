<!-- Start Container -->
<div class="main-wrapper">
	<!-- User-info-section-01 Start -->
	<section class="user-info-section-01 fwd">
		<div class="container-fluid">
			<!-- Flash Success and Error Message Code Start Here -->
			<div class="form-sucessmsg ajax_update_success_msg" style="display:none;"></div>
			<?php
	  		if($this->session->flashdata('msg')){
				$flash_array = $this->session->flashdata('msg'); ?>
				<div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
			<?php } ?>
			<!-- Flash Success and Error Message Code End Here -->
			<h3>You are almost ready to start selling!</h3>
			<?php if(empty($oxiinc_reseller[0]['store_name']) && empty($oxiinc_reseller[0]['store_description'])){ ?>
				<div class="update-info-col">
					<div class="update-info-content">
						<h4>Store Details</h4>
						<h5>Not Provided</h5> 
						<a class="update-btn" href="#UpdateStoreDetails">Update Now</a>
					</div>
				</div>
			<?php } ?>
			<?php if(empty($oxiinc_reseller[0]['signature_upload'])){ ?>
				<div class="update-info-col">
					<div class="update-info-content">
						<h4>Signature</h4>
						<h5>Not Provided</h5> 
						<a class="update-btn" href="#UpdateSignature">Update Now</a>
					</div>
				</div>
			<?php } ?>
			<?php if(empty($oxiinc_reseller_bank[0]['Bank_Cancelled_Cheque'])){ ?>
				<div class="update-info-col">
					<div class="update-info-content">
						<h4>Cancelled Cheque</h4>
						<h5>Not Provided</h5>
						<a class="update-btn" href="#UpdateCancelledCheque">Update Now</a>
					</div>
				</div>
			<?php } ?>
			<?php if(empty($oxiinc_reseller_bank[0]['Bank_Holder_Name']) && empty($oxiinc_reseller[0]['Bank_Account_Number']) && empty($oxiinc_reseller[0]['Bank_ifsc'])){ ?>
				<div class="update-info-col">
					<div class="update-info-content">
						<h4>Bank Details</h4>
						<h5>Not Provided</h5> <a class="update-btn" href="#UpdateBankDetails">Update Now</a>
					</div>
				</div>
			<?php } ?>
			<?php if(empty($reseller_company_details[0]['c_reseller_id'])){ ?>
				<div class="update-info-col">
					<div class="update-info-content">
						<h4>Company Details</h4>
						<h5>Not Provided</h5> <a class="update-btn" href="#UpdateCompanyDetails">Update Now</a>
					</div>
				</div>
			<?php } ?>
			<?php if(empty($director_details[0]['d_reseller_id'])){ ?>
				<div class="update-info-col">
					<div class="update-info-content">
						<h4>Director / Owner Details</h4>
						<h5>Not Provided</h5> <a class="update-btn" href="#UpdateDirectorDetails">Update Now</a>
					</div>
				</div>
			<?php } ?>
		</div>
	</section>
	<div class="clrfix"></div>
	<!-- Store Details Section -->
	<a name="UpdateStoreDetails" id="UpdateStoreDetails" class="section-slide"></a>
	<?php if(empty($oxiinc_reseller[0]['store_name']) && empty($oxiinc_reseller[0]['store_description'])){ ?>
		<section class="user-info-section-02 fwd">
			<div class="container">
				<h2 class="headding-01">Store Details</h2>
				<div class="form-content-block">
					<form class="form-block half-width">
						<p class="title-col">Your store details will be displayed to the buyers when they browse your products:</p>
						<div class="form-group">
							<label for="InputDisplayName">Enter Your Display Name <span class="mandatory-feild">*</span></label>
							<input type="text" class="textbox" name="store_name" id="store_name" value="<?php echo $oxiinc_reseller[0]['store_name'];?>" autocomplete="off" tabindex="1">
							<span class="bar"></span>
							<div id="store_name_error" class="input-erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="InputStoreLoaction">Enter Your Store Location <span class="mandatory-feild">*</span></label>
							<textarea class="textbox textarea" name="store_description" id="store_description" rows="3" autocomplete="off" tabindex="2" style="resize: none;"><?php echo $oxiinc_reseller[0]['store_description'];?></textarea>
							<span class="bar"></span>
							<div id="store_description_error" class="input-erroemsg" style="display:none;"></div>
						</div>
						<button type="button" class="submit-btn" tabindex="3" onclick="store_details_validation();">Save</button>
					</form>
				</div>
			</div>
		</section>
	<?php } ?>
	<div class="clrfix"></div>
	<a name="UpdateSignature" id="UpdateSignature" class="section-slide"></a>
	<a name="UpdateCancelledCheque" id="UpdateCancelledCheque" class="section-slide"></a>
	<section class="user-info-section-02 fwd">
		<div class="container">
			<?php
				if(empty($oxiinc_reseller[0]['signature_upload']) && empty($oxiinc_reseller_bank[0]['Bank_Cancelled_Cheque'])){
					$add_class = '';
				}
				else{
					$add_class = 'full-width-col';
				}
			?>
			<!-- Signature  Section -->
			<?php if(empty($oxiinc_reseller[0]['signature_upload'])){ ?>
				<div class="half-width-col fleft equal-height-col <?php echo $add_class;?>">
					<h2 class="headding-01">Signature</h2>
					<div class="form-content-block">
						<form class="form-block" method="POST" action="<?php echo site_url('Reseller_dashboard/signature_upload');?>" enctype="multipart/form-data" onsubmit="return upload_signature_validation();">
							<p class="title-col">Please read the instructions and upload your document by clicking below:  <span class="mandatory-feild">*</span></p>
							<div class="form-group">
								<input type="file" hidden="hidden" name="signature_upload" id="input_file_1" accept=".png, .jpg, .jpeg">
								<button type="button" id="upload_image_btn_1" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button> <span id="upload_image_text_1" class="upload-text">No file chosen, yet.</span>
								<div id="signature_upload_error" class="input-erroemsg" style="display:none;"></div>
							</div>
							<div class="form-group">
								<p class="title-col">Upload Instructions</p>
								<p> 1. Make sure that the document is visibly large and on a white background
									<br> 2. Allowed files png, jpg, jpeg etc.
									<br> 3. Maximum img size should not exceed 20MB
									<br> 4. Seal on the signature not a requirement. </p>
							</div>
							<div class="form-group no-margin">
								<p class="title-col">Signature Example: <img src="<?php echo base_url('reseller_user_assets/images/signature-eg.jpg');?>" alt="" class="eg-img-col" /></p>
							</div>
							<button type="submit" class="submit-btn" tabindex="3">Save</button>
						</form>
					</div>
				</div>
				<script type="text/javascript">
					const realFileBtn_1 = document.getElementById("input_file_1");
					const customBtn_1 = document.getElementById("upload_image_btn_1");
					const customTxt_1 = document.getElementById("upload_image_text_1");

					customBtn_1.addEventListener("click", function() {
					    realFileBtn_1.click();
					});

					realFileBtn_1.addEventListener("change", function() {
					    if (realFileBtn_1.value) {
					        customTxt_1.innerHTML = realFileBtn_1.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
					    } else {
					        customTxt_1.innerHTML = "No file chosen, yet.";
					    }
					});
				</script>
			<?php } ?>
			<!-- Cancelled Cheque Section -->
			<?php if(empty($oxiinc_reseller_bank[0]['Bank_Cancelled_Cheque'])){ ?>
				<div class="half-width-col frite equal-height-col xs-margin-01 <?php echo $add_class;?>">
					<h2 class="headding-01">Cancelled Cheque</h2>
					<div class="form-content-block">
						<form class="form-block">
							<p class="title-col">Please read the instructions and upload your document by clicking below:  <span class="mandatory-feild">*</span></p>
							<div class="form-group">
								<input type="file" hidden="hidden" name="Cancelled_Cheque_Img" id="input_file_2" accept=".png, .jpg, .jpeg">
								<button type="button" id="upload_image_btn_2" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button> <span id="upload_image_text_2" class="upload-text">No file chosen, yet.</span>
								<div id="cancelled_cheque_error" class="input-erroemsg" style="display:none;"></div>
							</div>
							<div class="form-group">
								<p class="title-col">Upload Instructions</p>
								<p> 1. Make sure that the document is visibly large and on a white background
									<br> 2. Allowed files png, jpg, jpeg etc.
									<br> 3. Maximum img size should not exceed 100KB.
									<br> &nbsp; </p>
							</div>
							<div class="form-group no-margin">
								<p class="title-col">Example: <img src="<?php echo base_url('reseller_user_assets/images/cancelled-cheque-eg.jpg');?>" alt="" class="eg-img-col" /></p>
							</div>
							<button type="button" class="submit-btn" tabindex="3" onclick="cancelled_cheque_validation();">Save</button>
						</form>
					</div>
				</div>
				<script type="text/javascript">
					const realFileBtn_2 = document.getElementById("input_file_2");
					const customBtn_2 = document.getElementById("upload_image_btn_2");
					const customTxt_2 = document.getElementById("upload_image_text_2");

					customBtn_2.addEventListener("click", function() {
					    realFileBtn_2.click();
					});

					realFileBtn_2.addEventListener("change", function() {
					    if (realFileBtn_2.value) {
					        customTxt_2.innerHTML = realFileBtn_2.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
					    } else {
					        customTxt_2.innerHTML = "No file chosen, yet.";
					    }
					});
				</script>
			<?php } ?>
		</div>
	</section>
	<div class="clrfix"></div>
	<a name="UpdateBankDetails" id="UpdateBankDetails" class="section-slide"></a>
	<!-- Bank Details Section -->
	<?php if(empty($oxiinc_reseller_bank[0]['Bank_Holder_Name']) && empty($oxiinc_reseller[0]['Bank_Account_Number']) && empty($oxiinc_reseller[0]['Bank_ifsc'])){ ?>
		<section class="user-info-section-02 fwd">
			<div class="container">
				<h2 class="headding-01">Bank Details</h2>
				<div class="form-content-block">
					<form class="form-block half-width fleft">
						<p class="title-col">This is where we will make your payments :</p>
						<div class="form-group">
							<label for="">Enter Account Holder’s Name <span class="mandatory-feild">*</span></label>
							<input type="text" class="textbox" name="Bank_Holder_Name" id="Bank_Holder_Name">
							<span class="bar"></span>
							<div id="bank_holder_name_error" class="input-erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Bank Account Number <span class="mandatory-feild">*</span></label>
							<input type="text" class="textbox" name="Bank_Account_Number" id="Bank_Account_Number">
							<span class="bar"></span>
							<div id="bank_account_number_error" class="input-erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="InputIFSC">Enter Your IFSC <span class="mandatory-feild">*</span></label>
							<input type="text" class="textbox ifsc-feild text-uppercase" name="Bank_ifsc" id="Bank_ifsc" maxlength="11">
							<button type="button" class="submit-btn IFSC-code-btn" onclick="verify_ifsc();">Check IFSC</button>
							<span class="bar"></span>
							<div id="ifsc_code_error" class="input-erroemsg" style="display:none;"></div>
							<div id="bank_name_error" class="input-erroemsg" style="display:none;"></div>
							<div id="ifsc_code_success" class="input-successmsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Your Bank Name</label>
							<input type="text" class="textbox" name="Bank_name" id="Bank_name" readonly="">
							<span class="bar"></span>
							<div id="" class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Your Bank Address</label>
							<input type="text" class="textbox" name="Bank_address" id="Bank_address" readonly="">
							<span class="bar"></span>
							<div id="" class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<button type="button" class="submit-btn" onclick="bank_details_validation();">Save</button>
					</form>
					<div class="form-block half-width frite xs-margin-01">
						<p class="title-col">Don't have a bank account in the name of your business?</p>
						<p>We can only transfer payments to accounts which are in the registered business name. Please open a new bank account with any bank in your registered business name</p>
						<br>
						<p class="title-col">Don't have a verification document?</p>
						<p>You can get a cheque book, or the statement of your account from your bank. If neither of these are available, you can also ask the bank to issue a letter with your account number, IFSC code and name mentioned on it.</p>
					</div>
				</div>
			</div>
		</section>
	<?php } ?>
	<div class="clrfix"></div>
	<!-- Company Details Section -->
	<a name="UpdateCompanyDetails" id="UpdateCompanyDetails" class="section-slide"></a>
	<?php if(empty($reseller_company_details[0]['c_reseller_id'])){ ?>
		<section class="user-info-section-02 fwd">
			<div class="container">
				<h2 class="headding-01">Company Details</h2>
				<div class="form-content-block">
					<form class="form-block">
						<div class="form-block half-width fleft">
							<div class="form-group">
								<label for="">Company Name <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_name" id="c_name" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company PAN No. <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox text-uppercase" name="c_pan_number" id="c_pan_number" maxlength="10" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company GST No.</label>
								<input type="text" class="textbox text-uppercase" name="c_gst_number" id="c_gst_number" maxlength="15" autocomplete="off">
								<span class="bar"></span>
								
							</div>
							<div class="form-group">
								<label for="">Company CIN No.</label>
								<input type="text" class="textbox text-uppercase" name="c_cin_number" id="c_cin_number" maxlength="21" autocomplete="off" tabindex="2">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company Establishment Reg. No.</label>
								<input type="text" class="textbox text-uppercase" name="c_r_number" id="c_r_number" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company Email <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_email" id="c_email" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company City <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_city" id="c_city" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company State <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_state" id="c_state" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company Mobile Number <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_mobile_number" id="c_mobile_number" maxlength="10" onkeypress="return isNumberKey(event);" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company Website</label>
								<input type="text" class="textbox ifsc-feild" name="website_link[]" id="website_link_1" autocomplete="off">
								<button type="button" class="submit-btn IFSC-code-btn" id="add_new_row">Add</button>
								<span class="bar"></span>
							</div>
							<div id="website_link_body"></div>
						</div>
						<div class="form-block half-width frite">
							<div class="form-group">
								<label for="">Company Type <span class="mandatory-feild">*</span></label>
								<select class="textbox input-selectbox" name="c_type" id="c_type" autocomplete="off" tabindex="1">
	                                <option value="">Select Company Type</option>
	                                <option value="public">Public Limited</option>
	                                <option value="private">Private Limited</option>
	                                <option value="partnership">Partnership</option>
	                                <option value="proprietorship">Proprietorship</option>
	                                <option value="llp">Limited Liability Parterneship (LLP)</option>
	                            </select>
							</div>
							<div class="form-group">
								<label for="">Company PAN Certificate  <span class="mandatory-feild">*</span></label>
								<input type="file" hidden="hidden" name="c_pan_number_img" id="input_file_5" accept=".png, .jpg, .jpeg, .pdf">
								<button type="button" id="upload_image_btn_5" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="upload_image_text_5" class="upload-text">No file chosen, yet.</span>
							</div>
							<div class="form-group">
								<label for="">Company GST Certificate</label>
								<input type="file" hidden="hidden" name="c_gst_img" id="input_file_6" accept=".png, .jpg, .jpeg, .pdf">
								<button type="button" id="upload_image_btn_6" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="upload_image_text_6" class="upload-text">No file chosen, yet.</span>
								
							</div>
							<div class="form-group">
								<label for="">Company CIN Certificate</label>
								<input type="file" hidden="hidden" name="c_cin_number_img" id="input_file_3" accept=".png, .jpg, .jpeg, .pdf">
								<button type="button" id="upload_image_btn_3" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="upload_image_text_3" class="upload-text">No file chosen, yet.</span>
							</div>
							<div class="form-group">
								<label for="">Company Establishment Reg No Certificate</label>
								<input type="file" hidden="hidden" name="c_r_number_img" id="input_file_4" accept=".png, .jpg, .jpeg, .pdf">
								<button type="button" id="upload_image_btn_4" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="upload_image_text_4" class="upload-text">No file chosen, yet.</span>
							</div>
							<div class="form-group">
								<label for="">Company Address <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_address" id="c_address" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company District <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_district" id="c_district" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company Pincode <span class="mandatory-feild">*</span></label>
								<input type="text" class="textbox" name="c_pincode" id="c_pincode" maxlength="6" onkeypress="return isNumberKey(event);" autocomplete="off">
								<span class="bar"></span>
							</div>
							<div class="form-group">
								<label for="">Company Telephone Number</label>
								<input type="text" class="textbox" name="c_telephone" id="c_telephone" maxlength="11" onkeypress="return isNumberKey(event);" autocomplete="off">
								<span class="bar"></span>
							</div>
						</div>
						<div class="form-group text-center">
							<button type="button" class="submit-btn" onclick="company_details();">Save</button>
							<div class="form-errormsg company_error_msg" style="display:none;"></div>
						</div>
					</form>
				</div>
			</div>
		</section>
		<script type="text/javascript">
			//File Upload Button
		    for (var i = 3; i <= 6; i++){
		        const c_realFileBtn = document.getElementById("input_file_" + i);
		        const c_customBtn = document.getElementById("upload_image_btn_" + i);
		        const c_customTxt = document.getElementById("upload_image_text_" + i);

		        c_customBtn.addEventListener("click", function() {
		            c_realFileBtn.click();
		        });

		        c_realFileBtn.addEventListener("change", function() {
		            if (c_realFileBtn.value) {
		                c_customTxt.innerHTML = c_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
		            } else {
		                c_customTxt.innerHTML = "No file chosen, yet.";
		            }
		        });
		    }
		</script>
	<?php } ?>
	<div class="clrfix"></div>
	<!-- Director / Owner Details Section -->
	<a name="UpdateDirectorDetails" id="UpdateDirectorDetails" class="section-slide"></a>
	<?php if(empty($director_details[0]['d_reseller_id'])){ ?>
		<section class="user-info-section-02 fwd">
			<div class="container">
				<h2 class="headding-01">Director / Owner Details</h2>
				<div class="form-content-block">
					<form class="form-block" method="post" action="<?php echo base_url('Reseller_dashboard/director_details_insert'); ?>" enctype="multipart/form-data" onsubmit="return director_validation();">
						<div class="fwd">
							<div class="form-block half-width fleft">
								<div class="form-group">
									<label for="">Director Name <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox" name="name[]" id="" autocomplete="off" required>
									<span class="bar"></span>
								</div>
								<div class="form-group">
									<label for="">Director PAN No. <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox text-uppercase" name="pan_no[]" id="" maxlength="10" autocomplete="off" required>
									<span class="bar"></span>
								</div>
								<div class="form-group">
									<label for="">Director Aadhar No. </label>
									<input type="text" class="textbox" name="Aadhar[]" id="" maxlength="12" onkeypress="return isNumberKey(event);" autocomplete="off">
									<span class="bar"></span>
								</div>
								<div class="form-group">
									<label for="">Director Email <span class="mandatory-feild">*</span></label>
									<input type="email" class="textbox" name="email[]" id="" autocomplete="off" required>
									<span class="bar"></span>
								</div>
							</div>
							<div class="form-block half-width frite">
								<div class="form-group">
									<label for="">Director Mobile No. <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox" name="Mobile[]" id="" maxlength="10" onkeypress="return isNumberKey(event);" autocomplete="off" required>
									<span class="bar"></span>
								</div>
								<div class="form-group">
									<label for="">Director PAN Certificate <span class="mandatory-feild">*</span></label>
									<input type="file" hidden="hidden" name="pan_card_img[]" id="input_file_7" accept=".png, .jpg, .jpeg">
									<button type="button" id="upload_image_btn_7" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button><span id="upload_image_text_7" class="upload-text">No file chosen, yet.</span>
									<div id="d_pan_card_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director Aadhar Certificate</label>
									<input type="file" hidden="hidden" name="adhar_card_img[]" id="input_file_8" accept=".png, .jpg, .jpeg">
									<button type="button" id="upload_image_btn_8" class="cust-channel-btn upload-btn" required><i class="fa fa-upload"></i> Upload</button> <span id="upload_image_text_8" class="upload-text">No file chosen, yet.</span>
									<div id="d_aadhar_card_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director Address <span class="mandatory-feild">*</span></label>
									<textarea class="textbox textarea" name="d_address[]" id="" rows="3" required></textarea>
									<span class="bar"></span>
								</div>
							</div>
						</div>
						<div id="add_director_structure"></div>
						<div class="form-group owners-details">
							<button type="button" class="submit-btn IFSC-code-btn" id="add_new_row_1">Add</button>
						</div>
						<div class="form-group text-center">
							<button type="submit" class="submit-btn">Save</button>
						</div>
					</form>
				</div>
			</div>
		</section>
		<script type="text/javascript">
			//File Upload Button
		    for (var i = 7; i <= 8; i++){
		        const d_realFileBtn = document.getElementById("input_file_" + i);
		        const d_customBtn = document.getElementById("upload_image_btn_" + i);
		        const d_customTxt = document.getElementById("upload_image_text_" + i);

		        d_customBtn.addEventListener("click", function() {
		            d_realFileBtn.click();
		        });

		        d_realFileBtn.addEventListener("change", function() {
		            if (d_realFileBtn.value) {
		                d_customTxt.innerHTML = d_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
		            } else {
		                d_customTxt.innerHTML = "No file chosen, yet.";
		            }
		        });
		    }
		</script>
	<?php } ?>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	function store_details_validation(){
        var rtn = true;
        var store_name = $("#store_name").val();
        var store_description = $("#store_description").val();
        if(store_description == ""){
            $("#store_description_error").css({"display": "block"}).text('Please Enter Your Store Location.');
            $("#store_description").focus();
            rtn = false;
        }
        else {
            $("#store_description_error").css({"display": "none"}).text('');
        }
        if(store_name == ""){
            $("#store_name_error").css({"display": "block"}).text('Please Enter Your Store Display Name.');
            $("#store_name").focus();
            rtn = false;
        }
        else {
            $("#store_name_error").css({"display": "none"}).text('');
        }
        if (rtn == true){
            $.ajax({
                url: "<?php echo base_url('Reseller_dashboard/update_store_information');?>",
                type: "POST",
                data: 'store_name=' + store_name + '&store_description=' + store_description,
                dataType: "text",
                success: function(data){
                	//alert(data);
                	$('html, body').animate({scrollTop: '0px'}, 1000);
                    $(".ajax_update_success_msg").css({"display": "block"}).text("Store details updated successfully.");
                    setTimeout(function() {
                        location.reload();
                    }, 5000);
                }
            });
        }
        else{
            return false;
        }
    }

    function upload_signature_validation(){
    	var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var uploadFile = document.getElementById("input_file_1").files[0];
	    var file_path = $("#input_file_1").val();
        if(file_path == ""){
        	/*Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Please Upload Signature.'
			})*/
            $("#signature_upload_error").css({"display": "block"}).text('Please Upload Signature.');
            return false;
        }
        else if ($.inArray(uploadFile.type.toLowerCase(), validImageTypes) < 0){
			/*Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Please select correct image formate, e.g. - png, jpg, jpeg.'
			})*/
            $("#signature_upload_error").css({"display": "block"}).text("Please select correct image formate, e.g. - png, jpg, jpeg.");
            return false;
        } 
        else {
            $("#signature_upload_error").css({"display": "none"}).text('');
            return true;
        }
    }

    function cancelled_cheque_validation(){
    	var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var uploadFile = document.getElementById("input_file_2").files[0];
	    var file_path = $("#input_file_2").val();
        if(file_path == ""){
        	/*Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Please Upload Cancelled Cheque.'
			})*/
            $("#cancelled_cheque_error").css({"display": "block"}).text('Please Upload Cancelled Cheque Image.');
            return false;
        }
        else if ($.inArray(uploadFile.type.toLowerCase(), validImageTypes) < 0){
			/*Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Please select correct image formate, e.g. - png, jpg, jpeg.'
			})*/
            $("#cancelled_cheque_error").css({"display": "block"}).text("Please select correct image formate, e.g. - png, jpg, jpeg.");
            return false;
        } 
        else {
            var form_data = new FormData();
			form_data.append("Cancelled_Cheque_Img", document.getElementById('input_file_2').files[0]);
			$.ajax({
				type:'POST',
				url:"<?php echo base_url('Reseller_dashboard/update_bank_information'); ?>",
				data: form_data,
				contentType: false,
				cache: false,
				processData: false,
				success:function(data){
					var obj = JSON.parse(data);
					//alert(obj.status);
					//alert(obj.message);
					if(obj.status == 'error'){
						$("#cancelled_cheque_error").css({"display": "block"}).text(obj.message);
					}
					if(obj.status == 'success'){
						$('html, body').animate({scrollTop: '0px'}, 1000);
						$("#cancelled_cheque_error").css({"display": "none"}).text('');
						$(".ajax_update_success_msg").css({"display": "block"}).text(obj.message);
						setTimeout(function (){
							location.reload();
						}, 5000);
					}
				}
			});
        }
    }

	function verify_ifsc() {
		var ifsc = $("#Bank_ifsc").val();
		if (ifsc == ""){
			$("#ifsc_code_success").css({"display": "none"}).text('');
			document.getElementById('Bank_name').value = '';
			document.getElementById('Bank_address').value = '';
			$("#ifsc_code_error").css({"display": "block"}).text('Please Enter Bank IFSC Code.');
            $("#Bank_ifsc").focus();
            return false;
		}
		else{
			$.ajax({
				type: "POST",
				url: "<?php echo base_url('Reseller_dashboard/verify_ifsc_code'); ?>",
				data: 'ifsc_code=' + ifsc,
				success:function(data){
					var obj = JSON.parse(data);
					//alert(obj.status);
					if(obj.status == 'error'){
						$("#ifsc_code_success").css({"display": "none"}).text('');
						document.getElementById('Bank_name').value = '';
						document.getElementById('Bank_address').value = '';
						$("#ifsc_code_error").css({"display": "block"}).text(obj.message);
					}
					if(obj.status == 'success'){
						$("#ifsc_code_error").css({"display": "none"}).text('');
						$("#ifsc_code_success").css({"display": "block"}).text(obj.message);
						document.getElementById('Bank_name').value = obj.BANK;
						document.getElementById('Bank_address').value = obj.ADDRESS;
					}
				}
			});
		}
	}

	function bank_details_validation(){
        var rtn = true;
        var Bank_Holder_Name = $("#Bank_Holder_Name").val();
        var Bank_Account_Number = $("#Bank_Account_Number").val();
        var Bank_ifsc = $("#Bank_ifsc").val();
        var Bank_name = $("#Bank_name").val();
        var Bank_address = $("#Bank_address").val();

        if(Bank_ifsc == ""){
        	$("#ifsc_code_success").css({"display": "none"}).text('');
        	document.getElementById('Bank_name').value = '';
			document.getElementById('Bank_address').value = '';
            $("#ifsc_code_error").css({"display": "block"}).text('Please Enter Bank IFSC Code.');
            $("#Bank_ifsc").focus();
            rtn = false;
        } else if(Bank_address == ""){
        	$("#ifsc_code_success").css({"display": "none"}).text('');
            $("#ifsc_code_error").css({"display": "block"}).text('Please Enter Valid Bank IFSC Code and Click on Check IFSC button.');
            $("#Bank_ifsc").focus();
            rtn = false;
        } else if(Bank_name == ""){
        	$("#ifsc_code_success").css({"display": "none"}).text('');
            $("#ifsc_code_error").css({"display": "block"}).text('Please Enter Valid Bank IFSC Code and Click on Check IFSC button.');
            $("#Bank_ifsc").focus();
            rtn = false;
        }
        else {
            $("#ifsc_code_error").css({"display": "none"}).text('');
        }

        if(Bank_Account_Number == ""){
            $("#bank_account_number_error").css({"display": "block"}).text('Please Enter Bank Account Number.');
            $("#Bank_Account_Number").focus();
            rtn = false;
        }
        else {
            $("#bank_account_number_error").css({"display": "none"}).text('');
        }

        if(Bank_Holder_Name == ""){
            $("#bank_holder_name_error").css({"display": "block"}).text('Please Enter Bank Holder Name.');
            $("#Bank_Holder_Name").focus();
            rtn = false;
        }
        else {
            $("#bank_holder_name_error").css({"display": "none"}).text('');
        }

        if (rtn == true){
            $.ajax({
                url: "<?php echo base_url('Reseller_dashboard/update_bank_information_data');?>",
                type: "POST",
                data: 'Bank_Holder_Name=' + Bank_Holder_Name + '&Bank_Account_Number=' + Bank_Account_Number + '&Bank_ifsc=' + Bank_ifsc + '&Bank_name=' + Bank_name + '&Bank_address=' + Bank_address,
                dataType: "text",
                success:function(data){
                    var obj = JSON.parse(data);
                    //alert(obj.status);
                    //alert(obj.message);
                    if(obj.status == 'error'){
                    	$("#bank_account_number_error").css({"display": "block"}).text(obj.message);
                    }
                    if(obj.status == 'success'){
                    	$('html, body').animate({scrollTop: '0px'}, 1000);
                    	//window.scrollTo(0, 0);
                    	$("#bank_account_number_error").css({"display": "none"}).text('');
                    	$(".ajax_update_success_msg").css({"display": "block"}).text(obj.message);
	                    setTimeout(function (){
	                    	location.reload();
	                	}, 5000);
                	}
                }
            });
        }
        else{
            return false;
        }
    }

    $(document).ready(function (){
		var row=1;
		$(document).on("click", "#add_new_row", function (){
			var new_row = '<div class="form-group"><label for="">Company Website</label><input type="text" class="textbox ifsc-feild" name="website_link[]" id="website_link_1" autocomplete="off"><button type="button" class="delete_row submit-btn IFSC-code-btn">Delete</button></div>';
			$('#website_link_body').append(new_row);
			row++;
			return false;
		});

		$(document).on("click", ".delete_row", function (){
			if(row > 1) {
				$(this).closest('.form-group').remove();
				row--;
			}
			return false;
		});
	});

	function company_details(){
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
		var panVal = $('#c_pan_number').val();

		if (!$('#c_name').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the company name.");
		} else if(!$('#c_type').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please select the company type.");
		} else if(!$('#c_pan_number').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the PAN card number.");
		} else if(!regpan.test(panVal)){
			$(".company_error_msg").css({"display": "block"}).text("Please enter the valid PAN card number.");
		} else if (!$('#input_file_5').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please upload the PAN card Copy.");  
		} else if(!$('#c_email').val()){
			$(".company_error_msg").css({"display": "block"}).text("Please enter the company email id.");
		} else if(!filter.test($('#c_email').val())){
			$(".company_error_msg").css({"display": "block"}).text("Please enter the valid company email id.");
		} else if (!$('#c_address').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the company address.");
		} else if (!$('#c_city').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the city.");
		} else if (!$('#c_district').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the district.");
		} else if (!$('#c_state').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the state.");
		} else if ($('#c_pincode').val() == "") {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the pincode.");
		} else if ($('#c_pincode').val().length < 6 || $('#c_pincode').val().length > 6) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the 6 digits valid pincode.");
		} else if (!$('#c_mobile_number').val()) {
			$(".company_error_msg").css({"display": "block"}).text("Please enter the mobile number.");
		} else if ($('#c_mobile_number').val().length < 10 || $('#c_mobile_number').val().length > 10){
			$(".company_error_msg").css({"display": "block"}).text("Please enter the 10 digits valid mobile number.");
		} else{
			$(".company_error_msg").css({"display": "none"}).text(" ");
			var form_data = new FormData();
			form_data.append("c_cin_number_img", document.getElementById('input_file_3').files[0]);
			form_data.append("c_r_number_img", document.getElementById('input_file_4').files[0]);
			form_data.append("c_pan_number_img", document.getElementById('input_file_5').files[0]);
			form_data.append("c_gst_img", document.getElementById('input_file_6').files[0]);
			form_data.append("c_type", $('#c_type').val());
			form_data.append("c_name", $('#c_name').val());
			form_data.append("c_cin_number", $('#c_cin_number').val());
			form_data.append("c_r_number", $('#c_r_number').val());
			form_data.append("c_email", $('#c_email').val());
			form_data.append("c_gst_number", $('#c_gst_number').val());
			form_data.append("c_pan_number", $('#c_pan_number').val());
			form_data.append("c_address", $('#c_address').val());
			form_data.append("c_city", $('#c_city').val());
			form_data.append("c_district", $('#c_district').val());
			form_data.append("c_state", $('#c_state').val());
			form_data.append("c_pincode", $('#c_pincode').val());
			form_data.append("c_mobile_number", $('#c_mobile_number').val());
			form_data.append("c_telephone", $('#c_telephone').val());
			form_data.append("c_website", $('input[name^=website_link]').map(function(idx, elem) {
				return $(elem).val();
			}).get());

			$.ajax({
				type:'POST',
				url:"<?php echo base_url('Reseller_dashboard/company_details'); ?>",
				data: form_data,
				contentType: false,
				cache: false,
				processData: false,
				success:function(data){
					var obj = JSON.parse(data);
					//alert(obj.status);
					//alert(obj.message);
					if(obj.status == 'error'){
						$(".company_error_msg").css({"display": "block"}).text(obj.message);
					}
					if(obj.status == 'success'){
						$('html, body').animate({scrollTop: '0px'}, 1000);
						$(".company_error_msg").css({"display": "none"}).text('');
						$(".ajax_update_success_msg").css({"display": "block"}).text(obj.message);
						setTimeout(function (){
							location.reload();
						}, 5000);
					}
				}
			});
		}
	}

	$(document).ready(function (){
		var row = 1;
		$(document).on("click", "#add_new_row_1", function (){
			if (row <= 4) {
				var new_row = '<div class="add_new_director fwd"><div class="form-block half-width fleft"><div class="form-group"><label for="">Your Name <span class="mandatory-feild">*</span></label><input type="text" class="textbox" name="name[]" id="" autocomplete="off" required><span class="bar"></span></div><div class="form-group"><label for="">PAN No <span class="mandatory-feild">*</span></label><input type="text" class="textbox text-uppercase" name="pan_no[]" id="" maxlength="10" autocomplete="off" required><span class="bar"></span></div><div class="form-group"><label for="">Aadhar No</label><input type="text" class="textbox" name="Aadhar[]" id="" maxlength="12" onkeypress="return isNumberKey(event);" autocomplete="off"><span class="bar"></span></div><div class="form-group"><label for="">Director Email <span class="mandatory-feild">*</span></label><input type="email" class="textbox" name="email[]" id="" autocomplete="off" required><span class="bar"></span></div><div class="form-group owners-details"><button type="button" class="delete_new_director submit-btn IFSC-code-btn">Remove</button></div></div><div class="form-block half-width frite"><div class="form-group"><label for="">Mobile No <span class="mandatory-feild">*</span></label><input type="text" class="textbox" name="Mobile[]" id="" maxlength="10" onkeypress="return isNumberKey(event);" autocomplete="off" required><span class="bar"></span></div><div class="form-group"><label for="">Pan Card Photo <span class="mandatory-feild">*</span></label><input type="file" hidden="hidden" name="pan_card_img[]" id="d1_input_file_'+row+'" accept=".png, .jpg, .jpeg"><button type="button" id="d1_upload_image_btn_'+row+'" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="d1_upload_image_text_'+row+'" class="upload-text">No file chosen, yet.</span></div><div class="form-group"><label for="">Aadhar Card Photo</label><input type="file" hidden="hidden" name="adhar_card_img[]" id="d2_input_file_'+row+'" accept=".png, .jpg, .jpeg"><button type="button" id="d2_upload_image_btn_'+row+'" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="d2_upload_image_text_'+row+'" class="upload-text">No file chosen, yet.</span></div><div class="form-group"><label for="">Director Address <span class="mandatory-feild">*</span></label><textarea class="textbox textarea" name="d_address[]" rows="3" autocomplete="off" required></textarea><span class="bar"></span></div></div></div>';

				$('#add_director_structure').append(new_row);

				//director details Pan Card Photo upload file button
				const d1_realFileBtn = document.getElementById("d1_input_file_" + row);
		        const d1_customBtn = document.getElementById("d1_upload_image_btn_" + row);
		        const d1_customTxt = document.getElementById("d1_upload_image_text_" + row);

		        d1_customBtn.addEventListener("click", function() {
		            d1_realFileBtn.click();
		        });

		        d1_realFileBtn.addEventListener("change", function() {
		            if (d1_realFileBtn.value) {
		                d1_customTxt.innerHTML = d1_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
		            }
		            else {
		                d1_customTxt.innerHTML = "No file chosen, yet.";
		            }
		        });

		        //director details Aadhar Card Photo upload file button
		        const d2_realFileBtn = document.getElementById("d2_input_file_" + row);
		        const d2_customBtn = document.getElementById("d2_upload_image_btn_" + row);
		        const d3_customTxt = document.getElementById("d2_upload_image_text_" + row);

		        d2_customBtn.addEventListener("click", function() {
		            d2_realFileBtn.click();
		        });

		        d2_realFileBtn.addEventListener("change", function() {
		            if (d2_realFileBtn.value) {
		                d3_customTxt.innerHTML = d2_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
		            }
		            else {
		                d3_customTxt.innerHTML = "No file chosen, yet.";
		            }
		        });

				row++;
				return false;
			}
			else{
                alert('You are Added Only Five Director / Owner Details.');
                return false;
            }
		});

		$(document).on("click", ".delete_new_director", function (){
			$(this).closest('.add_new_director').remove();
			return false;
		});
	});

	function director_validation(){
        var rtn = true;
        var input_file_7 = $("#input_file_7").val();
        var input_file_8 = $("#input_file_8").val();
        if(input_file_7 == ""){
            $("#d_pan_card_error").css({"display": "block"}).text('Please Enter Your PAN Card Copy.');
            rtn = false;
        }
        else {
            $("#d_pan_card_error").css({"display": "none"}).text('');
        }
        /*if(input_file_8 == ""){
            $("#d_aadhar_card_error").css({"display": "block"}).text('Please Enter Your Aadhar Card Copy.');
            rtn = false;
        }
        else {
            $("#d_aadhar_card_error").css({"display": "none"}).text('');
        }*/
        if (rtn == true){
            return true;
        }
        else{
            return false;
        }
    }
</script>