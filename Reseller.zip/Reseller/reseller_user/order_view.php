<!-- Start Container -->
<div class="main-wrapper">
	<!-- Order Status Section-01 Start -->
	<section class="order-status-section-01 fwd">
		<div class="container-fluid">
			<h1 class="mainpage-headding">Order <span>Details View</span></h1>
			<div class="container">
				<div class="form-content-block order-view-col">
					<?php
						//echo "<pre>";print_r($order_view_details);die();
						if(isset($order_view_details) && !empty($order_view_details)){
	                    $value = $order_view_details[0];
	                	?>
						<form>
							<div class="form-group">
								<span class="text-item-left">Product Image :</span>
								<span class="text-item-right">
								<img src="<?php echo $value['Product_Picture'];?>" width="150px" class="product-img">
								</span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Product Name :</span>
								<span class="text-item-right"><?php echo $value['Product_Name'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Customer Name :</span>
								<span class="text-item-right"><?php echo $value['customer_name'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Customer Contact :</span>
								<span class="text-item-right"><?php echo $value['mobile'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Product MRP :</span>
								<span class="text-item-right"><?php echo $value['Original_Prices'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Selling Price :</span>
								<span class="text-item-right"><?php echo $value['Prices'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Rate of GST :</span>
								<span class="text-item-right"><?php echo round(($value['gst_price'] * 100) / $value['Prices']);?>%</span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Total GST :</span>
								<span class="text-item-right"><?php echo $total_gst = round($value['gst_price']);?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Shipping Charges :</span>
								<span class="text-item-right"><?php echo $value['Shipping_Charges'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Grand Total Price :</span>
								<span class="text-item-right"><b>Rs. <?php echo round($total_gst + $value['Shipping_Charges'] + $value['Prices']);?>.00</b></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Transaction Id :</span>
								<span class="text-item-right"><?php echo $value['transaction_id'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Product Qty :</span>
								<span class="text-item-right"><?php echo $value['product_qty'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Product Size :</span>
								<span class="text-item-right"><?php echo $value['size'];?></span>
							</div>
							<div class="form-group">
								<span class="text-item-left">Purchased On :</span>
								<span class="text-item-right"><?php echo date("d-m-Y H:s:i", strtotime($value['order_date']));?></span>
							</div>
							<div class="form-group text-center">
								<a href="<?php echo site_url('Reseller_dashboard/reseller_order_invoice/'.$value['order_id'].'/'.$value['user_role']);?>" target="_blank"><button type="button" class="btn-style-01">Print Invoice</button></a>
							</div>
							<div class="clrfix"></div>
						</form>
						<?php
                    }
                    else{ ?>
                        <h2 style="color: #f20505; text-align: center;">Order details view not found.</h2>
                        <?php
                    }
                    ?>
				</div>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->