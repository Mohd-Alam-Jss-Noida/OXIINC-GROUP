<!-- Start Container -->
<div class="main-wrapper">
	<!-- Package Material Section -->
	<section class="order-status-section-01 package-material-section-01 fwd">
		<div class="container-fluid">
			<h1 class="mainpage-headding">Order <span>Package Material</span></h1>
			<div class="form-errormsg text-center" id="package_material_error_msg" style="display:none;"></div>
			<!-- <form class="form-block"> -->
			<form class="form-block" action="<?php echo base_url('Reseller_dashboard/add_packing_material_bank_deposit_statement'); ?>" onsubmit="return package_material_validation()" method="post" accept-charset="utf-8" enctype="multipart/form-data">
				<div class="package-material-container form-content-block">
					<h3 class="headding-02 text-center">Note - Minimum Packing Material order to be placed - 100 pcs of Courier Bags and 12 pcs of Cello Tape.</h3>
					<div class="form-block tbl-responsive">
						<table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
							<thead>
								<tr>
									<th>Product Name</th>
									<th>Quanity</th>
									<th>Price Per Unit</th>
									<th>Total Price</th>
									<th>Cancel</th>
								</tr>
							</thead>
							<tbody id="TextBoxContainer">
								<tr>
									<td>
										<div class="form-group">
											<select name="product_name[]" class="textbox input-selectbox" data-select="1" onchange="getvalue(1)" id="taskStatus1" required>
												<option value="">Select the material</option>
	                                            <?php foreach($packing_material as $value){ ?>
	                                                <option value="<?php echo $value['id']; ?>" data-product_price="<?php echo $value['product_price'] ?>" data-product_flag="<?php echo $value['product_flag']; ?>"><?php echo $value['product_name'] ?></option>
	                                            <?php } ?>
											</select>
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input name="product_qty[]" type="number" value="1" min="1" id="qty1" onchange="qty(1)" class="textbox" required>
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input name="product_price[]" type="text" value="" class="textbox" id="1" onchange="qty(1)" required readonly>
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input name="product_price_total[]" type="text" value="" class="textbox qty1" id="total1" required readonly>
											<span class="bar"></span>
										</div>
									</td>
								</tr>
							</tbody>
							<tfoot>
								<tr>
									<th colspan="5">
										<div class="form-group">
											<button type="button" id="btnAdd" class="submit-btn"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button>
										</div>
									</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
				<div class="package-material-container form-content-block">
					<h3 class="headding-02">Digital Bank Details</h3>
					<div class="tbl-responsive">
						<table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
							<thead>
								<tr>
									<th>Name</th>
									<th>Bank Name</th>
									<th>Account No</th>
									<th>IFSC Code</th>
									<th>Address</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>EROCKETMALL ONLINE ASIA LIMITED</td>
									<td>HDFC BANK LTD</td>
									<td>50200038864387</td>
									<td>HDFC0009358</td>
									<td>HDFC BANK LTD, GROUND FLOOR OPUS CENTER 47 MIDC, OPP TUNGA HOTEL, ANDHERI EAST MUMBAI MAHARASHTRA 400093.</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div class="package-material-container form-content-block">
					<div class="form-block half-width fleft">
						<div class="form-group">
							<label for="">Payable Amount</label>
                            <input type="text" class="textbox" name="amount" id="amount" onkeypress="return isNumberKey(event)" readonly autocomplete="off" required>
							<span class="bar"></span>
							<input type="hidden" class="textbox" id="total_tape" value="0" readonly required>
                            <input type="hidden" class="textbox" id="total_bag" value="0" readonly required>
						</div>
						<div class="form-group">
							<label for="">Payment Mode</label>
							<select class="textbox input-selectbox" name="payment_mode" id="payment_mode" autocomplete="off" required>
								<option value="">Select Payment Mode</option>
								<option value="NEFT">NEFT</option>
                                <option value="RTGS" >RTGS</option>
                                <option value="RTGS">IMPS</option>
                                <option value="UPI">UPI</option>
							</select>
							<span class="bar"></span>
						</div>
						<div class="form-group">
							<label for="">Transcation Number</label>
							<input type="text" class="textbox" name="transcation_number" id="transcation_number" autocomplete="off" required>
							<span class="bar"></span>
						</div>
						<div class="form-group">
							<label for="">Payment Deposit Date</label>
							<div id="datepicker" class="input-group date" data-date-format="dd-mm-yyyy">
							<input class="textbox" type="text" name="payment_depositedate" id="payment_depositedate" readonly autocomplete="off" required>
							<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					</div>
						</div>
					</div>
					<div class="form-block half-width frite">
						<div class="form-group">
							<label for="">Payee Bank</label>
							<input type="text" class="textbox" name="payee_bank" id="payee_bank" value="HDFC BANK LTD" readonly autocomplete="off" required>
							<span class="bar"></span>
						</div>
						<div class="form-group">
							<label for="">Branch Deposit Bank</label>
							<input type="text" class="textbox" name="branchdepositebank" id="branchdepositebank" autocomplete="off" required>
							<span class="bar"></span>
						</div>
						<div class="form-group">
							<label for="">Seller Remark</label>
							<input type="text" class="textbox" name="remark" id="remark" autocomplete="off" autocomplete="off" required>
							<span class="bar"></span>
						</div>
						<div class="form-group">
							<label for="">Bank Statement Image</label>
							<input type="file" hidden="hidden" name="bank_statement_image" id="input_file_11" accept=".png, .jpg, .jpeg">
							<button type="button" id="upload_image_btn_11" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="upload_image_text_11" class="upload-text">No file chosen, yet.</span>
							<div class="input-erroemsg" id="bank_statement_images_error" style="display:none;"></div>
						</div>
					</div>
					<div class="text-center fwd">
						<button type="submit" class="submit-btn">Submit</button>
					</div>
				</div>
			</form>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	$(document).ready(function(){
		const realFileBtn_11 = document.getElementById("input_file_11");
        const customBtn_11 = document.getElementById("upload_image_btn_11");
        const customTxt_11 = document.getElementById("upload_image_text_11");

        customBtn_11.addEventListener("click", function(){
            realFileBtn_11.click();
        });

        realFileBtn_11.addEventListener("change", function(){
            if (realFileBtn_11.value){
                customTxt_11.innerHTML = realFileBtn_11.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
            } else {
                customTxt_11.innerHTML = "No file chosen, yet.";
            }
        });
    });

    var total = 0;
    var value1 = 2;
    var material_count = '<?php echo count($packing_material);?>';
    $(function () {
        $("#btnAdd").bind("click", function (){
            if (value1 <= material_count) {
                var div = $("<tr />");
                div.html(GetDynamicTextBox(""));
                $("#TextBoxContainer").append(div);
                value1++;
            }
            else{
                alert('You Are Added All Package Materials.');
            }
        });

        $("body").on("click", ".remove_row", function () {
            $(this).closest("tr").remove();
        });
    });
        
    function GetDynamicTextBox(value) {
    return '<td><div class="form-group"><select name="product_name[]" class="textbox input-selectbox"  onchange="getvalue('+value1+')" id="taskStatus'+value1+'" required ><option>Select the material</option><?php foreach($packing_material as $value){ ?><option value="<?php echo $value['id'] ?>" data-product_price="<?php echo $value['product_price'] ?>" data-product_flag="<?php echo $value['product_flag'] ?>"><?php echo $value['product_name'] ?></option><?php } ?></select></div></td>' + '<td><div class="form-group"><input name = "product_qty[]" type="number" value = "1" min="1" id="qty'+value1+'" onchange="qty('+value1+')" class="textbox" required /></div></td>' + '<td><div class="form-group"><input name = "product_price[]" type="text" value = "" class="textbox" id="'+value1+'" onchange="qty('+value1+')" required readonly /></div></td> <td><div class="form-group"><input name = "product_price_total[]" type="text" value = "" class="textbox qty1" id="total'+value1+'" required readonly /></div></td>' + '<td><button type="button" class="submit-btn delete-icon-btn remove_row"><i class="fa fa-trash" aria-hidden="true"></i></button></button></td>';
    }
          
    function getvalue(value1) {
        $('#'+value1).val($('#taskStatus'+value1+' option:selected').data('product_price'));
        var product_flag = $('#taskStatus'+value1+' option:selected').data('product_flag');
        $('#qty'+value1).removeClass();
        $('#qty'+value1).addClass('textbox p_flag'+product_flag);
        qty(value1);
    }

    function qty(value1) {
        var qty = $('#qty'+value1).val();
        var Price = $('#'+value1).val();
        $('#total'+value1).val(qty*Price);

        var sum = 0;
        $(".qty1").each(function(){
            sum += +$(this).val();
        });
        $("#amount").val(sum);

        var product_flag = $('#taskStatus'+value1+' option:selected').data('product_flag');
        if (product_flag == 1) {
            var sum_tape = 0;
            $(".p_flag"+product_flag).each(function(){
                sum_tape += +$(this).val();
            });
            $("#total_tape").val(sum_tape);
        }
        if (product_flag == 2) {
            var sum_bag = 0;
            $(".p_flag"+product_flag).each(function(){
                sum_bag += +$(this).val();
            });
            $("#total_bag").val(sum_bag);
        }
    }

    function package_material_validation(){
    	var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var uploadFile = document.getElementById("input_file_11").files[0];
	    var file_path = $("#input_file_11").val();
        if(file_path == ""){
            $("#bank_statement_images_error").css({"display": "block"}).text('Please Upload Bank Statement Images.');
            return false;
        }
        else if ($.inArray(uploadFile.type.toLowerCase(), validImageTypes) < 0){
            $("#bank_statement_images_error").css({"display": "block"}).text("Please Select Correct Image Formate, e.g. - png, jpg, jpeg.");
            return false;
        }
        else{
        	$("#bank_statement_images_error").css({"display": "none"}).text('');
        }

        total_tape = $("#total_tape").val();
        total_bag = $("#total_bag").val();
        var trn = 0;
        
        if (total_bag == 0 && total_tape >= 12) {
            trn = 1;
        }
        if (total_tape == 0 && total_bag >= 100) {
            trn = 1;
        }
        if (total_tape >= 12 && total_bag >= 100) {
            trn = 1;
        }
        if (trn) {
            return true;
        }
        else{
            $("#package_material_error_msg").css({"display": "block"}).text('Error - Minimum Packing Material order to be placed - 100 pcs of Courier Bags and 12 pcs of Cello Tape.');
            $('html, body').animate({scrollTop: '0px'}, 1000);
            return false;

        }
    }
</script>

