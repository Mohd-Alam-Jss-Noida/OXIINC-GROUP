		<div class="clrfix"></div>
		<footer>
			<div class="container">
				<div class="foot-block-01 fwd">
					<div class="foot-links-col col-1 equal-height-col">
						<h3>Address</h3>
						<ul class="list-unstyled">
							<li>
								<strong class="fwd" style="margin-bottom:10px;">EROCKETMALL ONLINE ASIA LIMITED</strong> <br>
								CIN - U74999MH2014PLC257236 <br>
								S6-2, Pinnacle Business Park,<br> Mahakali Caves Rd, <br>
								Shanti Nagar, Andheri East, Mumbai, Maharashtra - 400093. <br><br>

								Email: sell@oxiinc.in <br><br>

								Contact No : +91 022 41582700
							</li>
						</ul>
					</div>
					<div class="foot-links-col col-2 equal-height-col">
						<h3>Services</h3>
						<ul class="list-unstyled">
							<li><a href="javascript:void(0);">Fulfilment Services</a></li>
							<li><a href="javascript:void(0);">Account Managemant</a></li>
							<li><a href="javascript:void(0);">Partner Services</a></li>
							<li><a href="javascript:void(0);">Packaging Services</a></li>
						</ul>
					</div>
					<div class="foot-links-col col-3 equal-height-col">
						<h3>Resources</h3>
						<ul class="list-unstyled">
							<li><a href="javascript:void(0);">Online Selling Guide</a></li>
							<li><a href="javascript:void(0);">Products In Demand</a></li>
							<li><a href="javascript:void(0);">Success Stories</a></li>
							<li><a href="javascript:void(0);">Seller Learning Center</a></li>
							<li><a href="javascript:void(0);">News</a></li>
							<li><a href="javascript:void(0);">API Documentation</a></li>
						</ul>
					</div>
					<div class="foot-links-col col-4 equal-height-col">
						<h3>FAQs</h3>
						<ul class="list-unstyled">
							<li><a href="javascript:void(0);">Getting Started</a></li>
							<li><a href="javascript:void(0);">Pricing And Payments</a></li>
							<li><a href="javascript:void(0);">Listing And Catalog</a></li>
							<li><a href="javascript:void(0);">Order Management And Shipping</a></li>
						</ul>
					</div>
				</div>

				<div class="foot-block-02 fwd">
					&copy; 2020. All Rights Reserved. Design by <a target="_blank" href="https://www.oxiincgroup.com/">OXIINCGROUP.COM</a>
				</div>
			</div>
		</footer>
		<div class="clrfix"></div>
		
		<!-- Reseller Login Model -->
		<div class="modal fade modal-block" id="ResellerLoginModel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<div class="modal-body">
						<form class="form-block">
							<div class="fwd">
								<h2 class="headding-01">Sign in to continue </h2>
								<div class="form-sucessmsg" id="ajax_update_success_msg" style="display:none;"></div>
								<div class="form-errormsg" id="ajax_update_error_msg" style="display:none;"></div>
								<div class="form-group">
									<label for="">E-mail</label>
									<input type="email" class="textbox" id="login_email" placeholder="Enter Your E-mail" autocomplete="off">
									<span class="bar"></span>
									<div class="input-erroemsg" id="email_error" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Password</label>
									<input type="password" class="textbox" id="login_password" placeholder="Enter Your Password" autocomplete="off">
									<span class="bar"></span>
									<div class="input-erroemsg" id="password_error" style="display:none;"></div>
								</div>
								<div class="form-group">
									<div id="reseller_login_recaptcha"></div>
									<div class="input-erroemsg" id="captcha_error" style="display:none;"></div>
								</div>
								<div class="form-group half-width checkbox">
									<label>
										<input type="checkbox"> Remember me
									</label>
								</div>
								<div class="form-group half-width">
									<label class="align-right"><a href="javascript:void(0);" data-dismiss="modal" data-toggle="modal" data-target="#ForgotPasswordModel">Forgot Password?</a></label>
								</div>
							</div>
							<div class="form-group text-center">
								<button type="button" class="submit-btn" id="re_login_button" onclick="reseller_login();">Sign in</button>
							</div>
						</form>
						<div class="clrfix"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- Reseller Forgot Password -->
		<div class="modal fade modal-block" id="ForgotPasswordModel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<div class="modal-body">
						<form class="form-block">
							<div class="fwd">
								<h2 class="headding-01">Reset Your Password </h2>
								<div class="form-sucessmsg" id="forgot_password_success_msg" style="display:none;"></div>
								<div class="form-errormsg" id="forgot_password_error_msg" style="display:none;"></div>
								<div class="form-group">
									<label for="">E-mail</label>
									<input type="email" class="textbox" name="forgot_email" id="forgot_email" placeholder="Enter Your E-mail" autocomplete="off">
									<span class="bar"></span>
									<div class="input-erroemsg" id="forgot_email_error" style="display:none;"></div>
								</div>
								<div class="form-group">
									<div id="forgot_password_recaptcha"></div>
									<div class="input-erroemsg" id="forgot_captcha_error" style="display:none;"></div>
								</div>
							</div>
							<div class="form-group text-center">
								<button type="button" class="submit-btn" id="reset_password_button" onclick="reset_password();">Submit</button>
							</div>
						</form>
						<div class="clrfix"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- Reseller Forgot Password OTP model -->
		<div class="modal fade modal-block" id="forgot_password_enter_otp_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<div class="modal-body">
						<form class="form-block">
							<div class="fwd">
								<h2 class="headding-01">Enter OTP & Reset Password </h2>
								<div class="form-sucessmsg" id="resend_verify_otp_success_msg" style="display:none;"></div>
								<div class="form-errormsg" id="resend_verify_otp_error_msg" style="display:none;"></div>
								<div class="form-group">
									<input type="hidden" class="textbox" id="resend_otp_email_id" readonly="">
									<label for="">Enter OTP</label>
									<input type="text" class="textbox" name="forgot_otp" id="forgot_otp" placeholder="Enter Your OTP" autocomplete="off" onkeypress="return isNumberKey(event)">
									<span class="bar"></span>
									<div class="input-erroemsg character_validation_error" id="forgot_otp_error" style="display:none;"></div>
								</div>
							</div>
							<div class="form-group text-center">
								<button type="button" class="submit-btn" id="resend_otp_button" onclick="reset_password_resend_otp();">Resend OTP</button>
								<button type="button" class="submit-btn" id="verify_otp_button" onclick="reset_password_verify_otp();">Verify OTP</button>
							</div>
						</form>
						<div class="clrfix"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- Reseller Forgot Password OTP model -->
		<div class="modal fade modal-block" id="forgot_password_new_Password_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<div class="modal-body">
						<form class="form-block">
							<div class="fwd">
								<h2 class="headding-01">Set Your New Password </h2>
								<div class="form-sucessmsg" id="reset_password_success_msg" style="display:none;"></div>
								<div class="form-errormsg" id="reset_password_error_msg" style="display:none;"></div>
								<div class="form-group">
									<input type="hidden" class="textbox" id="set_password_email" readonly="">
									<label for="">Password</label>
									<input type="password" class="textbox eye-textbox" id="password" autocomplete="off">
									<button type="button" class="submit-btn eye-btn" onclick="show_password();"><i id="add_slash" class="fa fa-eye"></i></button>
									<span class="bar"></span>
									<div class="input-erroemsg" id="reg_password_error" style="display:none;"></div>
									<div class="input-successmsg" id="reg_password_success" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Re-enter Password</label>
									<input type="password" class="textbox eye-textbox" id="conform_password" autocomplete="off">
									<button type="button" class="submit-btn eye-btn" onclick="show_conform_password();"><i id="add_cross" class="fa fa-eye"></i></button>
									<span class="bar"></span>
									<div class="input-erroemsg" id="conform_password_error" style="display:none;"></div>
									<div class="input-successmsg" id="conform_password_success" style="display:none;"></div>
								</div>
							</div>
							<div class="form-group text-center">
								<button type="button" class="submit-btn" id="new_password_button" onclick="set_new_password();">submit</button>
							</div>
						</form>
						<div class="clrfix"></div>
					</div>
				</div>
			</div>
		</div>

		<!-- Fontawesome -->
		<script defer src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/fontawesome/all.js"></script>
		<script defer src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/fontawesome/brands.js"></script>
		<script defer src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/fontawesome/solid.js"></script>
		<script defer src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/fontawesome/fontawesome.js"></script>

		<!-- Navigation -->
		<script type="text/javascript">
			if (screen && screen.width > 767) {
			document.write('<script type="text/javascript" src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/animation/wow.js"><\/script>');
			}
		</script>
		<script defer src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/menu.js"></script>
		<script src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/custom-script.js"></script>

		<!-- GOOGLE RECAPTCHA JAVASCRIPT CODE -->
		<script src="https://www.google.com/recaptcha/api.js?onload=CaptchaCallback&render=explicit" async defer></script>
		<script type="text/javascript">
			var CaptchaCallback = function() {
				grecaptcha.render('reseller_login_recaptcha', {
					'sitekey' : '6LdnTbUUAAAAAIvrDreEF1JTO4gmHqNz3Vy-jFtV',
		    		'theme' : 'light'
		    	});
				grecaptcha.render('forgot_password_recaptcha', {
					'sitekey' : '6LdnTbUUAAAAAIvrDreEF1JTO4gmHqNz3Vy-jFtV',
		    		'theme' : 'light'
				});
			};

		    function isNumberKey(evt){
		    	var charCode = (evt.which) ? evt.which : event.keyCode
		    	if (charCode > 31 && (charCode < 48 || charCode > 57)){
		    		$(".character_validation_error").css({"display": "block"}).text('Only digits are allowed.');
		    		return false;
		    	}
		    	else{
		    		$(".character_validation_error").css({"display": "none"}).text('');
		    		return true;
		    	}
		    }

		    function isNumberValidation(evt){
		    	var charCode = (evt.which) ? evt.which : event.keyCode
		    	if (charCode > 31 && (charCode < 48 || charCode > 57)){
		    		$(".number_validation").css({"display": "block"}).text('Only digits are allowed.');
		    		return false;
		    	}
		    	else{
		    		$(".number_validation").css({"display": "none"}).text('');
		    		return true;
		    	}
		    }

            function reseller_login(){
            	var rtn = true;
		    	var email = $('#login_email').val();
		    	var password = $('#login_password').val();
		    	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		    	var response = grecaptcha.getResponse(0);

		    	if(email == ""){
			        $("#email_error").css({"display": "block"}).text('Please Enter Your Email Id.');
			        rtn = false;
			    } else if (!filter.test(email)) {
		            $("#email_error").css({"display": "block"}).text("Please Enter Valid Email Id.");
		            rtn = false;
		        }
			    else {
			        $("#email_error").css({"display": "none"}).text('');
			    }

			  	if(password == ""){
		            $("#password_error").css({"display": "block"}).text('Please Enter Your Password.');
		            rtn = false;
			    }
			    else {
			        $("#password_error").css({"display": "none"}).text('');
			    }
			    if(response == ""){
		            $("#captcha_error").css({"display": "block"}).text('Please Select Captcha.');
		            rtn = false;
			    }
			    else {
			        $("#captcha_error").css({"display": "none"}).text('');
			    }

		        if (rtn == true){
		            $.ajax({
		            	type: "POST",
						url:"<?php echo base_url('Oxiinc_reseller/login'); ?>",
						data:'email='+ email +'&password='+ password,
						cache: false,
						processData: false,
		                success:function(data){
		                    var obj = JSON.parse(data);
		                    //alert(obj.status);alert(obj.message);
		                    if(obj.status == 'error'){
		                    	$("#ajax_update_error_msg").css({"display": "block"}).text(obj.message);
		                    }
		                    if(obj.status == 'success'){
		                    	$("#re_login_button").prop('disabled', true);
		                    	$("#ajax_update_error_msg").css({"display": "none"}).text('');
		                    	$("#ajax_update_success_msg").css({"display": "block"}).text(obj.message);
			                    setTimeout(function (){
			                    	window.location.href = '<?php echo base_url('Reseller_dashboard'); ?>';
			                	}, 2000);
		                	}
		                	if(obj.status == 'Verify'){
		                		$("#re_login_button").prop('disabled', true);
                      			$("#ajax_update_error_msg").css({"display": "block"}).text(obj.message);
                      			setTimeout(function () {
                      				document.getElementById("register_id").value = obj.id;
                                 	$('#registration_form').submit();
                             	}, 2000);
                      		}
		                }
		            });
		        }
		        else{
		            return false;
		        }
		    }

		    function reset_password(){
            	var rtn = true;
		    	var forgot_email = $('#forgot_email').val();
		    	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		    	var forgot_response = grecaptcha.getResponse(1);
		    	//alert(forgot_response);

		    	if(forgot_email == ""){
			        $("#forgot_email_error").css({"display": "block"}).text('Please Enter Your Email Id.');
			        rtn = false;
			    } else if (!filter.test(forgot_email)) {
		            $("#forgot_email_error").css({"display": "block"}).text("Please Enter Valid Email Id.");
		            rtn = false;
		        }
			    else {
			        $("#forgot_email_error").css({"display": "none"}).text('');
			    }

			    if(forgot_response == ""){
		            $("#forgot_captcha_error").css({"display": "block"}).text('Please Select Captcha.');
		            rtn = false;
			    }
			    else {
			        $("#forgot_captcha_error").css({"display": "none"}).text('');
			    }

		        if (rtn == true){
		            $.ajax({
		            	type: "POST",
						url:"<?php echo base_url('Oxiinc_reseller/forgot_email_check'); ?>",
						data:'email='+ forgot_email,
						cache: false,
						processData: false,
		                success:function(data){
		                    var obj = JSON.parse(data);
		                    //alert(obj.email);alert(obj.message);
		                    if(obj.status == 'error'){
		                    	$("#forgot_password_error_msg").css({"display": "block"}).text(obj.message);
		                    }
		                    if(obj.status == 'success'){
		                    	$("#reset_password_button").prop('disabled', true);
		                    	$("#forgot_password_error_msg").css({"display": "none"}).text('');
		                    	$("#forgot_password_success_msg").css({"display": "block"}).text(obj.message);
		                    	document.getElementById("resend_otp_email_id").value = obj.email;
			                    setTimeout(function (){
			                    	$('#ForgotPasswordModel').modal('hide');
			                    	$('#forgot_password_enter_otp_model').modal('show');
			                	}, 2000);
		                	}
		                }
		            });
		        }
		        else{
		            return false;
		        }
		    }

		    function reset_password_resend_otp(){
		    	var resend_otp_email_id = $('#resend_otp_email_id').val();
	            $.ajax({
	            	type: "POST",
					url:"<?php echo base_url('Oxiinc_reseller/forgot_email_check'); ?>",
					data:'email='+ resend_otp_email_id,
					cache: false,
					processData: false,
	                success:function(data){
	                    var obj = JSON.parse(data);
	                    //alert(obj.status);alert(obj.message);
	                    if(obj.status == 'error'){
	                    	$("#resend_verify_otp_error_msg").css({"display": "block"}).text(obj.message);
	                    }
	                    if(obj.status == 'success'){
	                    	$("#resend_verify_otp_error_msg").css({"display": "none"}).text('');
	                    	$("#resend_verify_otp_success_msg").css({"display": "block"}).text(obj.message);
	                	}
	                }
	            });
		    }

		    function reset_password_verify_otp(){
            	var rtn = true;
		    	var forgot_otp = $('#forgot_otp').val();
		    	var resend_otp_email_id = $('#resend_otp_email_id').val();

		    	if(forgot_otp == ""){
			        $("#forgot_otp_error").css({"display": "block"}).text('Please Enter Your OTP.');
			        rtn = false;
			    } else {
			        $("#forgot_otp_error").css({"display": "none"}).text('');
			    }

		        if (rtn == true){
		            $.ajax({
		            	type: "POST",
						url:"<?php echo base_url('Oxiinc_reseller/mail_otp_check'); ?>",
						data:'email='+ resend_otp_email_id +'&otp='+ forgot_otp,
						cache: false,
						processData: false,
		                success:function(data){
		                    var obj = JSON.parse(data);
		                    //alert(obj.email);alert(obj.message);
		                    if(obj.status == 'error'){
		                    	$("#resend_verify_otp_success_msg").css({"display": "none"}).text('');
		                    	$("#resend_verify_otp_error_msg").css({"display": "block"}).text(obj.message);
		                    }
		                    if(obj.status == 'success'){
		                    	$("#resend_otp_button").prop('disabled', true);
		                    	$("#verify_otp_button").prop('disabled', true);
		                    	$("#resend_verify_otp_error_msg").css({"display": "none"}).text('');
		                    	$("#resend_verify_otp_success_msg").css({"display": "block"}).text(obj.message);
		                    	document.getElementById("set_password_email").value = obj.email;
			                    setTimeout(function (){
			                    	$('#forgot_password_enter_otp_model').modal('hide');
			                    	$('#forgot_password_new_Password_model').modal('show');
			                	}, 2000);
		                	}
		                }
		            });
		        }
		        else{
		            return false;
		        }
		    }

		    function set_new_password(){
            	var rtn = true;
            	var password_check = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/;
		    	var set_password_email = $('#set_password_email').val();
		    	var password = $('#password').val();
		    	var conform_password = $('#conform_password').val();

		    	if(password == ""){
		    		$("#reg_password_success").css({"display":"none"}).text("");
		    		$("#reg_password_error").css({"display": "block"}).text('Please Enter Your password.');
		    		rtn = false;
		    	} else if (password_check.test(password) === false){
		    		$("#reg_password_success").css({"display":"none"}).text("");
		    		$("#reg_password_error").css({"display": "block"}).text("Uppercase, lowercase, number, special character and betwen 6 to 15 character should be required.");
		    		rtn = false;
		    	} else {
		    		$("#reg_password_error").css({"display": "none"}).text("");
		    		$("#reg_password_success").css({"display":"block"}).text("Strong password, It's valid password.");
		    	}

		    	if(conform_password == ""){
		    		$("#conform_password_success").css({"display":"none"}).text("");
		    		$("#conform_password_error").css({"display": "block"}).text('Please Enter Your conform password.');
		    		rtn = false;
		    	} else if (password_check.test(conform_password) === false) {
		    		$("#conform_password_success").css({"display":"none"}).text("");
		    		$("#conform_password_error").css({"display": "block"}).text("Uppercase, lowercase, number, special character and betwen 6 to 15 character should be required.");
		    		rtn = false;
		    	} else if (password != conform_password) {
		    		$("#conform_password_success").css({"display":"none"}).text("");
		    		$("#conform_password_error").css({"display": "block"}).text("Password and confirm password should be same.");
		    		rtn = false;
		    	} else {
		    		$("#conform_password_error").css({"display": "none"}).text("");
		    		$("#conform_password_success").css({"display":"block"}).text("Strong password, It's valid password.");
		    	}
		        if (rtn == true){
		            $.ajax({
		            	type: "POST",
						url:"<?php echo base_url('Oxiinc_reseller/set_password'); ?>",
						data:'email='+ set_password_email +'&password='+ password,
						cache: false,
						processData: false,
		                success:function(data){
		                    var obj = JSON.parse(data);
		                    //alert(obj.status);alert(obj.message);
		                    if(obj.status == 'error'){
		                    	$("#reset_password_success_msg").css({"display": "none"}).text('');
		                    	$("#reset_password_error_msg").css({"display": "block"}).text(obj.message);
		                    }
		                    if(obj.status == 'success'){
		                    	$("#new_password_button").prop('disabled', true);
		                    	$("#reset_password_error_msg").css({"display": "none"}).text('');
		                    	$("#reset_password_success_msg").css({"display": "block"}).text(obj.message);
			                    setTimeout(function (){
			                    	window.location.href = '<?php echo base_url('reseller'); ?>';
			                	}, 2000);
		                	}
		                }
		            });
		        }
		        else{
		            return false;
		        }
		    }

		    function show_password() {
		    	var x = document.getElementById("password");
		    	if (x.type === "password") {
		    		x.type = "text";
		    		$("#add_slash").addClass("fa fa-eye-slash");
		    	} else {
		    		x.type = "password";
		    		$("#add_slash").addClass("fa fa-eye");
		    	}
		    }

		    function show_conform_password() {
		    	var x = document.getElementById("conform_password");
		    	if (x.type === "password") {
		    		x.type = "text";
		    		$("#add_cross").addClass("fa fa-eye-slash");
		    	} else {
		    		x.type = "password";
		    		$("#add_cross").addClass("fa fa-eye");
		    	}
		    }
		    
		    $(document).ready(function(){
		    	$('#password').on('keypress', function(e) {
		    		var k = e ? e.which : window.e.keyCode;
		    		if(k == 32) return false;
		    		var password_check =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/;
		    		var password = $('#password').val();
		    		if(password_check.test(password) === false){
		    			$("#reg_password_success").css({"display":"none"}).text("");
		    			$("#reg_password_error").css({"display": "block"}).text("Uppercase, lowercase, number, special character and betwen 6 to 15 character should be required.");
		    		}
		    		else{
		    			$("#reg_password_error").css({"display": "none"}).text("");
		    			$("#reg_password_success").css({"display":"block"}).text("Strong password, It's valid password.");
		    		}
		    	});

		    	$('#conform_password').on('keypress', function(e) {
		    		var k = e ? e.which : window.e.keyCode;
		    		if(k == 32) return false;
		    		var password_check =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/;
		    		var conform_password = $('#conform_password').val();
		    		if(password_check.test(conform_password) === false){
		    			$("#conform_password_success").css({"display":"none"}).text("");
		    			$("#conform_password_error").css({"display": "block"}).text("Uppercase, lowercase, number, special character and betwen 6 to 15 character should be required.");
		    		}
		    		else{
		    			$("#conform_password_error").css({"display": "none"}).text("");
		    			$("#conform_password_success").css({"display":"block"}).text("Strong password, It's valid password.");
		    		}
		    	});
		    });
		</script>
	</div>
</body>
</html>
