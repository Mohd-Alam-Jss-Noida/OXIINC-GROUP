<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Oxiinc Reseller | <?php echo $title;?></title>

	<link rel="apple-touch-icon" href="<?php echo base_url();?>reseller_files/images/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>image/logo.png">

	<!-- Css -->
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/bootstrap.min.css" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet"> 
	<!-- Fontawesome -->
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/fontawesome/all.css" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/fontawesome/fontawesome.css" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/fontawesome/brands.css" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/fontawesome/solid.css" rel="stylesheet">
	
	<!-- Animation -->
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/animation/animate.css" rel="stylesheet">

	<!-- Navigation -->
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/menu.css" rel="stylesheet">

	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/custom-style.css" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/landing_page/');?>css/custom-responsive.css" rel="stylesheet">

	<!-- jQuery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="<?php echo base_url('reseller_user_assets/landing_page/');?>js/bootstrap.min.js"></script>
</head>
<body>
	<div id="main-page-wrapper">
		<header>
			<div class="top-head fwd">
				<div class="container">
					<div class="search-col">
						<input type="text" class="input-search" id="InputSearch" placeholder="Enter Your Keyword">
						<button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
					</div>
					<ul class="list-inline head-social-media">
						<li><a href="https://www.facebook.com/Erocketmallonlineasialtd" target="blank"><i class="fab fa-facebook-f"></i></a></li>
						<li><a href="https://twitter.com/myoxiinc" target="blank"><i class="fab fa-twitter"></i></a></li>
						<li><a href="https://www.linkedin.com/company/oxiincgroup" target="blank"><i class="fab fa-linkedin-in"></i></a></li>
						<li><a href="https://www.youtube.com/c/OXIINCGROUP" target="blank"><i class="fab fa-youtube"></i></a></li>
						<li><a href="https://www.instagram.com/oxiinc_group" target="blank"><i class="fab fa-instagram"></i></a></li>
					</ul>
				</div>
			</div>
			<div class="container">
				<div class="navigation-col fwd">
					<a href="<?php echo site_url('seller');?>" class="logo-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/oxiinc-logo.png" alt=""/></a>
					<a href="javascript:void(0);" class="existing-seller-login-btn" data-toggle="modal" data-target="#ResellerLoginModel"><i class="fa fa-user-circle"></i> <span>Existing Sellers</span></a>
					<div class="xs-search-btn"><i class="fa fa-search"></i></div>
					<nav id='cssmenu' class="fwd">
						<div id="head-mobile"></div>
						<div class="button"></div>
						<ul class="nav-main-ul">
							<li class="fee-structure-active <?php echo ($this->uri->segment(1) == 'fee_structure') ? 'active' : '' ;?>"><a href="<?php echo site_url('fee_structure');?>">Fee Structure</a></li>
							<li class="service-active <?php echo ($this->uri->segment(1) == 'services') ? 'active' : '' ;?>"><a href="<?php echo site_url('services');?>">Service</a></li>
							<li class="resources-active <?php echo ($this->uri->segment(1) == 'resources') ? 'active' : '' ;?>"><a href="<?php echo site_url('resources');?>">Resources</a></li>
							<li class="faqs-active <?php echo ($this->uri->segment(1) == 'faqs') ? 'active' : '' ;?>"><a href="<?php echo site_url('faqs');?>">FAQs</a></li>
							<li><a target="_blank" href='https://www.oxiinc.in'>Oxiinc.in</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>
		<div class="clrfix"></div>