<!-- Start Container -->
<div class="main-wrapper">
	<!-- Services Section-03 -->
	<section class="services-section-01 section-space fwd">
		<div class="container">
			<h2 class="headding-01 wow fadeInUp" data-wow-delay=".25s">Minimum cost with maximum benefits</h2>
			<p class="paraha-txt wow fadeInUp" data-wow-delay=".25s">The intention was to design an intervention that would be likely to be cost-effective by maximizing patient benefit at minimum coast  and which could feasibly be rolled out quickly on a national scale if it proved to be effective.</p>
			<ul class="list-inline services-list">
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/service-img-01.png"/></div>
						<span class="title">Oxiinc Fulfilment</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/service-img-02.png"/></div>
						<span class="title">Smart Fulfilment</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/service-img-03.png"/></div>
						<span class="title">Oxiinc Branded Packaging</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/service-img-04.png"/></div>
						<span class="title">Paid Account Management (PAM)</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
			</ul>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->