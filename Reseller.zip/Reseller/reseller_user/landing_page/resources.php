<!-- Start Container -->
<div class="main-wrapper">
	<!-- Services Section-03 -->
	<section class="services-section-01 section-space fwd">
		<div class="container">
			<h2 class="headding-01 wow fadeInUp" data-wow-delay=".25s">Enhancing your selling experience</h2>
			<p class="paraha-txt wow fadeInUp" data-wow-delay=".25s">This will make your selling experience much easier.</p>
			<ul class="list-inline services-list">
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/resources-img-01.png"/></div>
						<span class="title">Online Selling Guide</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/resources-img-02.png"/></div>
						<span class="title">Seller Success Stories</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/resources-img-03.png"/></div>
						<span class="title">Products in Demand</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/resources-img-04.png"/></div>
						<span class="title">Seller Learning Center</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="services-col fwd">
						<div class="image-col"><img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/resources-img-05.png"/></div>
						<span class="title">Oxiinc in News</span>
						<span class="desc">Oxiinc Admin | 1st Jul 2019 | 1 min read</span>
					</div>
				</li>
			</ul>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->