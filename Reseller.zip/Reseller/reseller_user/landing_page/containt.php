<?Php
    $this->load->view('reseller_user/landing_page/header');
	$this->load->view($main_containt);
	$this->load->view('reseller_user/landing_page/footer');
?>