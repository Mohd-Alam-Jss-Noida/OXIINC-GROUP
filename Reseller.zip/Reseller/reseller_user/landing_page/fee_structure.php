<!-- Start Container -->
<div class="main-wrapper">
	<!-- Fee Structure Section-01 -->
	<section class="home-section-02 section-space fwd">
		<div class="container">
			<div class="left-col">
				<img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/register-process-img.png" alt="" class="img-responsive wow fadeInLeftBig" data-wow-delay=".25s"/>
			</div>
			<div class="right-col">
				<h2 class="headding-01 wow fadeInDown" data-wow-delay=".25s">Oxiinc's Marketplace Fee Structure</h2>
				<!--<p class="paraha-txt wow fadeInDown" data-wow-delay=".25s">You need just 3 things to become a Oxiinc Seller.</p>-->
				<ul class="list-unstyled register-steps-list">
					<li class="wow fadeInDown" data-wow-delay=".25s">
						<div class="icon-col">
							<img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/product-sell-icon.png" alt=""/>
						</div>
						<span class="fwd title-col">Commission fee</span>
						<span class="fwd desc-col">Percentage of Order item value ( depends on category & sub-category</span>
					</li>
					<li class="wow fadeInDown" data-wow-delay=".50s">
						<div class="icon-col">
							<img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/GSTIN-detail-icon.png" alt=""/>
						</div>
						<span class="fwd title-col">Shipping fee</span>
						<span class="fwd desc-col">Calculated on the basis of product weight and shipping location</span>
					</li>
					<li class="wow fadeInDown" data-wow-delay=".75s">
						<div class="icon-col">
							<img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/cancelled-cheque-icon.png" alt=""/>
						</div>
						<span class="fwd title-col">Collection fee</span>
						<span class="fwd desc-col">Payment gateway or cash collection charges for every sale</span>
					</li>
					<li class="wow fadeInDown" data-wow-delay="1s">
						<div class="icon-col">
							<img src="<?php echo base_url('reseller_user_assets/landing_page/');?>images/GSTIN-detail-icon.png" alt=""/>
						</div>
						<span class="fwd title-col">Fixed fee</span>
						<span class="fwd desc-col">A small fee that Oxiinc charges on all transactions</span>
					</li>
				</ul>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
	<!-- Fee Structure Section-02 -->
	<section class="feestructure-section-02 section-space fwd">
		<div class="container">
			<ul class="list-inline feestructure-list">
				<li class="equal-height-col wow fadeInDown" data-wow-delay=".25s">
					<div class="feestructure-col fwd">
						<span class="title">Settlement Amount</span>
						<span class="desc">Credited to your bank account within 7-15 business days of dispatch</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInDown" data-wow-delay=".50s">
					<div class="feestructure-col fwd">
						<span class="title">Order Item Value</span>
						<span class="desc">Selling price & Shipping charge paid by customer and excludes discount offered by Seller</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInDown" data-wow-delay=".75s">
					<div class="feestructure-col fwd">
						<span class="title">Marketplace Fee</span>
						<span class="desc">Includes shipping fee, fixed fee and selling commission</span>
					</div>
				</li>
				<li class="equal-height-col wow fadeInDown" data-wow-delay="1s">
					<div class="feestructure-col fwd">
						<span class="title">GST</span>
						<span class="desc">18% of Marketplace Fee</span>
					</div>
				</li>
			</ul>
		</div>
	</section>
	<div class="clrfix"></div>
	<!-- Fee Structure Section-03 -->
	<section class="feestructure-section-03 section-space fwd">
		<div class="container">
			<h2 class="headding-01 wow fadeInUp" data-wow-delay=".50s">Shipping Fees</h2>
			<p class="paraha-txt wow fadeInUp" data-wow-delay=".50s">To ensure ease of selling and the best possible customer experience, we mandate delivery to all customers via our logistics partners and deduct the shipping cost from the selling price before making a payment to you. Shipping fee is calculated on actual weight or volumetric weight, whichever is higher. This is to account for items which are lightweight but occupy a lot of shipping space.</p>
			<p class="subtitle wow fadeInUp" data-wow-delay=".50s"><strong>Volumetric Weight (kg) = Length (cm) X Breadth (cm) X Height (cm)/5000</strong></p>
			<div class="tbl-responsive wow fadeInUp" data-wow-delay=".50s">
				<table class="table table-striped table-bordered dt-responsive nowrap"  width="100%">
					<thead>
						<tr>
							<th>WEIGHT SLAB</th>
							<th>LOCAL (INTRACITY)</th>
							<th>ZONAL (INTRAZONE)</th>
							<th>NATIONAL (INTERZONE)</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>0-500 grams</td>
							<td>₹30</td>
							<td>₹46</td>
							<td>₹66</td>
						</tr>
						<tr>
							<td>+0.5Kg,upto 1Kg</td>
							<td>₹18</td>
							<td>₹23</td>
							<td>₹27</td>
						</tr>
						<tr>
							<td>+0.5Kg,upto 3Kg</td>
							<td>₹8</td>
							<td>₹10</td>
							<td>₹15</td>
						</tr>
						<tr>
							<td>+1Kg,upto 12Kg</td>
							<td>₹8</td>
							<td>₹10</td>
							<td>₹15</td>
						</tr>
						<tr>
							<td>+1Kg,beyond 12Kg</td>
							<td>₹4</td>
							<td>₹5</td>
							<td>₹8</td>
						</tr>
					</tbody>
				</table>
			</div>
			<p class="subtitle wow fadeInUp" data-wow-delay=".50s"><strong>Note :</strong></p>
			<ul class="list-unstyled note-list wow fadeInUp" data-wow-delay=".50s">
				<li>Shipping rate for forward shipments is applicable for Bronze Sellers only</li>
				<li>There is 20% and 10% discount on the forward shipping fee for Gold and Silver Sellers respectively</li>
				<li>Mentioned rates are exclusive of all taxes.</li>
				<li>Local (Intracity): Item shipped within a city.</li>
				<li>Zonal (Intrazone): Item shipped within the borders of a zone (North, South, East, West)</li>
				<li>National (Interzone): Item shipped across zones.</li>
			</ul>
		</div>
	</section>
	<div class="clrfix"></div>
	<!-- Fee Structure Section-04 -->
	<section class="feestructure-section-04 section-space fwd">
		<div class="container">
			<ul class="list-inline shipping-list">
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".25s">
					<div class="shipping-col fwd">
						<div class="icon-col"><i class="fa fa-truck"></i></div>
						<span class="title">Seller Fulfilment</span>
						<span class="desc">Under seller fulfillment, you are responsible for processing and managing your orders and inventory. Once you have packed your orders and marked RTD, an E-kart agent will collect this package and deliver it to the respective customer</span>
						<a href="#" class="know-more-btn">Know More</a>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
					<div class="shipping-col fwd">
						<div class="icon-col"><i class="fa fa-truck"></i></div>
						<span class="title">Smart Fulfilment</span>
						<span class="desc">Smart Fulfillment is a program wherein you get help from Oxiinc for systematically arranging your warehouse, easily maintaining your inventory and getting it smoothly delivered to your customer via a Oxiinc logistics partner. All you have to do is comply with the smart</span>
						<a href="#" class="know-more-btn">Know More</a>
					</div>
				</li>
				<li class="equal-height-col wow fadeInUp" data-wow-delay=".75s">
					<div class="shipping-col fwd">
						<div class="icon-col"><i class="fa fa-truck"></i></div>
						<span class="title">Oxiinc Fulfilment</span>
						<span class="desc">At Oxiinc, we help you have maximum returns with minimum investment. That’s why the Oxiinc Fulfilment service offers you the use of our state-of-the-art fulfillment centers at very low costs. You store your products in our fulfillment centers where we take utmost </span>
						<a href="#" class="know-more-btn">Know More</a>
					</div>
				</li>
			</ul>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->