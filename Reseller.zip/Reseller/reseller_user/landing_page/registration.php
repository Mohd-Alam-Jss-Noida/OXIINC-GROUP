<!-- Start Container -->
<div class="main-wrapper">
	<!-- Registration Section-01 -->
	<section class="registration-section-01 section-space fwd">
		<div class="container">
			<h2 class="headding-01 wow fadeInUp" data-wow-delay=".25s">Create Your Seller Account</h2>
			<div class="modal-block wow fadeInUp" data-wow-delay=".50s">
				<div class="form-sucessmsg" id="reseller_registration_success_msg" style="display:none;"></div>
				<div class="form-errormsg" id="reseller_registration_error_msg" style="display:none;"></div>
				<form class="form-block">
					<input type="hidden" class="textbox" id="id" value="<?php echo $register[0]['id'] ?>">
					<div class="fwd">
						<div class="form-group">
							<label for="">E-mail</label>
							<input type="email" class="textbox" id="email" autocomplete="off" value="<?php echo $register[0]['email'] ?>" readonly>
							<span class="bar"></span>
							<div class="input-erroemsg" id="reg_email_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Mobile Number</label>
							<input type="text" class="textbox otp-textbox" id="register_mobile_mumber" maxlength="10" autocomplete="off" value="<?php echo $register[0]['mobile_number'] ?>" onkeypress="return isNumberKey(event)">
							<input type="button" class="submit-btn otp-btn" id="resend_otp" value="Resend OTP" onclick="ResendOTP();">
							<span class="bar"></span>
							<div class="input-erroemsg character_validation_error" id="mobile_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Enter OTP</label>
							<input type="text" class="textbox otp-textbox" id="mobile_otp" autocomplete="off" onkeypress="return isNumberValidation(event)">
							<input type="hidden" class="textbox otp-textbox" id="correct_otp" readonly>
							<input type="button" class="submit-btn otp-btn" id="verify_otp" value="Verify OTP" onclick="verifyOTP(<?php echo $register[0]['mobile_number'];?>);">
							<span class="bar"></span>
							<div class="input-erroemsg number_validation" id="otp_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Full Name</label>
							<input type="text" class="textbox" id="full_name" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" id="full_name_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Password</label>
							<input type="password" class="textbox eye-textbox" id="password" autocomplete="off">
							<button type="button" class="submit-btn eye-btn" onclick="show_password();"><i id="add_slash" class="fa fa-eye"></i></button>
							<span class="bar"></span>
							<div class="input-erroemsg" id="reg_password_error" style="display:none;"></div>
							<div class="input-successmsg" id="reg_password_success" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Re-enter Password</label>
							<input type="password" class="textbox eye-textbox" id="conform_password" autocomplete="off">
							<button type="button" class="submit-btn eye-btn" onclick="show_conform_password();"><i id="add_cross" class="fa fa-eye"></i></button>
							<span class="bar"></span>
							<div class="input-erroemsg" id="conform_password_error" style="display:none;"></div>
							<div class="input-successmsg" id="conform_password_success" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Select Your Package</label>
							<select class="textbox input-selectbox" id="package" autocomplete="off">
								<option value="">Select Package</option>
								<option value="0">Free</option>
								<option value="1">Silver</option>
								<option value="2">Gold</option>
								<option value="3">Platinum</option>
								<option value="4">Reseller Club</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" id="package_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Referral Id (E-Panalist Id)</label>
							<input type="text" class="textbox" id="" autocomplete="off">
							<input type="hidden" name="" id="employee_id" value="1">
                        	<input type="hidden" name="" id="user_id" value="1">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Referral Name</label>
							<input type="text" class="textbox" id="referral_name" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;"></div>
						</div>
					</div>
					<div class="form-group">
						<div id="reseller_registration_recaptcha"></div>
						<div class="input-erroemsg" id="reg_captcha_error" style="display:none;"></div>
					</div>
					<div class="form-group text-center">
						<button type="button" class="submit-btn" onclick="ResellerRegistration();">Sign Up</button>
					</div>
				</form>
				<div class="clrfix"></div>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script src="https://www.google.com/recaptcha/api.js?onload=callback_reseller_registration&render=explicit" async defer></script>
<script type="text/javascript">
    var callback_reseller_registration = function(){
    	var reseller_registration_recaptcha = grecaptcha.render('reseller_registration_recaptcha', {
    		'sitekey' : '6LdnTbUUAAAAAIvrDreEF1JTO4gmHqNz3Vy-jFtV',
    		'theme' : 'light'
    	});
    };

	function ResendOTP(){
		var rtn = true;
		mobile_number = $('#register_mobile_mumber').val();
		if(mobile_number == ""){
			$("#mobile_error").css({"display": "block"}).text('Please enter your mobile number.');
			rtn = false;
		} else if(mobile_number.length != 10){
			$("#mobile_error").css({"display": "block"}).text('Please enter complete 10 digits mobile number.');
			rtn = false;
		} else{
			$("#mobile_error").css({"display": "none"}).text('');
		}
		if (rtn == true){
		$.ajax({
			type:"POST",
			url:"<?php echo base_url('Oxiinc_reseller/change_mobile_get_otp'); ?>",
			data:'mobile_number='+ mobile_number,
			success:function(data){
				var obj = JSON.parse(data);
				//alert(obj.status);
				//alert(obj.message);
				if(obj.status == 'error'){
					$("#reseller_registration_success_msg").css({"display": "none"}).text('');
					$("#reseller_registration_error_msg").css({"display": "block"}).text(obj.message);
					setTimeout(function () {
						$("#reseller_registration_error_msg").css({"display": "none"}).text('');
					}, 30000);
				}
				if(obj.status == 'success'){
					document.getElementById("register_mobile_mumber").readOnly = true;
					$("#reseller_registration_error_msg").css({"display": "none"}).text('');
					$("#reseller_registration_success_msg").css({"display": "block"}).text(obj.message);
					setTimeout(function (){
						$("#reseller_registration_success_msg").css({"display": "none"}).text('');
					}, 30000);
				}
			}
		});
		}
	}

	function verifyOTP(){
		var rtn = true;
		mobile_number = $('#register_mobile_mumber').val();
		mobile_otp = $('#mobile_otp').val();

		if(mobile_number == ""){
			$("#mobile_error").css({"display": "block"}).text('Please enter your mobile number.');
			rtn = false;
		} else if(mobile_number.length != 10){
			$("#mobile_error").css({"display": "block"}).text('Please enter complete 10 digits mobile number.');
			rtn = false;
		} else{
			$("#mobile_error").css({"display": "none"}).text('');
		}

		if(mobile_otp == ""){
			$("#otp_error").css({"display": "block"}).text('Please enter your OTP.');
			rtn = false;
		}
		else{
			$("#otp_error").css({"display": "none"}).text('');
		}

		if (rtn == true){
		$.ajax({
			type:"POST",
			url:"<?php echo base_url('Oxiinc_reseller/mobile_otp_check'); ?>",
			data:'mobile_number='+ mobile_number +'&otp='+ mobile_otp,
			success:function(data){
				var obj = JSON.parse(data);
				//alert(obj.status);
				//alert(obj.message);
				if(obj.status == 'error'){
					$("#reseller_registration_error_msg").css({"display": "block"}).text(obj.message);
					setTimeout(function () {
						$("#reseller_registration_error_msg").css({"display": "none"}).text('');
					}, 100000);
				}
				if(obj.status == 'success'){
					document.getElementById("register_mobile_mumber").readOnly = true;
					document.getElementById("mobile_otp").readOnly = true;
					document.getElementById("resend_otp").disabled = true; 
					document.getElementById("verify_otp").disabled = true;
					document.getElementById("correct_otp").value = obj.correct_otp;
					$("#reseller_registration_error_msg").css({"display": "none"}).text('');
					$("#reseller_registration_success_msg").css({"display": "block"}).text(obj.message);
					setTimeout(function (){
						$("#reseller_registration_success_msg").css({"display": "none"}).text('');
					}, 100000);
				}
			}
		});
		}
	}

	function ResellerRegistration(){
    	var rtn = true;
    	var password_check = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/;
    	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var reg_cap_response = grecaptcha.getResponse();
		//alert(reg_cap_response);

    	var id = $('#id').val();
    	var email = $('#email').val();
    	var mobile_number = $('#register_mobile_mumber').val();
    	var mobile_otp = $('#mobile_otp').val();
    	var correct_otp = $('#correct_otp').val();
    	var full_name = $('#full_name').val();
    	var password = $('#password').val();
    	var conform_password = $('#conform_password').val();
    	var package = $('#package').val();
    	var employee_id = $('#employee_id').val();
    	var user_id = $('#user_id').val();
    	var referral_name = $('#referral_name').val();

    	if(email == ""){
	        $("#reg_email_error").css({"display": "block"}).text('Please Enter Your Email Id.');
	        rtn = false;
	    } else if (!filter.test(email)) {
            $("#reg_email_error").css({"display": "block"}).text("Please provide valid email Id.");
            rtn = false;
        }
	    else {
	        $("#reg_email_error").css({"display": "none"}).text('');
	    }

	    if(mobile_number == ""){
			$("#mobile_error").css({"display": "block"}).text('Please enter your mobile number.');
			rtn = false;
		} else if(mobile_number.length != 10){
			$("#mobile_error").css({"display": "block"}).text('Please enter complete 10 digits mobile number.');
			rtn = false;
		} else{
			$("#mobile_error").css({"display": "none"}).text('');
		}

		if(mobile_otp == ""){
			$("#otp_error").css({"display": "block"}).text('Please enter your OTP and click verify OTP button.');
			rtn = false;
		} else if(mobile_otp != correct_otp){
			$("#otp_error").css({"display": "block"}).text('You have entered the wrong OTP Please enter correct OTP and click verify OTP button.');
			rtn = false;
		} else{
			$("#otp_error").css({"display": "none"}).text('');
		}

	  	if(full_name == ""){
            $("#full_name_error").css({"display": "block"}).text('Please Enter Your full name.');
            rtn = false;
	    }
	    else {
	        $("#full_name_error").css({"display": "none"}).text('');
	    }

	    if(password == ""){
	    	$("#reg_password_success").css({"display":"none"}).text("");
	        $("#reg_password_error").css({"display": "block"}).text('Please Enter Your password.');
	        rtn = false;
	    } else if (password_check.test(password) === false){
	    	$("#reg_password_success").css({"display":"none"}).text("");
            $("#reg_password_error").css({"display": "block"}).text("Uppercase, lowercase, number, special character and betwen 6 to 15 character should be required.");
            rtn = false;
        } else {
	    	$("#reg_password_error").css({"display": "none"}).text("");
	        $("#reg_password_success").css({"display":"block"}).text("Strong password, It's valid password.");
	    }

	    if(conform_password == ""){
	    	$("#conform_password_success").css({"display":"none"}).text("");
	        $("#conform_password_error").css({"display": "block"}).text('Please Enter Your conform password.');
	        rtn = false;
	    } else if (password_check.test(conform_password) === false) {
	    	$("#conform_password_success").css({"display":"none"}).text("");
            $("#conform_password_error").css({"display": "block"}).text("Uppercase, lowercase, number, special character and betwen 6 to 15 character should be required.");
            rtn = false;
        } else if (password != conform_password) {
	    	$("#conform_password_success").css({"display":"none"}).text("");
            $("#conform_password_error").css({"display": "block"}).text("Password and confirm password should be same.");
            rtn = false;
        } else {
	    	$("#conform_password_error").css({"display": "none"}).text("");
	        $("#conform_password_success").css({"display":"block"}).text("Strong password, It's valid password.");
	    }

		if(package == ""){
            $("#package_error").css({"display": "block"}).text('Please select your package.');
            rtn = false;
	    }
	    else {
	        $("#package_error").css({"display": "none"}).text('');
	    }	    

	    if(reg_cap_response == ""){
            $("#reg_captcha_error").css({"display": "block"}).text('Please Select Captcha.');
            rtn = false;
	    }
	    else {
	        $("#reg_captcha_error").css({"display": "none"}).text('');
	    }
        if (rtn == true){
            $.ajax({
            	type:"POST",
            	url:"<?php echo base_url('Oxiinc_reseller/reseller_referral'); ?>",
            	data:'reseller_id='+ id +'&employee_id='+ employee_id +'&user_id='+ user_id +'&referral_name='+ referral_name +'&mobile_number='+ mobile_number +'&email='+ email,
            	success:function(data){
            		//alert(data);
        		}
    		});

            $.ajax({
            	type:"POST",
            	url:"<?php echo base_url('Oxiinc_reseller/upload_registration_data'); ?>",
            	data:'full_name='+ full_name +'&password='+ password +'&id='+ id +'&mobileNo='+ mobile_number +'&package='+ package +'&reseller_referral='+ referral_name +'&reseller_referral_emp_code='+ employee_id,
            	success:function(data){
            		//alert(data);
            		$('html, body').animate({scrollTop: '0px'}, 1000);
            		$("#reseller_registration_error_msg").css({"display": "none"}).text('');
					$("#reseller_registration_success_msg").css({"display": "block"}).text("Reseller account successfully created please wait admin approval.");
            		setTimeout(function () {
            			window.location.href = '<?php echo base_url('reseller'); ?>';
            		}, 3000);
            	}
            });
        }
        else{
            return false;
        }
    }
</script>