<form class="form-block edit-profile-details-block" action="<?php echo base_url('Reseller_dashboard/fetch_product_data_update'); ?>" method="post">
    <h2 class="headding-01">Update Product Information Details</h2>
    <input type="hidden" class="textbox" id="id" name="ID" value="<?php echo $product_information[0]['ID'] ?>" readonly>
    <div class="form-group half-width-col">
        <label for="">Product Name</label>
        <input type="text" class="textbox" name="Product_Name" id="Product_Name" value="<?php echo $product_information[0]['Product_Name'];?>" autocomplete="off" required="">
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="">Original Price</label>
        <input type="text" class="textbox" value="<?php echo $product_information[0]['Original_Prices'];?>" readonly>
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="">Price</label>
        <input type="text" class="textbox" value="<?php echo $product_information[0]['Prices'];?>" readonly>
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="">GST Percentage</label>
        <input type="text" class="textbox" value="<?php echo $product_information[0]['GST_Persentage'];?>" readonly>
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="">Shipping Charges</label>
        <input type="text" class="textbox" value="<?php echo $product_information[0]['Shipping_Charges'];?>" readonly>
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="">Product Color</label>
        <input type="text" class="textbox" name="product_color" id="product_color" value="<?php echo $product_information[0]['product_color'];?>" autocomplete="off" required="">
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="InputAccountHolderName">Short Information</label>
        <textarea class="textbox textarea" name="Short_Description" id="Short_Description" rows="3" autocomplete="off" required=""><?php echo $product_information[0]['Short_Description'];?></textarea>
        <span class="bar"></span>
    </div>
    <div class="form-group half-width-col">
        <label for="InputAccountHolderName">Long Information</label>
        <textarea class="textbox textarea" name="large_Description" id="large_Description" rows="3" autocomplete="off" required=""><?php echo $product_information[0]['large_Description'];?></textarea>
        <span class="bar"></span>
    </div>
    <div class="form-group text-center">
        <button type="submit" class="submit-btn">Save Changes</button>
        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
    </div>
</form>
<div class="clrfix"></div>