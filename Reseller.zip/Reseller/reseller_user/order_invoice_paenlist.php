<?php
	$state_query1 =$this->db->query("SELECT state_code FROM states WHERE LOWER(name) = '".strtolower($reseller_company_data[0]['c_state'])."' ");
	$seller_state_array = $state_query1->result_array();
	$seller_state_code = $seller_state_array[0]['state_code'];

	$state_query2 =$this->db->query("SELECT state_code FROM states WHERE LOWER(name) = '".strtolower($Product_invoice[0]['shipping_state'])."' ");
	$shipping_state_array = $state_query2->result_array();
	$shipping_state_code = $shipping_state_array[0]['state_code'];
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php echo $Product_invoice[0]['shipping_Name'];?> Order Invoice</title>
		<style type="text/css">
			* {
				margin: 0;
				padding: 0;
				box-sizing: border-box;
			}

			body {
				margin: 0;
				padding: 0;
				font-family: 'Roboto', sans-serif;
				color: #333333;
				overflow-x: hidden;
				background: #fff;
			}

			.fleft {
				float: left !important;
			}

			.frite {
				float: right !important;
			}

			.clrfix {
				clear: both;
				display: block;
			}

			.demostyle {
				border: solid 1px #ccc;
			}

			.no-margin {
				margin: 0 !important;
			}

			.no-padding {
				padding: 0 !important;
			}

			ul,
			li,
			h1,
			h2,
			h3,
			h4,
			h5,
			h6 {
				margin: 0;
				padding: 0;
				text-align: left;
			}

			a,
			a:hover,
			a:focus,
			 :hover {
				text-decoration: none;
			}

			.invoice-wrapper {
				background: #fff;
				width: 1000px;
				margin: 0 auto;
				border: solid 0 #ccc;
				display: table;
				padding: 20px;
			}

			.fwd {
				width: 100%;
				float: left;
			}

			.half-width {
				width: 50%;
				float: left;
			}

			.main-headding {
				font-size: 25px;
				color: #222;
				font-weight: 600;
				text-align: center;
				text-transform: uppercase;
				letter-spacing: 1px;
				position: relative;
				padding: 0 0 10px 0;
				margin: 0 0 20px 0;
				border-bottom: solid 1px #ccc;
			}

			.headding-01 {
				font-size: 17px;
				color: #222;
				font-weight: 500;
				text-transform: uppercase;
				letter-spacing: 0.50px;
				position: relative;
				padding: 0;
				margin: 0 0 5px 0;
			}

			.headding-02 {
				font-size: 15px;
				color: #222;
				font-weight: 500;
				letter-spacing: 0.50px;
				position: relative;
				padding: 0;
				margin: 0;
			}

			p {
				font-size: 14px;
				margin: 0 0 5px 0;
				line-height: 20px;
			}

			.align-left {
				text-align: left;
			}

			.align-right {
				text-align: right;
			}

			.align-center {
				text-align: center;
			}

			.top-head {
				border-bottom: solid 1px #ccc;
				padding: 0 0 10px 0;
				margin: 0 0 10px 0;
			}

			.top-head .logo-col {
				float: left;
				width: 180px;
			}

			.top-head .logo-col img {
				width: 100%;
			}

			.top-head .address-col {
				width: 50%;
				float: left;
				margin: 0 0 0 40px;
			}

			.top-head .recipt-txt {
				float: right;
				font-size: 18px;
				font-weight: 500;
			}

			.block-01 .half-width {
				width: 48%;
				float: left;
			}

			.block-01 .headding-01 {
				text-decoration: underline;
			}

			.block-01 .info-col {
				width: 100%;
				border: solid 1px #ccc;
				padding: 15px;
				margin: 20px 0 0 0;
			}

			.block-02 {
				margin: 10px 0 10px 0;
			}

			.tbl-col {
				border: solid 1px #ccc;
				font-size: 14px;
				line-height: 22px;
			}

			.tbl-col>tbody>tr>td,
			.tbl-col>tbody>tr>th,
			.tbl-col>tfoot>tr>td,
			.tbl-col>tfoot>tr>th,
			.tbl-col>thead>tr>td,
			.tbl-col>thead>tr>th {
				border: solid 1px #ccc;
				vertical-align: top;
				padding: 10px;
			}

			.barcode-img {
				width: 110px;
			}

			.signature-img {
				width: 200px;
			}

			.block-04 .headding-02 {
				margin-bottom: 5px;
			}
		</style>
	</head>
	<body onload="window.print();">
		<div class="invoice-wrapper">
			<div class="top-head fwd">
				<div class="logo-col"><img src="<?php echo base_url('image/empowers_tred.png');?>" alt="oxiinc"/></div>
				<div class="address-col">
					<h3 class="headding-01">EROCKETMALL ONLINE ASIA LIMITED</h3>
					<p>S6-2, Pinnacle Business Park, Mahakali Caves Rd, 
						Shanti Nagar, Andheri East, Mumbai, Maharashtra 400093 
					</p>
					<p><strong>Tel :</strong> +91 022 68732700 <strong>Email :</strong> digital@oxiinc.in</p>
					<p><strong>PAN No. :</strong> AAHCR0085N <strong>GST No. :</strong> 27AAHCR0085N1ZY</p>
					<p><strong>State Name :</strong> Maharashtra <strong>State Code :</strong> 27 </p>
				</div>
				<div class="recipt-txt">Original for Recipient<br><br><br>
					<p><strong>Invoice Number :</strong> oxiinc<?php echo $Product_invoice[0]['ID'];?></p>
	                <p><strong>Invoice Date :</strong> <?php echo date("d-m-Y");?> </p>
				</div>
			</div>
			<div class="clrfix"></div>
			<div class="block-01 fwd">
				<h2 class="main-headding">Tax Invoice</h2>
				<div class="half-width fleft">
					<h4 class="headding-02">Sold By (From) : </h4>
					<div class="info-col">
						<h3 class="headding-01"><?php echo $reseller_company_data[0]['c_name'];?></h3>
						<p><?php echo $reseller_company_data[0]['c_address'].", ".$reseller_company_data[0]['c_city'].", ".$reseller_company_data[0]['c_district'].", ".$reseller_company_data[0]['c_state'].", ".$reseller_company_data[0]['c_pincode'];?></p>
                        <p><strong>Tel :</strong> +91 <?php echo $reseller_company_data[0]['c_mobile_number'];?> <strong>Email :</strong> <?php echo strtolower($reseller_company_data[0]['c_email']);?></p>
                        <p><strong>PAN No. :</strong> <?php echo $reseller_company_data[0]['c_pan_number'];?> <strong>GST No. :</strong> <?php echo $reseller_company_data[0]['c_gst_number'];?></p>
                        <p><strong>State Name :</strong> <?php echo $reseller_company_data[0]['c_state'];?> <strong>State Code :</strong> <?php echo $seller_state_code;?></p>
                        <p><strong>Order Number :</strong> <?php echo $Product_invoice[0]['txnid'];?></p>
                        <p><strong>Order Date :</strong> <?php echo date("d-m-Y", strtotime($Product_invoice[0]['order_year_month_data'])); ?></p>
					</div>
				</div>
				<div class="half-width frite">
					<h4 class="headding-02">Shipping Address (To) : </h4>
					<div class="info-col">
						<h3 class="headding-01"><?php echo $Product_invoice[0]['shipping_Name'];?></h3>
						<p><?php echo $Product_invoice[0]['shipping_address_in'].", ".$Product_invoice[0]['shipping_Landmark'].", ".$Product_invoice[0]['shipping_Locality'].", ".$Product_invoice[0]['shipping_City'].", ".$Product_invoice[0]['shipping_state'].", ".$Product_invoice[0]['shipping_Pincode'];?></p>
                        <p>Contact Number : <?php echo $Product_invoice[0]['shipping_Phone_number'].", ".$Product_invoice[0]['shipping_Alternate_Phone'];?></p>
                        <p><strong>Place of Supply :</strong> <?php echo ($reseller_company_data[0]['c_state']) ? $reseller_company_data[0]['c_state'] : 'Maharashtra' ;?></p>
                        <p><strong>Place of Delivery :</strong> <?php echo $Product_invoice[0]['shipping_state'];?> <strong>State Code : </strong><?php echo $shipping_state_code;?></p>
					</div>
				</div>
			</div>
			<div class="clrfix"></div>
			<div class="block-02 fwd">
				<table class="tbl-col" style="width:100%">
					<thead>
						<tr>
							<th>Sr No</th>
							<th>Product Name</th>
							<th>HSN Code</th>
							<th>Qty</th>
							<th>Product MRP Price</th>
							<th>Total Discount</th>
							<th>Product Unit Price</th>
							<th style="width: 150px;">Net Amount</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<?php
								$product_unit_price = $Product_invoice[0]['Prices'] / $Product_invoice[0]['product_qty'];
								$total_discount = ($Product_invoice[0]['Original_Prices'] - $product_unit_price) * $Product_invoice[0]['product_qty'];
								$net_amount = $Product_invoice[0]['Prices'];
								$shipping_charges = $Product_invoice[0]['Shipping_Charges'];
								$cgst = ($Product[0]['GST_Persentage'] / 2);
								$sgst = ($Product[0]['GST_Persentage'] / 2);
								$igst = ($Product[0]['GST_Persentage']) ? $Product[0]['GST_Persentage'] : 0;
								$cgst_amount = $net_amount * $cgst / 100;
								$sgst_amount = $net_amount * $sgst / 100;
								$igst_amount = $net_amount * $igst / 100;
								$paid_amount = $net_amount + $cgst_amount + $sgst_amount + $shipping_charges;
							?>
							<td>1</td>
							<td><?php echo $Product_invoice[0]['Product_Name'];?></td>
							<td class="align-center"><?php echo $Product[0]['hsn_code'];?></td>
							<td class="align-center"><?php echo $Product_invoice[0]['product_qty'];?></td>
							<td class="align-center"><?php echo number_format($Product_invoice[0]['Original_Prices'], 2);?></td>
							<td class="align-center"><?php echo number_format($total_discount , 2);?></td>
							<td class="align-center"><?php echo number_format($product_unit_price, 2);?></td>
							<td class="align-right"><?php echo number_format($net_amount, 2);?></td>
						</tr>
						<tr>
							<td colspan="4" class="align-center">
								<?php 
					                if(!empty($Product_invoice[0]['user_id'])){
					                $qr_code_array = array('order_id' => $Product_invoice[0]['ID'], 'user_type_role' => '1', 'salt' => SALT);
					                   $order_id = rtrim(base64_encode(serialize($qr_code_array)), '=');
					                 ?>
					                <img src="https://chart.googleapis.com/chart?chs=150x160&amp;cht=qr&amp;chl=https://www.enexpress.in/received_qrcode_scan/<?php echo $order_id; ?>&amp;choe=UTF-8" class="barcode-img">
					            <?php } else{ ?>
									<!-- <img src="barcode-img.png" alt="" class="barcode-img"/> <br> -->
					            <?php } ?>
							</td>
							<td colspan="3">
								Taxable Value <br>
								CGST @ <?php echo $cgst;?>% <br>
								SGST @ <?php echo $sgst;?>% <br>
								IGST @ <?php echo $igst;?>% <br>
								Shipping Charges <br>
								TOTAL <strong>(Inclusive of all taxes)</strong>
							</td>
							<td colspan="2" class="align-right">
								<?php echo number_format($net_amount, 2);?> <br>
								<?php
									if ($seller_state_code == $shipping_state_code){
										echo number_format($cgst_amount, 2).'<br>';
										echo number_format($sgst_amount, 2).'<br>';
										echo '-<br>';
									} else{
										echo '-<br>';
										echo '-<br>';
										echo number_format($igst_amount, 2).'<br>';
									}
								?>
								<?php echo number_format($shipping_charges, 2);?><br>
								<b><?php echo number_format($paid_amount, 2);?><b>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="7">Amount Paid <strong>(Inclusive of Taxes)</strong></td>
							<td colspan="2" class="align-right"><b>Rs. <?php echo number_format($paid_amount, 2);?></b></td>
						</tr>
						<tr class="align-left">
							<th colspan="4">
								Amount chargeable (in words) <br> <?php echo convertToIndianCurrency($paid_amount);?>
							</th>
							<th colspan="5">
								Company's Bank Details <br>
								Bank Name : HDFC BANK LTD Branch : MIDC 47 Andheri <br>
								Account No. : 50200037908477 IFSC Code : HDFC0009358
							</th>
						</tr>
					</tfoot>
				</table>
			</div>
			<div class="clrfix"></div>
			<div class="block-03 fwd">
				<div class="half-width">
					<p><strong>Have a question? Our 9x7 customer service is here to help<br>
						022-6157-6157 from 10.00 AM to 7:00 PM.</strong>
					</p>
				</div>
				<div class="half-width align-right">
					<?php
					if($reseller_signature){ ?>
                        <img src="<?php echo $reseller_signature;?>" class="signature-img"/>
                    <?php } else{ ?>
                    	<br><br>
                    <?php } ?>
					<p>For <?php echo $reseller_company_data[0]['c_name'];?></p>
				</div>
			</div>
			<div class="clrfix"></div>
			<div class="block-04 fwd">
				<h4 class="headding-02">Disclaimer : </h4>
				<p>1. This invoice Is generated and issued on behalf of and under the instructions of the Merchant mentioned in this invoice. The goods described in this invoice are sold to the Customer by the Merchant and not by Erocketmall Online Asia Limited. Erocketmall Online Asia Limited has merely facilitated the sale and purchase between the Merchant and the Customer and the Merchant is responsible and liable for all the warranties, quality, merchantability etc. of the goods mentioned herein. Erocketmall Online Asia Limited is not an agent and shall not be deemed to be construed as an agent of Merchant. <br>
				2. The goods sold as part of this shipment are intended for end user consumption and not for re-sale. <br>
				</p>
			</div>
		</div>
	</body>
</html>