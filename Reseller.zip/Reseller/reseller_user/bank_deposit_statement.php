<!-- Start Container -->
<div class="main-wrapper">
	<!-- Company Details Section -->
	<section class="user-info-section-02 fwd">
		<div class="container">
			<h1 class="mainpage-headding">Bank Deposit <span>Statement</span></h1>
			<div class="form-sucessmsg" id="ajax_update_success_msg" style="display:none;"></div>
			<div class="form-errormsg" id="ajax_update_error_msg" style="display:none;"></div>
			<div class="package-material-container bank-statement-container form-content-block">
				<h3 class="headding-02">Digital Bank Details</h3>
				<div class="tbl-responsive">
					<table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Bank Name</th>
								<th>Account No</th>
								<th>IFSC Code</th>
								<th>Address</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>EROCKETMALL ONLINE ASIA LIMITED</td>
								<td>HDFC BANK LTD</td>
								<td>50200038864387</td>
								<td>HDFC0009358</td>
								<td>HDFC BANK LTD, GROUND FLOOR OPUS CENTER 47 MIDC, OPP TUNGA HOTEL, ANDHERI EAST MUMBAI MAHARASHTRA 400093.</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="form-content-block">
				<form class="form-block">
					<div class="form-block half-width fleft">
						<div class="form-group">
							<label for="">Payment Mode</label>
							<select class="textbox input-selectbox" id="payment_mode" autocomplete="off">
								<option value="NEFT">NEFT</option>
			                    <option value="RTGS" >RTGS</option>
			                    <option value="RTGS">IMPS</option>
			                    <option value="UPI">UPI</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Amount</label>
							<input type="text" class="textbox" id="amount" onkeypress="return isNumberKey(event)" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" id="amount_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Remark</label>
							<input type="text" class="textbox" id="remark" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" id="remark_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Branch Deposit Bank</label>
							<input type="text" class="textbox" id="branchdepositebank" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" id="branch_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Payment Deposit Time</label>
							<input type="time" class="textbox" id="payment_depositetime" value="<?php echo date("H:i:s"); ?>" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;"></div>
						</div>
					</div>
					<div class="form-block half-width frite">
						<div class="form-group">
							<label for="">Payee Bank</label>
							<input type="text" class="textbox" id="payee_bank" value="HDFC BANK LTD" readonly="" autocomplete="off">
							<span class="bar"></span>
						</div>
						<div class="form-group">
							<label for="">Images</label>
							<input type="file" id="bank_deposit_image" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="upload_deposit_btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="upload_deposit_text" class="upload-text">No file chosen, yet.</span>
							<div class="input-erroemsg" id="deposit_image_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Transcation Number</label>
							<input type="text" class="textbox" id="transcation_number" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" id="transcation_error" style="display:none;"></div>
						</div>
						<div class="form-group">
							<label for="">Payment Deposit Date</label>
							<div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
								<input class="textbox" type="text" id="payment_depositedate" readonly />
								<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
							</div>
							<div class="input-erroemsg" style="display:none;">Please select Date</div>
						</div>
						<div class="form-group">
							<label for="">Package</label>
							<select class="textbox input-selectbox" id="package" autocomplete="off">
								<option value="Silver">Silver</option>
			                    <option value="Gold">Gold</option>
			                    <option value="Platinum">Platinum</option>
			                    <option value="Reseller Club">Reseller Club</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;"></div>
						</div>
					</div>
					<div class="form-group text-center">
						<button type="button" class="submit-btn" id="bank_deposite_statement">Submit</button>
						<!-- <button  class="submit-btn" tabindex="3" onclick="cancelled_cheque_validation();">Save</button> -->
					</div>
				</form>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	const realFileBtn = document.getElementById("bank_deposit_image");
	const customBtn = document.getElementById("upload_deposit_btn");
	const customTxt = document.getElementById("upload_deposit_text");

	customBtn.addEventListener("click", function() {
		realFileBtn.click();
	});

	realFileBtn.addEventListener("change", function() {
		if (realFileBtn.value) {
			customTxt.innerHTML = realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
		} else {
			customTxt.innerHTML = "No file chosen, yet.";
		}
	});

  	$('#bank_deposite_statement').click(function(){
	  	var rtn = true;
	  	var amount = $('#amount').val();
	  	var bank_deposit_image = $('#bank_deposit_image').val();
	  	var remark = $('#remark').val();
	  	var transcation_number = $('#transcation_number').val();
	  	var branchdepositebank = $('#branchdepositebank').val();

	  	var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var uploadFile = document.getElementById("bank_deposit_image").files[0];

	  	if(amount == ""){
            $("#amount_error").css({"display": "block"}).text('Please Enter Your Amount.');
            rtn = false;
	    }
	    else {
	        $("#amount_error").css({"display": "none"}).text('');
	    }

	    if(bank_deposit_image == ""){
	        $("#deposit_image_error").css({"display": "block"}).text('Please Upload Bank Deposit Image.');
	        rtn = false;
	    } else if ($.inArray(uploadFile.type.toLowerCase(), validImageTypes) < 0){
            $("#deposit_image_error").css({"display": "block"}).text("Please select correct image formate, e.g. - png, jpg, jpeg.");
            rtn = false;
        }
	    else {
	        $("#deposit_image_error").css({"display": "none"}).text('');
	    }

	    if(remark == ""){
            $("#remark_error").css({"display": "block"}).text('Please Enter Bank Deposit Remark.');
            rtn = false;
        }
        else {
            $("#remark_error").css({"display": "none"}).text('');
        }

        if(transcation_number == ""){
            $("#transcation_error").css({"display": "block"}).text('Please Enter Transcation Number.');
            rtn = false;
        }
        else {
            $("#transcation_error").css({"display": "none"}).text('');
        }

        if(branchdepositebank == ""){
            $("#branch_error").css({"display": "block"}).text('Please Enter Branch Deposite Bank.');
            rtn = false;
        }
        else {
            $("#branch_error").css({"display": "none"}).text('');
        }

        if (rtn == true){
        	var form_data = new FormData();
			form_data.append("images", document.getElementById("bank_deposit_image").files[0]);
			form_data.append("payment_mode", $('#payment_mode').val());
			form_data.append("payee_bank", $('#payee_bank').val());
			form_data.append("amount", $('#amount').val());
			form_data.append("remark", $('#remark').val());
			form_data.append("transcation_number", $('#transcation_number').val());
			form_data.append("branchdepositebank", $('#branchdepositebank').val());
			form_data.append("payment_depositedate", $('#payment_depositedate').val());
			form_data.append("payment_depositetime", $('#payment_depositetime').val());
			form_data.append("package", $('#package').val());

            $.ajax({
            	type: "POST",
				url:"<?php echo base_url('Reseller_dashboard/add_bank_deposit_statement'); ?>",
				data: form_data,
				contentType: false,
				cache: false,
				processData: false,
                success:function(data){
                    var obj = JSON.parse(data);
                    //alert(obj.status);
                    //alert(obj.message);
                    if(obj.status == 'error'){
                    	$('html, body').animate({scrollTop: '0px'}, 1000);
                    	$("#ajax_update_error_msg").css({"display": "block"}).text(obj.message);
                    }
                    if(obj.status == 'success'){
                    	$('html, body').animate({scrollTop: '0px'}, 1000);
                    	$("#ajax_update_error_msg").css({"display": "none"}).text('');
                    	$("#ajax_update_success_msg").css({"display": "block"}).text(obj.message);
	                    setTimeout(function (){
	                    	window.location.href = '<?php echo base_url('Reseller_dashboard/view_bank_deposit_statement'); ?>';
	                	}, 5000);
                	}
                }
            });
        }
        else{
            return false;
        }
	});
</script>

