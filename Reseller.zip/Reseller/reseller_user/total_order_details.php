<!-- Start Container -->
<?php
    if ($this->uri->segment(2)=="total_order"){
        $page_heading =  "Total Order";
    } elseif ($this->uri->segment(2)=="order_confirm"){
        $page_heading =  "Order confirm";
    } elseif ($this->uri->segment(2)=="order_packed"){
        $page_heading =  "Order packed confirm";
    } elseif ($this->uri->segment(2)=="order_shipped"){
        $page_heading =  "Order Shipping confirm";
    } elseif ($this->uri->segment(2)=="order_intransit"){
        $page_heading =  "Order Intransit confirm";
    } elseif ($this->uri->segment(2)=="order_out_for_delivery"){
        $page_heading =  "Order out for delivery";
    } elseif ($this->uri->segment(2)=="order_delivered"){
        $page_heading =  "Total Order Delivered";
    }
?>
<div class="main-wrapper">
	<!-- Order Status Section-01 Start -->
	<section class="order-status-section-01 fwd">
		<div class="container-fluid">
			<h1 class="mainpage-headding"><?php echo $page_heading;?></h1>
			<div class="data-table-block form-content-block">
				<?php
                    if(isset($order_data) && !empty($order_data)){ ?>
                        <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Order <br>ID</th>
                                    <th>Image</th>
                                    <th>Product Name</th>
                                    <th>Customer Name</th>
                                    <th>Contact Number</th>
                                    <th>Unit Price</th>
                                    <th>Qty</th>
                                    <th>Total Price</th>
                                    <th>GST %</th>
                                    <th>GST Price</th>
                                    <th>Shipping <br>Charges</th>
                                    <th>Grand <br>Total Price</th>
                                    <th>Size</th>
                                    <th>Order Date</th>
                                    <th>Delivered Date</th>
                                    <th>Transaction Id#</th>
                                    <?php if ($this->uri->segment(2) == 'order_confirm') { ?>
                                            <th>Order Packed Confirmation</th>
                                    <?php } elseif($this->uri->segment(2) == 'order_packed'){  ?>
                                            <th>Order Shipped Confirmation</th>
                                    <?php } elseif($this->uri->segment(2) == 'order_shipped'){ ?>
                                            <th>Order In Transit Confirmation</th> 
                                    <?php } elseif($this->uri->segment(2) == 'order_intransit'){ ?>
                                            <th>Order Delivery Confirmation</th>
                                    <?php } elseif($this->uri->segment(2) == 'order_out_for_delivery'){ ?>
                                        <th>Order Delivered Confirmation</th>
                                    <?php } elseif($this->uri->segment(2) == 'order_delivered'){ ?>
                                        <th>Order Delivered</th>
                                    <?php } else{ ?>
                                        <th>Order Confirmation</th>
                                        <th>Order Packed Confirmation</th>
                                        <th>Order Shipped Confirmation</th>
                                        <th>Order In Transit Confirmation</th>
                                        <th>Order Delivery Confirmation</th>
                                        <th>Order Delivered</th>
                                        <?php
                                    }
                                    ?>
                                    <th>View Details</th>
                                    <th>Print Invoice</th>
                                    <?php if($this->uri->segment(2) == 'order_confirm'){ ?>
                                        <th>Order Cancel</th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //echo "<pre>";print_r($order_data);die();
                                //echo $this->session->userdata('r_email');die();
                                $check_query = $this->db->query("SELECT COUNT(id) AS count FROM packing_material_bank_deposite_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 1 AND delivery_status = 1 ");
                                $check_reseller = $check_query->result_array();
                                $reseller_count = $check_reseller[0]['count'];
                                if ($reseller_count > 0) {
                                    $status = 1;
                                    $delivery_status = 1;
                                }
                                else{
                                    $status = 0;
                                    $delivery_status = 0;
                                }
                                $i = 1;
                                //echo "<pre>";print_r($order_data);die();
                                $condition_date = '2020-11-15';
                                if(isset($order_data) && !empty($order_data)) foreach ($order_data as $key => $value){
                                    $gst_query = $this->db->query("SELECT GST_Persentage FROM wellness WHERE reseller_id = ".$this->session->userdata('r_id')." AND ID = ".$value['product_id']);
                                    $gst = $gst_query->result_array();
                                    $gst_persentage = $gst[0]['GST_Persentage'];
                                    $total_price = $value['reseller_sold_price'];
                                    $gst_price = ($total_price * $gst_persentage) / 100;
                                    $grand_total_price = $total_price + $value['Shipping_Charges'] + $gst_price;
                                    $order_delivered_datetime = explode(" ", $value['order_delivered_datetime']);
                                    ?>
                                        <tr>
                                            <td><?php echo $i++;?></td>
                                            <td><?php echo $value['order_id'];?></td>
                                            <td><img src="<?php echo $value['Product_Picture'];?>" alt="<?php echo $value['Product_Name'];?>" style="width: 100px;height: 100px" /></td>
                                            <td><?php echo $value['Product_Name'];?></td>
                                            <td><?php echo $value['customer_name'];?></td>
                                            <td><?php echo $value['mobile'];?></td>
                                            <td><?php echo ($value['reseller_sold_price'] / $value['product_qty']);?></td>
                                            <td><?php echo $value['product_qty'];?></td>
                                            <td><?php echo $total_price;?></td>
                                            <?php
                                                if ($order_delivered_datetime[0] > $condition_date){ ?>
                                                    <td><?php echo $gst_persentage;?></td>
                                                    <td><?php echo $gst_price;?></td>
                                                    <td><?php echo $value['Shipping_Charges'];?></td>
                                                    <td><?php echo $grand_total_price;?></td>
                                                    <?php
                                                } else { ?>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <?php
                                                }
                                            ?>
                                            <td><?php echo $value['size'];?></td>
                                            <td><?php echo date("d-m-Y H:i:s", strtotime($value['order_date']));?></td>
                                            <td class="text-center"><?php echo ($value['order_delivered_datetime']) ? date("d-m-Y H:i:s", strtotime($value['order_delivered_datetime'])) : '-';?></td>
                                            <td><?php echo $value['transaction_id'];?></td>
                                            <?php
                                                if ($this->uri->segment(2) == 'order_confirm') { ?>
                                                    <td><button type="button" class="status-done" data-toggle="modal" onclick="order_confirmation(<?php echo $value['order_id'];?>, <?php echo $value['dispatchment_confirmation'];?>, '<?php echo $value['user_type'];?>', 'order_packed_confirmation');"><?php echo ($value['dispatchment_confirmation'] == 1) ? 'Order Packed Confirm' : 'Order Packed Pending';?></button></td>
                                                <?php } elseif($this->uri->segment(2) == 'order_packed'){ ?>
                                                <td><button type="button" class="status-done" data-toggle="modal" onclick="order_confirmation(<?php echo $value['order_id'];?>, <?php echo $value['shipping_confirmation'];?>, '<?php echo $value['user_type'];?>', 'order_shipping_confirmation');"><?php echo ($value['shipping_confirmation'] == 1) ? 'Order Shipping Confirm' : 'Order Shipping Pending';?></button></td>
                                                <?php } elseif($this->uri->segment(2) == 'order_shipped'){ ?>
                                                <td><button type="button" class="status-done" data-toggle="modal" onclick="order_confirmation(<?php echo $value['order_id'];?>, <?php echo $value['order_intransit'];?>, '<?php echo $value['user_type'];?>', 'order_intransit_confirmation');"><?php echo ($value['order_intransit'] == 1) ? 'Order Intransit Confirm' : 'Order Not intransit Pending';?></button></td>
                                                <?php } elseif($this->uri->segment(2) == 'order_intransit'){ ?>
                                                <td><button type="button" class="status-done" data-toggle="modal" onclick="order_confirmation(<?php echo $value['order_id'];?>, <?php echo $value['out_for_delivery'];?>, '<?php echo $value['user_type'];?>', 'order_delivery_confirmation');"><?php echo ($value['out_for_delivery'] == 1) ? 'Order Out For Delivery Confirm' : 'Order Out For Delivery Pending';?></button></td>
                                                <?php } elseif($this->uri->segment(2) == 'order_out_for_delivery'){ ?>
                                                    <td><button type="button" class="status-done" data-toggle="modal" onclick="order_confirmation(<?php echo $value['order_id'];?>, <?php echo $value['order_delivered'];?>, '<?php echo $value['user_type'];?>', 'order_delivery_success');"><?php echo ($value['order_delivered'] == 1) ? 'order Delivered Confirm' : 'Order Delivered Pending';?></button></td>
                                                    <!-- <td><button type="button" class="status-done" onclick="return confirm('Some work is going on Please wait some time.')"><?php //echo ($value['order_delivered'] == 1) ? 'order Delivered Confirm' : 'Order Delivered Pending';?></button></td> -->
                                                <?php } elseif($this->uri->segment(2) == 'order_delivered'){ ?>
                                                    <td><button type="button" class="status-done"><?php echo ($value['order_delivered'] == 1) ? 'Order Delivered' : 'Order Delivered Failed';?></button></td>
                                                <?php } else{ ?>
                                                    <td><button type="button" class="status-done"><?php echo ($value['order_confirmation'] == 1) ? 'Order Confirm' : 'Order Pending';?></button></td>
                                                    <td><button type="button" class="status-done"><?php echo ($value['dispatchment_confirmation'] == 1) ? 'Order Packed Confirm' : 'Order Packed Pending';?></button></td>
                                                    <td><button type="button" class="status-done"><?php echo ($value['shipping_confirmation'] == 1) ? 'Order Shipping Confirm' : 'Order Shipping Pending';?></button></td>
                                                    <td><button type="button" class="status-done"><?php echo ($value['order_intransit'] == 1) ? 'Order Intransit Confirm' : 'Order Not intransit Pending';?></button></td>
                                                    <td><button type="button" class="status-done"><?php echo ($value['out_for_delivery'] == 1) ? 'Order Out For Delivery Confirm' : 'Order Not Out For Delivery Pending';?></button></td>
                                                    <td><button type="button" class="status-done"><?php echo ($value['order_delivered'] == 1) ? 'Order Delivered' : 'Order Delivered Pending';?></button></td>
                                                <?php } ?>
                                            <td><a href="<?php echo site_url('Reseller_dashboard/order_view/'.$value['order_id']);?>"><button type="button" class="status-done">View Details</button></a></td>
                                            <?php
                                                if ($reseller_count > 0 && $status == 1 && $delivery_status == 1){ ?>
                                                    <td><a href="<?php echo site_url('Reseller_dashboard/reseller_order_invoice/'.$value['order_id'].'/'.$value['user_role']);?>" target="_blank"><button type="button" class="status-done">Print Invoice</button></a></td>
                                                    <?php
                                                }
                                                else{ ?>
                                                    <td><button type="button" class="status-done" onclick="print_invoice();">Print Invoice</button></td>
                                                    <?php
                                                }
                                            ?>
                                            <?php if($this->uri->segment(2) == 'order_confirm'){ ?>
                                                <td><button type="button" class="status-reject" onclick="cancle_order_show_model(<?php echo $value['order_id'] .','. $value['user_role'];?>);">Order Cancel</button></td>
                                            <?php } ?>
                                        </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <?php
                    }
                    else{ ?>
                        <h4 style="color: red; text-align: center;">Not Have Any Product Order Yet.</h4>
                    <?php } ?>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<!-- Order Remark Modal -->
<div class="modal fade modal-block" id="packing_material_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">Update Order Remark</h2>
                        <div class="form-sucessmsg" id="order_remark_success" style="display:none;"></div>
                        <div class="form-errormsg" id="order_remark_fail" style="display:none;"></div>
                        <div class="form-group">
                            <label for="">Order Remark</label>
                            <textarea class="textbox textarea" name="order_remark" id="order_remark" rows="3" autocomplete="off" required style="resize: none; border-color: #000;"></textarea>
                            <span class="bar"></span>
                            <div id="order_remark_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                        	<input type="hidden" class="textbox" name="order_id" id="order_id" readonly>
		                    <input type="hidden" class="textbox" name="update_value" id="update_value" readonly>
		                    <input type="hidden" class="textbox" name="user_type" id="user_type" readonly>
		                    <input type="hidden" class="textbox" name="method_name" id="method_name" readonly>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="submit-btn" onclick="update_confirmation();">submit</button>
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Order Cancle Modal -->
<div class="modal fade modal-block" id="order_cancel_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">Cancel Order Remark</h2>
                        <div class="form-sucessmsg" id="cancel_order_success" style="display:none;"></div>
                        <div class="form-errormsg" id="cancel_order_fail" style="display:none;"></div>
                        <div class="form-group">
                            <label for="">Cancellation Reason</label>
                            <select class="textbox input-selectbox" name="reason_info" id="reason_info" autocomplete="off">
                                <option value="">Select Cancellation Reason </option>
                                <option value="Product out of stock">Product out of stock</option>
                                <option value="Product risk factor">Product risk factor</option>
                                <option value="Products returned due to short address">Products returned due to short address</option>
                                <option value="Customer not contactable">Customer not contactable</option>
                                <option value="Duplicate Order">Duplicate Order</option>
                                <option value="Ordered By Mistake">Ordered By Mistake</option>
                                <option value="Delayed Delivery Cancellation">Delayed Delivery Cancellation</option>
                                <option value="Product not required anymore">Product not required anymore</option>
                                <option value="Wants to change style or color">Wants to change style or color</option>
                                <option value="Incorrect size ordered">Incorrect size ordered</option>
                            </select>
                            <div id="cancel_reason_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">Cancellation Remark</label>
                            <textarea class="textbox textarea" name="Cancellation_info" id="Cancellation_info" rows="3" autocomplete="off" required style="resize: none; border-color: #000;"></textarea>
                            <span class="bar"></span>
                            <div id="cancel_remark_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="textbox" name="ID" id="ID" readonly>
                            <input type="hidden" class="textbox" name="cancel_user_type" id="cancel_user_type" readonly>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="submit-btn" onclick="cancle_order_submit();">submit</button>
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function order_confirmation(order_id, update_value, user_type, method_name) {
        var reseller_count = '<?php echo $reseller_count; ?>';
        var status = '<?php echo $status; ?>';
        var delivery_status = '<?php echo $delivery_status; ?>';
        if (reseller_count == 0) {
            Swal.fire({
                icon: 'info',
                text: 'First Purchase packing material after you can Order Packed Confirmation.',
                footer: '<a href="<?php echo site_url('pack_add');?>">Purchase packing material</a>'
            });
            return false;
        }

        if (status == 0) {
            Swal.fire({
                icon: 'info',
                text: 'Please wait some time. You are Order packing material but Your payment is not approved by admin.'
            });
            return false;
        }

        if (delivery_status == 0) {
            Swal.fire({
                icon: 'info',
                text: 'Please wait some time. Your packing materials are Confirm After Some time its delivered by admin.'
            });
            return false;
        }

        if (reseller_count > 0 && status == 1 && delivery_status == 1) {
            $('#packing_material_model').modal('show');
            document.getElementById("order_id").value = order_id;
            document.getElementById("update_value").value = update_value;
            document.getElementById("user_type").value = user_type;
            document.getElementById("method_name").value = method_name;
            return true;
        }
    }

    function update_confirmation(){
        var order_remark = $('#order_remark').val();
        var order_id = $('#order_id').val();
        var update_value = $('#update_value').val();
        var user_type = $('#user_type').val();
        var method_name = $('#method_name').val();
        if (order_remark) {
            $.ajax({
                url: "<?php echo base_url('Reseller_dashboard/');?>" + method_name,
                type: "POST",
                data: 'order_id=' + order_id + '&update_value=' + update_value + '&user_type=' + user_type + '&order_remark=' + order_remark + '&submit=' + 'update',
                dataType:"text",
                success: function(res){
                    //alert(res);exit();
                    $("#order_remark_error").css({"display": "none"}).text('');
                    $("#order_remark_fail").css({"display": "none"}).text('');
                    $("#order_remark_success").css({"display": "none"}).text('');
                    
                    if(res == 'error_1'){
                        $("#order_remark_fail").css({"display": "block"}).text("Order remark updated status failed.");
                    } else if (res == 'error_2'){
                        $("#order_remark_fail").css({"display": "block"}).text("Something went worng to updated order remark.");
                    } else if (res == 'error_3'){
                        $("#order_remark_fail").css({"display": "block"}).text("Your order has been already delivered.");
                    } else{
                        $("#order_remark_success").css({"display": "block"}).text("Order remark updated successfully.");
                    }
                    setTimeout(function(){
                        location.reload();
                    }, 1000);
                }
            });
        }
        else{
            $("#order_remark_error").css({"display": "block"}).text('Please Enter Order Remark.');
            return false;
        }
    }

    function print_invoice() {
        var reseller_count = '<?php echo $reseller_count; ?>';
        var status = '<?php echo $status; ?>';
        var delivery_status = '<?php echo $delivery_status; ?>';
        if (reseller_count == 0) {
            Swal.fire({
                icon: 'info',
                text: 'You could not print invoice without purchase packing materials.',
                footer: '<a href="<?php echo site_url('pack_add');?>">Purchase packing material</a>'
            });
            return false;
        }

        if (status == 0) {
            Swal.fire({
                icon: 'info',
                text: 'Your Order packing material Is Confirmed. But Your payment is not approved by admin so its not delivered. Once It Is Delivered By Admin, Then You Will Be Allowed to Print Invoice.'
            });
            return false;
        }

        if (delivery_status == 0) {
            Swal.fire({
                icon: 'info',
                text: 'Your Packing Material Is Confirmed. Once It Is Delivered By Admin, Then You Will Be Allowed to Print Invoice.'
            });
            return false;
        }
    }
    function cancle_order_show_model(ID, cancel_user_type) {
        $('#order_cancel_modal').modal('show');
        document.getElementById("ID").value = ID;
        document.getElementById("cancel_user_type").value = cancel_user_type;
    }

    function cancle_order_submit(){
        var rtn = true;
        var ID = $('#ID').val();
        var cancel_user_type = $('#cancel_user_type').val();
        var reason_info = $('#reason_info').val();
        var Cancellation_info = $('#Cancellation_info').val();

        if(Cancellation_info == ""){
            $("#cancel_remark_error").css({"display": "block"}).text('Please Enter Order Cancellation Remark.');
            $("#Cancellation_info").focus();
            rtn = false;
        }
        else {
            $("#cancel_remark_error").css({"display": "none"}).text('');
        }
        if(reason_info == ""){
            $("#cancel_reason_error").css({"display": "block"}).text('Please Select Order Cancellation Reason.');
            $("#reason_info").focus();
            rtn = false;
        }
        else {
            $("#cancel_reason_error").css({"display": "none"}).text('');
        }
        if (rtn == true){
            $.ajax({
                url: "<?php echo base_url('Reseller_dashboard/order_cancellation_request');?>",
                type: "POST",
                data: 'ID=' + ID + '&cancel_user_type=' + cancel_user_type + '&reason_info=' + reason_info + '&Cancellation_info=' + Cancellation_info,
                dataType:"text",
                success: function(data){
                    var obj = JSON.parse(data);
                    if(obj.status == 'success'){
                        $("#cancel_order_success").css({"display": "block"}).text(obj.message);
                    }
                    if(obj.status == 'error'){
                        $("#cancel_order_fail").css({"display": "block"}).text(obj.message);
                    }
                    setTimeout(function() {
                        location.reload();
                    }, 3000);
                }
            });
        }
        else{
            return false;
        }
    }
</script>