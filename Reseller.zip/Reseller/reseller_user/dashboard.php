<!-- Start Container -->
<div class="main-wrapper">
    <!-- Dashboard Section-01 Start -->
    <section class="dashboard-section-01 fwd">
        <div class="container-fluid">
            <!-- Flash Success and Error Message Code Start Here -->
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <!-- Flash Success and Error Message Code End Here -->
            <div class="dashboard-panel-01">
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Useful Links</h3>
                    <ul class="list-unstyled links-col">
                        <li><a href="javascript:void(0);"><i class="fas fa-chalkboard-teacher"></i> Reseller Learning Center</a></li>
                        <li><a href="javascript:void(0);"><i class="fas fa-user-friends"></i> Star Reseller Community</a></li>
                        <li><a href="javascript:void(0);"><i class="fas fa-user"></i> Manage Your Profile</a></li>
                    </ul>
                </div>
            </div>
            <div class="dashboard-panel-02">
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Seller Fulfilled Orders</h3>
                    <ul class="list-inline order-list">
                        <!-- <li>
                            <a href="<?php //echo base_url('Reseller_dashboard/total_order');?>" class="order-info-content">
                                <div class="order-number"><?php //echo $total_order;?></div>
                                <div class="order-title">Total Orders</div>
                            </a>
                        </li> -->
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/order_confirm');?>" class="order-info-content">
                                <div class="order-number"><?php echo $order_confirm;?></div>
                                <div class="order-title">Order Confirm</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/order_packed');?>" class="order-info-content">
                                <div class="order-number"><?php echo $order_packed;?></div>
                                <div class="order-title">Order Packed Confirm</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/order_shipped');?>" class="order-info-content">
                                <div class="order-number"><?php echo $order_shipped;?></div>
                                <div class="order-title">Order Shipped Confirm</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/order_intransit');?>" class="order-info-content">
                                <div class="order-number"><?php echo $order_intransit;?></div>
                                <div class="order-title">Order In Transit Confirm</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/order_out_for_delivery');?>" class="order-info-content">
                                <div class="order-number"><?php echo $order_out_for_delivery;?></div>
                                <div class="order-title">Order Delivery Confirm</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/order_delivered');?>" class="order-info-content">
                                <div class="order-number"><?php echo $order_delivered;?></div>
                                <div class="order-title">Total Delivered</div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Product Listings</h3>
                    <ul class="list-inline order-list">
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/pending_product_list');?>" class="order-info-content">
                                <div class="order-number"><?php echo $pending_product;?></div>
                                <div class="order-title">Pending</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/approved_product_list');?>" class="order-info-content">
                                <div class="order-number"><?php echo $approved_product;?></div>
                                <div class="order-title">Approved</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/rejected_product_list');?>" class="order-info-content">
                                <div class="order-number"><?php echo $rejected_product;?></div>
                                <div class="order-title">Rejected</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/out_of_stock_product_list');?>" class="order-info-content">
                                <div class="order-number"><?php echo $out_of_stock_product;?></div>
                                <div class="order-title">Out of Stock</div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Returns and SPF Claims</h3>
                    <ul class="list-inline order-list">
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number">0</div>
                                <div class="order-title">Total Returns</div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number"><?php echo $total_cancle_order;?></div>
                                <div class="order-title">Total cancelled</div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number">0</div>
                                <div class="order-title">Delivered</div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number">0</div>
                                <div class="order-title">Delivery Returned</div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Packing Material Listings</h3>
                    <ul class="list-inline order-list">
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/packing_material_pending');?>" class="order-info-content">
                                <div class="order-number"><?php echo $packing_material_pending;?></div>
                                <div class="order-title">Pending</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/packing_material_approved');?>" class="order-info-content">
                                <div class="order-number"><?php echo $packing_material_approved;?></div>
                                <div class="order-title">Approved</div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/packing_material_rejected');?>" class="order-info-content">
                                <div class="order-number"><?php echo $packing_material_rejected;?></div>
                                <div class="order-title">Rejected</div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Wallet Statement</h3>
                    <ul class="list-inline order-list">
                        <li>
                            <a href="<?php echo base_url('Reseller_dashboard/wallet_balance');?>" class="order-info-content">
                                <div class="order-number"><span>₹ <?php echo number_format($this->session->userdata('reseller_wallet_amount'), 2);?></span></div>
                                <div class="order-title">Net wallet amount</div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number"><span>₹ 0</span></div>
                                <div class="order-title">Commission wallet amount</div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Payout Request statement</h3>
                    <ul class="list-inline order-list">
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number"><span>₹ <?php echo number_format($pending_payout[0]['pending_amount'], 2);?></span></div>
                                <div class="order-title">Pending Payout Request</div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number"><span>₹ <?php echo number_format($approved_payout[0]['approved_amount'], 2);?></span></div>
                                <div class="order-title">Approved Payout Request</div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="order-info-content">
                                <div class="order-number"><span>₹ <?php echo number_format($rejected_payout[0]['rejected_amount'], 2);?></span></div>
                                <div class="order-title">Rejected Payout Request</div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Growth opportunities</h3>
                    <div class="title-col">Price recommendations to grow your sales</div>
                    <div class="price-col">0</div>
                </div>
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Payments</h3>
                    <div class="title-col">Next Payment <br> <span>Due on NAN</span></div>
                    <div class="price-col">0</div>
                    <hr class="hrline-01">
                    <div class="title-col"><span>Prepaid</span></div>
                    <div class="price-col">0</div>
                    <div class="title-col"><span>Postpaid/TDS</span></div>
                    <div class="price-col">0</div>
                </div>
            </div>
            <div class="dashboard-panel-03">
                <div class="dashboard-content-block">
                    <h3 class="headding-01">Recent Promotions</h3>
                    <img src="<?php echo base_url('reseller_user_assets/images/adv-banner01.jpeg');?>" class="adv-banner-img" alt=""/>
                </div>
            </div>
        </div>
    </section>
    <div class="clrfix"></div>
</div>
<!-- End Container -->

