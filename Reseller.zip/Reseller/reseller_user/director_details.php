<!-- Start Container -->
<div class="main-wrapper">
    <!-- Order Status Section-01 Start -->
    <section class="order-status-section-01 fwd">
        <div class="container-fluid">
            <h1 class="mainpage-headding">Director <span>Details</span></h1>
            <a href="<?php echo base_url('Reseller_dashboard/director');?>" class="add-director-btn"><i class="fa fa-plus-circle"></i> Add New Director</a>
            <!-- Flash Success and Error Message Code Start Here -->
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <div class="data-table-block form-content-block">
                <?php
                    if(isset($director_result) && !empty($director_result)){ ?>
                        <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                <th>Sr.No</th>
                                <th>Director Name</th>
                                <th>Director Email</th>
                                <th>Director Contact No.</th>
                                <th>Director Address</th>
                                <th>Director PAN No.</th>
                                <th>PAN Certificate</th>
                                <th>Director Adhar No.</th>
                                <th>Adhar Certificate</th>
                                <th>View Details</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php
                                    //echo "<pre>";print_r($director_result);die();
                                    $i = 0;
                                    if(isset($director_result) && !empty($director_result)) foreach ($director_result as $key => $value){

                                        $pan_image = (isset($value['d_pan_card']) && !empty($value['d_pan_card']) && file_exists('reseller_files/reseller_documents/director_info/'.$value['d_pan_card'])) ? base_url('reseller_files/reseller_documents/director_info/'.$value['d_pan_card']) : base_url('reseller_user_assets/images/image_not_found.png');

                                        $adhar_image = (isset($value['d_adhar_img']) && !empty($value['d_adhar_img']) && file_exists('reseller_files/reseller_documents/director_info/'.$value['d_adhar_img'])) ? base_url('reseller_files/reseller_documents/director_info/'.$value['d_adhar_img']) : base_url('reseller_user_assets/images/image_not_found.png');
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $value['d_name']; ?></td>
                                            <td><?php echo $value['d_email']; ?></td>
                                            <td><?php echo $value['d_mobile']; ?></td>
                                            <td><?php echo $value['d_address']; ?></td>
                                            <td><?php echo $value['d_pan_no']; ?></td>
                                            <td  class="text-center"><img onclick="view_image_statement('<?php echo $pan_image;?>')" src="<?php echo $pan_image;?>" style="height: 100px; width: 100px;  cursor: pointer;"></td>
                                            <td><?php echo $value['d_adhar_card']; ?></td>
                                            <td  class="text-center"><img onclick="view_image_statement('<?php echo $adhar_image;?>')" src="<?php echo $adhar_image;?>" style="height: 100px; width: 100px;  cursor: pointer;"></td>
                                            <td class="text-center"><a href="<?php echo base_url('Reseller_dashboard/director_details_edit/'.$value['d_id']);?>"><button class="status-done">View Details</button></a></td>
                                            <td><?php echo date("d-m-Y H:i:s", strtotime($value['d_date_time'])); ?></td>
                                        </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <?php
                    }
                    else{ ?>
                        <h4 style="color: red; text-align: center;">You have not any director details yet.</h4>
                    <?php } ?>
            </div>
        </div>
    </section>
    <div class="clrfix"></div>
</div>
<!-- adhar card show image modal -->
<div class="modal fade modal-block" id="director_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog md-top-space" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">View image statement</h2>
                        <div class="form-group">
                            <img src="" id="statement_image" style="width: 100%">
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- End Container -->
<script type="text/javascript">
    function view_image_statement(img_src) {
        $('#director_image_model').modal('show');
        document.getElementById("statement_image").src = img_src;
    }
</script>