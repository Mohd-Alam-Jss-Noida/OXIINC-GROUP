<?php
	$pan_image = (isset($director_data[0]['d_pan_card']) && !empty($director_data[0]['d_pan_card']) && file_exists('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_pan_card'])) ? base_url('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_pan_card']) : base_url('reseller_user_assets/images/image_not_found.png');

	$aadhar_image = (isset($director_data[0]['d_adhar_img']) && !empty($director_data[0]['d_adhar_img']) && file_exists('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_adhar_img'])) ? base_url('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_adhar_img']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<!-- Start Container -->
<div class="main-wrapper">
	<!-- Company Details Section -->
	<section class="user-info-section-02 fwd">
		<div class="container">
			<h1 class="mainpage-headding">View and Update <span>Director Details</span></h1>
			<div class="form-content-block">
				<form class="form-block" action="<?php echo base_url('Reseller_dashboard/director_details_update'); ?>" method="POST"  enctype="multipart/form-data">
					<input type="hidden" class="textbox" name="d_id" value="<?php echo $director_data[0]['d_id'];?>" readonly>
					<input type="hidden" class="textbox" name="d_reseller_id" value="<?php echo $director_data[0]['d_reseller_id'];?>" readonly>
					<div class="form-block half-width fleft">
						<div class="form-group">
							<label for="">Director Name</label>
							<input type="text" class="textbox" name="d_name" id="d_name" value="<?php echo $director_data[0]['d_name'];?>" autocomplete="off" required>
						</div>
						<div class="form-group">
							<label for="">Director Mobile No.</label>
							<input type="text" class="textbox" name="d_mobile" id="d_mobile" value="<?php echo $director_data[0]['d_mobile'];?>" maxlength="10" onkeypress="return isNumberKey(event)" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Director PAN No.</label>
							<input type="text" class="textbox" name="d_pan_no" id="d_pan_no" value="<?php echo $director_data[0]['d_pan_no'];?>" maxlength="10" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group pan-card-img">
							<img onclick="director_image_statement('<?php echo $pan_image;?>')" src="<?php echo $pan_image;?>" style="cursor: pointer;">
						</div>
						<div class="form-group">
							<label for="">Director PAN Certiticate</label>
							<input type="file" id="director_file_1" name="d_pan_card" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="director_image_btn_1" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="director_image_text_1" class="upload-text">No file chosen, yet.</span>
						</div>
						<p style="color: #FF0000;">Note:- Please select document formate e.g. - png, jpg, jpeg</p>
					</div>
					<div class="form-block half-width frite">
						<div class="form-group">
							<label for="">Director Email</label>
							<input type="email" class="textbox" name="d_email" id="d_email" value="<?php echo $director_data[0]['d_email'];?>" autocomplete="off" required>
						</div>
						<div class="form-group">
							<label for="">Director Address</label>
							<input type="text" class="textbox" name="d_address" id="d_address" value="<?php echo $director_data[0]['d_address'];?>" autocomplete="off" required>
						</div>
						<div class="form-group">
							<label for="">Director Aadhar No.</label>
							<input type="text" class="textbox" name="d_adhar_card" id="d_adhar_card" value="<?php echo $director_data[0]['d_adhar_card'];?>" maxlength="12" onkeypress="return isNumberKey(event)" autocomplete="off" required>
						</div>
						<div class="form-group pan-card-img">
							<img onclick="director_image_statement('<?php echo $aadhar_image;?>')" src="<?php echo $aadhar_image;?>" style="cursor: pointer;">
						</div>
						<div class="form-group">
							<label for="">Director Aadhar Certiticate</label>
							<input type="file" id="director_file_2" name="d_adhar_img" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="director_image_btn_2" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="director_image_text_2" class="upload-text">No file chosen, yet.</span>
						</div>
						<p style="color: #FF0000;">Note:- Please select document formate e.g. - png, jpg, jpeg</p>
					</div>
					<input type="hidden" class="textbox" name="old_pan_img" value="<?php echo $director_data[0]['d_pan_card'];?>" readonly>
					<input type="hidden" class="textbox" name="old_adhar_img" value="<?php echo $director_data[0]['d_adhar_img'];?>" readonly>
					<div class="form-group text-center">
					<button type="submit" class="submit-btn">Update</button>
					</div>
				</form>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- director show image modal -->
<div class="modal fade modal-block" id="director_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog md-top-space" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">View image statement</h2>
                        <div class="form-group">
                            <img src="" id="director_pan_aadhar_image" style="width: 100%">
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- End Container -->
<script type="text/javascript">
	//File Upload Button
    for (var a = 1; a <= 2; a++){
        const common_realFileBtn = document.getElementById("director_file_" + a);
        const common_customBtn = document.getElementById("director_image_btn_" + a);
        const common_customTxt = document.getElementById("director_image_text_" + a);

        common_customBtn.addEventListener("click", function() {
            common_realFileBtn.click();
        });

        common_realFileBtn.addEventListener("change", function() {
            if (common_realFileBtn.value) {
                common_customTxt.innerHTML = common_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
            } else {
                common_customTxt.innerHTML = "No file chosen, yet.";
            }
        });
    }

    function director_image_statement(img_src) {
        $('#director_model').modal('show');
        document.getElementById("director_pan_aadhar_image").src = img_src;
    }
</script>