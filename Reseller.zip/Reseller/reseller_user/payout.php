<!-- Start Container -->
<div class="main-wrapper">
	<!-- Order Status Section-01 Start -->
	<section class="order-status-section-01 package-material-section-01 fwd">
		<div class="container-fluid">
			<div class="fwd text-center">
				<h2 class="headding-02 wallet-balance">Your Wallet Balance Amount : <span>₹ <?php echo number_format($this->session->userdata('reseller_wallet_amount'), 2);?></span> </h2>
			</div>
			
			<h1 class="mainpage-headding">Payout <span>Request</span></h1>
			<form class="form-block" action="<?php echo base_url('Reseller_dashboard/payout_request');?>" method="POST" id="payout_form_data">
				<div class="container">
					<?php
					if($this->session->flashdata('msg')){
						$flash_array = $this->session->flashdata('msg');?>
						<div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
					<?php } ?>
					<div class="form-content-block">
						<div class="form-group col-3-div">
							<select class="textbox input-selectbox" name="transfer_info" id="transfer_info" required autocomplete="off">
								<option value="">Select Transfer Type</option>
								<option value="bank_account">Bank Account</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group col-3-div">
							<input type="text" class="textbox" name="payouts_amount" value="" placeholder="Amount(s)" max_length="64" required="required" id="payouts_amount" autocomplete="off" onkeypress="return isNumberKey(event)">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group col-3-div">
							<input type="text" class="textbox" name="payouts_remark" value="" placeholder="Enter Remark" max_length="255" id="payouts_remark" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<input type="hidden" name="balance_amount" id="balance_amount" value="<?php echo $this->session->userdata('reseller_wallet_amount');?>">
						<div class="fwd text-center">
							<button type="button" class="submit-btn" onclick="validateRequest();">&nbsp;Request Payout&nbsp;</button>
							<button type="reset" class="submit-btn cancel-btn">&nbsp;Reset&nbsp;</button>
						</div>
					</div>
				</div>
				<div class="clrfix"></div>
				<div class="data-table-block form-content-block">
					<?php
                	if(isset($payout_details) && !empty($payout_details)){ ?>
						<table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
							<thead>
								<tr>
									<th>No.</th>
									<th>Reseller Name</th>
									<th>Bank Holder Name</th>
									<th>Account Number</th>
									<th>Bank Name</th>
									<th>IFSC Code</th>
									<th>Request Amount</th>
									<th>Admin Charge</th>
									<th>TDS Deduction</th>
									<th>Payable Amount</th>
									<th>Status</th>
									<th>Reseller Remarks</th>
									<th>Reseller Request Date</th>
									<th>Admin Remark</th>
									<th>Admin Response Date</th>
								</tr>
							</thead>
							<tbody>
									<?php
			                        $i = 1;
			                        foreach ($payout_details as $key => $value){
			                        	if($value['status'] == 0){
									        $status = 'Pending';
									        $heading_color = 'badge badge-warning';
									    } elseif ($value['status'] == 1){
									        $status = 'Approved';
									        $heading_color = 'badge badge-success';
									    } elseif ($value['status'] == 2){
									        $status = 'Rejected';
									        $heading_color = 'badge badge-danger';
									    }
			                        	?>
										<tr>
											<td><?php echo $i++; ?></td>
		                                    <td><?php echo $value['name']; ?></td>
		                                    <td><?php echo $value['bank_holder_name']; ?></td>
		                                    <td><?php echo $value['account_number']; ?></td>
		                                    <td><?php echo $value['branch']; ?></td>
		                                    <td><?php echo $value['ifsc']; ?></td>
		                                    <td><?php echo $value['amount']; ?></td>
		                                    <td><?php echo $value['admin_charge']; ?></td>
											<td><?php echo $value['TDS']; ?></td>
											<td><?php echo $value['amount_after_tax']; ?></td>
		                                    <td><center><span class="<?php echo $heading_color;?>"><?php echo $status;?></span></center></td>
		                                    <td><?php echo $value['remarks']; ?></td>
		                                    <td><?php echo date("d-m-Y H:i:s", strtotime($value['user_request_date'])); ?></td>
		                                    <td class="text-center"><?php echo ($value['admin_remark']) ? $value['admin_remark'] : '-';?></td>
		                                    <td class="text-center"><?php echo ($value['admin_response_date']) ? date("d-m-Y H:i:s", strtotime($value['admin_response_date'])) : '-';?></td>
										</tr>
									<?php } ?>
								</tbody>
						</table>
						<?php
	            	}
		            else{ ?>
		                <h4 style="color: red; text-align: center;">Not Have Any Payout Request Statement Yet.</h4>
		            <?php } ?>
				</div>
			</form>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
	function validateRequest(){
		var d = new Date();
		var day_number = d.getDay(); //1- Monday to 7-Sunday
		var weekly_transaction = '<?php echo !empty($weekly_transaction) ? 0 : 1 ; ?>';
		var wallet_amount = '<?php echo $this->session->userdata('reseller_wallet_amount');?>';
		var transfer_info = $('#transfer_info').val();
		var payouts_amount = $('#payouts_amount').val();
		var payouts_remark = $('#payouts_remark').val();

		if(transfer_info == '' || payouts_amount == '' || payouts_remark == ''){
			error_msg = "Please select transfer type and enter payout amount and enter payouts remark.";
			icon = "error";
		}
		else{
			if(day_number == 1){
				error_msg = "Dear customer, withdrawl request can not be accepted on monday. please try some other day.";
				icon = "error";
			} else if(parseInt(payouts_amount) > parseInt(wallet_amount)){
				error_msg = "You have insufficient balance in your wallet.";
				icon = "error";
			} else if(parseInt(payouts_amount) < 1 || parseInt(payouts_amount) > 100000){
				error_msg = "Minimum amount should be 1 and maximum amount should 1,00,000";
				icon = "error";
			} else if(weekly_transaction == 0){
				error_msg = "Dear customer, withdrawl request can be accepted only once in a week. you have already placed withdrawl request in this week. please try in next week.";
				icon = "error";
			} else{
				error_msg = '';
			}
		}
		if(error_msg != ''){
			swal({
				title: "Error Occurred",
				text: error_msg,
				type: "error",
				icon: "error",
				showConfirmButton: true,
				showCancelButton: false,
				confirmButtonColor: "#3085d6",
				cancelButtonColor: "#d33",
				confirmButtonClass: "btn btn-danger",
				cancelButtonClass: "btn btn-danger",
				buttonsStyling: false,
				confirmButtonText: "Ok"
			});
		}
		else{
			$('#payout_form_data').submit();
		}
	}
</script>