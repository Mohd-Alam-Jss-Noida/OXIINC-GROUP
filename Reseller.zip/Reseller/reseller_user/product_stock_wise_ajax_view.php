<?php if(isset($size_manage) && !empty($size_manage)){ ?>
    <form class="form-block product-list-form-modal" action="<?php echo base_url('Reseller_dashboard/product_information_view_stock_wise_size');?>" method="post">
        <h2 class="headding-01">Product Size With Stock</h2>
        <div class="form-sucessmsg" id="product_stock_delete_success" style="display:none;"></div>
        <div class="form-errormsg" id="product_stock_delete_fail" style="display:none;"></div>
        <div class="form-group half-width-col">
        <label for="">Product Size</label>
        </div>
        <div class="form-group half-width-col">
            <label for="">Product Stock</label>
        </div>
        <input type="hidden" class="textbox" name="Product_id" value="<?php echo $size_manage[0]['p_id'];?>">
        <?php foreach ($size_manage as $key => $value){ ?>
            <div class="">
                <div class="form-group half-width-col">
                    <input type="text" class="textbox" name="size[]" value="<?php echo $value['size'];?>" autocomplete="off" required>
                    <span class="bar"></span>
                </div>
                <div class="form-group half-width-col">
                    <input type="text" class="textbox" name="stock[]" value="<?php echo $value['stock'];?>" autocomplete="off" required>
                    <span class="bar"></span>
                </div>
                <div class="form-group btn-half-width-col">
                    <button type="button" class="submit-btn IFSC-code-btn" onclick="delete_size(<?php echo $value['id'];?>, <?php echo $value['p_id'];?>, <?php echo $value['stock'];?>);">Delete</button>
                </div>
                <input type="hidden" class="textbox" name="id[]" value="<?php echo $value['id'];?>">
            </div>
        <?php } ?>
        <div class="form-group text-center">
            <button type="submit" value="Submit" class="submit-btn">Submit</button>
            <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
        </div>
    </form>
    <div class="clrfix"></div>
<?php } ?>

<script type="text/javascript">
    function delete_size(id, p_id, stock){
        if (id != "" && p_id != ""  && stock != "") {
            $.ajax({
                type:'POST',
                url:'<?php echo base_url('Reseller_dashboard/delete_size_stock'); ?>',
                data:{id: id, Product_id:p_id, stock:stock},
                success:function(data){
                    //alert(data);
                    var obj = JSON.parse(data);
                    if(obj.status == 'success'){
                        $("#product_stock_delete_fail").css({"display": "none"}).text('');
                        $("#product_stock_delete_success").css({"display": "block"}).text(obj.message);
                    }
                    if(obj.status == 'error'){
                        $("#product_stock_delete_fail").css({"display": "block"}).text(obj.message);
                    }
                    setTimeout(function() {
                        location.reload();
                    }, 3000);
                }
            });
        }
        else{
            $("#product_stock_delete_fail").css({"display": "block"}).text('Please Enter Product Size And Product Stock.');
            return false;
        }
    }
</script>

