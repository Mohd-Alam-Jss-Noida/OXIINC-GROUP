<form class="form-block product-list-form-modal">
    <h2 class="headding-01">View Product Images</h2>
    <div class="form-sucessmsg" id="product_image_delete_success" style="display:none;"></div>
    <div class="form-errormsg" id="product_image_delete_fail" style="display:none;"></div>
    <div class="form-group">
        <?php if(isset($product_images_information) && !empty($product_images_information)) foreach ($product_images_information as $key => $value){ ?>
            <div class="uploaded-image-col">
                <img src="<?php echo base_url('uploads/Multiple_Picture/'.$value['Product_Picture_Mult']); ?>" alt="" />
                <div class="delete-icon-col" title="DELETE THIS IMAGE" onclick="return confirm('Are you sure want to delete this product Image.') ? delete_product_images(<?php echo $value['ID']; ?>, <?php echo $value['Product_id']; ?>) : '' ;"><i class="fas fa-trash-alt"></i></div>
            </div>
            <?php
        }
        else{ ?>
            <div class="uploaded-image-col">
                <img src="<?php echo base_url('reseller_user_assets/images/not-found.jpg');?>" alt=""/>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="form-group text-center">
        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
    </div>
</form>
<div class="clrfix"></div>

<script type="text/javascript">
    function delete_product_images(ID, Product_id){
        $.ajax({
            type:'POST',
            url:'<?php echo base_url('Reseller_dashboard/fetch_product_images_data_delete'); ?>',
            data:{ ID: ID, Product_id: Product_id },
            success:function(data){
                //alert(data);
                var obj = JSON.parse(data);
                if(obj.status == 'success'){
                    $("#product_image_delete_fail").css({"display": "none"}).text('');
                    $("#product_image_delete_success").css({"display": "block"}).text(obj.message);
                }
                if(obj.status == 'error'){
                    $("#product_image_delete_fail").css({"display": "block"}).text(obj.message);
                }
                setTimeout(function() {
                    location.reload();
                }, 3000);
            }
        });
    }
</script>

