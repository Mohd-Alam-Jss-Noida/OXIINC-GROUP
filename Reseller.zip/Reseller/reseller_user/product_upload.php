<!-- Start Container -->
<div class="main-wrapper">
	<!-- Package Material Section -->
	<section class="order-status-section-01 package-material-section-01 fwd">
		<div class="container-fluid">
			<h1 class="mainpage-headding">Reseller Product <span>upload</span></h1>
			<form class="form-block" action="<?php echo base_url('Reseller_dashboard/blulk_upload_form_add'); ?>" method="post" enctype="multipart/form-data">
				<div class="container">
					<input type="hidden" class="textbox" name="company_name_product" id="company_name_product" value="" required readonly>
					<div class="form-content-block">
						<div class="form-group col-3-div">
							<select class="textbox input-selectbox" name="category_id" id="product_category" data-placeholder="Select Category" autocomplete="off" required onchange="getSubCategory()">
								<option value="">Select Category</option>
								<?php foreach ($category_data as $key => $value) {?>
                                    <option value="<?php echo $value['category_id']; ?>"><?php echo $value['category_name']; ?></option>
                                <?php } ?>
							</select>
							<span class="bar"></span>
						</div>
						<div class="form-group col-3-div">
							<select class="textbox input-selectbox" name="sub_category_id" id="sub_category_id" autocomplete="off" required onchange="getproCategory()">
                                <option value="" data-id="">Select Sub Category</option> 
                            </select>
							<span class="bar"></span>
						</div>
						<div class="form-group col-3-div">
							<select class="textbox input-selectbox" name="product_category_id" id="product_category_id" autocomplete="off" required>
                                <option value="" data-id="">Select Product Category</option>
                            </select>
							<span class="bar"></span>
						</div>
					</div>
				</div>
				<div class="clrfix"></div>
				<div class="package-material-container form-content-block">
					<div class="form-block tbl-responsive">
						<table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
							<thead>
								<tr>
									<th width="285px;">Product Images</th>
									<th>Product name</th>
									<th>Product MRP</th>
									<th>Product Price</th>
									<th>Shipping Charges</th>
									<th>Product Color</th>
									<th>GST Percentage</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody id="TextBoxContainer">
								<tr>
									<td>
										<div class="form-group">
											<input type="file" class="textbox textbox-tbl-xs" name="Product_Image[0][]" id="" accept=".png, .jpg, .jpeg" autocomplete="off" required>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input type="text" class="textbox textbox-tbl-xs" name="Product_Name[]" id="" placeholder="Product name" autocomplete="off" required>
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input type="text" class="textbox textbox-tbl-xs" name="Original_Prices[]" id="" placeholder="Product MRP" autocomplete="off" required onkeypress="return isNumberKey(event)">
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input type="text" class="textbox textbox-tbl-xs" name="Prices[]" id="" placeholder="Product Price" autocomplete="off" required onkeypress="return isNumberKey(event)">
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input type="text" class="textbox textbox-tbl-xs" name="Shipping_Charges[]" id="" placeholder="Shipping Charges" autocomplete="off" required onkeypress="return isNumberKey(event)">
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<input type="text" class="textbox textbox-tbl-xs" name="product_color[]" id="" placeholder="Product Color" autocomplete="off" required> 
											<span class="bar"></span>
										</div>
									</td>
									<td>
										<div class="form-group">
											<select class="textbox input-selectbox" name="GST_Persentage[]">
												<option value="0">0%</option>
												<option value="5">5%</option>
												<option value="12">12%</option>
												<option value="18">18%</option>
												<option value="28">28%</option>
											</select>
											<span class="bar"></span>
										</div>
									</td>
									<td></td>
								</tr>
								<tr>
									<td>
										<div class="form-group">
											<label for="">HSN Code</label>
											<input type="text" class="textbox textbox-tbl-xs" name="hsn_code[]" id="" maxlength="8" placeholder="HSN Code" autocomplete="off" required>
											<span class="bar"></span>
										</div>
									</td>
									<td colspan="2">
										<div class="form-group">
											<label for="">Short Info</label>
											<textarea class="textbox textarea" name="Short_Description[]" id="" rows="2" placeholder="Short Description" autocomplete="off" required></textarea>
											<span class="bar"></span>
										</div>
									</td>
									<td colspan="2">
										<div class="form-group">
											<label for="">Long Info</label>
											<textarea class="textbox textarea" name="large_Description[]" id="" rows="2" placeholder="Long Description" autocomplete="off" required></textarea>
											<span class="bar"></span>
										</div>
									</td>
									<td colspan="3" class="product-listing-size-wise-stock" id="product_size_wise_stock_0">
										<div class="form-group">
											<label for="">Product Size & Size Wise Stock</label>
										</div>
										<div class="form-group">
											<button type="button" class="submit-btn cancel-btn add-btn no-margin" onclick="product_size_stock(0)"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button>
										</div>
										<div class="add-col-01">
											<div class="form-group col-1">
												<input type="text" class="textbox" name="sizes[0][]" id="" placeholder="Product Size" autocomplete="off" required>
												<span class="bar"></span>
											</div>
											<div class="form-group col-1">
												<input type="text" class="textbox" name="stock_sizes[0][]" id="" placeholder="Size Wise Stock" autocomplete="off" required onkeypress="return isNumberKey(event)">
												<span class="bar"></span>
											</div>
										</div>
									</td>
								</tr>
							</tbody>
							<tfoot>
								<tr>
									<th colspan="8">
										<div class="form-group">
											<button type="button" id="btnAdd123" class="submit-btn cancel-btn" onclick="add_multiple_product()"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button>
										</div>
									</th>
								</tr>
								<tr>
									<th colspan="8">
										<div class="form-group text-center">
											<button type="submit" class="submit-btn">&nbsp;Upload Product&nbsp;</button>
										</div>
									</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
			</form>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	function getSubCategory(){
        var category_id = $('#product_category').val();
        var postData = {
            'category_id' : category_id
        }
        $.post('<?php echo base_url('Reseller_dashboard/getSubCategory')?>',postData,function(data){
            var subcats = $.parseJSON(data);
            $('#select2-sub_category_id-container').html('Select Sub Category');
            $('#sub_category_id').html('');

            var html = '<option value="">Select Sub Category</option>';
            $.each(subcats,function(i,val){
                html += '<option value="'+val.sub_category_id+'" data-id="'+val.sub_category_name+'">'+val.sub_category_name+'</option>';
            })
            //alert(html);
            $('#sub_category_id').html(html);
        });
    }

    function getproCategory(){
    	var sub_category_id = $('#sub_category_id').val();
    	var postData = {
    		'sub_category_id' : sub_category_id
    	}
    	$.post('<?php echo base_url('Oxiinc_Reseller_Dashboard/getproCategory')?>',postData,function(data){
    		var subcats = $.parseJSON(data);
    		$('#select2-sub_category_id-container').html('Select Sub Category');
    		$('#product_category_id').html('');

    		var html = '<option value="">Select Sub product Category</option>';
    		$.each(subcats,function(i,val){
    			html += '<option value="'+val.product_category_id+'" data-id="'+val.product_category_name+'">'+val.product_category_name+'</option>';
    		})
    		$('#product_category_id').html(html);
    	});
    }

    count_stock = 0;
    function product_size_stock(count_stock){
    	//alert(count_stock)
        $('#product_size_wise_stock_'+count_stock).append('<div class="add-col-01 remove_product_size"><div class="form-group col-1"><input type="text" class="textbox" name="sizes['+count_stock+'][]" id="" placeholder="Product Size" autocomplete="off" required><span class="bar"></span></div><div class="form-group col-1"><input type="text" class="textbox" name="stock_sizes['+count_stock+'][]" id="" placeholder="Size Wise Stock" autocomplete="off" required onkeypress="return isNumberKey(event)"><span class="bar"></span></div><div class="form-group col-2"><button type="button" class="submit-btn delete-icon-btn delete_product_size"><i class="fa fa-trash" aria-hidden="true"></i></button></div></div>');

        count_stock++;
    }

    $("body").on("click", ".delete_product_size", function () {
        $(this).closest(".remove_product_size").remove();
    });

    add_count = 1
    function add_multiple_product(){
    	//alert(add_count);
        $('#TextBoxContainer').append('<tr class="remove_multiple_product_'+add_count+'"><td><div class="form-group"><input type="file" class="textbox textbox-tbl-xs" name="Product_Image['+add_count+'][]" id="" accept=".png, .jpg, .jpeg" autocomplete="off" required></div></td><td><div class="form-group"><input type="text" class="textbox textbox-tbl-xs" name="Product_Name[]" id="" placeholder="Product name" autocomplete="off" required><span class="bar"></span></div></td><td><div class="form-group"><input type="text" class="textbox textbox-tbl-xs" name="Original_Prices[]" id="" placeholder="Product MRP" autocomplete="off" required onkeypress="return isNumberKey(event)"><span class="bar"></span></div></td><td><div class="form-group"><input type="text" class="textbox textbox-tbl-xs" name="Prices[]" id="" placeholder="Product Price" autocomplete="off" required onkeypress="return isNumberKey(event)"><span class="bar"></span></div></td><td><div class="form-group"><input type="text" class="textbox textbox-tbl-xs" name="Shipping_Charges[]" id="" placeholder="Shipping Charges" autocomplete="off" required onkeypress="return isNumberKey(event)"><span class="bar"></span></div></td><td><div class="form-group"><input type="text" class="textbox textbox-tbl-xs" name="product_color[]" id="" placeholder="Product Color" autocomplete="off" required> <span class="bar"></span></div></td><td><div class="form-group"><select class="textbox input-selectbox" name="GST_Persentage[]"><option value="0">0%</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option><option value="28">28%</option></select><span class="bar"></span></div></td><td><button type="button" class="submit-btn delete-icon-btn delete_multiple_product"><i class="fa fa-trash" aria-hidden="true"></i></button></td></tr><tr class="remove_multiple_product_'+add_count+'"><td><div class="form-group"><label for="">HSN Code</label><input type="text" class="textbox textbox-tbl-xs" name="hsn_code[]" id="" maxlength="8" placeholder="HSN Code" autocomplete="off" required><span class="bar"></span></div></td><td colspan="2"><div class="form-group"><label for="">Short Info</label><textarea class="textbox textarea" name="Short_Description[]" id="" rows="2" placeholder="Short Description" autocomplete="off" required></textarea><span class="bar"></span></div></td><td colspan="2"><div class="form-group"><label for="">Long Info</label><textarea class="textbox textarea" name="large_Description[]" id="" rows="2" placeholder="Long Description" autocomplete="off" required></textarea><span class="bar"></span></div></td><td colspan="3" class="product-listing-size-wise-stock" id="product_size_wise_stock_'+add_count+'"><div class="form-group"><label for="">Product Size & Size Wise Stock</label></div><div class="form-group"><button type="button" class="submit-btn cancel-btn add-btn no-margin" onclick="product_size_stock('+add_count+')"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button></div><div class="add-col-01"><div class="form-group col-1"><input type="text" class="textbox" name="sizes['+add_count+'][]" id="" placeholder="Product Size" autocomplete="off" required><span class="bar"></span></div><div class="form-group col-1"><input type="text" class="textbox" name="stock_sizes['+add_count+'][]" id="" placeholder="Size Wise Stock" autocomplete="off" required onkeypress="return isNumberKey(event)"><span class="bar"></span></div></div></td></tr>');

        add_count++;
    }

    remove_count = 1
    $("body").on("click", ".delete_multiple_product", function () {
        $(".remove_multiple_product_"+remove_count).remove();
    	//alert(remove_count);
    	remove_count++;
    });
</script>

