<!-- Start Container -->
<div class="main-wrapper">
	<!-- Order Status Section-01 Start -->
	<section class="order-status-section-01 fwd">
		<div class="container-fluid">
			<h1 class="mainpage-headding">Bank Deposit Statement</h1>
			<?php
	  		if($this->session->flashdata('msg')){
				$flash_array = $this->session->flashdata('msg');?>
				<div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
			<?php } ?>
			<div class="data-table-block form-content-block">
				<?php
                if(isset($bank_deposit_details) && !empty($bank_deposit_details)){ ?>	
					<table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
						<thead>
							<tr>
								<th>Sr.No</th>
								<th>Payee Bank</th>
								<th>Payable <br> Amount</th>
								<th>Seller <br> Package</th>
								<th>Bank Deposit <br> Statement</th>
								<th>Trancation <br> Number</th>
								<th>Payment <br> Mode</th>
								<th>Bank Deposit <br> Branch</th>
								<th>Seller <br> Remark</th>
								<th>Deposit Date</th>
								<th>Status</th>
								<th>Admin <br> Remark</th>
							</tr>
						</thead>
						<tbody>
							<?php
	                        $i = 1;
	                        foreach ($bank_deposit_details as $key => $value) {
	                        	if($value['status'] == 0){
							        $status = 'Pending';
							        $heading_color = 'badge badge-warning';
							    } elseif ($value['status'] == 1){
							        $status = 'Approved';
							        $heading_color = 'badge badge-success';
							    } elseif ($value['status'] == 2){
							        $status = 'Rejected';
							        $heading_color = 'badge badge-danger';
							    }
	                        	?>
								<tr>
									<td><?php echo $i++; ?></td>
                                    <td><?php echo $value['payee_bank']; ?></td>
                                    <td><?php echo $value['amount']; ?></td>
                                    <td><?php echo $value['package']; ?></td>
                                    <td><img onclick="view_bank_statement('<?php echo base_url('/reseller_files/reseller_documents/bank_deposite_statement/'.$value['images']); ?>')" src="<?php echo base_url('/reseller_files/reseller_documents/bank_deposite_statement/'.$value['images']); ?>" style="height: 100px; width: 100px;  cursor: pointer;"></td>
                                    <td><?php echo $value['transcation_number']; ?></td>
                                    <td><?php echo $value['payment_mode']; ?></td>
                                    <td><?php echo $value['branchdepositebank']; ?></td>
                                    <td><?php echo $value['remark']; ?></td>
                                    <td><?php echo $value['payment_depositedate']; ?></td>
                                    <td><center><span class="<?php echo $heading_color;?>"><?php echo $status;?></span></center></td>
                                    <td><?php echo $value['status_remark']; ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
					<?php
	            }
	            else{ ?>
	                <h4 style="color: red; text-align: center;">Not Have Any Bank Deposit Statement Yet.</h4>
	            <?php } ?>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<!-- Bank Statement Modal -->
<div class="modal fade modal-block" id="bank_statement_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog md-top-space" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">View Bank deposit statement</h2>
                        <div class="form-group">
                            <img src="" id="bank_statement_image" style="width: 100%">
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function view_bank_statement(img_src) {
        $('#bank_statement_model').modal('show');
        document.getElementById("bank_statement_image").src = img_src;
    }
</script>