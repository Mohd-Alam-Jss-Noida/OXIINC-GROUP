<!-- Start Container -->
<?php
    if ($this->uri->segment(2) == "packaging_material_status"){
        $page_heading =  "Packing Material Order Status";
    } elseif ($this->uri->segment(2) == "packing_material_pending"){
        $page_heading =  "Pending Packing Material";
    } elseif ($this->uri->segment(2) == "packing_material_approved"){
        $page_heading =  "Approved Packing Material";
    } elseif ($this->uri->segment(2) == "packing_material_rejected"){
        $page_heading =  "Rejected Packing Material";
    } 
?>
<div class="main-wrapper">
    <!-- Order Status Section-01 Start -->
    <section class="order-status-section-01 fwd">
        <div class="container-fluid">
            <h1 class="mainpage-headding"><?php echo $page_heading;?></h1>
            <!-- Flash Success and Error Message Code Start Here -->
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg123 <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <div class="data-table-block form-content-block">
                <?php
                    if(isset($bank_deposit_statement) && !empty($bank_deposit_statement)){ ?>
                        <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                <th>Sr.No</th>
                                <th>Payment Mode</th>
                                <th>Payee Bank</th>
                                <th>Payable Amount</th>
                                <th>Trancation Number</th>
                                <th>Bank Deposit Statement</th>
                                <th>Reseller Remark</th>
                                <th>Branch Of Deposit Bank</th>
                                <th>View Order Materials</th>
                                <th>Deposit Date</th>
                                <th>Payment Status</th>
                                <th>Payment Remark</th>
                                <th>Delivery Status</th>
                                <th>Delivery Remark</th>
                                <th>Delivery Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php
                                    //echo "<pre>";print_r($bank_deposit_statement);die();
                                    $i = 0;
                                    if(isset($bank_deposit_statement) && !empty($bank_deposit_statement)) foreach ($bank_deposit_statement as $key => $value){
                                        if ($value['status'] == 0){
                                            $status = 'Pending';
                                            $heading_color = 'badge badge-warning';
                                        }
                                        if ($value['status'] == 1){
                                            $status = 'Approved';
                                            $heading_color = 'badge badge-success';
                                        }
                                        if ($value['status'] == 2){
                                            $status = 'Rejected';
                                            $heading_color = 'badge badge-danger';
                                        }
                                        if ($value['delivery_status'] == 0){
                                            $delivery_status = 'Pending';
                                            $delivery_color = 'badge badge-warning';
                                        }
                                        if ($value['delivery_status'] == 1){
                                            $delivery_status = 'Done';
                                            $delivery_color = 'badge badge-success';
                                        }
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $value['payment_mode']; ?></td>
                                            <td><?php echo $value['payee_bank']; ?></td>
                                            <td><?php echo $value['amount']; ?></td>
                                            <td><?php echo $value['transcation_number']; ?></td>
                                            <td><img onclick="view_bank_statement('<?php echo base_url('/reseller_files/reseller_documents/bank_deposite_statement/'.$value['images']); ?>')" src="<?php echo base_url('/reseller_files/reseller_documents/bank_deposite_statement/'.$value['images']); ?>" style="height: 100px; width: 100px;  cursor: pointer;"></td>
                                            <td><?php echo $value['remark']; ?></td>
                                            <td><?php echo $value['branchdepositebank']; ?></td>
                                            <td onclick="get_packing_material(<?php echo $value['id']; ?>)"><button type="button" class="status-done">View Order Materials</button></td>
                                            <td><?php echo date("d-m-Y", strtotime($value['payment_depositedate'])); ?></td>
                                            <td><center><span class="<?php echo $heading_color;?>"><?php echo $status;?></span></center></td>
                                            <td ><?php echo $value['admin_remark']; ?></td>
                                            <td><span class="<?php echo $delivery_color;?>"><?php echo $delivery_status;?></span></td>
                                            <td><?php echo $value['delivery_remark']; ?></td>
                                            <td ><?php echo ($value['delivery_date'] == '0000-00-00 00:00:00') ? "--" : date("d-m-Y H:i:s", strtotime($value['delivery_date'])); ?></td>
                                        </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <?php
                    }
                    else{ ?>
                        <h4 style="color: red; text-align: center;">You have not order any packing material yet.</h4>
                    <?php } ?>
            </div>
        </div>
    </section>
    <div class="clrfix"></div>
</div>
<!-- End Container -->
<!-- Bank Statement Modal -->
<div class="modal fade modal-block" id="bank_statement_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog md-top-space" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">View Bank deposit statement</h2>
                        <div class="form-group">
                            <img src="" id="bank_statement_image" style="width: 100%">
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Packing Material Modal -->
<div class="modal fade modal-block" id="packing_material_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">View Order Packing Material</h2>
                        <div class="form-group">
                            <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Product Name</th>
                                    <th>Product Qty</th>
                                    <th>Product Price</th>
                                    <th>Total Price</th>
                                </tr>
                            </thead>
                            <tbody id="order_packing_material">
                            </tbody>
                        </table>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function view_bank_statement(img_src) {
        $('#bank_statement_model').modal('show');
        document.getElementById("bank_statement_image").src = img_src;
    }

    function get_packing_material(id){
        $('#packing_material_model').modal('show');
        $.ajax({
            type:'POST',
            url:"<?php echo base_url('Reseller_dashboard/get_packing_material'); ?>",
            data:{id: id},
            success:function(data){
                var obj = JSON.parse(data);
                var html = "";
                var grand_total = 0;
                $.each(obj, function(i, data1){
                    grand_total += parseInt(data1.product_price_total);
                    html += '<tr><td>'+ (1+i) +'</td><td>'+data1.paking_material+'</td><td>'+data1.product_qty+'</td><td>'+data1.product_price+'</td><td>'+data1.product_price_total+'</td></tr>';
                });
                html += '<tr><th colspan="4">Grand Total Price</th><th>'+grand_total+'</th></tr>';
                $('#order_packing_material').html(html);
            }
        });
    }
</script>