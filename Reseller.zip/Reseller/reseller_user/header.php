<!-- START HEADER -->
<header>
	<a href="<?php echo site_url('Reseller_dashboard');?>" class="logo-col"><img src="<?php echo base_url('reseller_user_assets/images/oxiinc-logo.png');?>" alt="" /></a>
	<nav id='cssmenu' class="fwd">
		<div id="head-mobile"></div>
		<div class="button"></div>
		<?php
			$query_approval_status = $this->db->query('SELECT approval_status  FROM reseller WHERE id="'.$this->session->userdata('r_id').'" ');
			$data_approval_status = $query_approval_status->result_array();
			if ($data_approval_status[0]['approval_status'] == 1) { ?>
				<ul class="nav-main-ul">
					<li class='active'><a href='<?php echo base_url('Reseller_dashboard');?>'>Home</a></li>
					<li><a href='javascript:void(0);'>Product Listings</a>
						<ul>
							<li><a href='<?php echo base_url('Reseller_dashboard/product_upload');?>'>Add New Product</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/Product_list');?>'>Product Listing Status</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/approved_product_list');?>'>Approved Product Listing</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/pending_product_list');?>'>Pending Product Listing</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/rejected_product_list');?>'>Rejected Product Listing</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/out_of_stock_product_list');?>'>Out of Stock Product</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Inventory</a>
						<ul>
							<li><a href='javascript:void(0);'>Inventory Health</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Orders</a>
						<ul>
							<li><a href='<?php echo base_url('Reseller_dashboard/total_order');?>'>Total Orders</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/order_confirm');?>'>Order Confirm</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/order_packed');?>'>Order Packed Confirm</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/order_shipped');?>'>Shipped Confirm</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/order_intransit');?>'>In Transit Confirm</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/order_out_for_delivery');?>'>Out for Delivered confrim</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/order_delivered');?>'>Delivered confrim</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Payments</a>
						<ul>
							<li><a href='javascript:void(0);'>Payment Overview</a></li>
							<li><a href='javascript:void(0);'>Previous Payment</a></li>
							<li><a href='javascript:void(0);'>Transactions</a></li>
							<li><a href='javascript:void(0);'>Invoices</a></li>
							<li><a href='javascript:void(0);'>Statements</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Growth</a>
						<ul>
							<li><a href='javascript:void(0);'>Inventory Health</a></li>
							<li><a href='javascript:void(0);'>Perfomance Overview</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Reports</a>
						<ul>
							<li><a href='javascript:void(0);'>Reports Centre</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Bank Deposit Statement</a>
						<ul>
							<li><a href='<?php echo base_url('Reseller_dashboard/bank_deposit_statement');?>'>Add Bank Deposit Statement</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/view_bank_deposit_statement');?>'>View Bank Deposit Statements</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Oxiinc Packing Material</a>
						<ul>
							<li><a href='<?php echo base_url('Reseller_dashboard/packaging_material_order');?>'>Order Packaging Material</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/packaging_material_status');?>'>Packing Material Order Status</a></li>
						</ul>
					</li>
				</ul>
				<?php
			}
			else{ ?>
				<ul class="nav-main-ul">
					<li class='active'><a href='<?php echo base_url('Reseller_dashboard');?>'>Home</a></li>
					<li><a href='javascript:void(0);'>Product Listings</a>
						<ul>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Inventory</a>
						<ul>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Orders</a>
						<ul>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Payments</a>
						<ul>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Growth</a>
						<ul>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Reports</a>
						<ul>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Bank Deposit Statement</a>
						<ul>
							<li><a href='<?php echo base_url('Oxiinc_Reseller_Dashboard/bank_deposit_statement');?>'>Add Bank Deposit Statement</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/view_bank_deposit_statement');?>'>View Bank Deposit Statements</a></li>
						</ul>
					</li>
					<li><a href='javascript:void(0);'>Oxiinc Packing Material</a>
						<ul>
							<li><a href='<?php echo base_url('Reseller_dashboard/packaging_material_order');?>'>Order Packaging Material</a></li>
							<li><a href='<?php echo base_url('Reseller_dashboard/packaging_material_status');?>'>Packing Material Order Status</a></li>
						</ul>
					</li>
				</ul>
				<?php
			} ?>
	</nav>
	<?php
		//echo '<pre>';print_r($_SESSION);die();
		$seller_query = $this->db->query("SELECT reseller_closing_amount AS RCA FROM seller_wallet WHERE reseller_id = '".$this->session->userdata('r_id')."' ORDER BY id DESC LIMIT 1");
        $seller_closing = $seller_query->result_array();
        $reseller_wallet_amount = ($seller_closing[0]['RCA']) ? $seller_closing[0]['RCA'] : 0;
        $this->session->set_userdata('reseller_wallet_amount', $reseller_wallet_amount);

        $profile_img = $this->session->userdata('r_profile_image');

        $profile_image = (isset($profile_img) && !empty($profile_img) && file_exists('reseller_files/seller_profile_image/'.$profile_img)) ? base_url('reseller_files/seller_profile_image/'.$profile_img) : '';

        $notification_query = $this->db->query("SELECT * FROM seller_notification WHERE status = 1"." ORDER BY id DESC LIMIT 5");
        $notification_data = $notification_query->result_array();
        $notification_count = count($notification_data);
        //echo '<pre>';print_r();die();
	?>
	<div class="navbar navbar-default">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <i class="fa fa-ellipsis-v fa-w-6"></i> </button>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('reseller_user_assets/images/admin-icon.png');?>" alt="" /></a>
					<ul class="dropdown-menu">
						<li>
							<div class="login-user-detail">
								<?php
								if($profile_image){ ?>
									<div class="login-user-img"><img src="<?php echo $profile_image;?>" class="eg-img-col"></div>
								<?php } else{ ?>
									<div class="login-user-img"></div>
								<?php } ?>
								
								<div class="login-user-info"> <span><?php echo ($this->session->userdata('r_full_name')) ? strtoupper($this->session->userdata('r_full_name')) : '';?></span> <span><?php echo ($this->session->userdata('r_email')) ? strtolower($this->session->userdata('r_email')) : '';?></span> </div>
							</div>
							<div class="clrfix"></div>
						</li>
						<li role="separator" class="divider"></li>
						<li>
							<a href="<?php echo base_url('Reseller_dashboard/wallet_balance');?>"><i class="fas fa-fw fa-user-circle"></i> Wallet <span class="wallet-amount">Rs. <?php echo number_format($reseller_wallet_amount, 2);?></span></a>
						</li>
						<li>
							<a href="javascript:void(0);" data-toggle="modal" data-target="#ProfileModal"><i class="fas fa-fw fa-user-circle"></i> Seller Profile</a>
						</li>
						<li>
							<a href="javascript:void(0);" data-toggle="modal" data-target="#BankDetailsModal"><i class="fas fa-fw fa-user-circle"></i> Bank Details</a>
						</li>
						<!-- <li>
							<a href="javascript:void(0);" data-toggle="modal" data-target="#CancelledChequeModal"><i class="fas fa-fw fa-user-circle"></i> Cancelled Cheque</a>
						</li> -->
						<li>
							<a href="javascript:void(0);" data-toggle="modal" data-target="#BillingModal"><i class="fas fa-fw fa-user-circle"></i> Billing</a>
						</li>
						<li>
							<a href="<?php echo base_url('Reseller_dashboard/company_detail');?>"><i class="fas fa-fw fa-user-circle"></i> Company Detail</a>
						</li>
						<li>
							<a href="<?php echo base_url('Reseller_dashboard/director_details'); ?>"><i class="fas fa-fw fa-user-circle"></i> Director/Owner Derails</a>
						</li>
						<li role="separator" class="divider"></li>
						<li>
							<a href="<?php echo base_url('Reseller_dashboard/logout');?>"><i class="fas fa-fw fa-user-circle"></i> Log out</a>
						</li>
					</ul>
				</li>
				<li class="dropdown">
					<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('reseller_user_assets/images/bell-icon.png');?>" alt=""><span class="notify-no"><?php echo $notification_count;?></span></a>
					<ul class="dropdown-menu">
						<?php
							if(isset($notification_data) && !empty($notification_data)) foreach ($notification_data as $key => $value){ ?>
								<li onclick="show_notification_details(<?php echo $value['id'];?>)"><a href="javascript:void(0);"><span class="notify-title"><i class="fa fa-bell"></i><?php echo $value['noti_title'];?></span></a></li>
						<?php } else{ ?>
							<li><a href="javascript:void(0);"><span class="notify-title"><i class="fa fa-bell"></i>Notification not available</span></a></li>
						<?php } ?>
					</ul>
				</li>
				<li class="dropdown">
					<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('reseller_user_assets/images/grid-icon.png');?>" alt="" /></a>
					<ul class="dropdown-menu">
						<li><a href="javascript:void(0);"><i class="fas fa-fw fa-edit"></i> Action</a></li>
						<li><a href="javascript:void(0);"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="javascript:void(0);"><i class="fas fa-fw fa-star "></i> Somthing else here</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</header>
<div class="clrfix"></div>
<!-- END HEADER -->
<!-- Notification Modal -->
<div class="modal fade modal-block" id="NotificationModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="modal-body">
				<form class="form-block">
					<h2 class="headding-01 txt-lower">Seller Notification</h2>
					<div id="notification_hide">
						<div class="form-group">
							<p class="title-col">Notification Title</p>
							<p id="notification_title"></p>
							<p class="title-col">Notification Description</p>
							<p id="notification_description"></p>
						</div>
					</div>
					<div id="noti_not_found" style="color: #c60e0e; font-size: 20px; margin-bottom: 20px;"></div>
					<div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
				</form>
				<div class="clrfix"></div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
    function show_notification_details(id){
    	//alert(id);
        $.ajax({
			type: "POST",
			url: "<?php echo base_url('Reseller_dashboard/notification_details'); ?>",
			data: 'id=' + id,
			success:function(data){
				//alert(data);
				var obj = JSON.parse(data);
				if(obj.status == 'success'){
					$("#notification_title").text(obj.noti_title);
					$("#notification_description").text(obj.noti_description);
					$('#NotificationModal').modal('show');
				}
				if(obj.status == 'error'){
					$('#notification_hide').hide();
					$("#noti_not_found").text(obj.message);
					$('#NotificationModal').modal('show');
				}
			}
		});
    }
</script>