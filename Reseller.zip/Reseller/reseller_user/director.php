<!-- Start Container -->
<div class="main-wrapper">
	<!-- Company Details Section -->
	<section class="user-info-section-02 fwd">
			<div class="container">
				<h1 class="mainpage-headding">Add New <span>Director / Owner Details</span></h1>
				<div class="form-content-block">
					<form class="form-block" method="post" action="<?php echo base_url('Reseller_dashboard/director_details_insert'); ?>" enctype="multipart/form-data" onsubmit="return add_director_validation();">
						<div class="fwd">
							<input type="hidden" class="textbox" name="url" value="director" required readonly>
							<div class="form-block half-width fleft">
								<div class="form-group">
									<label for="">Director Name <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox" name="name[]" id="name" autocomplete="off">
									<span class="bar"></span>
									<div id="dir_name_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director PAN No. <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox text-uppercase" name="pan_no[]" id="pan_no" maxlength="10" autocomplete="off">
									<span class="bar"></span>
									<div id="dir_pan_no_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director Aadhar No. <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox" name="Aadhar[]" id="aadhar" maxlength="12" onkeypress="return isNumberKey(event);" autocomplete="off">
									<span class="bar"></span>
									<div id="dir_aadhar_no_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director Email <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox" name="email[]" id="email" autocomplete="off">
									<span class="bar"></span>
									<div id="dir_email_error" class="input-erroemsg" style="display:none;"></div>
								</div>
							</div>
							<div class="form-block half-width frite">
								<div class="form-group">
									<label for="">Director Mobile No. <span class="mandatory-feild">*</span></label>
									<input type="text" class="textbox" name="Mobile[]" id="mobile" maxlength="10" onkeypress="return isNumberKey(event);" autocomplete="off">
									<span class="bar"></span>
									<div id="dir_mobile_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director PAN Certificate <span class="mandatory-feild">*</span></label>
									<input type="file" hidden="hidden" name="pan_card_img[]" id="add_dir_file_1" accept=".png, .jpg, .jpeg">
									<button type="button" id="add_dir_image_btn_1" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button><span id="add_dir_image_text_1" class="upload-text">No file chosen, yet.</span>
									<div id="dir_pan_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director Aadhar Certificate <span class="mandatory-feild">*</span></label>
									<input type="file" hidden="hidden" name="adhar_card_img[]" id="add_dir_file_2" accept=".png, .jpg, .jpeg">
									<button type="button" id="add_dir_image_btn_2" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button> <span id="add_dir_image_text_2" class="upload-text">No file chosen, yet.</span>
									<div id="dir_aadhar_error" class="input-erroemsg" style="display:none;"></div>
								</div>
								<div class="form-group">
									<label for="">Director Address <span class="mandatory-feild">*</span></label>
									<textarea class="textbox textarea" name="d_address[]" id="d_address" rows="3"></textarea>
									<span class="bar"></span>
									<div id="dir_address_error" class="input-erroemsg" style="display:none;"></div>
								</div>
							</div>
						</div>
						<div class="form-group text-center">
							<button type="submit" class="submit-btn">Save</button>
						</div>
					</form>
				</div>
			</div>
		</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<script type="text/javascript">
	//File Upload Button
    for (var a = 1; a <= 2; a++){
        const common_realFileBtn = document.getElementById("add_dir_file_" + a);
        const common_customBtn = document.getElementById("add_dir_image_btn_" + a);
        const common_customTxt = document.getElementById("add_dir_image_text_" + a);

        common_customBtn.addEventListener("click", function() {
            common_realFileBtn.click();
        });

        common_realFileBtn.addEventListener("change", function() {
            if (common_realFileBtn.value) {
                common_customTxt.innerHTML = common_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
            } else {
                common_customTxt.innerHTML = "No file chosen, yet.";
            }
        });
    }

    function add_director_validation(){
        var rtn = true;
        var pan_filter = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
        var email_filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var upload_file_1 = document.getElementById("add_dir_file_1").files[0];
        var upload_file_2 = document.getElementById("add_dir_file_2").files[0];

        var name = $("#name").val();
        var pan_no = $("#pan_no").val();
        var aadhar = $("#aadhar").val();
        var email = $("#email").val();
        var mobile = $("#mobile").val();
        var d_address = $("#d_address").val();
        var add_dir_file_1 = $("#add_dir_file_1").val();
        var add_dir_file_2 = $("#add_dir_file_2").val();

        if(name == ""){
            $("#dir_name_error").css({"display": "block"}).text('Please enter director name.');
            rtn = false;
        }
        else {
            $("#dir_name_error").css({"display": "none"}).text('');
        }

        if(pan_no == ""){
            $("#dir_pan_no_error").css({"display": "block"}).text('Please enter director pan card number.');
            rtn = false;
        } else if (pan_no.length != 10){
			$("#dir_pan_no_error").css({"display": "block"}).text("Please enter the 10 digits valid director pan card number.");
			rtn = false;
		} else if(!pan_filter.test(pan_no)){
			$("#dir_pan_no_error").css({"display": "block"}).text("Please enter the valid format director card number.");
			rtn = false;
		} else {
            $("#dir_pan_no_error").css({"display": "none"}).text('');
        }

        if(aadhar == ""){
            $("#dir_aadhar_no_error").css({"display": "block"}).text('Please enter director aadhar card number.');
            rtn = false;
        } else if (aadhar.length != 12){
			$("#dir_aadhar_no_error").css({"display": "block"}).text("Please enter the 12 digits valid director aadhar card number.");
			rtn = false;
		} else {
            $("#dir_aadhar_no_error").css({"display": "none"}).text('');
        }

        if(email == ""){
            $("#dir_email_error").css({"display": "block"}).text('Please enter director email id.');
            rtn = false;
        } else if(!email_filter.test($('#email').val())){
			$("#dir_email_error").css({"display": "block"}).text("Please enter the valid format director email id.");
			rtn = false;
		} else {
            $("#dir_email_error").css({"display": "none"}).text('');
        }

        if(mobile == ""){
            $("#dir_mobile_error").css({"display": "block"}).text('Please enter director mobile number.');
            rtn = false;
        } else if (mobile.length != 10){
			$("#dir_mobile_error").css({"display": "block"}).text("Please enter the 10 digits valid mobile number.");
			rtn = false;
		} else {
            $("#dir_mobile_error").css({"display": "none"}).text('');
        }

        if(d_address == ""){
            $("#dir_address_error").css({"display": "block"}).text('Please enter director address.');
            rtn = false;
        }
        else {
            $("#dir_address_error").css({"display": "none"}).text('');
        }

        if(add_dir_file_1 == ""){
            $("#dir_pan_error").css({"display": "block"}).text('Please enter director your pan certificate.');
            rtn = false;
        } else if ($.inArray(upload_file_1.type.toLowerCase(), validImageTypes) < 0){
            $("#dir_pan_error").css({"display": "block"}).text("Please select correct image formate, e.g. - png, jpg, jpeg.");
            rtn = false;
        } else {
            $("#dir_pan_error").css({"display": "none"}).text('');
        }

        if(add_dir_file_2 == ""){
            $("#dir_aadhar_error").css({"display": "block"}).text('Please enter director your aadhar certificate.');
            rtn = false;
        } else if ($.inArray(upload_file_2.type.toLowerCase(), validImageTypes) < 0){
            $("#dir_aadhar_error").css({"display": "block"}).text("Please select correct image formate, e.g. - png, jpg, jpeg.");
            rtn = false;
        } else {
            $("#dir_aadhar_error").css({"display": "none"}).text('');
        }

        if (rtn == true){
            return true;
        }
        else{
            return false;
        }
    }
</script>