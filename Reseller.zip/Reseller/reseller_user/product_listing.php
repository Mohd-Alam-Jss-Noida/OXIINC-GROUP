<?php
    //echo "<pre>";print_r($Product_list);die();
    if ($this->uri->segment(2) == 'Product_list') {
        $heading = 'All Product details';
        $heading_color = 'text-success';
    } elseif ($this->uri->segment(2) == 'pending_product_list'){
        $heading = '<b>Pending</b> Product details';
        $heading_color = 'text-warning';
    } elseif ($this->uri->segment(2) == 'approved_product_list'){
        $heading = '<b>Approved</b> Product details';
        $heading_color = 'text-success';
    } elseif ($this->uri->segment(2) == 'rejected_product_list'){
        $heading = '<b>Rejected</b> Product details';
        $heading_color = 'text-danger';
    } elseif ($this->uri->segment(2) == 'out_of_stock_product_list'){
        $heading = '<b>Out of Stock</b> Product details';
        $heading_color = 'text-danger';
    }
?>
<!-- Start Container -->
<div class="main-wrapper">
	<!-- Order Status Section-01 Start -->
	<section class="order-status-section-01 fwd">
		<div class="container-fluid">
			<h1 class="mainpage-headding"><?php echo $heading;?></h1>
			<?php
	  		if($this->session->flashdata('msg')){
				$flash_array = $this->session->flashdata('msg');?>
				<div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
			<?php } ?>
			<div class="data-table-block form-content-block">
				<?php
                if(isset($Product_list) && !empty($Product_list)){ ?>		
					<table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
						<thead>
							<tr>
								<th>Sr.No</th>
								<th>Product <br> Name</th>
								<th>Sub Category <br> Name</th>
								<th>Original <br> Price</th>
								<th>Price</th>
								<th>GST <br> Percentage</th>
								<th>Shipping <br> Charges</th>
								<th>Total <br> Stock</th>
								<th>Product <br> Status</th>
								<th>Admin Remark</th>
								<th>Size Wise <br> Stock</th>
								<th>Add Stock <br> With Size</th>
								<th>Product <br> Image</th>
								<th>Upload <br> Image</th>
								<th>Edit</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
							<?php
	                        $i = 1;
	                        foreach ($Product_list as $key => $value) {
	                        	if($value['product_approval_status'] == 0){
							        $product_status = 'Pending';
							        $heading_color = 'badge badge-warning';
							    } elseif ($value['product_approval_status'] == 1){
							        $product_status = 'Approved';
							        $heading_color = 'badge badge-success';
							    } elseif ($value['product_approval_status'] == 2){
							        $product_status = 'Rejected';
							        $heading_color = 'badge badge-danger';
							    }
	                        	?>
								<tr>
									<td><?php echo $i++; ?></td>
                                    <td><?php echo $value['Product_Name']; ?></td>
                                    <td><?php echo $value['sub_category_name']; ?></td>
                                    <td><?php echo $value['Original_Prices']; ?></td>
                                    <td><?php echo $value['Prices']; ?></td>
                                    <td><?php echo $value['GST_Persentage']; ?></td>
                                    <td><?php echo $value['Shipping_Charges']; ?></td>
                                    <td><?php echo $value['stock_status']; ?></td>
                                    <td><center><span class="<?php echo $heading_color;?>"><?php echo $product_status;?></span></center></td>
                                    <td ><?php echo $value['reject_remark']; ?></td>
									<td>
										<center onclick="product_information_view_stock_wise(<?php echo $value['ID']; ?>)" class="cursor-p"><i class="fas fa-chart-pie"></i></center>
									</td>
									<td>
										<center onclick="add_product_stock_with_size(<?php echo $value['ID']; ?>)" class="cursor-p"><i class="fab fa-stack-overflow"></i></center>
									</td>
									<td>
										<center onclick="product_information_view_images(<?php echo $value['ID']; ?>)" class="cursor-p"><i class="fas fa-image"></i></center>
									</td>
									<td>
										<center onclick="product_information_upload_images(<?php echo $value['ID']; ?>)" class="cursor-p"><i class="fas fa-upload"></i></center>
									</td>
									<td>
										<center onclick="edit_update_product_information(<?php echo $value['ID']; ?>)" class="cursor-p"><i class="fas fa-edit"></i></center>
									</td>
									<td class="cursor-p">
										<center><a title="Delete" href="<?php echo base_url('Reseller_dashboard/fetch_product_data_delete/'.$value['ID']);?>" onclick="return confirm('Are you sure want to delete this product.')"><i class="fas fa-trash-alt"></i></a></center>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
					<?php
	            }
	            else{ ?>
	                <h4 style="color: red; text-align: center;">Not Have Any Product Yet.</h4>
	            <?php } ?>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<!-- Size Wise Stock Modal -->
<div class="modal fade modal-block" id="SizeWiseStock" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="modal-body">
				<div id="product_stock_wise_ajax_view"></div>
			</div>
		</div>
	</div>
</div>
<!-- Add Stock With Size Modal -->
<div class="modal fade modal-block" id="AddStockWithSize" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog md-top-space" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="modal-body">
				<form class="form-block product-list-form-modal" method="post" action="<?php echo base_url('Reseller_dashboard/product_stock_with_size');?>">
					<h2 class="headding-01">Add Product Stock With Size</h2>
					<div class="fwd">
						<input type="hidden" class="textbox" name="id" id="stock_size_id" required readonly>
						<div class="form-group half-width-col">
							<label for="">Product Size</label>
						</div>
						<div class="form-group half-width-col">
							<label for="">Product Stock</label>
						</div>
					</div>
					<div class="fwd">
						<div class="form-group half-width-col">
							<input type="text" class="textbox" name="sizes[]" autocomplete="off" required>
							<span class="bar"></span>
						</div>
						<div class="form-group half-width-col">
							<input type="text" class="textbox" name="stock_sizes[]" autocomplete="off" required>
							<span class="bar"></span>
						</div>
					</div>
					<div id="append_product_stock_input_field"></div>
					<div class="form-group btn-half-width-col">
						<button type="button" class="submit-btn IFSC-code-btn" id="add_new_product_list">Add</button>
					</div>
					<div class="form-group text-center">
						<button type="submit" class="submit-btn">Update</button>
						<button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
					</div>
				</form>
				<div class="clrfix"></div>
			</div>
		</div>
	</div>
</div>
<!-- View Product Images Model -->
<div class="modal fade modal-block" id="ViewProductImagesModel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="modal-body">
				<div id="product_images_ajax_view"></div>
			</div>
		</div>
	</div>
</div>
<!-- Upload Images Modal -->
<div class="modal fade modal-block" id="UploadProductImages" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="modal-body">
				<form class="form-block" action="<?php echo base_url('Reseller_dashboard/upload_more_product_images'); ?>" method="post" enctype="multipart/form-data">
					<h2 class="headding-01">Upload your images</h2>
					<input type="hidden" class="textbox" name="Product_id" id="Product_id" value="" required readonly>
					<div class="form-group">
						<input type="file" hidden="hidden" id="input_file_10" name="Product_Images[]" accept=".png, .jpg, .jpeg" multiple required>
						<button type="button" id="upload_image_btn_10" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
						<span id="upload_image_text_10" class="upload-text">No file chosen, yet.</span>
						<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
					</div>
					<div class="form-group">
						<span id="insert_after"></span>
					</div>
					<div class="form-group text-center">
				        <button type="submit" value="Submit" class="submit-btn">Submit</button>
				        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
				    </div>
				</form>
				<div class="clrfix"></div>
			</div>
		</div>
	</div>
</div>
<!-- Edit Modal Modal -->
<div class="modal fade modal-block" id="EditUpdateProductModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog md-top-space" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="modal-body">
				<div id="product_update_ajax_view"></div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function product_information_view_stock_wise(id){
	    $.ajax({
	        type: 'POST',
	        url: '<?php echo base_url('Reseller_dashboard/product_information_view_stock_wise');?>',
	        data: { id: id },
	        success: function(data){
	        	//alert(data);
	            $('#SizeWiseStock').modal('show');
	            $('#product_stock_wise_ajax_view').html(data);
	        }
	    });
	}

	function add_product_stock_with_size(id) {
	    $('#AddStockWithSize').modal('show');
	    $('#stock_size_id').val(id);
	}

	$(document).ready(function (){
		var row = 1;
		$(document).on("click", "#add_new_product_list", function (){
			if (row <= 9) {
				var new_row = '<div class="fwd delete_close_product_list"><div class="form-group half-width-col"><input type="text" class="textbox" name="sizes[]" autocomplete="off" required><span class="bar"></span></div><div class="form-group half-width-col"><input type="text" class="textbox" name="stock_sizes[]" autocomplete="off" required><span class="bar"></span></div><div class="form-group btn-half-width-col"><button type="button" class="submit-btn IFSC-code-btn delete_product_list">Delete</button></div></div>';

				$('#append_product_stock_input_field').append(new_row);

				row++;
				return false;
			}
			else{
				alert("You Have Added Only Ten Product Stock With Size At a Time.");
				return false;
			}
		});

		$(document).on("click", ".delete_product_list", function (){
			if(row > 1) {
				$(this).closest('.delete_close_product_list').remove();
				row--;
			}
			return false;
		});
	});

	function product_information_view_images(id) {
	    $.ajax({
	        type: 'POST',
	        url: '<?php echo base_url('Reseller_dashboard/fetch_product_images_data');?>',
	        data: { id: id },
	        success: function(data) {
	            //alert(data);
	            $('#ViewProductImagesModel').modal('show');
	            $('#product_images_ajax_view').html(data);
	        }
	    });
	}

	function product_information_upload_images(id){
	    $('#UploadProductImages').modal('show');
	    $('#Product_id').val(id);
	}

	$(document).ready(function() {
	    if (window.File && window.FileList && window.FileReader) {
	        $("#input_file_10").on("change", function(e) {
	            var files = e.target.files,
	            filesLength = files.length;
	            for (var i = 0; i < filesLength; i++) {
	                var f = files[i]
	                var fileReader = new FileReader();
	                fileReader.onload = (function(e) {
	                    var file = e.target;
	                    $('<div class="uploaded-image-col"><img src=" '+e.target.result+' " /></div>').insertAfter("#insert_after");
	                });
	                fileReader.readAsDataURL(f);
	            }
	        });
	    }
	    else {
	        alert("Your browser doesn't support to File API")
	    }
	});

	function edit_update_product_information(id){
	    $.ajax({
	        type: 'POST',
	        url: '<?php echo base_url('Reseller_dashboard/fetch_product_data');?>',
	        data: { id: id },
	        success: function(data) {
	            $('#EditUpdateProductModal').modal('show');
	            $('#product_update_ajax_view').html(data);
	        }
	    });
	}
</script>