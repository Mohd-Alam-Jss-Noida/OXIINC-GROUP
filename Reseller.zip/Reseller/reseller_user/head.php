<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Oxiinc Reseller Dashboard</title>

	<!-- favicon links -->
	<link rel="apple-touch-icon" href="<?php echo base_url('reseller_files/images/apple-touch-icon.png');?>">
    <link rel="shortcut icon" href="<?php echo base_url('image/logo.png');?>">

	<!-- bootstrap css -->
	<link href="<?php echo base_url('reseller_user_assets/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

	<!-- Fontawesome css -->
	<link href="<?php echo base_url('reseller_user_assets/css/fontawesome/all.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/fontawesome/fontawesome.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/fontawesome/brands.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/fontawesome/solid.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/animate.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/menu.css');?>" rel="stylesheet">

	<!-- Data Table css -->
	<link href="<?php echo base_url('reseller_user_assets/css/datatable/dataTables.bootstrap4.min.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/datatable/buttons.bootstrap4.min.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/datatable/responsive.bootstrap4.min.css');?>" rel="stylesheet">

	<!-- Datepicker css -->
	<link href="<?php echo base_url('reseller_user_assets/css/datepicker.css');?>" rel="stylesheet">

	<!-- custom css -->
	<link href="<?php echo base_url('reseller_user_assets/css/custom-style.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('reseller_user_assets/css/custom-responsive.css');?>" rel="stylesheet">

	<!-- jQuery cdn -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<!-- sweetalert2 cdn -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	<!-- bootstrap javascript library -->
	<script src="<?php echo base_url('reseller_user_assets/js/bootstrap.min.js');?>"></script>
</head>
<body>
	<div id="main-page-wrapper">
	