<div class="clrfix"></div>
<footer>
    <div class="foot-block-01 fwd">
        <div class="container">
            <div class="foot-links-col col-1 equal-height-col">
                <h3>Services</h3>
                <ul class="list-unstyled">
                    <li><a href="javascript:void(0);">Fulfilment Services</a></li>
                    <li><a href="javascript:void(0);">Account Managemant</a></li>
                    <li><a href="javascript:void(0);">Partner Services</a></li>
                    <li><a href="javascript:void(0);">Packaging Services</a></li>
                </ul>
            </div>
            <div class="foot-links-col col-2 equal-height-col">
                <h3>Resources</h3>
                <ul class="list-unstyled">
                    <li><a href="javascript:void(0);">Online Selling Guide</a></li>
                    <li><a href="javascript:void(0);">Products In Demand</a></li>
                    <li><a href="javascript:void(0);">Success Stories</a></li>
                    <li><a href="javascript:void(0);">Seller Learning Center</a></li>
                    <li><a href="javascript:void(0);">News</a></li>
                    <li><a href="javascript:void(0);">API Documentation</a></li>
                </ul>
            </div>
            <div class="foot-links-col col-3 equal-height-col">
                <h3>FAQs</h3>
                <ul class="list-unstyled">
                    <li><a href="javascript:void(0);">Getting Started</a></li>
                    <li><a href="javascript:void(0);">Pricing And Payments</a></li>
                    <li><a href="javascript:void(0);">Listing And Catalog</a></li>
                    <li><a href="javascript:void(0);">Order Management And Shipping</a></li>
                </ul>
            </div>
            <div class="foot-links-col col-4 equal-height-col">
                <h3>Contact Us</h3>
                <ul class="list-unstyled">
                    <li>sell@oxiinc.in</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="foot-block-02 fwd">
        <div class="container">
            © 2020. All Rights Reserved. Design by <a href="https://www.oxiincgroup.com" target="_blank">OXIINCGROUP.COM</a>
            <ul class="list-inline foot-social-media">
                <li><a href="https://www.facebook.com/Erocketmallonlineasialtd" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="https://twitter.com/myoxiinc" target="_blank"><i class="fab fa-twitter"></i></a></li>
                <li><a href="https://www.linkedin.com/company/oxiincgroup" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                <li><a href="https://www.youtube.com/c/OXIINCGROUP" target="_blank"><i class="fab fa-youtube"></i></a></li>
                <li><a href="https://www.instagram.com/oxiinc_group" target="_blank"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>
    </div>
</footer>
<div class="clrfix"></div>
<!-- Profile Modal -->
<?php
$reseller_query = $this->db->query("SELECT full_name, email, mobile_number, store_name, store_description, seller_image FROM reseller WHERE id = ".$this->session->userdata('r_id')." AND mobile_verify = 1");
$reseller_profile = $reseller_query->result_array();
//echo "<pre>";print_r($reseller_profile);die();

$profile_img = (isset($reseller_profile[0]['seller_image']) && !empty($reseller_profile[0]['seller_image']) && file_exists('reseller_files/seller_profile_image/'.$reseller_profile[0]['seller_image'])) ? base_url('reseller_files/seller_profile_image/'.$reseller_profile[0]['seller_image']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<div class="modal fade modal-block" id="ProfileModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">Seller Profile</h2>
                        <div class="form-sucessmsg" id="profile_update_success_msg" style="display:none;"></div>
                        <div class="form-errormsg" id="profile_update_error_msg" style="display:none;"></div>
                        <div class="form-group">
                            <label for="">Full Name</label>
                            <input type="text" class="textbox" id="reseller_full_name" value="<?php echo $reseller_profile[0]['full_name'];?>" autocomplete="off" tabindex="1">
                            <span class="bar"></span>
                            <div id="full_name_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">E-mail</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_profile[0]['email'];?>" readonly="">
                        </div>
                        <div class="form-group">
                            <label for="">Mobile Number</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_profile[0]['mobile_number'];?>" readonly="">
                        </div>
                        <div class="form-group">
                            <label for="">Store Name</label>
                            <input type="text" class="textbox" id="reseller_store_name" value="<?php echo $reseller_profile[0]['store_name'];?>" autocomplete="off" tabindex="2">
                            <span class="bar"></span>
                            <div id="s_name_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">Store Information</label>
                            <textarea class="textbox textarea" id="reseller_store_description" rows="3" autocomplete="off" tabindex="3"><?php echo $reseller_profile[0]['store_description'];?></textarea>
                            <span class="bar"></span>
                            <div id="s_description_error" class="input-erroemsg" style="display:none;" tabindex="4"></div>
                        </div>
                        <div class="form-group no-margin">
                            <p class="title-col">Seller Profile Image: <img src="<?php echo $profile_img;?>" alt="" class="reseller-profile-img"></p>
                        </div>
                        <div class="form-group">
                            <label for="">Update Profile Image</label>
                            <input type="file" class="textbox" id="seller_image" accept=".png, .jpg, .jpeg">
                            <span class="bar"></span>
                            <div id="seller_img_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <input type="hidden" class="textbox" id="old_seller_image" value="<?php echo $reseller_profile[0]['seller_image'];?>" readonly>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="submit-btn" id="profile_update_btn" onclick="reseller_profile_update_validation();">Update Profile</button>
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Bank Details Modal -->
<?php
$bank_query = $this->db->query("SELECT * FROM reseller_bank_details WHERE reseller_id = ".$this->session->userdata('r_id'));
$reseller_bank = $bank_query->result_array();
//echo "<pre>";print_r($reseller_bank);//die();

$cancel_cheque = (isset($reseller_bank[0]['Bank_Cancelled_Cheque']) && !empty($reseller_bank[0]['Bank_Cancelled_Cheque']) && file_exists('reseller_files/reseller_documents/'.$reseller_bank[0]['Bank_Cancelled_Cheque'])) ? base_url('reseller_files/reseller_documents/'.$reseller_bank[0]['Bank_Cancelled_Cheque']) : base_url('reseller_user_assets/images/cancelled-cheque-eg.jpg');
$signature_text = file_exists('reseller_files/reseller_documents/'.$reseller_bank[0]['Bank_Cancelled_Cheque']) ? 'Uploaded Signature' : 'Signature Example';
?>
<div class="modal fade modal-block" id="BankDetailsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">Bank Details</h2>
                        <div class="form-sucessmsg" id="cheque_update_success_msg" style="display:none;"></div>
                        <div class="form-group">
                            <label for="">Account Holder's Name</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_bank[0]['Bank_Holder_Name'];?>" readonly>
                            <span class="bar"></span>
                            <div class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">Bank Account Number</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_bank[0]['Bank_Account_Number'];?>" readonly>
                            <span class="bar"></span>
                            <div class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">Bank IFSC Code</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_bank[0]['Bank_ifsc'];?>" readonly>
                            <span class="bar"></span>
                            <div class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">Bank Name</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_bank[0]['Bank_name'];?>" readonly>
                            <span class="bar"></span>
                            <div class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <label for="">Bank Address</label>
                            <input type="text" class="textbox" value="<?php echo $reseller_bank[0]['Bank_address'];?>" readonly>
                            <span class="bar"></span>
                            <div class="input-erroemsg" style="display:none;"></div>
                        </div>
                    </div>
                    <div class="form-block" style="margin-top: 20px;">
                        <h2 class="headding-01">Cancelled Cheque</h2>
                        <p class="title-col">Please read the instructions and upload your document by clicking below:</p>
                        <div class="form-group">
                            <input type="file" hidden="hidden" name="Cancelled_Cheque_Img" id="input_file_9" accept=".png, .jpg, .jpeg">
                            <button type="button" id="upload_image_btn_9" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
                            <span id="upload_image_text_9" class="upload-text">No file chosen, yet.</span>
                            <div id="cheque_update_error" class="input-erroemsg" style="display:none;"></div>
                        </div>
                        <div class="form-group">
                            <p class="title-col">Upload Instructions</p>
                            <p>
                                1.  Make sure that the document is visibly large and on a white background <br>
                                2.  Allowed files png, jpg etc. <br>
                                3.  Maximum img size should not exceed 100KB. <br> &nbsp;
                            </p>
                        </div>
                        <div class="form-group no-margin">
                            <p class="title-col"><?php echo $signature_text;?>: <img src="<?php echo $cancel_cheque;?>" alt="" class="eg-img-col" style="width: 160px; height: 65px;"></p>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="submit-btn" id="can_cheque_update_btn" onclick="cancelled_cheque_update_validation();">Update</button>
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- Cancelled Cheque Modal -->
<!-- <div class="modal fade modal-block" id="CancelledChequeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <h2 class="headding-01">Cancelled Cheque</h2>
                    <div class="form-sucessmsg" id="cheque_update_success_msg" style="display:none;"></div>
                    <p class="title-col">Please read the instructions and upload your document by clicking below:</p>
                    <div class="form-group">
                        <input type="file" hidden="hidden" name="Cancelled_Cheque_Img" id="input_file_9" accept=".png, .jpg, .jpeg">
                        <button type="button" id="upload_image_btn_9" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
                        <span id="upload_image_text_9" class="upload-text">No file chosen, yet.</span>
                        <div id="cheque_update_error" class="input-erroemsg" style="display:none;"></div>
                    </div>
                    <div class="form-group">
                        <p class="title-col">Upload Instructions</p>
                        <p>
                            1.  Make sure that the document is visibly large and on a white background <br>
                            2.  Allowed files png, jpg etc. <br>
                            3.  Maximum img size should not exceed 100KB. <br> &nbsp;
                        </p>
                    </div>
                    <div class="form-group no-margin">
                        <p class="title-col"><?php echo $signature_text;?>: <img src="<?php echo $cancel_cheque;?>" alt="" class="eg-img-col" style="width: 160px; height: 65px;"></p>
                    </div>
                    <button type="button" class="submit-btn" tabindex="3" onclick="cancelled_cheque_update_validation();">Update</button>
                    <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div> -->
<!-- fontawesome js -->
<script defer src="<?php echo base_url('reseller_user_assets/js/fontawesome/all.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/fontawesome/brands.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/fontawesome/solid.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/fontawesome/fontawesome.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/menu.js');?>"></script>

<!-- Data Table js -->
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/jquery.dataTables.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/dataTables.bootstrap4.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/dataTables.buttons.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/buttons.bootstrap4.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/jszip.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/pdfmake.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/vfs_fonts.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/buttons.html5.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/buttons.print.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/buttons.colVis.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/dataTables.responsive.min.js');?>"></script>
<script defer src="<?php echo base_url('reseller_user_assets/js/datatable/responsive.bootstrap4.min.js');?>"></script>

<!-- Datepicker js -->
<script src="<?php echo base_url('reseller_user_assets/js/datepicker.js');?>"></script>

<!-- custom js -->
<script src="<?php echo base_url('reseller_user_assets/js/custom-script.js');?>"></script>

<script type="text/javascript">
    //DATA TABLE JAVA SCRIPT
    $(document).ready(function() {
        var table = $('#example').DataTable({
            lengthChange: false,
            buttons: [ 'copy', 'excel', 'csv', 'pdf', 'print' ]
        });

        table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );
    });

    //DATEPICKER JAVA SCRIPT
    $(document).ready(function() {
        $("#datepicker").datepicker({
            autoclose: true, 
            todayHighlight: true
        }).datepicker('update', new Date());
    });

    /*ALERT MAEEAGE HIDE AFTER 5 SECOND JAVA SCRIPT CODE*/
    setTimeout(function() {
      $('.fadeout_flash_msg').fadeOut();
    }, 5000 );

    function isNumberKey(evt){
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)){
            return false;
        }
        else{
            return true;
        }
    }

    function reseller_profile_update_validation(){
        var rtn = true;
        var full_name = $("#reseller_full_name").val();
        var store_name = $("#reseller_store_name").val();
        var store_description = $("#reseller_store_description").val();
        var old_seller_image = $("#old_seller_image").val();

        if(store_description == ""){
            $("#s_description_error").css({"display": "block"}).text('Please Enter About Your Store.');
            $("#reseller_store_description").focus();
            rtn = false;
        }
        else {
            $("#s_description_error").css({"display": "none"}).text('');
        }

        if(store_name == ""){
            $("#s_name_error").css({"display": "block"}).text('Please Enter Your Store Display Name.');
            $("#reseller_store_name").focus();
            rtn = false;
        }
        else {
            $("#s_name_error").css({"display": "none"}).text('');
        }

        if(full_name == ""){
            $("#full_name_error").css({"display": "block"}).text('Please Enter Your Name.');
            $("#reseller_full_name").focus();
            rtn = false;
        }
        else {
            $("#full_name_error").css({"display": "none"}).text('');
        }

        if (rtn == true){
            var form_data = new FormData();
            form_data.append("seller_image", document.getElementById('seller_image').files[0]);
            form_data.append("full_name", $("#reseller_full_name").val());
            form_data.append("store_name", store_name);
            form_data.append("store_description", store_description);
            form_data.append("old_seller_image", old_seller_image);
            $.ajax({
                url: "<?php echo base_url('Reseller_dashboard/seller_profile_update');?>",
                type: "POST",
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data){
                    var obj = JSON.parse(data);
                    //alert(data);alert(obj.status);alert(obj.message);exit();
                    if(obj.status == 'error'){
                        $("#profile_update_error_msg").css({"display": "block"}).text(obj.message);
                    }
                    if(obj.status == 'success'){
                        $('#profile_update_btn').prop('disabled', true);
                        $("#profile_update_error_msg").css({"display": "none"}).text('');
                        $("#profile_update_success_msg").css({"display": "block"}).text(obj.message);
                        setTimeout(function (){
                            location.reload();
                        }, 3000);
                    }
                }
            });
        }
        else{
            return false;
        }
    }

    function cancelled_cheque_update_validation(){
        var fileReader = new FileReader();
        var validImageTypes = ["image/png", "image/jpg", "image/jpeg"];
        var uploadFile = document.getElementById("input_file_9").files[0];
        var file_path = $("#input_file_9").val();
        if(file_path == ""){
            $("#cheque_update_error").css({"display": "block"}).text('Please Upload Cancelled Cheque Image.');
            return false;
        }
        else if ($.inArray(uploadFile.type.toLowerCase(), validImageTypes) < 0){
            $("#cheque_update_error").css({"display": "block"}).text("Please select correct image formate, e.g. - png, jpg, jpeg.");
            return false;
        } 
        else {
            var form_data = new FormData();
            form_data.append("Cancelled_Cheque_Img", document.getElementById('input_file_9').files[0]);
            $.ajax({
                type:'POST',
                url:"<?php echo base_url('Reseller_dashboard/update_bank_information'); ?>",
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success:function(data){
                    var obj = JSON.parse(data);
                    //alert(obj.status);
                    //alert(obj.message);
                    if(obj.status == 'error'){
                        $(".cheque_update_error").css({"display": "block"}).text(obj.message);
                    }
                    if(obj.status == 'success'){
                        $('#can_cheque_update_btn').prop('disabled', true);
                        $("#cheque_update_error").css({"display": "none"}).text('');
                        $("#cheque_update_success_msg").css({"display": "block"}).text(obj.message);
                        setTimeout(function (){
                            location.reload();
                        }, 3000);
                    }
                }
            });
        }
    }

    
</script>
</div>
</body>
</html>

