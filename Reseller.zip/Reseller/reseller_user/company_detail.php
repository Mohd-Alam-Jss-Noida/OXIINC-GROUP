<?php
	$pan_image = (isset($company_data[0]['c_pan_number_img']) && !empty($company_data[0]['c_pan_number_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_pan_number_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_pan_number_img']) : base_url('reseller_user_assets/images/image_not_found.png');

	$gst_image = (isset($company_data[0]['c_gst_img']) && !empty($company_data[0]['c_gst_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_gst_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_gst_img']) : base_url('reseller_user_assets/images/image_not_found.png');

	$cin_image = (isset($company_data[0]['c_cin_number_img']) && !empty($company_data[0]['c_cin_number_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_cin_number_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_cin_number_img']) : base_url('reseller_user_assets/images/image_not_found.png');

	$cr_image = (isset($company_data[0]['c_r_number_img']) && !empty($company_data[0]['c_r_number_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_r_number_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_r_number_img']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<!-- Start Container -->
<div class="main-wrapper">
	<!-- Company Details Section -->
	<section class="user-info-section-02 fwd">
		<div class="container">
			<h1 class="mainpage-headding">Company <span>Details</span></h1>
			<?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
			<div class="form-content-block">
				<form class="form-block" action="<?php echo base_url('Reseller_dashboard/company_details_update'); ?>" method="POST"  enctype="multipart/form-data">
					<input type="hidden" class="textbox" name="c_id" value="<?php echo $company_data[0]['c_id'];?>" readonly>
					<input type="hidden" class="textbox" name="c_reseller_id" value="<?php echo $company_data[0]['c_reseller_id'];?>" readonly>
					<div class="form-block half-width fleft">
						<div class="form-group">
							<label for="">Company Name</label>
							<input type="text" class="textbox" value="<?php echo $company_data[0]['c_name'];?>" readonly>
						</div>
						<div class="form-group">
							<label for="">Company Type</label>
							<select class="textbox input-selectbox" name="c_type" id="c_type" required>
								<option value="">Select Company Type</option>
								<option value="public" <?php echo ($company_data[0]['c_type'] == "public") ? 'selected = selected' : '';?>>Public Limited</option>
								<option value="private" <?php echo ($company_data[0]['c_type'] == "private") ? 'selected = selected' : '';?>>Private Limited</option>
								<option value="partnership" <?php echo ($company_data[0]['c_type'] == "partnership") ? 'selected = selected' : '';?>>Partnership</option>
								<option value="proprietorship" <?php echo ($company_data[0]['c_type'] == "proprietorship") ? 'selected = selected' : '';?>>Proprietorship</option>
								<option value="llp" <?php echo ($company_data[0]['c_type'] == "llp") ? 'selected = selected' : '';?>>Limited Liability Parterneship (LLP)</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company PAN No.</label>
							<input type="text" class="textbox" id="c_pan_number" name="c_pan_number" value="<?php echo $company_data[0]['c_pan_number'];?>" maxlength="10" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company GST No.</label>
							<input type="text" class="textbox" id="c_gst_number" name="c_gst_number" value="<?php echo $company_data[0]['c_gst_number'];?>" maxlength="15" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company CIN No.</label>
							<input type="text" class="textbox" id="c_cin_number" name="c_cin_number" value="<?php echo $company_data[0]['c_cin_number'];?>" maxlength="21" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company Registration No.</label>
							<input type="text" class="textbox" id="c_r_number" name="c_r_number" value="<?php echo $company_data[0]['c_r_number'];?>" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company Address</label>
							<input type="text" class="textbox" id="c_address" name="c_address" value="<?php echo $company_data[0]['c_address'];?>" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company City</label>
							<input type="text" class="textbox" id="c_city" name="c_city" value="<?php echo $company_data[0]['c_city'];?>" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company District</label>
							<input type="text" class="textbox" id="c_district" name="c_district" value="<?php echo $company_data[0]['c_district'];?>" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company State</label>
							<input type="text" class="textbox" id="c_state" name="c_state" value="<?php echo $company_data[0]['c_state'];?>" autocomplete="off" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company Pincode</label>
							<input type="text" class="textbox" id="c_pincode" name="c_pincode" value="<?php echo $company_data[0]['c_pincode'];?>" autocomplete="off" maxlength="6" autocomplete="off" onkeypress="return isNumberKey(event)" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company Mobile Number</label>
							<input type="text" class="textbox" id="c_mobile_number" name="c_mobile_number" value="<?php echo $company_data[0]['c_mobile_number'];?>" maxlength="10" autocomplete="off" onkeypress="return isNumberKey(event)" required>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company Telephone Number</label>
							<input type="text" class="textbox" id="c_telephone" name="c_telephone" value="<?php echo $company_data[0]['c_telephone'];?>" autocomplete="off" maxlength="11" autocomplete="off" onkeypress="return isNumberKey(event)">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<div class="form-group">
							<label for="">Company Website</label>
							<input type="text" class="textbox" id="c_website" name="c_website" value="<?php echo $company_data[0]['c_website'];?>" autocomplete="off">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
					</div>
					<div class="form-block half-width frite">
						<div class="form-group">
							<label for="">Company Email</label>
							<input type="email" class="textbox" value="<?php echo $company_data[0]['c_email'];?>" readonly>
						</div>
						<div class="form-group pan-card-img">
							<img onclick="company_image_statement('<?php echo $pan_image;?>')" src="<?php echo $pan_image;?>" style="cursor: pointer;">
						</div>
						<div class="form-group">
							<label for="">Company PAN Certificate</label>
							<input type="file" id="company_file_1" name="c_pan_number_img" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="company_image_btn_1" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="company_image_text_1" class="upload-text">No file chosen, yet.</span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<p style="color: #FF0000;">Note:- Please select document formate e.g. - png, jpg, jpeg</p>
						<div class="form-group pan-card-img">
							<img onclick="company_image_statement('<?php echo $gst_image;?>')" src="<?php echo $gst_image;?>" style="cursor: pointer;">
						</div>
						<div class="form-group">
							<label for="">Company GST Certificate</label>
							<input type="file" id="company_file_2" name="c_gst_img" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="company_image_btn_2" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="company_image_text_2" class="upload-text">No file chosen, yet.</span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<p style="color: #FF0000;">Note:- Please select document formate e.g. - png, jpg, jpeg</p>
						<div class="form-group pan-card-img">
							<img onclick="company_image_statement('<?php echo $cin_image;?>')" src="<?php echo $cin_image;?>" style="cursor: pointer;">
						</div>
						<div class="form-group">
							<label for="">Company CIN Certificate</label>
							<input type="file" id="company_file_3" name="c_cin_number_img" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="company_image_btn_3" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="company_image_text_3" class="upload-text">No file chosen, yet.</span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<p style="color: #FF0000;">Note:- Please select document formate e.g. - png, jpg, jpeg</p>
						<div class="form-group pan-card-img">
							<img onclick="company_image_statement('<?php echo $cr_image;?>')" src="<?php echo $cr_image;?>" style="cursor: pointer;">
						</div>
						<div class="form-group">
							<label for="">Company Registration Certificate</label>
							<input type="file" id="company_file_4" name="c_r_number_img" hidden="hidden" accept=".png, .jpg, .jpeg">
							<button type="button" id="company_image_btn_4" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
							<span id="company_image_text_4" class="upload-text">No file chosen, yet.</span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						</div>
						<p style="color: #FF0000;">Note:- Please select document formate e.g. - png, jpg, jpeg</p>
					</div>
					<input type="hidden" class="textbox" name="old_pan_img" value="<?php echo $company_data[0]['c_pan_number_img'];?>" readonly>
					<input type="hidden" class="textbox" name="old_gst_img" value="<?php echo $company_data[0]['c_gst_img'];?>" readonly>
					<input type="hidden" class="textbox" name="old_cin_img" value="<?php echo $company_data[0]['c_cin_number_img'];?>" readonly>
					<input type="hidden" class="textbox" name="old_cr_img" value="<?php echo $company_data[0]['c_r_number_img'];?>" readonly>
					<div class="form-group text-center">
						<button type="submit" class="submit-btn">Update</button>
					</div>
				</form>
			</div>
		</div>
	</section>
	<div class="clrfix"></div>
</div>
<!-- End Container -->
<!-- company show image modal -->
<div class="modal fade modal-block" id="company_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog md-top-space" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="modal-body">
                <form class="form-block">
                    <div class="form-block">
                        <h2 class="headding-01">View image statement</h2>
                        <div class="form-group">
                            <img src="" id="statement_image" style="width: 100%">
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button type="button" class="cancel-btn" data-dismiss="modal">Close</button>
                    </div>
                </form>
                <div class="clrfix"></div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
	//File Upload Button
    for (var a = 1; a <= 4; a++){
        const common_realFileBtn = document.getElementById("company_file_" + a);
        const common_customBtn = document.getElementById("company_image_btn_" + a);
        const common_customTxt = document.getElementById("company_image_text_" + a);

        common_customBtn.addEventListener("click", function() {
            common_realFileBtn.click();
        });

        common_realFileBtn.addEventListener("change", function() {
            if (common_realFileBtn.value) {
                common_customTxt.innerHTML = common_realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
            } else {
                common_customTxt.innerHTML = "No file chosen, yet.";
            }
        });
    }

    function company_image_statement(img_src) {
        $('#company_image_model').modal('show');
        document.getElementById("statement_image").src = img_src;
    }
</script>