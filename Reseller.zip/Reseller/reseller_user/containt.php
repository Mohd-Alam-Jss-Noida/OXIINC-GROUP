<?Php
	$this->load->view('reseller_user/head');
    $this->load->view('reseller_user/header');
	$this->load->view($main_containt);
	$this->load->view('reseller_user/footer');
?>