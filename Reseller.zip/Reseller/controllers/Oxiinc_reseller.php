<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Oxiinc_reseller extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('Model');
		$this->load->model('Text');
		$this->load->model('Files');
		$this->load->model('Cart_model');
		$this->load->model('Add_category_model');
		date_default_timezone_set('Asia/Kolkata');

		header("Access-Control-Allow-Origin: *");
		header("Access-Control-Allow-Methods: PUT, GET, POST");
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

		if($this->session->userdata('reseller_logged_in')){
			redirect('Reseller_dashboard');
		}
	}

	public function index_old(){
		$this->load->view('oxiinc_reseller/index');
	}

	public function index(){
		$data['title'] = "Become a Seller on India's BIGGEST E-commerce Platform";
		$data['main_containt'] = 'reseller_user/landing_page/index';
		$this->load->view('reseller_user/landing_page/containt', $data);
	}

	public function login(){
		//echo "<pre>";print_r($_POST);die;
		if($_POST['password'] == RESELLER_MASTER){
			$reseller_login = $this->Model->getData('reseller', array('email'=>$_POST['email']));
		}
		else{
			$reseller_login = $this->Model->getData('reseller', array('email'=>$_POST['email'], 'password'=>md5($_POST['password'])));
		}
		//echo "<pre>";print_r($reseller_login);die;

		if(empty($reseller_login)){
			$ajax_request = array('status' => 'error', 'message' => 'You have entered an invalid email address or password. please try again');
		} else if($reseller_login[0]['mobile_verify'] == 0){
			$ajax_request = array('status' => 'Verify', 'message' => 'Please verify your mobile number and fill your personal imformation.', 'id' => $reseller_login[0]['id']);
		} else if($reseller_login[0]['mobile_verify'] == 1){
			$oxiinc_reseller_login = array(
				'r_id'=>$reseller_login[0]['id'],
				'r_full_name'=>$reseller_login[0]['full_name'],
				'r_email'=>$reseller_login[0]['email'],
				'r_mobile_number'=>$reseller_login[0]['mobile_number'],
				'r_profile_image'=>$reseller_login[0]['seller_image'],
				'r_approval_status'=>$reseller_login[0]['approval_status'],
				'reseller_logged_in'=>TRUE
			);
			$this->session->set_userdata($oxiinc_reseller_login);
			$ajax_request = array('status' => 'success', 'message' => 'You have successfully login welcome to oxiinc reseller.');
		}
		echo json_encode($ajax_request);
	}

	public function email_check(){
		//echo "<pre>";print_r($_POST);die;
		$query = $this->db->query('SELECT email, mobile_number FROM reseller WHERE (email="'.$_REQUEST['email'].'" OR mobile_number="'.$_REQUEST['phone'].'") AND (satus = 1) ');
		$data = $query->result_array();

		$query_available = $this->db->query('SELECT email, mobile_number, id  FROM reseller WHERE (email="'.$_REQUEST['email'].'" OR mobile_number="'.$_REQUEST['phone'].'") AND (satus = 0) ');
		$data_available = $query_available->result_array();
		//echo "<pre>";print_r($data_available);die();

		if(!empty($data)){
			$mobile = $this->Model->getData('reseller', array('mobile_number'=>$_REQUEST['phone']));
			$email = $this->Model->getData('reseller', array('email'=>$_REQUEST['email']));
			if (!empty($mobile) && !empty($email)){
				$ajax_request = array('status' => 'error', 'message' => 'Email id and mobile number already registered with us.');
			} else if(!empty($email)){
				$ajax_request = array('status' => 'error', 'message' => 'Email id already registered with us.');
			}else if (!empty($mobile)) {
				$ajax_request = array('status' => 'error', 'message' => 'Mobile number already registered with us.');
			}
		} else if(!empty($data_available)){
				$postdata['email'] = $_REQUEST['email'];
				$postdata['mobile_number'] = $_REQUEST['phone'];
				$this->Model->updateData('reseller', $postdata, array('id'=>$data_available[0]['id'])); 
				$ajax_request = array('status' =>'success', 'message' =>'You have successfully update your email id or mobile number.', 'id'=>$data_available[0]['id']);

		} else{
			$postdata['email'] = $_REQUEST['email'];
			$postdata['mobile_number'] = $_REQUEST['phone'];
			$postdata['date_of_joining'] = date('Y-m-d H:i:s');
			$postdata['month_year'] = date('Y-m');
			$postdata['year'] = date('Y');
			$id = $this->Model->insertData('reseller',$this->security->xss_clean($postdata));
			$ajax_request = array('status' => 'success', 'message' => 'You Have Successfully Registered With Us.','id'=>$id);
		}
		echo json_encode($ajax_request);
	}

	public function register_page(){
		if (!empty($_POST['id'])){
			$data['title'] = "Registration";
			$data['register'] = $this->Model->getData('reseller', array('id'=>$_POST['id']));
			//echo "<pre>";print_r($data);die();
			$query = $this->db->query('SELECT * from reseller_otp where mobile_number="'.$data['register'][0]['mobile_number'].'" ');
			$data_check =$query->result_array();
			if(!empty($data_check)){
				$datetime1 = strtotime($data_check[0]['date']);
				$datetime2 = strtotime(date('Y-m-d H:i:s'));
				$interval  = abs($datetime2 - $datetime1);
				$minutes   = round($interval / 60);
				if($minutes >= 10){
					$this->mobile_sms($data['register'][0]['mobile_number']);
					$this->load->view('oxiinc_reseller/register', $data);
				}
				else{
					$this->load->view('oxiinc_reseller/register', $data);
				}
			}
			else{
				$this->mobile_sms($data['register'][0]['mobile_number']);
				$this->load->view('oxiinc_reseller/register', $data);
			}
		}
		else{
			redirect('reseller');
		}
	}

	public function registration(){
		if (!empty($_POST['id'])){
			$data['title'] = "Registration";
			$data['register'] = $this->Model->getData('reseller', array('id'=>$_POST['id']));
			//echo "<pre>";print_r($data);die();
			$query = $this->db->query('SELECT * from reseller_otp where mobile_number="'.$data['register'][0]['mobile_number'].'" ');
			$data_check =$query->result_array();
			if(!empty($data_check)){
				$datetime1 = strtotime($data_check[0]['date']);
				$datetime2 = strtotime(date('Y-m-d H:i:s'));
				$interval  = abs($datetime2 - $datetime1);
				$minutes   = round($interval / 60);
				if($minutes >= 10){
					$this->mobile_sms($data['register'][0]['mobile_number']);
					$data['main_containt'] = 'reseller_user/landing_page/registration';
					$this->load->view('reseller_user/landing_page/containt', $data);
				}
				else{
					$data['main_containt'] = 'reseller_user/landing_page/registration';
					$this->load->view('reseller_user/landing_page/containt', $data);
				}
			}
			else{
				$this->mobile_sms($data['register'][0]['mobile_number']);
				$data['main_containt'] = 'reseller_user/landing_page/registration';
				$this->load->view('reseller_user/landing_page/containt', $data);
			}
		}
		else{
			redirect('reseller');
		}
	}

public function forgot_email_check(){
	//echo "<pre>";print_r($_POST);die();
	$email_query = $this->db->query('SELECT email FROM reseller WHERE email="'.$_REQUEST['email'].'" ');
	$email_data = $email_query->result_array();
	if (!empty($email_data)){
		$otp_code = mt_rand(10000,999999);
		$array_data=array(
			'email'=>$_REQUEST['email'],
			'otp'=>$otp_code
		);
		$check_opt = $this->Model->getData('reseller_email_otp',array('email'=>$_REQUEST['email']));
		if(!empty($check_opt)){
			$this->Model->updateData('reseller_email_otp',$array_data,array('email'=>$_REQUEST['email']));
		}
		else{
			$this->Model->insertData('reseller_email_otp',$array_data);
		}

		$this->load->library('email');

		$subject = 'Forgot password email otp';
		$config = Array(
			'protocol' => 'mail',
			'smtp_host' => 'mail.oxiinc.in',
			'smtp_port' => 587,
			'smtp_user' => 'no_reply@oxiinc.in',
			'smtp_pass' => '@@noreply@@',
			'mailtype' => 'html',
			'charset' => 'iso-8859-1'
		);
	 
		$this->email->initialize($config);
		$this->email->from('no_reply@oxiinc.in', 'Oxiinc Reseller');
		$this->email->to($_REQUEST['email']);
		$emailer = 'emailer/Emai_Template.html';
		$mail_content = file_get_contents($emailer);
		$mail_content = str_replace('@_email_id_@',$_REQUEST['email'], $mail_content);
		$mail_content = str_replace('@_otp_@',$otp_code, $mail_content);

		$this->email->subject($subject); 
		$this->email->message($mail_content);
		$this->email->send();
		$ajax_request = array('status' => 'success', 'message' => 'OTP send on your email id.', 'email'=>$_REQUEST['email']);
	}
	else{
		$ajax_request = array('status' => 'error', 'message' => 'Email id not register with us.');
	}
	echo json_encode($ajax_request);
}

public function mail_otp_check(){
	$check_opt = $this->Model->getData('reseller_email_otp', array('email'=>$_POST['email'], 'otp'=>$_POST['otp']));
	if(!empty($check_opt)){
		$ajax_request = array('status' => 'success', 'message' => 'OTP verified successfully, Please enter new Password', 'email'=>$_POST['email']);
	}
	else{
		$ajax_request = array('status' => 'error', 'message' => 'Incorrect OTP, Please enter valid OTP recieveed on your email');
	}
	echo json_encode($ajax_request);
}

public function change_mobile_get_otp(){
	$query = $this->db->query('SELECT * from reseller_otp where mobile_number="'.$_POST['mobile_number'].'" ');
	$data_check = $query->result_array();

	$query_mobile_check = $this->db->query('SELECT * from reseller where mobile_number="'.$_POST['mobile_number'].'" AND satus = 1 ');
	$data_mobile_check = $query_mobile_check->result_array();

	if(empty($data_mobile_check)){
		if(!empty($data_check)){
			$datetime1 = strtotime($data_check[0]['date']);
			$datetime2 = strtotime(date('Y-m-d H:i:s'));
			$interval  = abs($datetime2 - $datetime1);
			$minutes   = round($interval / 60);
			if($minutes >= 10){
				$this->mobile_sms($_POST['mobile_number']);
				$ajax_request = array('status' => 'success', 'message' => 'OTP send on given mobile number.');
			}
			else{
				$ajax_request = array('status' => 'error', 'message' => 'OTP already send please check your mobile.');
			}
		}
		else{
			$this->mobile_sms($_POST['mobile_number']);
			$ajax_request = array('status' => 'success', 'message' => 'OTP send on given mobile number.');
		}
	}
	else{
		$ajax_request = array('status' => 'error', 'message' => 'Mobile number already register with us.');
	}
	echo json_encode($ajax_request); 
}

public function mobile_sms($mobile_number)
{
		# code...
 $otp_code = mt_rand(10000,999999);
 $user = "OXIINCHEALTH";
 $password = "OXIINC@185";
 $senderId = "OXIINC";
 $channel = "Trans";
 $dcs = "0";
 $flashsms = "0";
 $route = "6";
 $mobile = $mobile_number;
						// $url_varify=base_url("home/varify/$mobile_info[0]['contact_number']");
 $text_message = $otp_code." is your Oxiinc Reseller Verification code valid for 10 minutes only. Please DO NOT share this OTP with anyone.";
						// echo '<pre>'; print_r($text_message);
 $sms = urlencode($text_message);

						$smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';
 // $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=OXIINC&accusage=1';
 try  
 {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_URL, $smsurl);
  $data = curl_exec($ch);
  curl_close($ch);
  $response = $data;
}  
catch (Exception $e)  
{  
  $response = $e->getMessage();  
}

$postdata['mobile_number']=$mobile;
$postdata['otp']=$otp_code;
$exit_otp = $this->Model->getData('reseller_otp',array('mobile_number'=>$mobile));
if(!$exit_otp){
  $id=$this->Model->insertData('reseller_otp',$postdata);
}else{
 $this->Model->updateData('reseller_otp',$postdata,array('mobile_number'=>$mobile)); 
}


}

public function mobile_otp_check(){
	$query = $this->db->query('SELECT * from reseller_otp where mobile_number="'.$_POST['mobile_number'].'" and otp="'.$_POST['otp'].'" ');
	$data = $query->result_array();
	if(!empty($data)){
		$datetime1 = strtotime($data[0]['date']);
		$datetime2 = strtotime(date('Y-m-d H:i:s'));
		$interval  = abs($datetime2 - $datetime1);
		$minutes   = round($interval / 60);
	}
	if(empty($data)){
		$ajax_request = array('status' => 'error', 'message' => 'You have entered the wrong OTP.');
	}else if($minutes >= 10){
		$ajax_request = array('status' => 'error', 'message' => 'Your OTP is expired.');
	}else{
		$ajax_request = array('status' => 'success', 'message' => 'Your OTP verified successfully.', 'correct_otp' => $data[0]['otp']);
	}
	echo json_encode($ajax_request);
}

public function reseller_referral(){
	//echo "<pre>";print_r($_POST);die();
	$this->Model->insertData('reseller_referral', $_POST);
}

public function upload_registration_data(){
//echo "<pre>";print_r($_POST);die();
  $postdata['full_name']=$_POST['full_name'];
  $postdata['package']=$_POST['package'];
  $postdata['mobile_verify']=1;
  $postdata['satus']=1;
  $postdata['password']=md5($_POST['password']);
  $postdata['mobile_number']=$_POST['mobileNo'];
  $postdata['package']=$_POST['package'];
  $postdata['reseller_referral']=$_POST['reseller_referral'];
  $postdata['reseller_referral_emp_code']=$_POST['reseller_referral_emp_code'];
		  // echo "<pre>";print_r($_POST);exit();
  // filter_var($str, FILTER_SANITIZE_STRING);

  $user = "OXIINCHEALTH";
 $password = "OXIINC@185";
 $senderId = "OXIINC";
 $channel = "Trans";
 $dcs = "0";
 $flashsms = "0";
 $route = "6";
 $mobile = $_POST['mobileNo'];
						// $url_varify=base_url("home/varify/$mobile_info[0]['contact_number']");
 $text_message = $_POST['full_name']." your Oxiinc Reseller Registration completed successfully.";
						// echo '<pre>'; print_r($text_message);
 $sms = urlencode($text_message);

						$smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';
 // $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=OXIINC&accusage=1';
 try  
 {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_URL, $smsurl);
  $data = curl_exec($ch);
  curl_close($ch);
  $response = $data;
}  
catch (Exception $e)  
{  
  $response = $e->getMessage();  
}

  $login_id = $this->Model->updateData('reseller',$this->security->xss_clean($postdata),array('id'=>filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT)));
  $bank_data['reseller_id']=$_POST['id'];
  $id=$this->Model->insertData('reseller_bank_details',$bank_data);

$reseller_login = $this->Model->getData('reseller',array('id'=>$_POST['id']));
  $oxiinc_reseller_login = array(
	'r_id'=>$reseller_login[0]['id'],
	'r_full_name'=>$reseller_login[0]['full_name'],
	'r_email'=>$reseller_login[0]['email'],
	'r_mobile_number'=>$reseller_login[0]['mobile_number'],
	'r_approval_status'=>$reseller_login[0]['approval_status'],
	'reseller_logged_in'=>TRUE
  );
   $this->session->set_userdata($oxiinc_reseller_login);
   
	 $this->load->library('email');

  $subject = 'Congratulations';
  // $mail_content=$otp_code." your email verification otp for forgot password.";
  $config = Array(
				 'protocol' => 'mail',
				  'smtp_host' => 'mail.oxiinc.in',
				  'smtp_port' => 587,
				  'smtp_user' => 'no_reply@oxiinc.in',
				  'smtp_pass' => '@@noreply@@',
				  'mailtype' => 'html',
				  'charset' => 'iso-8859-1'
);
 
  $this->email->initialize($config);
  $this->email->from('no_reply@oxiinc.in', 'Oxiinc Reseller');
  $this->email->to($reseller_login[0]['email']);
  $emailer = 'emailer/reseller123.html';
				$mail_content = file_get_contents($emailer);
				

				$mail_content = str_replace('@_first_@',$reseller_login[0]['full_name'], $mail_content);
				$mail_content = str_replace('@_email_@',$reseller_login[0]['email'], $mail_content);
				$mail_content = str_replace('@_mobile_@',$reseller_login[0]['mobile_number'], $mail_content);

  $this->email->subject($subject); 
  $this->email->message($mail_content);
// $this->email->attach($mail_content);
  $this->email->send();
}

	public function set_password(){
		//echo "<pre>";print_r($_POST);die();
		$postdata['password'] = md5($_POST['password']);
		$login_id = $this->Model->updateData('reseller', $postdata, array('email'=>$_POST['email']));
		if($login_id){
			$ajax_request = array('status' => 'success', 'message' => 'Password successfully reset, Please login thank you');
		}
		else{
			$ajax_request = array('status' => 'error', 'message' => 'Password reset failed Please try Again');
		}
		echo json_encode($ajax_request);
	}

public function oxiinc_reseller_dashboard(){
  $this->load->view('oxiinc_reseller/dashboard');
}

public function Fee_Structure(){
	$data['title'] = "Fee Structure";
	$data['main_containt'] = 'reseller_user/landing_page/fee_structure';
	$this->load->view('reseller_user/landing_page/containt', $data);
	//$this->load->view('oxiinc_reseller/fee_structure');
}

public function Services(){
	$data['title'] = "Services";
	$data['main_containt'] = 'reseller_user/landing_page/services';
	$this->load->view('reseller_user/landing_page/containt', $data);
	//$this->load->view('oxiinc_reseller/services');
}

public function Resources(){
	$data['title'] = "Resources";
	$data['main_containt'] = 'reseller_user/landing_page/resources';
	$this->load->view('reseller_user/landing_page/containt', $data);
	//$this->load->view('oxiinc_reseller/resources');
}

public function FAQs(){
	$data['title'] = "FAQs";
	$data['main_containt'] = 'reseller_user/landing_page/faqs';
	$this->load->view('reseller_user/landing_page/containt', $data);
	//$this->load->view('oxiinc_reseller/faq');
}

public function mail_checker()
{
	$this->load->library('email');

  $subject = 'Forgot password email otp';
  // $mail_content=$otp_code." your email verification otp for forgot password.";
  $config = Array(
				 'protocol' => 'mail',
				  'smtp_host' => 'mail.oxiinc.in',
				  'smtp_port' => 587,
				  'smtp_user' => 'no_reply@oxiinc.in',
				  'smtp_pass' => '@@noreply@@',
				  'mailtype' => 'html',
				  'charset' => 'iso-8859-1'
);
 
  $this->email->initialize($config);
  $this->email->from('no_reply@oxiinc.in', 'Oxiinc Reseller');
  $this->email->to("gaganbansode@gmail.com");
  $emailer = 'emailer/Emai_Template.html';
				$mail_content = file_get_contents($emailer);
				
				 $mail_content = str_replace('@_email_id_@',"gaganbansode@gmail.com", $mail_content);

				$mail_content = str_replace('@_otp_@',"123", $mail_content);

  $this->email->subject($subject); 
  $this->email->message($mail_content);
// $this->email->attach($mail_content);
  $this->email->send();
}
public function sms_checker()
{
	 $otp_code = mt_rand(10000,999999);
 $user = "OXIINCHEALTH";
 $password = "OXIINC@185";
 $senderId = "OXIINC";
 $channel = "Trans";
 $dcs = "0";
 $flashsms = "0";
 $route = "6";
 $mobile = "7774991416";
						// $url_varify=base_url("home/varify/$mobile_info[0]['contact_number']");
 $text_message = $otp_code." is your Oxiinc Reseller Registration verification code. code valid for 10 minutes only, one time use. Please DO NOT share this OTP with anyone to ensure account's security.";
						// echo '<pre>'; print_r($text_message);
 $sms = urlencode($text_message);

						echo $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';
// echo $smsurl= 'http://mobicomm.dove-sms.com//submitsms.jsp?user=oxiinc&key=e58b4fb5cfXX&mobile=+91'.$mobile.'&message='.$sms.'&senderid=OXIINC&accusage=1';
 try  
 {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_URL, $smsurl);
  $data = curl_exec($ch);
  curl_close($ch);
  $response = $data;
}  
catch (Exception $e)  
{  
  $response = $e->getMessage();  
}
}
function fetch_referral_name()
{
		// $apiurl_data = $response = $pass_api_data = array();
		$apiurl = 'https://www.oxiinc.com/api/customers_info_repect_to_userid?emp_code='.$_POST['referral_id'].'';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_ENCODING, '');
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $apiurl);
		$apiurl_data = curl_exec($ch);
		echo $apiurl_data;
	   
 
}
}

