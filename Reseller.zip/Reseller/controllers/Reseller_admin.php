<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reseller_admin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Banner_add');   
        $this->load->model('Model');
        $this->load->model('Home_page');  
        $this->load->model('Customer_login_Information');
        $this->load->helper('common_helper');
        date_default_timezone_set("Asia/Kolkata");

        if(!$this->session->userdata('is_logged_in')){
            redirect('Reseller_login');
        }
    }

    public function index(){
        $data['title'] = 'Reseller Admin Dashboard';
        $data['main_containt'] = 'reseller_admin/index';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function packing_material_add_update(){
        //echo "<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata = array(
                'product_name' => $this->input->post('product_name'),
                'product_price' => $this->input->post('product_price')
            );
            if (!empty($_POST['id'])){
                $postdata['updated_date'] = date("Y-m-d H:i:s");
                $update_id = $this->Model->updateData('packing_material', $this->security->xss_clean($postdata), array('id'=>$_POST['id']));
                if($update_id){
                    $flash_data = array('text_msg'=>'Packing material updated successfully.', 'text_class'=>'form-sucessmsg text-center');
                }
                else{
                    $flash_data = array('text_msg'=>'Packing material updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
                }
            } else{
                $insert_id = $this->Model->insertData('packing_material',$this->security->xss_clean($postdata));
                if($insert_id){
                    $flash_data = array('text_msg'=>'Packing material added successfully.', 'text_class'=>'form-sucessmsg text-center');
                }
                else{
                    $flash_data = array('text_msg'=>'Packing material added failed? please try again.', 'text_class'=>'form-errormsg text-center');
                }
            }
            $this->session->set_flashdata('msg', $flash_data);
            redirect('Reseller_admin/packing_material_list');
        }
    }

    public function packing_material_list(){
        $data['title'] = 'Reseller Packing Materials';
        $data['reseller_packing'] = $this->Model->getData('packing_material', array());
        $data['main_containt'] = 'reseller_admin/packing_material_list';
        //echo "<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function packing_material_status(){
        //echo "<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['status'] = $_POST['status'];
            $update_id = $this->Model->updateData('packing_material', $postdata, array('id'=>$_POST['id']));
            if($update_id){
                $flash_data = array('text_msg'=>'Packing material status updated successfully.', 'text_class'=>'form-sucessmsg text-center');
            }
            else{
                $flash_data = array('text_msg'=>'Packing material status updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
            }
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/packing_material_list');
    }

    public function pending_reseller(){
        $data['title'] = 'Pending Reseller details';
        $query = $this->db->query("SELECT * FROM reseller WHERE approval_status = '0' ORDER BY id DESC");
        $data['reseller_data'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_list';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function approved_reseller(){
        $data['title'] = 'Approved Reseller details';
        $query = $this->db->query("SELECT * FROM reseller WHERE approval_status = '1' ORDER BY date_of_joining  DESC");
        $data['reseller_data'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_list';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function rejected_reseller(){
        $data['title'] = 'Rejected Reseller details';
        $query = $this->db->query("SELECT * FROM reseller WHERE approval_status = '2' ORDER BY date_of_joining  DESC");
        $data['reseller_data'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_list';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function director_details(){
        $data['title'] = 'Reseller Director details';
        $data['director_data'] = $this->Model->getData('director_details', array('d_reseller_id'=>$this->uri->segment(3)));
        $data['main_containt'] = 'reseller_admin/director_details';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function director_details_edit(){
        $data['director_data'] = $this->Model->getData('director_details', array('d_id'=>$this->uri->segment(3)));
        $data['main_containt'] = 'reseller_admin/director_details_edit';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function director_details_update(){
        //echo"<pre>";print_r($_POST);die();
        $upload_dir = 'reseller_files/reseller_documents/director_info/';
        if(!empty($_FILES['d_pan_card']['name'])){
            $ext = pathinfo($_FILES['d_pan_card']['name'], PATHINFO_EXTENSION);
            $oxiinc = rand(). '.' .$ext;
            $uploadfile = $upload_dir . $oxiinc;
            if(move_uploaded_file($_FILES['d_pan_card']['tmp_name'], $uploadfile)){
                $d_pan_card_img = $oxiinc;
                unlink($upload_dir . $this->input->post('old_pan_img'));
            }
        }
        else{
            $d_pan_card_img = $this->input->post('old_pan_img');
        }

        if(!empty($_FILES['d_adhar_img']['name'])){
            $ext1 = pathinfo($_FILES['d_adhar_img']['name'], PATHINFO_EXTENSION);
            $oxiinc1 = rand(). '.' .$ext1;
            $uploadfile1 = $upload_dir . $oxiinc1;
            if(move_uploaded_file($_FILES['d_adhar_img']['tmp_name'], $uploadfile1)){
                $d_adhar_card_img = $oxiinc1;
                unlink($upload_dir . $this->input->post('old_adhar_img'));
            }
        }
        else{
            $d_adhar_card_img = $this->input->post('old_adhar_img');
        }
        $postdata = array(
            'd_name' => $this->input->post('d_name'),
            'd_email' => $this->input->post('d_email'),
            'd_mobile' => $this->input->post('d_mobile'),
            'd_address' => $this->input->post('d_address'),
            'd_pan_no' => $this->input->post('d_pan_no'),
            'd_pan_card' => $d_pan_card_img,
            'd_adhar_card' => $this->input->post('d_adhar_card'),
            'd_adhar_img' => $d_adhar_card_img,
            'd_update_time' => date('Y-m-d H:i:s')
        );
        //echo"<pre>";print_r($postdata);exit();
        $update_id = $this->Model->updateData('director_details', $this->security->xss_clean($postdata), array('d_id'=>$_POST['d_id'], 'd_reseller_id'=>$_POST['d_reseller_id']));

        if ($update_id){
            $flash_data = array('text_msg'=>'Director details updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Director details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/director_details/'.$_POST['d_reseller_id']);
    }

    public function company_details(){
        $data['title'] = 'Reseller company details';
        $data['company_data'] = $this->Model->getData('reseller_company_details', array('c_reseller_id'=>$this->uri->segment(3)));
        $data['main_containt'] = 'reseller_admin/company_details';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function company_details_update(){
        //echo "<pre>";print_r($_POST);
        //echo "<pre>";print_r($_FILES);die();
        $upload_dir = 'reseller_files/reseller_documents/';
        if(!empty($_FILES['c_pan_number_img']['name'])){
            $ext = pathinfo($_FILES['c_pan_number_img']['name'], PATHINFO_EXTENSION);
            $oxiinc = rand(). '.' .$ext;
            $uploadfile = $upload_dir . $oxiinc;
            if (move_uploaded_file($_FILES['c_pan_number_img']['tmp_name'], $uploadfile)){
                $pan_img = $oxiinc;
            }
        }
        else{
            $pan_img = $this->input->get_post('old_pan_img');
        }

        if(!empty($_FILES['c_gst_img']['name'])){
            $ext = pathinfo($_FILES['c_gst_img']['name'], PATHINFO_EXTENSION);
            $oxiinc2 = rand(). '.' .$ext;
            $uploadfile2 = $upload_dir . $oxiinc2;
            if (move_uploaded_file($_FILES['c_gst_img']['tmp_name'], $uploadfile2)){
                $gst_img = $oxiinc2;
            }
        }
        else{
            $gst_img = $this->input->get_post('old_gst_img');
        }

        if(!empty($_FILES['c_cin_number_img']['name'])){
            $ext = pathinfo($_FILES['c_cin_number_img']['name'], PATHINFO_EXTENSION);
            $oxiinc3 = rand(). '.' .$ext;
            $uploadfile2 = $upload_dir . $oxiinc3;
            if (move_uploaded_file($_FILES['c_cin_number_img']['tmp_name'], $uploadfile2)){
                $cin_img = $oxiinc3;
            }
        }
        else{
            $cin_img = $this->input->get_post('old_cin_img');
        }

        if(!empty($_FILES['c_r_number_img']['name'])){
            $ext = pathinfo($_FILES['c_r_number_img']['name'], PATHINFO_EXTENSION);
            $oxiinc4 = rand(). '.' .$ext;
            $uploadfile1 = $upload_dir . $oxiinc4;
            if (move_uploaded_file($_FILES['c_r_number_img']['tmp_name'], $uploadfile1)){
                $cr_img = $oxiinc4;
            }
        }
        else{
            $cr_img = $this->input->get_post('old_cr_img');
        }
        
        $postdata = array(
            'c_type' => $this->input->post('c_type'),
            'c_name' => $this->input->post('c_name'),
            'c_email' => $this->input->post('c_email'),
            'c_address' => $this->input->post('c_address'),
            'c_city' => $this->input->post('c_city'),
            'c_district' => $this->input->post('c_district'),
            'c_state' => $this->input->post('c_state'),
            'c_pincode' => $this->input->post('c_pincode'),
            'c_mobile_number' => $this->input->post('c_mobile_number'),
            'c_telephone' => $this->input->post('c_telephone'),
            'c_website' => $this->input->post('c_website'),
            'c_pan_number' => $this->input->post('c_pan_number'),
            'c_gst_number' => $this->input->post('c_gst_number'),
            'c_cin_number' => $this->input->post('c_cin_number'),
            'c_r_number' => $this->input->post('c_r_number'),
            'c_pan_number_img' => $pan_img,
            'c_gst_img' => $gst_img,
            'c_cin_number_img' => $cin_img,
            'c_r_number_img' => $cr_img
        );
        //echo"<pre>";print_r($postdata);exit();
        $update_id = $this->Model->updateData('reseller_company_details', $this->security->xss_clean($postdata), array('c_id'=>$_POST['c_id'], 'c_reseller_id'=>$_POST['c_reseller_id']));
        if($update_id){
            $flash_data = array('text_msg'=>'Company details updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Company details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/company_details/'.$_POST['c_reseller_id']);
    }

    public function bank_details(){
        $data['title'] = 'Reseller bank details';
        $data['bank_data'] = $this->Model->getData('reseller_bank_details', array('reseller_id'=>$this->uri->segment(3)));
        $data['main_containt'] = 'reseller_admin/bank_details';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function bank_details_update(){
        //echo"<pre>";print_r($_POST);die();
        $upload_dir = 'reseller_files/reseller_documents/';
        if(!empty($_FILES['Bank_Cancelled_Cheque']['name'])){
            $ext = pathinfo($_FILES['Bank_Cancelled_Cheque']['name'], PATHINFO_EXTENSION);
            $oxiinc = rand(). '.' .$ext;
            $uploadfile = $upload_dir . $oxiinc;
            if(move_uploaded_file($_FILES['Bank_Cancelled_Cheque']['tmp_name'], $uploadfile)){
                $cancelled_cheque = $oxiinc;
            }
        }
        else{
            $cancelled_cheque = $this->input->post('old_cheque_img');
        }
        $postdata = array(
            'Bank_Holder_Name' => $this->input->post('Bank_Holder_Name'),
            'Bank_Account_Number' => $this->input->post('Bank_Account_Number'),
            'Bank_ifsc' => $this->input->post('Bank_ifsc'),
            'Bank_name' => $this->input->post('Bank_name'),
            'Bank_address' => $this->input->post('Bank_address'),
            'Bank_Cancelled_Cheque' => $cancelled_cheque,
            'rb_status' => $this->input->post('rb_status'),
            'admin_remark' => $this->input->post('admin_remark'),
            'rb_update_time' => date('Y-m-d H:i:s')
        );
        //echo"<pre>";print_r($postdata);exit();
        $update_id = $this->Model->updateData('reseller_bank_details', $this->security->xss_clean($postdata), array('id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));

        if ($update_id){
            $flash_data = array('text_msg'=>'Reseller bank details updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Reseller bank details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/bank_details/'.$_POST['reseller_id']);
    }

    public function reseller_pending_product(){
        $data['title'] = 'Reseller pending product details';
        $query = $this->db->query("SELECT w.ID, w.reseller_id, w.Product_Name, w.Original_Prices, w.Prices, w.product_approval_status, w.GST_Persentage, w.Shipping_Charges, w.stock_status, w.created, r.id, r.full_name FROM wellness AS w LEFT JOIN reseller AS r ON w.reseller_id = r.id WHERE w.product_approval_status = 0 and w.reseller_id != '' ORDER BY w.ID DESC");
        $data['product_data'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_product_list';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function reseller_approved_product(){
        $data['title'] = 'Reseller approved product details';
        $query = $this->db->query("SELECT w.ID, w.reseller_id, w.Product_Name, w.Original_Prices, w.Prices, w.product_approval_status, w.GST_Persentage, w.Shipping_Charges, w.stock_status, w.created, r.id, r.full_name FROM wellness AS w LEFT JOIN reseller AS r ON w.reseller_id = r.id WHERE w.product_approval_status = 1 and w.reseller_id != '' ORDER BY w.ID DESC");
        $data['product_data'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_product_list';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function reseller_rejected_product(){
        $data['title'] = 'Reseller rejected product details';
        $query = $this->db->query("SELECT w.ID, w.reseller_id, w.Product_Name, w.Original_Prices, w.Prices, w.product_approval_status, w.GST_Persentage, w.Shipping_Charges, w.stock_status, w.created, r.id, r.full_name FROM wellness AS w LEFT JOIN reseller AS r ON w.reseller_id = r.id WHERE w.product_approval_status = 2 and w.reseller_id != '' ORDER BY w.ID DESC");
        $data['product_data'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_product_list';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function reseller_product_edit(){
        $temp_data['ID'] = $this->uri->segment(3);
        $temp_data['reseller_id'] = $this->uri->segment(4);
        $this->session->set_userdata($temp_data);
        ?>
        <script type="text/javascript">
            window.location = "<?php echo base_url('Reseller_admin/reseller_product_update'); ?>";
        </script>
        <?php
    }

    public function reseller_product_update(){
        $data['title'] = 'Reseller product update details';
        $data['category_name'] = $this->Model->getData('category', array('status'=>'1'));
        $data['sub_category_name'] = $this->Model->getData('subcategory', array('status'=>'1'));
        $data['product_category_name'] = $this->Model->getData('product_category', array('status'=>'1'));
        $data['product_details'] = $this->Model->getData('wellness',array('ID'=>$this->session->userdata('ID'), 'reseller_id'=>$this->session->userdata('reseller_id')));
        $data['multiple_image'] = $this->Model->getData('multiple_picture', array('Product_id'=>$this->session->userdata('ID')));
        $data['main_containt'] = 'reseller_admin/reseller_product_update';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function reseller_product_submit(){
        if(!empty($_POST['ID']) && !empty($_POST['reseller_id'])){
            //echo"<pre>";print_r($_POST);die();
            $remove[] = "'";
            $remove[] = '"';
            $postData['category_id'] = $_POST['category_id'];
            $postData['sub_category_id'] = $_POST['sub_category_id'];
            $postData['product_category_id'] = $_POST['product_category_id'];
            $postData['Product_Name'] = str_replace($remove, "", $_POST['Product_Name']);
            $postData['Original_Prices'] = $_POST['Original_Prices'];
            $postData['Prices'] = $_POST['Prices'];
            $postData['reseller_original_prices'] = $_POST['Original_Prices'];
            $postData['reseller_prices'] = $_POST['Prices'];
            $postData['Shipping_Charges'] = $_POST['Shipping_Charges'];
            $postData['GST_Persentage'] = $_POST['GST_Persentage'];
            $postData['product_color'] = $_POST['product_color'];
            $postData['hsn_code'] = $_POST['hsn_code'];
            $postData['Short_Description'] = $_POST['Short_Description'];
            $postData['large_Description'] = $_POST['large_Description'];
            $postData['product_approval_status'] = $_POST['product_approval_status'];
            $postData['admin_remark'] = $_POST['admin_remark'];

            if ($_POST['product_approval_status'] == 0){
                $postData['status'] = 0;
            }
            if ($_POST['product_approval_status'] == 1){
                $postData['status'] = 1;
            }
            if ($_POST['product_approval_status'] == 2){
                $postData['status'] = 0;
            }

            //echo "<pre>";print_r($postData);die();
            $id = $this->Model->updateData('wellness',$postData,array('ID'=>$_POST['ID'], 'reseller_id'=>$_POST['reseller_id']));
            if($id){
                if(!empty($_FILES['Product_Picture_Mult']['name'])){
                    $upload_dir = 'uploads/Multiple_Picture/';
                    $ext = pathinfo($_FILES['Product_Picture_Mult']['name'], PATHINFO_EXTENSION);
                    $oxiinc = rand(). '.' .$ext;
                    $uploadfile = $upload_dir . $oxiinc;
                    if(move_uploaded_file($_FILES['Product_Picture_Mult']['tmp_name'], $uploadfile)){
                        $product_image = $oxiinc;
                    }
                }
                else{
                    $product_image = $this->input->post('old_product_img');
                }
                $post_image['Product_Picture_Mult'] = $product_image;

                $update_img=$this->Model->updateData('multiple_picture', $post_image, array('ID'=>$_POST['image_id'], 'Product_id'=>$_POST['ID']));
                
                if($update_img){
                    $flash_data = array('text_msg'=>'Reseller product details and product image updated successfully.', 'text_class'=>'form-sucessmsg text-center');
                }
                else{
                    $flash_data = array('text_msg'=>'Reseller product image updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
                }
            }
            else{
                $flash_data = array('text_msg'=>'Reseller product details and product image updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
            }
            $this->session->set_flashdata('msg', $flash_data);
            redirect('Reseller_admin/reseller_product_update');
        }
        else{
            $flash_data = array('text_msg'=>'Reseller product details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
            $this->session->set_flashdata('msg', $flash_data);
            redirect('Reseller_admin/reseller_pending_product');
        }
    }

    public function reseller_package(){
        $query = $this->db->query("SELECT bds.*, r.full_name FROM bank_deposite_statement AS bds LEFT JOIN reseller AS r ON r.id = bds.reseller_id WHERE bds.status =".$this->uri->segment(3)." ORDER BY bds.id DESC");
        $data['package_details'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/reseller_package_list';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function reseller_package_status_update(){
        //echo"<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['status'] = $_POST['status'];
            $postdata['status_remark'] = $_POST['status_remark'];
            $postdata['updated_date'] = date('Y-m-d H:i:s');
            $update_id = $this->Model->updateData('bank_deposite_statement', $postdata, array('id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));
            if($update_id){
                $flash_data = array('text_msg'=>'Reseller package status updated successfully.', 'text_class'=>'form-sucessmsg text-center');
            }
            else{
                $flash_data = array('text_msg'=>'Reseller package status updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
            }
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/reseller_package/'.$_POST['url']);
    }

    public function packing_material_request(){
        $query = $this->db->query("SELECT bds.*, r.full_name FROM packing_material_bank_deposite_statement AS bds LEFT JOIN reseller AS r ON r.id = bds.reseller_id WHERE bds.status = ".$this->uri->segment(3)."  ORDER BY bds.id DESC");
        $data['material_details'] = $query->result_array();
        $data['main_containt'] = 'reseller_admin/packing_material_request_list';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function packing_material_payment_status_update(){
        //echo "<pre>";print_r($_POST);die();
        $data['status'] = $_POST['status'];
        $data['admin_remark'] = $_POST['status_remark'];
        $data['updated_date'] = date('Y-m-d H:i:s');

        $data['delivery_status'] = 0;
        $data['delivery_remark'] = NULL;
        $data['delivery_date'] = NULL;

        $id_1 = $this->Model->updateData('packing_material_bank_deposite_statement', $data, array('id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));
        $id_2 = $this->Model->updateData('reseller_packing_material_request', $data, array('bank_deposite_id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));

        if($id_1 && $id_2){
            $flash_data = array('text_msg'=>'Seller packing material payment status updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Seller packing material payment status updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/packing_material_request/'.$_POST['url']);
    }

    public function packing_material_delivery_status_update(){
        //echo "<pre>";print_r($_POST);die();
        $data['delivery_status'] = $_POST['delivery_status'];
        $data['delivery_remark'] = $_POST['delivery_remark'];
        $data['delivery_date'] = date('Y-m-d H:i:s');

        $id_1 = $this->Model->updateData('packing_material_bank_deposite_statement', $data, array('id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));
        $id_2 = $this->Model->updateData('reseller_packing_material_request', $data, array('bank_deposite_id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));

        if($id_1 && $id_2){
            $flash_data = array('text_msg'=>'Seller packing material delivery status updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Seller packing material delivery status updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/packing_material_request/'.$_POST['url']);
    }

    public function notification(){
        $data['title'] = 'Add seller notification details';
        $data['main_containt'] = 'reseller_admin/notification';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function notification_insert(){
        //echo"<pre>";print_r($_POST);
        //echo"<pre>";print_r($_FILES);die();
        if(!empty($_FILES['noti_image']['name'])){
            $upload_dir = 'reseller_files/seller_notification_image/';
            $ext = pathinfo($_FILES['noti_image']['name'], PATHINFO_EXTENSION);
            if(($ext == "png") || ($ext == "jpg") || ($ext == "jpeg")){
                $oxiinc = rand(). '.' .$ext;
                $uploadfile = $upload_dir . $oxiinc;
                if(move_uploaded_file($_FILES['noti_image']['tmp_name'], $uploadfile)){
                    $uploaded_img = $oxiinc;
                }
            }
            else{
               $flash_data = array('text_msg'=>'Please select correct image formate, e.g. - png, jpg, jpeg.', 'text_class'=>'form-errormsg text-center');
               $this->session->set_flashdata('msg', $flash_data);
               redirect('Reseller_admin/notification_details');
            }
        }
        else{
            $flash_data = array('text_msg'=>'Seller notification image and details inserted failed? Please try again.', 'text_class'=>'form-errormsg text-center');
            $this->session->set_flashdata('msg', $flash_data);
            redirect('Reseller_admin/notification_details');
        }
        $post_data = array(
            'noti_title'=>$_POST['noti_title'],
            'noti_description'=>$_POST['noti_description'],
            'noti_image'=>$uploaded_img
        );

        $insert_id = $this->Model->insertData('seller_notification', $this->security->xss_clean($post_data));
        if($insert_id){
            $flash_data =array('text_msg'=>'Seller notification details inserted successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data =array('text_msg'=>'Seller notification details inserted failed? Please try again.', 'text_class'=>'form-sucessmsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/notification_details');
    }

    public function notification_details(){
        $data['title'] = 'Seller Notification Details';
        $data['notification_data'] = $this->Model->getDataOrderBy('seller_notification', array(), 'id','DESC');
        $data['main_containt'] = 'reseller_admin/notification_details';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function notification_status_update(){
        //echo"<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $post_data['status'] = $_POST['status'];
            $post_data['status_remark'] = $_POST['status_remark'];
            $post_data['updated_date'] = date('Y-m-d H:i:s');
            $update_id = $this->Model->updateData('seller_notification', $post_data, array('id'=>$_POST['id']));
            if($update_id){
                $flash_data = array('text_msg'=>'Notification status updated successfully.', 'text_class'=>'form-sucessmsg text-center');
            }
            else{
                $flash_data = array('text_msg'=>'Notification status updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
            }
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/notification_details');
    }

    public function notification_update(){
        $data['title'] = 'View and Update seller notification details';
        $data['notification_data'] = $this->Model->getData('seller_notification', array('id'=>$this->uri->segment(3)));
        $data['main_containt'] = 'reseller_admin/notification_update';
        //echo"<pre>";print_r($data);die();
        $this->load->view('reseller_admin/containt', $data);
    }

    public function notification_update_submit(){
        //echo "<pre>";print_r($_POST);
        //echo "<pre>";print_r($_FILES);exit();
        if(!empty($_FILES['noti_image']['name'])){
            $upload_dir = 'reseller_files/seller_notification_image/';
            $ext = pathinfo($_FILES['noti_image']['name'], PATHINFO_EXTENSION);
            if(($ext == "png") || ($ext == "jpg") || ($ext == "jpeg")){
                $oxiinc = rand(). '.' .$ext;
                $uploadfile = $upload_dir . $oxiinc;
                if(move_uploaded_file($_FILES['noti_image']['tmp_name'], $uploadfile)){
                    $uploaded_img = $oxiinc;
                    unlink($upload_dir . $this->input->post('old_noti_image'));
                }
            }
            else{
               $flash_data = array('text_msg'=>'Please select correct image formate, e.g. - png, jpg, jpeg.', 'text_class'=>'form-errormsg text-center');
               $this->session->set_flashdata('msg', $flash_data);
               redirect('Reseller_admin/notification_details');
            }
        }
        else{
            $uploaded_img = $this->input->post('old_noti_image');
        }
        $post_data = array(
            'noti_title'=>$_POST['noti_title'],
            'noti_description'=>$_POST['noti_description'],
            'noti_image'=>$uploaded_img,
            'updated_date'=>date('Y-m-d H:i:s')
        );

        $update_id = $this->Model->updateData('seller_notification', $this->security->xss_clean($post_data), array('id'=>$_POST['id']));
        if($update_id){
            $flash_data = array('text_msg'=>'Notification details updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Notification details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/notification_details');
    }

    public function bank_format_payout_request(){
        $data['title'] = 'Bank format payout request details';
        if (isset($_POST['to_date']) && !empty($_POST['to_date']) && isset($_POST['from_date']) && !empty($_POST['from_date'])){
            $to_date = date('Y-m-d ', strtotime($_POST['to_date'])).'00:00:00';
            $from_date = date('Y-m-d ', strtotime($_POST['from_date'])).'23:59:00';
            $condition = array('user_request_date >= ' => $to_date, 'user_request_date <= ' => $from_date);
            $data['to_date'] = $_POST['to_date'];
            $data['from_date'] = $_POST['from_date'];
        }
        else{
            $condition = array();
        }
        $data['reseller_payout'] = $this->Model->getDataOrderBy('payout_statement', $condition, 'id', 'DESC');
        //echo "<pre>";print_r($data['reseller_payout']);die();
        $data['main_containt'] = 'reseller_admin/bank_format_payout_request';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function bank_payout_upload_excel(){
        $data['title'] = 'Bank payout upload excel details';
        $data['main_containt'] = 'reseller_admin/bank_payout_upload_excel';
        $this->load->view('bank_payout_upload_excel');
    }

    public function reseller_payout_upload_excel(){
        //echo "<pre>";print_r($_FILES);die();
        if(isset($_POST["submit"]) && !empty($_POST['submit'])){
            include("third_party/PHPExcel.php");
            include("third_party/PHPExcel/IOFactory.php");
            $reader = PHPExcel_IOFactory::createReader('Excel5');
            $reader->setReadDataOnly(true);
            $file = isset($_FILES["upload_excel"]['tmp_name']) ? $_FILES["upload_excel"]['tmp_name'] : '';
            $objPHPExcel = $reader->load($file);
            $objWorksheet = $objPHPExcel->getActiveSheet();
            $header = true;
            if($header){
                $highestRow = $objWorksheet->getHighestRow();
                $highestColumn = $objWorksheet->getHighestColumn();
                $headingsArray = $objWorksheet->rangeToArray('A2:' . $highestColumn . '2', null, true, true, true);
                $headingsArray = $headingsArray[2];
                $r = -1;
                $namedDataArray = array();
                for ($row = 7; $row <= $highestRow; ++$row) {
                    $dataRow = $objWorksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, true, true);
                    if ((isset($dataRow[$row]['A'])) && ($dataRow[$row]['A'] > '')) {
                        ++$r;
                        foreach ($headingsArray as $columnKey => $columnHeading) {
                            $namedDataArray[$r][$columnHeading] = $dataRow[$row][$columnKey];
                        }
                    }
                }
            }
            else {
                $namedDataArray = $objWorksheet->toArray(null, true, true, true);
            }
    
            foreach ($namedDataArray as $key => $value){
                $postdata = array(
                    'status' => 1,
                    'admin_remark' => $_POST['admin_remark'],
                    'admin_response_date' => date("Y-m-d H:i:s")
                );
                //echo "<pre>";print_r($postdata);
                
                $payout_query = "UPDATE payout_statement SET status = 1, admin_remark = '".$_POST['admin_remark']."', admin_response_date = '".date("Y-m-d H:i:s")."' WHERE LOWER(reseller_email) = '".strtolower($value['Bene Bank Name'])."' AND id = ".$value['Payment details 1'];

                $payout_update = $this->db->query($payout_query);
                $this->session->set_flashdata('msg','payout approval statement uploaded successfully.');
            }
        }
        else{
            $this->session->set_flashdata('msg','payout approval statement uploaded failed.');
        }
        redirect('Slider/bank_payout_upload_excel');
    }

    public function reseller_payout_request(){
        $data['title'] = 'Seller payout request details';
        $data['reseller_payout'] = $this->Model->getDataOrderBy('payout_statement', array('status'=>$this->uri->segment(3)), 'id', 'DESC');
        //echo "<pre>";print_r($data['reseller_payout']);die();
        $data['main_containt'] = 'reseller_admin/bank_reseller_payout_request_list';
        $this->load->view('reseller_admin/containt', $data);
    }

    public function reseller_payout_request_update(){
        //echo "<pre>";print_r($_POST);die();
        $update_data['status'] = $_POST['status'];
        $update_data['admin_remark'] = $_POST['admin_remark'];
        $update_data['admin_response_date'] = date('Y-m-d H:i:s');
        $update_id = $this->Model->updateData('payout_statement', $this->security->xss_clean($update_data), array('id'=>$_POST['id'], 'reseller_id'=>$_POST['reseller_id']));
        if($update_id){
            $flash_data =array('text_msg'=>'Seller payout request status updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Seller payout request status updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_admin/reseller_payout_request/'.$_POST['url']);
    }


    public function View(){
        $id = $_GET['id'];
        $table = $this->Model->getData('slider',array('id'=>$id));
        $data['view'] = $table;
        $data['main_containt']='view_slider';
        
        $this->load->view('containt',$data);
    }

    public function car_report(){
        $id = $_GET['id'];
        $table = $this->Model->getData('e_panelist_gift_order',array('status'=>'1'));
        $data['e_panelist_gift_order'] = $table;
        $data['main_containt']='car_report';
        
        $this->load->view('containt',$data);
    }

    public function Slider_eidt(){
        $id = $_GET['id'];
        $data['table'] = $this->Model->getData('slider',array('id'=>$id));
        $data['main_containt']='edit_slider';
        $this->load->view('containt',$data);
    }

    public function Delete(){
        $user_id = $this->input->get_post('id');
        $this->Model->deleteData('slider',array('id'=>$user_id));
        $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');
        redirect('Slider/Slide_list');
    }

    public function Total_GST_Report_date(){
        $query =$this->db->query("SELECT * from order_data where order_year_month_data between '".$_POST['start']."' and '".$_POST['end']."' ");
        $data['order_data'] = $query->result_array();
        $data['main_containt']='Total_GST_Report';
        $this->load->view('containt',$data);
    }

    public function Total_GST_Report_epanelist_date(){
        $var_from= $_POST['start']." 00:00:00";
        $var_to = $_POST['end']." 23:59:59";
        $query = $this->db->query("select * from e_paenlist_order_data where order_confirmation='1' AND order_date_time between '".$var_from."' and '".$var_to."' ");
        $data['order_data'] = $query->result_array();
        $data['main_containt']='Total_GST_Report_epanelist';
        $this->load->view('containt',$data);
    }

    public function Edit(){
        $postData = $_POST;
        $id = $this->input->get_post('id');
            if(!empty($_FILES['picture'])){
            $uploaddir = './uploads/images/';
            $uploadfile = $uploaddir . basename($_FILES['picture']['name']);
            if (move_uploaded_file($_FILES['picture']['tmp_name'], $uploadfile)) {
                $postData['picture'] = basename($_FILES['picture']['name']);
            }
        }
        $this->Model->updateData('slider',$postData,array('id'=>$id)); 
        $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');

        $table = $this->Model->getData('slider');
        $data['sliderpicture'] = $table;
        $data['main_containt']='Slide_list';
        $this->load->view('containt',$data);
    }

    public function Add_banner(){
        $category_data = $this->Model->getData('category');
        $data['category_data'] = $category_data;
        $data['main_containt']='add_banner';
        $this->load->view('containt',$data);
    }
    
    //Add new banner homepage start
    public function add_new_banner(){
        $data['main_containt']='new_admin/add_banner_new';
        $this->load->view('new_admin/new_page',$data);
    }

    public function new_add(){
        if($this->input->post('userSubmit')){
            //Check whether user upload picture
            if(!empty($_FILES['product_image']['name'])){
                $config['upload_path'] = 'uploads/new_admin/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['product_image']['name'];
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                if($this->upload->do_upload('product_image')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{

                    $picture = '';
                }
            }else{

                $picture = '';
            }
            //Prepare array of user data
            $userData = array(
                'category' => $this->input->post('product_category'),
                'name' => $this->input->post('product_name'),
                'type' => $this->input->post('product_type'),
                'brand' => $this->input->post('product_brand'),
                'price' => $this->input->post('product_price'),
                'status' => 'A',
                'image' => $picture

            );
            // echo '<pre>'; print_r($userData); //exit;
            //Pass user data to model
            $insertUserData = $this->Home_page->insert($userData);
            $this->session->set_flashdata('msg','Congratulations Successfully uploaded');
            redirect('slider/banner_list/'.$this->input->post('product_category'));
            
        }
        //Form for adding user data
        // $this->load->view('views/camera_wrap');
    }


public function banner_edit_save(){
    $postData = $_POST;
    $id = $this->input->get_post('id');
    if(!empty($_FILES['product_image'])){
        $uploaddir = './uploads/new_admin/';
        $uploadfile = $uploaddir . basename($_FILES['product_image']['name']);

        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadfile)) {
          // echo "File is valid, and was successfully uploaded.\n";
          $img = basename($_FILES['product_image']['name']);
      }
  }
    //echo '<pre>'; print_r($postData); exit;
  $postData = array(
    'category' => $this->input->post('product_category'),
    'name' => $this->input->post('product_name'),
    'type' => $this->input->post('product_type'),
    'brand' => $this->input->post('product_brand'),
    'price' => $this->input->post('product_price'),
    'image' => $img,
    'status' => 'A',
);
  $this->Model->updateData('home_page_contents',$postData,array('id'=>$id)); 
  $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
  $sql="select * from home_page_contents where id = '".$id."' and status = 'A'";
  $query = $this->db->query($sql);  
  $data['sliderpicture'] = $query->result_array(); 
  $data['main_containt']='new_admin/banner_list';
  $this->load->view('new_admin/new_page',$data);
}


function banner_delete_new(){
    $id = $this->input->get_post('id');
    //$this->Model->deleteData('slider',array('id'=>$user_id));
    $postData=array('status' => 'D');
    $this->Model->updateData('home_page_contents',$postData,array('id'=>$id)); 
    $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

    $sql="select * from home_page_contents where category = '".$this->input->get_post('category')."' and status = 'A'";
    $query = $this->db->query($sql);  
    $data['sliderpicture'] = $query->result_array(); 
    $data['main_containt']='new_admin/banner_list';
    $this->load->view('new_admin/new_page',$data);
}

function banner_list(){
    // echo '<pre>'; print_r($_POST);exit;
    //$table = $this->Model->getData('home_page_contents');
    $sql="select * from home_page_contents where category = '".$this->uri->segment(3)."' and status = 'A'";
    $query = $this->db->query($sql);
    //$data['order_data'] = $query->result_array();    
    //echo '<pre>'; print_r($query->result_array());exit;    
    $data['sliderpicture'] = $query->result_array(); 
    $data['main_containt']='new_admin/banner_list';
    $this->load->view('new_admin/new_page',$data);
}


function banner_view(){
    $id = $_GET['id'];
    $sql="select * from home_page_contents where category = '".$this->uri->segment(3)."' and status = 'A' and id='".$id."'";
    $query = $this->db->query($sql);
    //$table = $this->Model->getData('slider',array('id'=>$id));
    $data['view'] = $query->result_array();
    /*$data['main_containt']='view_slider';
    $this->load->view('containt',$data);*/

    $data['main_containt']='new_admin/banner_view';
    $this->load->view('new_admin/new_page',$data);
}

function banner_edit_new(){
    //echo '<pre>'; print_r($_GET); exit;
    $id = $_GET['id'];
    $sql="select * from home_page_contents where category = '".$this->uri->segment(3)."' and status = 'A' and id='".$id."'";//die;
    $query = $this->db->query($sql);
    //$table = $this->Model->getData('slider',array('id'=>$id));
    $data['table'] = $query->result_array();
    // echo '<pre>'; print_r($data); exit;
    //$data['main_containt']='edit_banner';
    $data['main_containt']='new_admin/edit_banner';

    $this->load->view('new_admin/new_page',$data);
}



/******Add new banner homepage end*******/


function Add_Pro_banner(){
    $category_data = $this->Model->getData('category');
    $data['category_data'] = $category_data;
    $data['main_containt']='Add_Pro_banner';

    $this->load->view('containt',$data);
}
function List_Pro_banner(){

    $Pro_banner = $this->Model->getData('pro_banner');
    $data['Pro_banner'] = $Pro_banner;
    $data['main_containt']='List_Pro_banner';
    $this->load->view('containt',$data);
}
function List_Of_Cancel_Product(){

    $cancellation_request = $this->Model->getData('cancellation_request',array('status'=>'1'));
            // $strSql = "SELECT * FROM cancellation_request  payment_method='enpay'OR payment_method='PayUMoney'";
            //     $cancellation_request =$this->Model->getSqlData($strSql);
    $data['cancellation_request'] = $cancellation_request;
    $data['main_containt']='cancellation_request';
    $this->load->view('containt',$data);
}
function List_Of_Return_Product(){

    $return_order = $this->Model->getData('return_order',array('status'=>'1'));
    $data['return_order'] = $return_order;
    $data['main_containt']='return_order_page';
    $this->load->view('containt',$data);
}
    

function admin_approval_return_product()
{   
    $data['admin_approval']=$_POST['admin_approval'];
    $this->Model->updateData('e_paenlist_order_data',$data,array('ID'=>$_POST['ID']));
    redirect($_POST['url']);
}
function Pro_Banner_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('pro_banner',array('ID'=>$ID));

    $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

    redirect('Slider/List_Pro_banner');
}
public function Pro_Banner_eidt()
{
            // echo '<pre>'; print_r($_GET); exit;
    $ID = $_GET['ID'];

    $data['Pro_Banner_eidt'] = $this->Model->getData('pro_banner',array('ID'=>$ID));
// echo '<pre>'; print_r($data['Pro_Banner_eidt']); exit;
    $data['main_containt']='Pro_Banner_eidt';

    $this->load->view('containt',$data);
}
function Pro_Banner_edit_form(){
    $postData = $_POST;
    $ID = $this->input->get_post('ID');

    if(!empty($_FILES['banner_Picture'])){
        $uploaddir = './uploads/Pro_banner/';
        $uploadfile = $uploaddir . basename($_FILES['banner_Picture']['name']);

        if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
          $postData['banner_Picture'] = basename($_FILES['banner_Picture']['name']);
      }
  }
// echo '<pre>'; print_r($postData); exit;

  $this->Model->updateData('pro_banner',$postData,array('ID'=>$ID)); 
  $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');

  $Pro_banner = $this->Model->getData('pro_banner');
  $data['Pro_banner'] = $Pro_banner;
  $data['main_containt']='List_Pro_banner';
  $this->load->view('containt',$data);


         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}
public function List_banner()
{
    $table = $this->Model->getData('banner');
    $data['bannerpicture'] = $table;
    $data['main_containt']='list_banner';

    $this->load->view('containt',$data);
}
public function Banner_eidt()
{
            // echo '<pre>'; print_r($_GET); exit;
    $ID = $_GET['ID'];
    $data['categpry_list'] = $this->Model->getData('category',array('status'=>'1'));
    $data['sub_category_list'] =$this->Model->getData('subcategory',array('status'=>'1'));
    $data['banner'] = $this->Model->getData('banner',array('ID'=>$ID));

    $data['main_containt']='banner_eidt';

    $this->load->view('containt',$data);
}
function Banner_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('banner',array('ID'=>$ID));

    $this->session->set_flashdata('msg' ,'The Banner has been deleted successfully.');

    redirect('Slider/List_banner');
}
function getSubCategory(){
 $postData = $_POST;
        // $postData['category_id'] = 1;

 $sub_category_list = $this->Model->getData('subcategory',array('status'=>'1'));

 $sub_cats = array();
 foreach ($sub_category_list as $key => $value) {
    if($postData['category_id'] == $value['category_id']){
        $sub_cats[] = $value;
    }
}
echo json_encode($sub_cats);
}
function Banner_edit_form(){
    $postData = $_POST;
    $ID = $this->input->get_post('ID');

    if(!empty($_FILES['banner_Picture'])){
        $uploaddir = './uploads/banner/';
        $uploadfile = $uploaddir . basename($_FILES['banner_Picture']['name']);

        if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
          $postData['banner_Picture'] = basename($_FILES['banner_Picture']['name']);
      }
  }
// echo '<pre>'; print_r($postData); exit;

  $this->Model->updateData('banner',$postData,array('ID'=>$ID)); 
  $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');

  $table = $this->Model->getData('banner');
  $data['bannerpicture'] = $table;
  $data['main_containt']='list_banner';

  $this->load->view('containt',$data);


         // $this->Model->updateData('banner',$_POST,array('id'=>$_POST['id']));
         //   $this->session->set_flashdata('msg' ,'The banner has been updated successfully.');
         //   redirect('Slider/list_banner');
}
public function Camera_wrap()
{
        // $table = $this->Model->getData('slider');
        // $data['sliderpicture'] = $table;
   $data['main_containt']='Slider';

   $this->load->view('containt',$data);
}
function Upend_heading_List(){
    $upend_list = $this->Model->getData('upend_wrapper');
    $data['upend_list'] = $upend_list;
    $data['main_containt']='upend_heading_List';
    $this->load->view('containt',$data);    
}
public function Upend_eidt()
{
    $upend_id = $_GET['upend_id'];

    $data['table'] = $this->Model->getData('upend_wrapper',array('upend_id'=>$upend_id));
    $data['main_containt']='upend_eidt';

    $this->load->view('containt',$data);
}
function Upend_delete(){
    $upend_id = $this->input->get_post('upend_id');
    $this->Model->deleteData('upend_wrapper',array('upend_id'=>$upend_id));

    $this->session->set_flashdata('msg' ,'The Upend Heading has been deleted successfully.');

    redirect('Slider/upend_heading_List');
}
public function Edit_upend_form()
{

    $this->Model->updateData('upend_wrapper',$_POST,array('upend_id'=>$_POST['upend_id']));
    $this->session->set_flashdata('msg','Upend Update Successfully ');
    redirect('Slider/upend_heading_List');
}
public function Upend_information_list()
{
    $product_list = $this->Model->getData('wrapper_wellness');
    $data['product_list'] = $product_list;
    $data['main_containt']='Upend_information_list';
    $this->load->view('containt',$data);
}
public function Append_information_eidt()
{
    $ID = $_GET['ID'];

    $data['table'] = $this->Model->getData('wrapper_wellness',array('ID'=>$ID));
    $data['main_containt']='Append_information_eidt';

    $this->load->view('containt',$data);
}
function Append_information_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('wrapper_wellness',array('ID'=>$ID));
    $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

    redirect('Slider/Upend_information_list');
}
public function Slide_list()
{
        // echo '<pre>'; print_r($_POST);exit;

    $table = $this->Model->getData('slider');
    $data['sliderpicture'] = $table;
    $data['main_containt']='Slide_list';
    $this->load->view('containt',$data);
}
public function Url_Upend_heading()
{

    $data['main_containt']='Url_Upend_heading';

    $this->load->view('containt',$data);
}
public function url_Enter_upend()
{
    $url_enter=$_POST;
        // echo '<pre>'; print_r($_POST);exit;

        // $this->Add_category_model->insertupend($_POST);
    $this->Model->insertData('url_append_heading',$url_enter);
    $this->session->set_flashdata('msg',' Successfully your Url upend_heading Add');
    redirect('Slider/Url_Upend_heading');
}
public function Url_Append_information()
{ 
         // $category_data = $this->Model->getData('category');
   //      $data['category_data'] = $category_data;
    $data['upend_information'] = $this->Model->getAllData('url_append_heading');
    $category_data = $this->Model->getData('category');
    $data['category_data'] = $category_data;
    $data['main_containt']='Url_Append_information';

    $this->load->view('containt',$data);
}
function Url_Upend_heading_List(){
    $table = $this->Model->getData('url_append_heading');
    $data['url_append_heading'] = $table;
    $data['main_containt']='url_append_heading_list';
    $this->load->view('containt',$data);
}
function Url_Upend_delete(){
    $url_id = $this->input->get_post('url_id');
    $this->Model->deleteData('url_append_heading',array('url_id'=>$url_id));

    $this->session->set_flashdata('msg' ,'The Url Upend Heading has been deleted successfully.');

    redirect('Slider/Url_Upend_heading_List');
}
public function Url_Upend_eidt()
{
    $url_id = $_GET['url_id'];

    $data['table'] = $this->Model->getData('url_append_heading',array('url_id'=>$url_id));
    $data['main_containt']='url_upend_head_eidt';

    $this->load->view('containt',$data);
}
public function url_Enter_upend_edit()
{

    $this->Model->updateData('url_append_heading',$_POST,array('url_id'=>$_POST['url_id']));
    $this->session->set_flashdata('msg','Append Heading Update Successfully ');
    redirect('Slider/Url_Upend_heading_List');
}
function Add_Promo_Code_2(){
    $custumer_login = $this->Model->getData('custumer_login');
    $data['custumer_login'] = $custumer_login;
    $data['main_containt']='Add_Promo_Code_2';

    $this->load->view('containt',$data);
}
function Add_Advertisement_banner(){

 $category_data = $this->Model->getData('category');
 $data['category_data'] = $category_data;
 $data['main_containt']='Add_Advertisement_banner';

 $this->load->view('containt',$data);
}
function Url_Upend_information_list(){

    $product_list = $this->Model->getData('url_append_info');
    $data['product_list'] = $product_list;
    $data['main_containt']='Url_Upend_information_list';
    $this->load->view('containt',$data);
}
function Url_Append_information_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('url_append_info',array('ID'=>$ID));
    $this->session->set_flashdata('msg' ,'The Product has been deleted successfully.');

    redirect('Slider/Url_Upend_information_list');
}
function Url_Append_information_eidt(){
    $ID = $_GET['ID'];
    $data['url_append_heading'] = $this->Model->getData('url_append_heading',array('status'=>'1'));
    $data['product_category_name'] = $this->Model->getData('product_category',array('status'=>'1'));
    $data['table'] = $this->Model->getData('url_append_info',array('ID'=>$ID));
    $data['main_containt']='Url_Append_information_eidt';

    $this->load->view('containt',$data);

}
function Url_append_edit_form(){
    $postData = $_POST;
    $ID = $this->input->get_post('ID');

    if(!empty($_FILES['Product_Picture'])){
        $uploaddir = './uploads/append/';
        $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

        if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
          $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
      }
  }
// echo '<pre>'; print_r($postData); exit;

  $this->Model->updateData('url_append_info',$postData,array('ID'=>$ID)); 
  $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');

  $product_list = $this->Model->getData('url_append_info');
  $data['product_list'] = $product_list;
  $data['main_containt']='Url_Upend_information_list';
  $this->load->view('containt',$data);
}
function Edit_Upend_Product(){
        // echo '<pre>'; print_r($_POST); exit;
    $postData = $_POST;
    $ID = $this->input->get_post('ID');

    if(!empty($_FILES['Product_Picture'])){
        $uploaddir = './uploads/wrapper/wellness/';
        $uploadfile = $uploaddir . basename($_FILES['Product_Picture']['name']);

        if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
          $postData['Product_Picture'] = basename($_FILES['Product_Picture']['name']);
      }
  }
// echo '<pre>'; print_r($postData); exit;

  $this->Model->updateData('wrapper_wellness',$postData,array('ID'=>$ID)); 
  $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');

  $product_list = $this->Model->getData('wrapper_wellness');
  $data['product_list'] = $product_list;
  $data['main_containt']='Upend_information_list';
  $this->load->view('containt',$data);
}
function List_Advertisement_banner(){

    $advertisement = $this->Model->getData('advertisement');
    $data['advertisement'] = $advertisement;
    $data['main_containt']='advertisement_list';
    $this->load->view('containt',$data);
}
function Advertisement_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('advertisement',array('ID'=>$ID));
    $this->session->set_flashdata('msg' ,'The Advertisement Banner has been deleted successfully.');

    redirect('Slider/List_Advertisement_banner');
}
function Advertisement_eidt(){
    $ID = $_GET['ID'];
    $data['category_name'] = $this->Model->getData('category',array('status'=>'1'));
    $data['sub_category_name'] = $this->Model->getData('subcategory',array('status'=>'1'));
    $data['table'] = $this->Model->getData('advertisement',array('ID'=>$ID));
    $data['main_containt']='Advertisement_eidt';

    $this->load->view('containt',$data);

}
function Edit_advertisment_banner(){
        // echo '<pre>'; print_r($_POST); exit;
    $postData = $_POST;
    $ID = $this->input->get_post('ID');

    if(!empty($_FILES['Advertisement_Picture'])){
        $uploaddir = './uploads/Advertisement/';
        $uploadfile = $uploaddir . basename($_FILES['Advertisement_Picture']['name']);

        if (move_uploaded_file($_FILES['Advertisement_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
          $postData['Advertisement_Picture'] = basename($_FILES['Advertisement_Picture']['name']);
      }
  }
// echo '<pre>'; print_r($postData); exit;

  $this->Model->updateData('advertisement',$postData,array('ID'=>$ID)); 
  $this->session->set_flashdata('msg' ,'The Advertisement has been Updated successfully.');

  $advertisement = $this->Model->getData('advertisement');
  $data['advertisement'] = $advertisement;
  $data['main_containt']='advertisement_list';
  $this->load->view('containt',$data);
}
function Add_new_Customer()
{
    $data['main_containt']='Add_new_Customer';

    $this->load->view('containt',$data);
}
function Add_customer_info()
{
 $user_name = $this->input->get_post('user_name');
 $last_name = $this->input->get_post('last_name');
 $email_id =  $this->input->get_post('email_id');
 $password = $this->input->get_post('password');
 $contact_number =  $this->input->get_post('contact_number');


 if($user_name!='' && $email_id!='' && $password!='' && $contact_number!=''){
    $email_info=$this->Model->getData('custumer_login',array('email_id'=>$email_id));
    $mobile_info=$this->Model->getData('custumer_login',array('contact_number'=>$contact_number));

    if(isset($email_info) && empty($email_info)){
        if(isset($mobile_info) && empty($mobile_info)){
            $array_data=array(
                'user_name'=>$user_name,
                'last_name'=>$last_name,
                'email_id'=>$email_id,
                'password'=>md5($password),
                'contact_number'=>$contact_number,
                'resigtation_month'=> date('m'),
                'resigtation_year'=> date('Y'),
                'resigtation_day'=> date('d'),
                'resigtation_year_month'=> date('Y-m'),
                'resigtation_year_month_data' =>date('Y-m-d'),
                'resigtation_year_month_data_time'=> date('Y-m-d H:i:s'),

            );
            $user_inserted_id=$this->Model->insertData('custumer_login',array_map('strtoupper', $array_data));

            if(!empty($_FILES['Pan_Picture']['name'])){
               $config['upload_path'] = 'uploads/Customer_pan/';
               $config['allowed_types'] = 'jpg|jpeg|png|gif';
               $config['file_name'] = $_FILES['Pan_Picture']['name'];

                        //Load upload library and initialize configuration
               $this->load->library('upload',$config);
               $this->upload->initialize($config);

               if($this->upload->do_upload('Pan_Picture')){
                $uploadData = $this->upload->data();
                $picture = $uploadData['file_name'];
            }else{
                $picture = '';
            }
        }else{
            $picture = 'no';
        }
        $userData = array(
            'Customer_id' =>  $user_inserted_id, 
            'pan_number' => $this->input->post('pan_number'),
            'Pan_Full_Name' => $this->input->post('Pan_Full_Name'),
            'Pan_Picture' => $picture
        );
        $this->Customer_login_Information->insert($userData);
        if($user_inserted_id){

            $this->session->set_flashdata('msg' ,'Customer account has been registered successfully.');
            redirect('Slider/Add_new_Customer');
        }else{

            $this->session->set_flashdata('msg' ,'Error while signing up. please try again.');
            redirect('Slider/Add_new_Customer');

        }
                        // $user = "OXIINCHEALTH";
                        // $password = "OXIINC@185";
                        // $senderId = "OXIINC";
                        // $channel = "Trans";
                        // $dcs = "0";
                        // $flashsms = "0";
                        // $route = "6";
                        // $mobile = $contact_number;
                        // $text_message = "Dear ". $user_name. ". Thank you for Register with us, We have received your Number no ".$contact_number.". We will process your Register at your chosen date and time.";
                        // $sms = urlencode($text_message);

                        // $smsurl = 'http://103.233.76.120/api/mt/SendSMS?user='.$user.'&password='.$password.'&senderid='.$senderId.'&channel='.$channel.'&DCS='.$dcs.'&flashsms='.$flashsms.'&number=91'.$mobile.'&text='.$sms.'&route='.$route.'';

                        // try  
                        // {
                        //     $ch = curl_init();
                        //     curl_setopt($ch, CURLOPT_HEADER, 0);
                        //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        //     curl_setopt($ch, CURLOPT_URL, $smsurl);
                        //     $data = curl_exec($ch);
                        //     curl_close($ch);
                        //     $response = $data;
                        // }  
                        // catch (Exception $e)  
                        // {  
                        //     $response = $e->getMessage();  
                        // }



    }else{

        $this->session->set_flashdata('msg' ,'Mobile number is already registered with us.');
        redirect('Slider/Add_new_Customer');

    }
}else{

    $this->session->set_flashdata('msg' ,'Email address is already registered with us. Please enter unique email address');
    redirect('Slider/Add_new_Customer');

}
}else{


    $this->session->set_flashdata('msg' ,'Required parameters are missing.');
    redirect('Slider/Add_new_Customer');
}
}
function List_of_customer(){

    $custumer_login = $this->Model->getData('custumer_login');
    $data['custumer_login'] = $custumer_login;
    $data['main_containt']='List_of_customer';
    $this->load->view('containt',$data);
}
function Customer_eidt(){
   $ID = $_GET['id'];

   $data['custumer_login'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
   $data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$ID));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
   $data['main_containt']='Customer_eidt';

   $this->load->view('containt',$data);
}
function edit_customer_info(){

 $user_name = $this->input->get_post('user_name');
 $last_name = $this->input->get_post('last_name');
 $email_id =  $this->input->get_post('email_id');
 $id = $this->input->get_post('id');
 $contact_number =  $this->input->get_post('contact_number');
 $status =  $this->input->get_post('status');

 $array_data=array(
    'user_name'=>$user_name,
    'last_name'=>$last_name,
    'email_id'=>$email_id,
                        // 'password'=>md5($password),
    'contact_number'=>$contact_number,
    'status'=>$status,

);
 $this->Model->updateData('custumer_login',$array_data,array('id'=>$id)); 



 $this->session->set_flashdata('msg' ,'Customer account Updated has been registered successfully.');
 redirect('Slider/List_of_customer');      

}
function Pan_information(){
   $id = $_GET['id'];
   $data['customer_pan_info'] = $this->Model->getData('customer_pan_info',array('Customer_id'=>$id));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
   $data['main_containt']='Pan_information';

   $this->load->view('containt',$data);
}
function Promo_Code(){
   $id = $_GET['id'];
   $data['customer_login_info'] = $this->Model->getData('custumer_login',array('id'=>$id));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
   $data['main_containt']='Promo_Code';

   $this->load->view('containt',$data);
}
function Edit_customer_pan_info(){

    $postData = $_POST;
    $ID = $this->input->get_post('ID');

    if(!empty($_FILES['Pan_Picture'])){
        $uploaddir = './uploads/Customer_pan/';
        $uploadfile = $uploaddir . basename($_FILES['Pan_Picture']['name']);

        if (move_uploaded_file($_FILES['Pan_Picture']['tmp_name'], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
          $postData['Pan_Picture'] = basename($_FILES['Pan_Picture']['name']);
      }
  }
        // echo '<pre>'; print_r($postData['Pan_Picture']); exit;
  $this->Model->updateData('customer_pan_info',$postData,array('ID'=>$ID)); 
  $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
  redirect('Slider/List_of_customer'); 
}
function Customer_Delete(){
    $id = $this->input->get_post('id');
    $this->Model->deleteData('custumer_login',array('id'=>$id));
    $this->session->set_flashdata('msg' ,'The Customer Account has been deleted successfully.');

    redirect('Slider/List_of_customer');
}
function Add_customer_Promo_info(){

    $promo_codo = $_POST;
        // echo '<pre>'; print_r($promo_codo); exit;
    $id = $this->Model->insertData('promo_codo',$promo_codo);
       // echo '<pre>'; print_r($id); exit;
    $this->session->set_flashdata('msg' ,'The Promo code has been add successfully.');
    redirect('Slider/Add_Promo_Code_2');
}
function Add_Promo_info(){

    $promo_codo = $_POST;
        // echo '<pre>'; print_r($promo_codo); exit;
    $id = $this->Model->insertData('promo_codo',$promo_codo);
       // echo '<pre>'; print_r($id); exit;
    $this->session->set_flashdata('msg' ,'The Promo code has been add successfully.');
    redirect('Slider/Add_Promo_Code');
}
function List_Of_Promo_Code(){

    $promo_codo = $this->Model->getData('promo_codo');
    $data['promo_codo'] = $promo_codo;
    $data['main_containt']='List_Of_Promo_Code';
    $this->load->view('containt',$data);
}
function enpay(){

   $custumer_login = $this->Model->getData('custumer_login');
   $data['custumer_login'] = $custumer_login;
   $data['main_containt']='enpay';
   $this->load->view('containt',$data);
}
function enpay_Balance(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        //  $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        // $data['customer_enpay'] = $customer_enpay;
    $data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
        // echo '<pre>'; print_r($data); exit;
    $data['main_containt']='enpay_Balance';
    $this->load->view('containt',$data);

}
function Debits_enpay(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
        //  $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
        // $data['customer_enpay'] = $customer_enpay;
    $data['customer_enpay'] = $this->Model->getDataOrderBy('customer_enpay',array('Customer_id'=>$id),'ID','DESC');
    $data['main_containt']='Debits_enpay';
    $this->load->view('containt',$data);

}
function Add_enpay_amount(){
   $this->Model->updateData('custumer_login',$_POST,array('id'=>$_POST['id']));
   $this->session->set_flashdata('msg','enpay amount Update Successfully ');
   redirect('Slider/enpay');
}
function Add_debits_amount(){
   $this->Model->insertData('customer_enpay',$_POST);
   $this->session->set_flashdata('msg','enpay amount Update Successfully ');
   redirect('Slider/enpay');
}
function Credits_enpay(){
    $id = $_GET['id'];
    $data['custumer_login'] = $this->Model->getData('custumer_login',array('id'=>$id));
    $customer_enpay = $this->Model->getData('customer_enpay',array('Customer_id'=>$id));
    $data['customer_enpay'] = $customer_enpay;
    $data['main_containt']='Credits_enpay';
    $this->load->view('containt',$data);

}
function Promo_code_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('promo_codo',array('ID'=>$ID));
    $this->session->set_flashdata('msg' ,'The Promo Code has been deleted successfully.');

    redirect('Slider/List_Of_Promo_Code');
}
function Promo_code_eidt(){
   $ID = $_GET['ID'];

        // $data['custumer_login'] = $this->Model->getData('custumer_login',array('ID'=>$ID));
   $data['promo_codo'] = $this->Model->getData('promo_codo',array('ID'=>$ID));
        // echo '<pre>'; print_r($data['customer_pan_info']); exit;
   $data['main_containt']='Promo_code_eidt';
// echo '<pre>'; print_r($data['promo_codo']); exit;
   $this->load->view('containt',$data);
}
public function Edit_Promo_code_info()
{

    $this->Model->updateData('promo_codo',$_POST,array('ID'=>$_POST['ID']));
    $this->session->set_flashdata('msg','Promo code Update Successfully ');
    redirect('Slider/List_Of_Promo_Code');
}
function List_Of_Wishlist(){

    $wishlist = $this->Model->getData('wishlist');
    $data['wishlist'] = $wishlist;
    $data['main_containt']='List_Of_Wishlist';
    $this->load->view('containt',$data);
}
function append_List_Of_Wishlist(){

    // $wishlist = $this->Model->getData('wishlist');
        // $data['wishlist'] = $wishlist;
    $data['main_containt']='append_List_Of_Wishlist';
    $this->load->view('containt',$data);
}

//epanelist order tracking system code
public function Total_e_order_search(){
    //echo "<pre>";print_r($_POST);die();
    if ($this->uri->segment(3) == 1) {
        $sql = "SELECT * FROM e_paenlist_order_data WHERE reseller_id != '' AND order_confirmation = 1";
    }
    else{
        $sql = "SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1";
    }

    if (!empty($_POST['Product_Name'])){
        $sql .= ' AND Product_Name like "%'.$_POST['Product_Name'].'%" ';
    }

    if (!empty($_POST['Customer_name'])){
        $sql .= ' AND shipping_Name like "%'.$_POST['Customer_name'].'%"';
    }

    if (!empty($_POST['Transaction_id'])){
        $sql .= ' AND txnid like "%'.$_POST['Transaction_id'].'%"';
    }

    if (!empty($_POST['City'])){
        $sql .= ' AND shipping_City like "%'.$_POST['City'].'%"';
    }

    if (!empty($_POST['State'])){
        $sql .= ' AND shipping_state like "%'.$_POST['State'].'%"';
    }

    if (!empty($_POST['Pincode'])){
        $sql .= ' AND shipping_Pincode like "%'.$_POST['Pincode'].'%"';
    }

    if ((!empty($_POST['start_date'])) && (!empty($_POST['end_date']))){
        $sql .= ' AND order_year_month_data_time between "'.$_POST['start_date'].'" and "'.$_POST['end_date'].'"';
    }

    if (!empty($_POST['limit'])){
    $sql .= ' ORDER BY ID DESC LIMIT '.$_POST['limit'].' ';

    }

    $query = $this->db->query($sql);
    $data['Out_For_Delivery']= $query->result_array();
    $data['main_containt'] = 'Total_e_order_search_View';
    $this->load->view('containt',$data);
}

public function total_epanelist(){
    if ($this->uri->segment(3) == 1) {
        $data['Out_For_Delivery'] = $this->Model->getDataOrderBy('e_paenlist_order_data', array('order_confirmation' => '1', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query1 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 ORDER BY ID DESC");
        $data['Out_For_Delivery'] = $query1->result_array();
    }
    $data['main_containt'] = 'total_epanelist';
    $this->load->view('containt',$data);
}

public function  E_panelist_List_Of_Dispatchment(){
    if ($this->uri->segment(3) == 1) {
        $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('e_paenlist_order_data', array('order_confirmation' => '1', 'dispatchment_confirmation'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query2 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 0 ORDER BY ID DESC");
        $data['dispatchment_confirmation'] = $query2->result_array();
    }
   $data['main_containt'] = 'E_panelist_List_Of_Dispatchment';
   $this->load->view('containt', $data);
}

public function  E_panelist_List_Of_Shipping(){
    if ($this->uri->segment(3) == 1) {
        $data['shipping_confirmation'] = $this->Model->getDataOrderBy('e_paenlist_order_data', array('dispatchment_confirmation' => '1', 'shipping_confirmation'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query3 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND dispatchment_confirmation = 1 AND shipping_confirmation = 0 ORDER BY ID DESC");
        $data['shipping_confirmation'] = $query3->result_array();
    }
    $data['main_containt'] = 'E_panelist_List_Of_Shipping';
    $this->load->view('containt',$data);
}

public function E_panelist_List_Of_Vendor(){
    if ($this->uri->segment(3) == 1) {
        $data['order_delivered'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('shipping_confirmation'=>'1', 'order_intransit'=>'0', 'out_for_delivery'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query4 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND shipping_confirmation = 1 AND order_intransit = 0 ORDER BY ID DESC");
        $data['order_delivered'] = $query4->result_array();
    }
    $data['main_containt'] = 'E_panelist_List_Of_Vendor';
    $this->load->view('containt',$data);
}

public function E_panelist_Out_For_Delivery(){
    if ($this->uri->segment(3) == 1) {
        $data['Out_For_Delivery'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_intransit'=>'1', 'out_for_delivery'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query5 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_intransit = 1 AND out_for_delivery = 0 ORDER BY ID DESC");
        $data['Out_For_Delivery'] = $query5->result_array();
    }
    $data['main_containt'] = 'E_panelist_Out_For_Delivery';
    $this->load->view('containt',$data);
}

public function E_panelist_List_Of_Delivered(){
    if ($this->uri->segment(3) == 1) {
        $data['List_Of_Delivered'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query6 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 1 AND order_intransit = 1 AND out_for_delivery = 1 AND order_delivered = 0 ORDER BY ID DESC");
        $data['List_Of_Delivered'] = $query6->result_array();
    }
    $data['main_containt'] = 'E_panelist_List_Of_Delivered';
    $this->load->view('containt',$data);
}

public function E_panelist_List_Of_Order_Delivered_product(){
    if ($this->uri->segment(3) == 1) {
        $data['List_Of_Order_Delivered_product'] = $this->Model->getDataOrderBy('e_paenlist_order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query7 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 1 AND order_intransit = 1 AND out_for_delivery = 1 AND order_delivered = 1 ORDER BY ID DESC");
        $data['List_Of_Order_Delivered_product'] = $query7->result_array();
    }
    $data['main_containt']='E_panelist_List_Of_Order_Delivered_product';
    $this->load->view('containt',$data);
}

public function List_Hold(){
    if ($this->uri->segment(3) == 1) {
        $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('e_paenlist_order_data', array('order_confirmation' => '2', 'dispatchment_confirmation'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query8 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 2 AND dispatchment_confirmation = 0 ORDER BY ID DESC");
        $data['dispatchment_confirmation'] = $query8->result_array();
    }
    $data['main_containt'] = 'List_Hold';
    $this->load->view('containt',$data);
}

public function E_panelist_List_Of_Dispatchment_Remain(){
    if ($this->uri->segment(3) == 1) {
        $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('e_paenlist_order_data', array('order_confirmation' => '1', 'dispatchment_confirmation'=>'3', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query9 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 3 ORDER BY ID DESC");
        $data['dispatchment_confirmation'] = $query9->result_array();
    }
    $data['main_containt'] = 'E_panelist_List_Of_Dispatchment';
    $this->load->view('containt',$data);
}

public function epanelist_reseller_product_return_order(){
    $sql = "SELECT A.*, B.* FROM return_product AS A LEFT JOIN e_paenlist_order_data AS B ON B.ID = A.order_id WHERE reseller_id != '' AND return_order = 1 AND admin_approval = ".$this->uri->segment(3);
    $query = $this->db->query($sql);
    //echo "<pre>";print_r($query);die();
    $return_order = $query->result_array();
    $data['return_order'] = $return_order;
    $data['main_containt'] = 'list_of_epanelist_return_order_view';
    $this->load->view('containt', $data);
}

public function epanelist_oxiinc_product_return_order(){
    $sql = "SELECT A.*, B.* FROM return_product AS A LEFT JOIN e_paenlist_order_data AS B ON B.ID = A.order_id WHERE (reseller_id = '' OR reseller_id IS NULL) AND return_order = 1 AND admin_approval = ".$this->uri->segment(3);
    $query = $this->db->query($sql);
    //echo "<pre>";print_r($query);die();
    $return_order = $query->result_array();
    $data['return_order'] = $return_order;
    $data['main_containt'] = 'list_of_epanelist_return_order_view';
    $this->load->view('containt', $data);
}

//normal order tracking system code
public function List_Of_order_confirmation(){
    if ($this->uri->segment(3) == 1) {
        $data['customer_order_data'] = $this->Model->getDataOrderBy('order_data', array('order_confirmation' => '1', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_1 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 ORDER BY ID DESC");
        $data['customer_order_data'] = $query_1->result_array();
    }
    $data['main_containt'] = 'List_Of_order_confirmation';
    $this->load->view('containt', $data);
}

public function List_Of_Dispatchment(){
    if ($this->uri->segment(3) == 1) {
        $data['dispatchment_confirmation'] = $this->Model->getDataOrderBy('order_data', array('order_confirmation' => '1','dispatchment_confirmation'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_2 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 0  ORDER BY ID DESC");
        $data['dispatchment_confirmation'] = $query_2->result_array();
    }
    $data['main_containt'] = 'List_Of_Dispatchment';
    $this->load->view('containt',$data);
}

public function List_Of_Shipping(){
    if ($this->uri->segment(3) == 1) {
        $data['shipping_confirmation'] = $this->Model->getDataOrderBy('order_data', array('dispatchment_confirmation' => '1','shipping_confirmation'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_3 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND dispatchment_confirmation = 1 AND shipping_confirmation = 0  ORDER BY ID DESC");
        $data['shipping_confirmation'] = $query_3->result_array();
    }
    $data['main_containt'] = 'List_Of_Shipping';
    $this->load->view('containt',$data);
}

public function List_Of_Vendor(){
    if ($this->uri->segment(3) == 1) {
        $data['order_delivered'] = $this->Model->getDataOrderBy('order_data', array('shipping_confirmation' => '1', 'order_intransit'=>'0','out_for_delivery'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_4 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND shipping_confirmation = 1 AND order_intransit = 0 AND out_for_delivery = 0  ORDER BY ID DESC");
        $data['order_delivered'] = $query_4->result_array();
    }
    $data['main_containt'] = 'List_Of_Vendor';
    $this->load->view('containt',$data);
}

public function Out_For_Delivery(){
    if ($this->uri->segment(3) == 1) {
        $data['Out_For_Delivery'] = $this->Model->getDataOrderBy('order_data', array('order_intransit'=>'1', 'out_for_delivery'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_5 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_intransit = 1 AND out_for_delivery = 0  ORDER BY ID DESC");
        $data['Out_For_Delivery'] = $query_5->result_array();
    }
    $data['main_containt'] = 'Out_For_Delivery';
    $this->load->view('containt',$data);
}

public function List_Of_Delivered(){
    if ($this->uri->segment(3) == 1) {
        $data['List_Of_Delivered'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'0', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_5 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 1 AND order_intransit = 1 AND out_for_delivery = 1 AND order_delivered = 0 ORDER BY ID DESC");
        $data['List_Of_Delivered'] = $query_5->result_array();
    }
    $data['main_containt'] = 'List_Of_Delivered';
    $this->load->view('containt', $data);
}

public function List_Of_Order_Delivered_product(){
    if ($this->uri->segment(3) == 1) {
        $data['List_Of_Order_Delivered_product'] = $this->Model->getDataOrderBy('order_data',array('order_confirmation' => '1', 'dispatchment_confirmation'=>'1', 'shipping_confirmation'=>'1', 'order_intransit'=>'1', 'out_for_delivery'=>'1', 'order_delivered'=>'1', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query_6 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 AND dispatchment_confirmation = 1 AND shipping_confirmation = 1 AND order_intransit = 1 AND out_for_delivery = 1 AND order_delivered = 1 ORDER BY ID DESC");
        $data['List_Of_Order_Delivered_product'] = $query_6->result_array();
    }
    $data['main_containt'] = 'List_Of_Order_Delivered_product';
    $this->load->view('containt',$data);
}

public function Dispatchment_Confirmation(){
 // echo '<pre>'; print_r($_POST); exit;

    $ID = $_POST['ID'];
    $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];



    $i=0; 
    foreach ($ID as $key => $question) {




        $data = $this->Model->getData('order_data',array('ID'=> $ID[$i]));


        $item_in_cart='';

        $item_in_cart.='

        <tr>
        <td valign="top" width="187">
        <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
        <tr>
        <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
        <tr>
        <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

        <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


        </a></td>
        </tr>
        </table>
        </td>
        </tr>
        </table>
        <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

        <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

        </td>

        <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

        <td valign="top" width="374">
        <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
        <div>
        <table>
        <tr>
        <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
        <td width="25"></td>
        <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
        </tr>
        <tr>
        <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
        <td width="25"></td>
        <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
        </tr>



        </table>
        </div>
        </div>
        </td>

        <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

        </tr>


        ';






        $query = $this->db->query('select * from manage_addresses where ID='.$data[0]['address_id']);
        $row_gagan = $query->row(); 

//         $user_name = $user_name;
// 		$user_names = $user_name;
        $to_email_address = $data[0]['email_id'];
        $subject = 'Thankyou For Register With as, Oxiinc Group';
        $emailer = 'emailer/tracking_admin.html';
        $mail_content = file_get_contents($emailer);

        $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
        $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
        $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
        $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/13/13edb2dda8.png", $mail_content);
        $mail_content = str_replace('@_action_@',"packed", $mail_content);

        $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
        $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
        $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
        $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
        $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
        $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
        $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
        $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
        $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
        $headers = "From:no-reply@oxiinc.in\r\n" .
        'Reply-To: myorder@oxiinc.in' . "\r\n" .
        "MIME-Version: 1.0\r\n".
        "Content-Type: text/html; charset=ISO-8859-1\r\n";
        'X-Mailer: PHP/';
        mail($to_email_address, $subject, $mail_content, $headers);

    // echo '<pre>'; print_r($ID); exit;
        $status['dispatchment_confirmation']='1';
        $status['dispatchment_confirmation_info']=$dispatchment_confirmation_info;
        $status['dispatchment_confirmation_table']= date('Y-m-d');
        $Update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID[$i]));
        $i++;
    }
    $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
    redirect('Slider/List_Of_Dispatchment');
    // echo '<pre>'; print_r($ID); exit;
}
function normal_shipping_Confirmation_all(){

    include("third_party/PHPExcel.php");
    include("third_party/PHPExcel/IOFactory.php");
    $reader = PHPExcel_IOFactory::createReader('Excel5');
    $reader->setReadDataOnly(true);
    $file = isset($_FILES["uploadexcel"]['tmp_name']) ? $_FILES["uploadexcel"]['tmp_name'] : '';
    $objPHPExcel = $reader->load($file);
    $objWorksheet = $objPHPExcel->getActiveSheet();
    $header=true;
    if ($header) {
        $highestRow = $objWorksheet->getHighestRow();
        $highestColumn = $objWorksheet->getHighestColumn();
        $headingsArray = $objWorksheet->rangeToArray('A1:' . $highestColumn . '1', null, true, true, true);
        $headingsArray = $headingsArray[1];
        $r = -1;
        $namedDataArray = array();
        for ($row = 2; $row <= $highestRow; ++$row) {
            $dataRow = $objWorksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, true, true);
            if ((isset($dataRow[$row]['A'])) && ($dataRow[$row]['A'] > '')) {
                ++$r;
                foreach ($headingsArray as $columnKey => $columnHeading) {
                    $namedDataArray[$r][$columnHeading] = $dataRow[$row][$columnKey];
                }
            }
        }
    } else {
        //excel sheet with no header
        $namedDataArray = $objWorksheet->toArray(null, true, true, true);

    }

    foreach ($namedDataArray as $key => $value) {
        // echo "<pre>";print_r($value['Tracking No']); exit();



     $data = $this->Model->getData('order_data',array('ID'=> $value['ID']));

     $item_in_cart='';

     $item_in_cart.='

     <tr>
     <td valign="top" width="187">
     <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
     <tr>
     <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
     <tr>
     <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

     <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


     </a></td>
     </tr>
     </table>
     </td>
     </tr>
     </table>
     <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

     <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

     </td>

     <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

     <td valign="top" width="374">
     <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
     <div>
     <table>
     <tr>
     <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
     <td width="25"></td>
     <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
     </tr>
     <tr>
     <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
     <td width="25"></td>
     <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
     </tr>



     </table>
     </div>
     </div>
     </td>

     <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

     </tr>


     ';






     $query = $this->db->query('select * from manage_addresses where ID='.$data[0]['address_id']);
     $row_gagan = $query->row(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
     $to_email_address = $data[0]['email_id'];
     $subject = 'Thankyou For Register With as, Oxiinc Group';
     $emailer = 'emailer/tracking_admin.html';
     $mail_content = file_get_contents($emailer);

     $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
     $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
     $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
     $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/142a1ce82e.png", $mail_content);
     $mail_content = str_replace('@_action_@',"shipped", $mail_content);

     $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
     $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
     $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
     $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
     $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
     $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
     $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
     $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
     $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
     $headers = "From:no-reply@oxiinc.in\r\n" .
     'Reply-To: myorder@oxiinc.in' . "\r\n" .
     "MIME-Version: 1.0\r\n".
     "Content-Type: text/html; charset=ISO-8859-1\r\n";
     'X-Mailer: PHP/';
     mail($to_email_address, $subject, $mail_content, $headers);
     $status['shipping_confirmation']='1';
     $status['Shipping_confirmation_info']=$value['Tracking No'];
     $status['Shipping_confirmation_date']=date('Y-m-d');
     $status['height']=$value['Height'];
     $status['width']=$value['Width'];
     $status['lenght']=$value['Lenght'];
     $status['weight']=$value['Weight'];
     $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$value['ID']));

 }
    // exit();
 $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
 redirect('Slider/List_Of_Shipping');

// exit();


}
function  By_mistake_normal_dispatchment_confirmation(){
// echo '<pre>'; print_r($this->uri->segment(3)); exit;
   $status['dispatchment_confirmation']='0';
    // $status['Shipping_confirmation_info']="0";
   $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$this->uri->segment(3)));

   redirect('Slider/List_Of_Shipping');
}
function By_mistake_normal_Shipped(){
    // echo "<pre>";print_r($this->uri->segment(3));exit();

    $status['shipping_confirmation']='0';
    // $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
    $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$this->uri->segment(3)));

    $this->session->set_flashdata('msg','In Transit By Mistake Confirmation Update Successfully ');
    redirect('Slider/List_Of_Vendor');

}
function normal_List_Of_All(){

   $ID = $_POST['ID'];
   $status['order_intransit']='1';
   $status['out_for_delivery']='1';
   $status['order_delivered']='1';
   $status['In_Transit_confirmation_info']=$_POST['In_Transit_confirmation_info'];
   $status['Out_For_Delivery_confirmation_info']=$_POST['Out_For_Delivery_confirmation_info'];
   $status['Delivered_confirmation_info']=$_POST['Delivered_confirmation_info'];
   $status['Out_For_Delivery_confirmation_date']=date('Y-m-d');
   $status['Delivered_confirmation_date']=date('Y-m-d');
   $status['In_Transit_confirmation_date']=date('Y-m-d');
 //      echo "<pre>";
 // print_r($status);exit();
   $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));
   $this->session->set_flashdata('msg','In All Confirmation Update Successfully ');
   redirect('Slider/List_Of_Vendor');
}

function shipping_Confirmation(){

    $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];

























    $data = $this->Model->getData('order_data',array('ID'=> $ID));

    $item_in_cart='';

    $item_in_cart.='

    <tr>
    <td valign="top" width="187">
    <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
    <tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
    <tr>
    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

    <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


    </a></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    <td valign="top" width="374">
    <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
    <div>
    <table>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
    </tr>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
    </tr>



    </table>
    </div>
    </div>
    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    </tr>


    ';






    $query = $this->db->query('select * from manage_addresses where ID='.$data[0]['address_id']);
    $row_gagan = $query->row(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
    $to_email_address = $data[0]['email_id'];
    $subject = 'Thankyou For Register With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    $mail_content = file_get_contents($emailer);

    $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
    $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
    $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
    $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/142a1ce82e.png", $mail_content);
    $mail_content = str_replace('@_action_@',"shipped", $mail_content);

    $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
    $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
    $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
    $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
    $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
    $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
    $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
    $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
    $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
    $headers = "From:no-reply@oxiinc.in\r\n" .
    'Reply-To: myorder@oxiinc.in' . "\r\n" .
    "MIME-Version: 1.0\r\n".
    "Content-Type: text/html; charset=ISO-8859-1\r\n";
    'X-Mailer: PHP/';
    mail($to_email_address, $subject, $mail_content, $headers);
    $status['shipping_confirmation']='1';
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
    $status['Shipping_confirmation_date']=date('Y-m-d');
    $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Slider/List_Of_Shipping');
    // echo '<pre>'; print_r($ID); exit;
}

function Delivered_Confirmation(){
    // echo '<pre>'; print_r($_GET); exit;
    $ID = $_GET['ID'];
    // echo '<pre>'; print_r($ID); exit;
    $status['order_delivered']='1';
    $this->Model->updateData('order_data',$status,array('ID'=>$ID));
    $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
    redirect('Slider/List_Of_Vendor');
    // echo '<pre>'; print_r($ID); exit;
}
function In_transit_Confirmation(){

    $ID = $_POST['ID'];
    $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];
    
    
    
    
    $data = $this->Model->getData('order_data',array('ID'=> $ID));
    $item_in_cart='';

    $item_in_cart.='

    <tr>
    <td valign="top" width="187">
    <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
    <tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
    <tr>
    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

    <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


    </a></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    <td valign="top" width="374">
    <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
    <div>
    <table>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
    </tr>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
    </tr>



    </table>
    </div>
    </div>
    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    </tr>


    ';






    $query = $this->db->query('select * from manage_addresses where ID='.$data[0]['address_id']);
    $row_gagan = $query->row(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
    $to_email_address = $data[0]['email_id'];
    $subject = 'Thankyou For Register With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    $mail_content = file_get_contents($emailer);

    $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
    $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
    $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
    $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/1434f0e99c.png", $mail_content);
    $mail_content = str_replace('@_action_@',"intransit", $mail_content);

    $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
    $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
    $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
    $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
    $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
    $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
    $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
    $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
    $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
    $headers = "From:no-reply@oxiinc.in\r\n" .
    'Reply-To: myorder@oxiinc.in' . "\r\n" .
    "MIME-Version: 1.0\r\n".
    "Content-Type: text/html; charset=ISO-8859-1\r\n";
    'X-Mailer: PHP/';
    mail($to_email_address, $subject, $mail_content, $headers);

    $status['order_intransit']='1';
    $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
    $status['In_Transit_confirmation_date']=date('Y-m-d');
    $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Slider/List_Of_Vendor');

}
function Out_for_Delivery_Confirmation(){

   $ID = $_POST['ID'];
   $Out_For_Delivery_confirmation_info = $_POST['Out_For_Delivery_confirmation_info'];



   $data = $this->Model->getData('order_data',array('ID'=> $ID));
   $item_in_cart='';

   $item_in_cart.='

   <tr>
   <td valign="top" width="187">
   <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
   <tr>
   <td>
   <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
   <tr>
   <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

   <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


   </a></td>
   </tr>
   </table>
   </td>
   </tr>
   </table>
   <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

   <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

   </td>

   <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

   <td valign="top" width="374">
   <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
   <div>
   <table>
   <tr>
   <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
   <td width="25"></td>
   <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
   </tr>
   <tr>
   <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
   <td width="25"></td>
   <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
   </tr>



   </table>
   </div>
   </div>
   </td>

   <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

   </tr>


   ';






   $query = $this->db->query('select * from manage_addresses where ID='.$data[0]['address_id']);
   $row_gagan = $query->row(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
   $to_email_address = $data[0]['email_id'];
   $subject = 'Thankyou For Register With as, Oxiinc Group';
   $emailer = 'emailer/tracking_admin.html';
   $mail_content = file_get_contents($emailer);

   $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
   $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
   $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
   $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/14e6228623.png", $mail_content);
   $mail_content = str_replace('@_action_@',"out for deliverd", $mail_content);

   $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
   $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
   $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
   $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
   $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
   $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
   $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
   $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
   $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
   $headers = "From:no-reply@oxiinc.in\r\n" .
   'Reply-To: myorder@oxiinc.in' . "\r\n" .
   "MIME-Version: 1.0\r\n".
   "Content-Type: text/html; charset=ISO-8859-1\r\n";
   'X-Mailer: PHP/';
   mail($to_email_address, $subject, $mail_content, $headers);
   $status['out_for_delivery']='1';
   $status['Out_For_Delivery_confirmation_info']=$Out_For_Delivery_confirmation_info;
   $status['Out_For_Delivery_confirmation_date']=date('Y-m-d');

   $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

   $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
   redirect('Slider/Out_For_Delivery');

}
function Deliverd_info_Confirmation(){
  $ID = $_POST['ID'];
  $Delivered_confirmation_info = $_POST['Delivered_confirmation_info'];




  $data = $this->Model->getData('order_data',array('ID'=> $ID));
  $item_in_cart='';

  $item_in_cart.='

  <tr>
  <td valign="top" width="187">
  <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
  <tr>
  <td>
  <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
  <tr>
  <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

  <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


  </a></td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

  <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

  </td>

  <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

  <td valign="top" width="374">
  <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
  <div>
  <table>
  <tr>
  <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
  <td width="25"></td>
  <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
  </tr>
  <tr>
  <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
  <td width="25"></td>
  <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
  </tr>



  </table>
  </div>
  </div>
  </td>

  <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

  </tr>


  ';






  $query = $this->db->query('select * from manage_addresses where ID='.$data[0]['address_id']);
  $row_gagan = $query->row(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
  $to_email_address = $data[0]['email_id'];
  $subject = 'Thankyou For Register With as, Oxiinc Group';
  $emailer = 'emailer/tracking_admin.html';
  $mail_content = file_get_contents($emailer);

  $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
  $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
  $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
  $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/14f240af1e.png", $mail_content);
  $mail_content = str_replace('@_action_@',"deliverd", $mail_content);

  $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
  $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
  $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
  $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
  $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
  $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
  $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
  $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
  $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
  $headers = "From:no-reply@oxiinc.in\r\n" .
  'Reply-To: myorder@oxiinc.in' . "\r\n" .
  "MIME-Version: 1.0\r\n".
  "Content-Type: text/html; charset=ISO-8859-1\r\n";
  'X-Mailer: PHP/';
  mail($to_email_address, $subject, $mail_content, $headers);
  $status['order_delivered']='1';
  $status['Delivered_confirmation_info']=$Delivered_confirmation_info;
  $status['Delivered_confirmation_date']=date('Y-m-d');

  $update_id =  $this->Model->updateData('order_data',$status,array('ID'=>$ID));

  $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
  redirect('Slider/List_Of_Delivered');
}

function cancel_enpay_debits(){
 $ID = $_GET['ID'];
    // echo '<pre>'; print_r($ID); exit;
 $cancellation_request = $this->Model->getData('cancellation_request',array('ID'=>$ID));
 $cancel['Customer_id'] = $cancellation_request[0]['customer_id'];
 $cancel['customer_name'] = $cancellation_request[0]['user_name'];
 $cancel['custumer_email']   = $cancellation_request[0]['email_id'];
 $cancel['debits_amount']   = $cancellation_request[0]['Prices'];
 $cancel['debits_status']   = '1';
 $id =   $this->Model->insertData('customer_enpay',$cancel);
 
 $status['status']='0';
 $ID =   $this->Model->updateData('cancellation_request',$status,array('ID'=>$ID));

 $this->session->set_flashdata('msg','cancellation Request Amount Update Successfully ');
 redirect('Slider/List_Of_Cancel_Product');
}
function Cancellation_Confirm(){
 $ID = $_GET['ID'];
 $status['status']='0';
 $ID =   $this->Model->updateData('cancellation_request',$status,array('ID'=>$ID));

 $this->session->set_flashdata('msg','cancellation Request Amount Update Successfully ');
 redirect('Slider/List_Of_Cancel_Product');
}
function Return_Confirm_account(){
 $ID = $_GET['ID'];
 $status['status']='0';
 $ID =   $this->Model->updateData('return_order',$status,array('ID'=>$ID));

 $this->session->set_flashdata('msg','Return Product Update Successfully ');
 redirect('Slider/List_Of_Return_Product');
}

function epanelist_order_deactive(){
   echo  $ID = $_GET['ID'];
   $status['status']='0';


   $ID =   $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));


   redirect('Slider/total_epanelist');
}

function epanelist_order_active(){
   echo  $ID = $_GET['ID'];
   $status['status']='1';


   $ID =   $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));


   redirect('Slider/total_epanelist');
}

public function total_gst_report_epanelist(){
    if ($this->uri->segment(3) == 1) {
        $data['order_data'] = $this->Model->getDataOrderBy('e_paenlist_order_data', array('order_confirmation' => '1', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query1 = $this->db->query("SELECT * FROM e_paenlist_order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 ORDER BY ID DESC");
        $data['order_data'] = $query1->result_array();
    }
    $data['main_containt'] = 'Total_GST_Report_epanelist';
    $this->load->view('containt',$data);
}

public function total_gst_report_normal(){
    if ($this->uri->segment(3) == 1) {
        $data['order_data'] = $this->Model->getDataOrderBy('order_data', array('order_confirmation' => '1', 'reseller_id !=' => ''), 'ID', 'DESC');
    }
    else{
        $query2 = $this->db->query("SELECT * FROM order_data WHERE (reseller_id = '' OR reseller_id IS NULL) AND order_confirmation = 1 ORDER BY ID DESC");
        $data['order_data'] = $query2->result_array();
    }
    $data['main_containt'] = 'Total_GST_Report';
    $this->load->view('containt',$data);
}


function Order_delete(){
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('order_data',array('ID'=>$ID));

    $this->session->set_flashdata('msg' ,'The order has been deleted successfully.');

    redirect('Slider/List_Of_order_confirmation');
}
public function Registred_users()
{
    $Registred_users_COUNT = $this->Model->CountWhereRecord('custumer_login',array('status'=>'1'));
    $data['Registred_users_COUNT'] = $Registred_users_COUNT;
    $Registred_users = $this->Model->getData('custumer_login',array('status'=>'1'));
    $data['Registred_users'] = $Registred_users;
    $data['main_containt']='Registred_users';

    $this->load->view('containt',$data);
}
function List_chart(){

    $data['main_containt']='List_chart';
    $this->load->view('containt',$data);
}
function List_Login_Logout(){

    $data['main_containt']='List_Login_Logout';
    $this->load->view('containt',$data);
}
function Add_seminar_information(){

    $data['main_containt']='Add_seminar_information';
    $this->load->view('containt',$data);
}
function enter_seminar_information(){
    $seminar_info = $_POST;

    $this->Model->insertData('add_seminar_information',$seminar_info);
    $this->session->set_flashdata('msg','Seminar Information Add successfully');
    redirect('Slider/Add_seminar_information');
}
function Seminar_Information_List(){
    $Add_seminar_information = $this->Model->getData('add_seminar_information');
    $data['Add_seminar_information'] = $Add_seminar_information;
    $data['main_containt']='Seminar_Information_List';

    $this->load->view('containt',$data);
}
function update_seminar_information(){
    $this->Model->updateData('add_seminar_information',$_POST,array('ID'=>$_POST['ID']));
    $this->session->set_flashdata('msg','Seminar Information Update successfully');
    redirect('Slider/Seminar_Information_List');
}
function List_Of_Ticket_Book_Customer(){
    $summary = $this->Model->getData('summary');
    $data['summary'] = $summary;
    $data['main_containt']='List_Of_Ticket_Book_Customer';

    $this->load->view('containt',$data);

}
function delete_seminar_ticket(){
  $ID = $this->input->get_post('ID');
  $this->Model->deleteData('summary',array('ID'=>$ID));

  $this->session->set_flashdata('msg' ,'The Ticket has been deleted successfully.');

  redirect('Slider/List_Of_Ticket_Book_Customer');

}
public function Product_invoice(){
    $ID = $_GET['ID'];
    $data['Product_invoice'] = $this->Model->getData('order_data', array('ID'=>$ID));
    $data['Product'] = $this->Model->getData('wellness', array('ID'=>$ID));
    //echo '<pre>'; print_r($data);die();
    $this->load->view('product_invoice',$data);
}

public function epanelist_invoice(){
    $id = $_GET['ID'];
    $data['Product_invoice'] = $this->Model->getData('e_paenlist_order_data',array('ID'=>$id));
    $data['Product'] = $this->Model->getData('wellness',array('ID'=>$id));
    //echo '<pre>'; print_r($data['Product']);die();
    $this->load->view('epanelist_invoice',$data);
}

public function oxiinc_product_invoice(){
    $ID = $_GET['ID'];
    $data['invoice_type'] = $_GET['invoice_type'];
    $data['Product_invoice'] = $this->Model->getData('order_data', array('ID'=>$ID));
    $data['Product'] = $this->Model->getData('wellness', array('ID'=>$data['Product_invoice'][0]['product_id']));
    //echo '<pre>'; print_r($data);die();
    $this->load->view('order_invoice_normal',$data);
}

public function epanelist_product_invoice(){
    $id = $_GET['ID'];
    $data['invoice_type'] = $_GET['invoice_type'];
    $data['Product_invoice'] = $this->Model->getData('e_paenlist_order_data', array('ID'=>$id));
    $data['Product'] = $this->Model->getData('wellness', array('ID'=>$data['Product_invoice'][0]['product_id']));
    //echo '<pre>'; print_r($data);die();
    $this->load->view('order_invoice_paenlist',$data);
}

function Invoice_print(){
   $ID = $_GET['ID'];
   $data['Product_invoice'] = $this->Model->getData('order_data',array('ID'=>$ID));
//   $data['Product'] = $this->Model->getData('wellness',array('ID'=>$ID));
   $this->load->library('pdfgenerator');
   $html = $this->load->view('admin_pdf_invoice', $data, true);
   // $this->load->view('admin_pdf_invoice', $data);
   $filename = 'Invoice'.time();
   $this->pdfgenerator->generate($html, $filename, true, 'A4', 'letter');
}
function Invoice_print_epanelist(){
   $ID = $_GET['ID'];
   $data['Product_invoice'] = $this->Model->getData('e_paenlist_order_data',array('ID'=>$ID));
   $data['Product'] = $this->Model->getData('wellness',array('ID'=>$ID));
   $this->load->library('pdfgenerator');
//   echo '<pre>'; print_r($data['Product']); exit;
   $html = $this->load->view('admin_pdf_invoice_epanelist', $data, true);
   // $this->load->view('admin_pdf_invoice', $data);
   $filename = 'Invoice'.time();
   $this->pdfgenerator->generate($html, $filename, true, 'A4', 'letter');
}
function Add_user_role_by_department(){
    $data['id'] = $_POST['id'];
    // echo '<pre>'; print_r($data['id']); exit;
    $data['Add_user'] = $this->Model->getData('users',array('id'=>$_POST['id']));
    // echo '<pre>'; print_r($data['Add_user']); exit;
    $data['main_containt']='Add_user_role_by_department';
    $this->load->view('containt',$data);
}


function  E_panelist_Dispatchment_Confirmation(){
    $ID = $_POST['ID'];
    $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];
    
    
    
    
    
    
    $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));
//  echo "<pre>";
//  print_r($data);

//  $servername='172.19.2.230';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");

// $result=mysqli_query($conn,'select * from login where employee_id = '.$data[0]['shipping_employee_id']);
// $gagan=mysqli_fetch_assoc($result);
    $data_info['id']=$data[0]['shipping_employee_id'];
    $gagan=json_decode($this->epanelist_information($data_info),true);

    $item_in_cart='';

    $item_in_cart.='

    <tr>
    <td valign="top" width="187">
    <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
    <tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
    <tr>
    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

    <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


    </a></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    <td valign="top" width="374">
    <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
    <div>
    <table>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
    </tr>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
    </tr>



    </table>
    </div>
    </div>
    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    </tr>


    ';






    $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
    $row_gagan = $query->row(); 

//                                      echo"<pre>";print_r($row_gagan);
//  exit(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
    $to_email_address = $gagan[0]['primary_email'];
    $subject = 'Thankyou For shopping With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    $mail_content = file_get_contents($emailer);

    $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
    $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
    $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
    $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/13/13edb2dda8.png", $mail_content);
    $mail_content = str_replace('@_action_@',"packed", $mail_content);

    $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
    $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
    $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
    $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
    $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
    $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
    $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
    $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
    $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
    $headers = "From:no-reply@oxiinc.in\r\n" .
    'Reply-To: myorder@oxiinc.in' . "\r\n" .
    "MIME-Version: 1.0\r\n".
    "Content-Type: text/html; charset=ISO-8859-1\r\n";
    'X-Mailer: PHP/';
    mail($to_email_address, $subject, $mail_content, $headers);

    // echo '<pre>'; print_r($ID); exit;
    $status['dispatchment_confirmation']='1';
    $status['dispatchment_confirmation_info']=$dispatchment_confirmation_info;
    $Update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Dispatchment');
}

function Dispatchment_Confirmation_all(){
    // echo '<pre>'; print_r($_POST); exit;

   $ID = $_POST['ID'];
    // $sub_option = $_POST['sub_option'];
   $i=0; 
   foreach ($ID as $key => $question) {
    $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID[$i]));

    $data_info['id']=$data[0]['shipping_employee_id'];
    $gagan=json_decode($this->epanelist_information($data_info),true);

    $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
    $row_gagan = $query->row();  
    //                  $order_data = array(
    //                 'ID'=>$ID[$i],
    //                 'dispatchment_confirmation_info'=>$_POST['dispatchment_confirmation_info'],
    //   );
    
    
    $item_in_cart='';

    $item_in_cart.='

    <tr>
    <td valign="top" width="187">
    <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
    <tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
    <tr>
    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

    <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


    </a></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    <td valign="top" width="374">
    <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
    <div>
    <table>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
    </tr>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
    </tr>



    </table>
    </div>
    </div>
    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    </tr>


    ';

    $to_email_address = $gagan[0]['primary_email'];
    $subject = 'Thankyou For shopping With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    $mail_content = file_get_contents($emailer);

    $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
    $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
    $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
    $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/13/13edb2dda8.png", $mail_content);
    $mail_content = str_replace('@_action_@',"packed", $mail_content);

    $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
    $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
    $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
    $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
    $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
    $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
    $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
    $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
    $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
    $headers = "From:no-reply@oxiinc.in\r\n" .
    'Reply-To: myorder@oxiinc.in' . "\r\n" .
    "MIME-Version: 1.0\r\n".
    "Content-Type: text/html; charset=ISO-8859-1\r\n";
    'X-Mailer: PHP/';
    mail($to_email_address, $subject, $mail_content, $headers);

    // echo '<pre>'; print_r($ID); exit;
    $status['dispatchment_confirmation']='1';
    $status['dispatchment_confirmation_info']=$_POST['dispatchment_confirmation_info'];
    $Update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID[$i]));

    $i++;
}

$this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
redirect('Slider/E_panelist_List_Of_Dispatchment');
}

public function Add_gift_category()
{
    $data['main_containt']='Add_gift_category';

    $this->load->view('containt',$data);
}
public function enter_gift_category()
{
 if(!empty($_FILES['category_pictue']['name'])){
    $config['upload_path'] = 'uploads/gift/';
    $config['allowed_types'] = 'jpg|jpeg|png|gif';
    $config['file_name'] = $_FILES['category_pictue']['name'];

                //Load upload library and initialize configuration
    $this->load->library('upload',$config);
    $this->upload->initialize($config);

    if($this->upload->do_upload('category_pictue')){
        $uploadData = $this->upload->data();
        $picture = $uploadData['file_name'];
    }else{
        $picture = '';
    }
}else{
    $picture = '';
}
$userData = array(
    'category_name' => $this->input->post('category_name'),
    'category_pictue' => $picture
);

$Product_id =$this->Model->insertData('gift_category',$userData);
$this->session->set_flashdata('msg','successfully your Gift category Add');
redirect('Slider/Add_gift_category');
}
public function List_Of_Gift_Category()
{
    $category_list = $this->Model->getData('gift_category');
    $data['category_list'] = $category_list;
    $data['main_containt']='List_Of_Gift_Category';
    $this->load->view('containt',$data);
}
public function edit_gift_category()
{
 $ID = $_GET['ID'];

 $data['table'] = $this->Model->getData('gift_category',array('ID'=>$ID));
 $data['main_containt']='edit_gift_category';

 $this->load->view('containt',$data);
}
public function edit_Category_form_update_gift()
{
 if(!empty($_FILES['category_pictue']['name'])){
    $config['upload_path'] = 'uploads/gift/';
    $config['allowed_types'] = 'jpg|jpeg|png|gif';
    $config['file_name'] = $_FILES['category_pictue']['name'];

                //Load upload library and initialize configuration
    $this->load->library('upload',$config);
    $this->upload->initialize($config);

    if($this->upload->do_upload('category_pictue')){
        $uploadData = $this->upload->data();
        $picture = $uploadData['file_name'];
    }else{
        $picture = '';
    }
}else{
    $picture = '';
}
$userData = array(
    'category_name' => $this->input->post('category_name'),
    'status' => $this->input->post('status'),
    'category_pictue' => $picture
);
$this->Model->updateData('gift_category',$userData,array('ID'=>$_POST['ID']));
redirect('Slider/List_Of_Gift_Category');
}
public function gift_Category_delete()
{
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('gift_category',array('ID'=>$ID));

    $this->session->set_flashdata('msg' ,'The Category has been deleted successfully.');

    redirect('Slider/List_Of_Gift_Category');
}
public function add_gift_sub_category()
{
 $data['category_data'] = $this->Model->getAllData('gift_category');
 $data['main_containt']='add_gift_sub_category';

 $this->load->view('containt',$data);
}
public function enter_sub_category_gift()
{
    if(!empty($_FILES['Sub_category_pictue']['name'])){
        $config['upload_path'] = 'uploads/gift/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $_FILES['Sub_category_pictue']['name'];

                //Load upload library and initialize configuration
        $this->load->library('upload',$config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('Sub_category_pictue')){
            $uploadData = $this->upload->data();
            $picture = $uploadData['file_name'];
        }else{
            $picture = '';
        }
    }else{
        $picture = '';
    }
    $userData = array(
        'sub_category_name' => $this->input->post('sub_category_name'),
        'gift_category_id' => $this->input->post('gift_category_id'),
        'Sub_category_pictue' => $picture
    );

    $Product_id =$this->Model->insertData('gift_sub_categoy',$userData);
    $this->session->set_flashdata('msg','successfully your Gift Sub-category Add');
    redirect('Slider/Add_gift_category');
}
public function list_of_gift_sub_categoy()
{
    $subcategory_list = $this->Model->getData('gift_sub_categoy');
    $data['subcategory_list'] = $subcategory_list;
    $data['main_containt']='list_of_gift_sub_categoy';
    $this->load->view('containt',$data);
}
public function gift_sub_Category_delete()
{
    $ID = $this->input->get_post('ID');
    $this->Model->deleteData('gift_sub_categoy',array('ID'=>$ID));

    $this->session->set_flashdata('msg' ,'The Sub Category has been deleted successfully.');

    redirect('Slider/list_of_gift_sub_categoy');
}
public function Gift_sub_Category_eidt()
{
 $ID = $_GET['ID'];
 $subcategory_list = $this->Model->getData('gift_category');
 $data['subcategory_list'] = $subcategory_list;
 $data['table'] = $this->Model->getData('gift_sub_categoy',array('ID'=>$ID));
 $data['main_containt']='Gift_sub_Category_eidt';

 $this->load->view('containt',$data);
}
public function edit_sub_Category_form_update_gift()
{
    $userData=$_POST;
    if(!empty($_FILES['Sub_category_pictue']['name'])){
        $config['upload_path'] = 'uploads/gift/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $_FILES['Sub_category_pictue']['name'];

                //Load upload library and initialize configuration
        $this->load->library('upload',$config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('Sub_category_pictue')){
            $uploadData = $this->upload->data();
            $picture = $uploadData['file_name'];
        }else{
            $picture = '';
        }
        $userData['Sub_category_pictue']=$picture;
    }


    $this->Model->updateData('gift_sub_categoy',$userData,array('ID'=>$_POST['ID']));
    redirect('Slider/list_of_gift_sub_categoy');
}
public function add_gift_product()
{
    $gift_category = $this->Model->getData('gift_category');
    $data['gift_category'] = $gift_category;
    $data['main_containt']='add_gift_product';

    $this->load->view('containt',$data);
}
public function Add_product_gift_insert()
{

    if(!empty($_FILES['gift_image']['name'])){
        $config['upload_path'] = 'uploads/gift/product/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $_FILES['gift_image']['name'];

                //Load upload library and initialize configuration
        $this->load->library('upload',$config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('gift_image')){
            $uploadData = $this->upload->data();
            $picture = $uploadData['file_name'];
        }else{
            $picture = '';
        }
    }else{
        $picture = '';
    }



            //Check whether user upload picture
    if(!empty($_FILES['Brochore']['name'])){
        $config1['upload_path'] = 'uploads/gift/product/';
        $config1['allowed_types'] = 'pdf|csv';
        $config1['file_name'] = $_FILES['Brochore']['name'];

                //Load upload library and initialize config1uration
        $this->load->library('upload',$config1);
        $this->upload->initialize($config1);

        if($this->upload->do_upload('Brochore')){
            $uploadData = $this->upload->data();
            $Brochore = $uploadData['file_name'];
        }else{
            $Brochore = '';
        }
    }else{
        $Brochore = '';
    }

    $userData = array(
        'category_id' => $this->input->post('category_id'),
        'sub_category_id' => $this->input->post('sub_category_id'),
        'product_gift_name' => $this->input->post('product_gift_name'),
        'gift_short_name' => $this->input->post('gift_short_name'),
        '2019_down_payment_price' => $this->input->post('2019_down_payment_price'),
        '2018_down_payment_price' => $this->input->post('2018_down_payment_price'),
        'long_Description' => $this->input->post('long_Description'),
        'Product_Picture' => $picture,
        'Brochore' => $Brochore
    );

    $Product_id =$this->Model->insertData('gift_product',$userData);
    $this->session->set_flashdata('msg','successfully your Gift Product uploaded');
    redirect('Slider/add_gift_product');

}
public function edit_delete_gift_product()
{
   $gift_category = $this->Model->getData('gift_category');
   $data['gift_category'] = $gift_category;
   $data['main_containt']='edit_delete_gift_product';
   $data['gift_product_list'] =  $this->Model->getAllData('gift_product');
   $this->load->view('containt',$data);
}
public function delete_gift_product()
{
   $ID = $this->input->get_post('ID');
   $this->Model->deleteData('gift_product',array('ID'=>$ID));

   $this->session->set_flashdata('msg' ,'The Gift has been deleted successfully.');

   redirect('Slider/edit_delete_gift_product');
}

public function edit_gift_product()
{
    $data['gift_category'] = $this->Model->getData('gift_category',array('status'=>'1'));
    $data['gift_sub_categoy'] = $this->Model->getData('gift_sub_categoy',array('status'=>'1'));
    $ID = $this->input->get_post('ID');
    $data['table'] = $this->Model->getData('gift_product',array('ID'=>$ID));
    $data['main_containt']='edit_gift_product';
    $this->load->view('containt',$data);
}
public function edit_product_gift_insert()
{
    if(!empty($_FILES['gift_image']['name'])){
        $config['upload_path'] = 'uploads/gift/product/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $_FILES['gift_image']['name'];

                //Load upload library and initialize configuration
        $this->load->library('upload',$config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('gift_image')){
            $uploadData = $this->upload->data();
            $picture = $uploadData['file_name'];
        }else{
            $picture = '';
        }
    }else{
        $picture = '';
    }
    $userData = array(
        'category_id' => $this->input->post('category_id'),
        'sub_category_id' => $this->input->post('sub_category_id'),
        'product_gift_name' => $this->input->post('product_gift_name'),
        'gift_short_name' => $this->input->post('gift_short_name'),
        '2019_down_payment_price' => $this->input->post('2019_down_payment_price'),
        '2018_down_payment_price' => $this->input->post('2018_down_payment_price')
    );
    if ($picture) {
        $userData['Product_Picture'] = $picture;
    }

    $update_id =  $this->Model->updateData('gift_product',$userData,array('ID'=>$this->input->post('ID')));
    $this->session->set_flashdata('msg','successfully your Gift Product update');
    redirect('Slider/edit_delete_gift_product');
}
function  By_mistake_shipping(){
// echo '<pre>'; print_r($this->uri->segment(3)); exit;
   $status['dispatchment_confirmation']='0';
    // $status['Shipping_confirmation_info']="0";
   $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$this->uri->segment(3)));

   redirect('Slider/E_panelist_List_Of_Shipping');
}
function E_panelist_shipping_Confirmation(){
    $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];
    $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));
//  echo "<pre>";
//  print_r($data);

//  $servername='172.19.2.230';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");

// $result=mysqli_query($conn,'select * from login where employee_id = '.$data[0]['shipping_employee_id']);
// $gagan=mysqli_fetch_assoc($result);

    $data_info['id']=$data[0]['shipping_employee_id'];
    $gagan=json_decode($this->epanelist_information($data_info),true);

    $item_in_cart='';

    $item_in_cart.='

    <tr>
    <td valign="top" width="187">
    <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
    <tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
    <tr>
    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

    <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


    </a></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    <td valign="top" width="374">
    <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
    <div>
    <table>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
    </tr>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
    </tr>



    </table>
    </div>
    </div>
    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    </tr>


    ';






    $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
    $row_gagan = $query->row(); 

//                                      echo"<pre>";print_r($row_gagan);
//  exit(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
    $to_email_address = $gagan[0]['primary_email'];
    $subject = 'Thankyou For shopping With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    $mail_content = file_get_contents($emailer);

    $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
    $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
    $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
    $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/142a1ce82e.png", $mail_content);
    $mail_content = str_replace('@_action_@',"shipped", $mail_content);

    $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
    $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
    $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
    $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
    $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
    $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
    $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
    $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
    $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
    $headers = "From:no-reply@oxiinc.in\r\n" .
    'Reply-To: myorder@oxiinc.in' . "\r\n" .
    "MIME-Version: 1.0\r\n".
    "Content-Type: text/html; charset=ISO-8859-1\r\n";
    'X-Mailer: PHP/';
    mail($to_email_address, $subject, $mail_content, $headers);
    $status['shipping_confirmation']='1';
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
    $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Shipping');
}


function E_panelist_shipping_Confirmation_all(){

    include("third_party/PHPExcel.php");
    include("third_party/PHPExcel/IOFactory.php");
    $reader = PHPExcel_IOFactory::createReader('Excel5');
    $reader->setReadDataOnly(true);
    $file = isset($_FILES["uploadexcel"]['tmp_name']) ? $_FILES["uploadexcel"]['tmp_name'] : '';
    $objPHPExcel = $reader->load($file);
    $objWorksheet = $objPHPExcel->getActiveSheet();
    $header=true;
    if ($header) {
        $highestRow = $objWorksheet->getHighestRow();
        $highestColumn = $objWorksheet->getHighestColumn();
        $headingsArray = $objWorksheet->rangeToArray('A1:' . $highestColumn . '1', null, true, true, true);
        $headingsArray = $headingsArray[1];
        $r = -1;
        $namedDataArray = array();
        for ($row = 2; $row <= $highestRow; ++$row) {
            $dataRow = $objWorksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, true, true);
            if ((isset($dataRow[$row]['A'])) && ($dataRow[$row]['A'] > '')) {
                ++$r;
                foreach ($headingsArray as $columnKey => $columnHeading) {
                    $namedDataArray[$r][$columnHeading] = $dataRow[$row][$columnKey];
                }
            }
        }
    } else {
        //excel sheet with no header
        $namedDataArray = $objWorksheet->toArray(null, true, true, true);

    }
    
    foreach ($namedDataArray as $key => $value) {
        $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $value['ID']));
        // echo "<pre>";print_r($value['']);
        
//         $servername='172.19.2.230';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");

// $result=mysqli_query($conn,'select * from login where employee_id = '.$data[0]['shipping_employee_id']);
// $gagan=mysqli_fetch_assoc($result);
//  echo "<pre>";print_r($value['Massage']);
        $data_info['id']=$data[0]['shipping_employee_id'];
        $gagan=json_decode($this->epanelist_information($data_info),true);






        $item_in_cart='';

        $item_in_cart.='

        <tr>
        <td valign="top" width="187">
        <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
        <tr>
        <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
        <tr>
        <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

        <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


        </a></td>
        </tr>
        </table>
        </td>
        </tr>
        </table>
        <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

        <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

        </td>

        <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

        <td valign="top" width="374">
        <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
        <div>
        <table>
        <tr>
        <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
        <td width="25"></td>
        <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
        </tr>
        <tr>
        <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
        <td width="25"></td>
        <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
        </tr>



        </table>
        </div>
        </div>
        </td>

        <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

        </tr>


        ';

        




        $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
        $row_gagan = $query->row(); 

//                                      echo"<pre>";print_r($row_gagan);
//  exit(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
        $to_email_address =  $gagan[0]['primary_email'];
        $subject = 'Thankyou For shopping With as, Oxiinc Group';
        $emailer = 'emailer/tracking_admin.html';
        $mail_content = file_get_contents($emailer);

        $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
        $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
        $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
        $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/142a1ce82e.png", $mail_content);
        $mail_content = str_replace('@_action_@',"shipped", $mail_content);

        $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
        $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
        $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
        $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
        $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
        $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
        $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
        $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
        $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
        $headers = "From:no-reply@oxiinc.in\r\n" .
        'Reply-To: myorder@oxiinc.in' . "\r\n" .
        "MIME-Version: 1.0\r\n".
        "Content-Type: text/html; charset=ISO-8859-1\r\n";
        'X-Mailer: PHP/';
        mail($to_email_address, $subject, $mail_content, $headers);
        $status['shipping_confirmation']='1';
        $status['Shipping_confirmation_info']=$value['Massage'];
        $status['height']=$value['Height'];
        $status['width']=$value['Width'];
        $status['lenght']=$value['Lenght'];
        $status['weight']=$value['Weight'];
        $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$value['ID']));

    }
    
    $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Shipping');
    
    
    
}

function By_mistake_Shipped(){
    // echo "<pre>";print_r();

    $status['shipping_confirmation']='0';
    // $status['In_Transit_confirmation_info']=$In_Transit_confirmation_info;
    $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$this->uri->segment(3)));

    $this->session->set_flashdata('msg','In Transit By Mistake Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Vendor');
 //     $data['order_delivered'] = $this->Model->getData('e_paenlist_order_data',array('shipping_confirmation'=>'1','order_intransit'=>'0','out_for_delivery'=>'0'));
 // $data['main_containt']='E_panelist_List_Of_Vendor';
 //  $this->load->view('containt',$data);
}
function E_panelist_In_transit_Confirmation(){
    $ID = $_POST['ID'];
    $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];


    $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));
//  echo "<pre>";
//  print_r($data);

    $data_info['id']=$data[0]['shipping_employee_id'];
    $gagan=json_decode($this->epanelist_information($data_info),true);

    $item_in_cart='';

    $item_in_cart.='

    <tr>
    <td valign="top" width="187">
    <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
    <tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
    <tr>
    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

    <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


    </a></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    <td valign="top" width="374">
    <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
    <div>
    <table>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
    </tr>
    <tr>
    <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
    <td width="25"></td>
    <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
    </tr>



    </table>
    </div>
    </div>
    </td>

    <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

    </tr>


    ';






    $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
    $row_gagan = $query->row(); 

//                                      echo"<pre>";print_r($row_gagan);
//  exit(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
    $to_email_address = $gagan[0]['primary_email'];
    $subject = 'Thankyou For shopping With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    $mail_content = file_get_contents($emailer);

    $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
    $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
    $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
    $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/1434f0e99c.png", $mail_content);
    $mail_content = str_replace('@_action_@',"intransit", $mail_content);

    $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
    $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
    $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
    $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
    $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
    $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
    $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
    $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
    $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
    $headers = "From:no-reply@oxiinc.in\r\n" .
    'Reply-To: myorder@oxiinc.in' . "\r\n" .
    "MIME-Version: 1.0\r\n".
    "Content-Type: text/html; charset=ISO-8859-1\r\n";
    'X-Mailer: PHP/';
    mail($to_email_address, $subject, $mail_content, $headers);
    $status['order_intransit']='1';
    $status['In_Transit_confirmation_info']= $In_Transit_confirmation_info;
    $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
    redirect('Slider/E_panelist_List_Of_Vendor');
}

function E_panelist_List_Of_All(){
   $ID = $_POST['ID'];
   $status['order_intransit']='1';
   $status['out_for_delivery']='1';
   $status['order_delivered']='1';
   $status['In_Transit_confirmation_info']=$_POST['In_Transit_confirmation_info'];
   $status['Out_For_Delivery_confirmation_info']=$_POST['Out_For_Delivery_confirmation_info'];
   $status['Delivered_confirmation_info']=$_POST['Delivered_confirmation_info'];
   $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));
   $this->session->set_flashdata('msg','In All Confirmation Update Successfully ');
   redirect('Slider/E_panelist_List_Of_Vendor');
}


function E_panelist_Deliverd_info_Confirmation(){
  $ID = $_POST['ID'];
  $Delivered_confirmation_info = $_POST['Delivered_confirmation_info'];




  $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));
//  echo "<pre>";
//  print_r($data);

//  $servername='172.19.2.230';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");

// $result=mysqli_query($conn,'select * from login where employee_id = '.$data[0]['shipping_employee_id']);
// $gagan=mysqli_fetch_assoc($result);

  $data_info['id']=$data[0]['shipping_employee_id'];
  $gagan=json_decode($this->epanelist_information($data_info),true);

  $item_in_cart='';

  $item_in_cart.='

  <tr>
  <td valign="top" width="187">
  <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
  <tr>
  <td>
  <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
  <tr>
  <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

  <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


  </a></td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

  <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

  </td>

  <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

  <td valign="top" width="374">
  <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
  <div>
  <table>
  <tr>
  <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
  <td width="25"></td>
  <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
  </tr>
  <tr>
  <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
  <td width="25"></td>
  <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
  </tr>



  </table>
  </div>
  </div>
  </td>

  <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

  </tr>


  ';






  $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
  $row_gagan = $query->row(); 

//                                      echo"<pre>";print_r($row_gagan);
//  exit(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
  $to_email_address = $gagan[0]['primary_email'];
  $subject = 'Thankyou For shopping With as, Oxiinc Group';
  $emailer = 'emailer/tracking_admin.html';
  $mail_content = file_get_contents($emailer);

  $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
  $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
  $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
  $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/14f240af1e.png", $mail_content);
  $mail_content = str_replace('@_action_@',"deliverd", $mail_content);

  $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
  $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
  $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
  $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
  $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
  $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
  $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
  $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
  $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
  $headers = "From:no-reply@oxiinc.in\r\n" .
  'Reply-To: myorder@oxiinc.in' . "\r\n" .
  "MIME-Version: 1.0\r\n".
  "Content-Type: text/html; charset=ISO-8859-1\r\n";
  'X-Mailer: PHP/';
  mail($to_email_address, $subject, $mail_content, $headers);
  $status['order_delivered']='1';
  $status['Delivered_confirmation_info']=$Delivered_confirmation_info;

  $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

  $this->session->set_flashdata('msg','Delivered Confirmation Update Successfully ');
  redirect('Slider/E_panelist_List_Of_Delivered');
}

function add_user_role_insert(){
    $id = $this->Model->updateData('users',$_POST,array('id'=>$_POST['user_id']));
// echo '<pre>'; print_r($id); exit;
    $this->session->set_flashdata('msg' ,'User Role Add successfully.');
    redirect('Usersadmin/Add_User_Role');
}
function Digital_Markating_Program(){
    $product_list = $this->Model->getDataOrderBy('wellness',array('allow_data'=>'0'),'ID','DESC');
    $data['product_list'] = $product_list;
        // echo '<pre>'; print_r($product_list); exit;
    $data['main_containt']='Digital_Markating_Program';
    $this->load->view('containt',$data);
}
function My_Digital_allow(){
//   echo '<pre>'; print_r($_POST); 
    $product_allow_id = $_POST['Product_allow_id'];
    $i = 0;
    foreach ($product_allow_id as $key => $value) {


       $PQR =  mt_rand(10000,999999);
       $SKU = 'OXIINC'.$PQR;
            // echo '<pre>'; print_r($SKU); exit;
       $var['allow_data'] = '1';
       $this->Model->updateData('wellness',$var,array('ID'=>$value));


       $product_data = $this->Model->getData('wellness',array('ID'=>$value));
            // echo '<pre>'; print_r($product_data); exit;
       $allow_data = array(
        'Prices'=>$product_data[0]['Prices'],
        'Original_Prices'=>$product_data[0]['Original_Prices'],
        'Product_Name'=>$product_data[0]['Product_Name'],
        'verified_status'=>$product_data[0]['verified_status'],
        'offer_specification'=>$product_data[0]['offer_specification'],
        'Product_Attribute'=>$product_data[0]['Product_Attribute'],

        'Product_id'=>$product_data[0]['ID'],
        'product_allow_id'=>$value,
        'panel_name'=>$_POST['panel_name'],
        'expirey_date'=>$_POST['expirey_date'],
        'caption_code'=>$SKU,
        'allow_information'=>$_POST['Shipping_confirmation_info'],

        'allow_month'=> date('m'),
        'allow_year'=> date('Y'),
        'allow_day'=> date('d'),
        'allow_year_month'=> date('Y-m'),
        'allow_year_month_data' =>date('Y-m-d'),
        'allow_year_month_data_time'=> date('Y-m-d H:i:s')

    );
       $order_id = $this->Model->insertData('allow_data_my_digital',$allow_data);

       $i++;
   }
   $this->session->set_flashdata('msg' ,' Add successfully.');
   redirect('Slider/Digital_Markating_Program');
       // echo '<pre>'; print_r($i); 
// echo '<pre>'; print_r($allow_data); exit;
}
function List_of_Allow_Product_For_Digital_Marketing(){
   $product_list = $this->Model->getDataOrderBy('wellness',array('allow_data'=>'1'),'ID','DESC');
   $data['product_list'] = $product_list;
        // echo '<pre>'; print_r($product_list); exit;
   $data['main_containt']='List_of_Allow_Product_For_Digital_Marketing';
   $this->load->view('containt',$data);
}
function Replace_system(){
    // print_r();
    $today = date("Y-m-d");

    $this->load->model('dbs');
    $query = $this->db->query('select * from allow_data_my_digital where status=1 and expirey_date>="'.$today.'"   ');

    $product_list= $query->result_array();

    // $product_list = $this->Model->getDataOrderBy('allow_data_my_digital',array('status'=>'1'),'ID','DESC');
    $data['product_list'] = $product_list;
        // echo '<pre>'; print_r($product_list); exit;
    $data['main_containt']='Replace_system';
    $this->load->view('containt',$data);
}
function Allowed_delete(){
//   print_r();

   $this->Model->deleteData('allow_data_my_digital',array('ID'=>$this->uri->segment(3)));

   $this->session->set_flashdata('msg' ,'The Allowed Product has been deleted successfully.');

   redirect('Slider/Replace_system');
}
public function Replace_system_process()
{
 $data['Replace_ID'] = $this->uri->segment(3);
 $product_list = $this->Model->getDataOrderBy('wellness',array('allow_data'=>'0'),'ID','DESC');
 $data['product_list'] = $product_list;
        // echo '<pre>'; print_r($product_list); exit;
 $data['main_containt']='Replace_system_process';
 $this->load->view('containt',$data);
}
public function Replace_system_compl()
{
 $product_id = $this->uri->segment(3);
 $Replace_ID = $this->uri->segment(4);
       // $product_allow_id = $_POST['Product_allow_id'];
    // $i = 0;
    //     foreach ($product_allow_id as $key => $value) {


// echo '<pre>'; print_r($SKU); exit;
 $var['allow_data'] = '1';
 $this->Model->updateData('wellness',$var,array('ID'=>$product_id));
// echo '<pre>'; print_r(); exit;

 $product_data = $this->Model->getData('wellness',array('ID'=>$product_id));
            // echo '<pre>'; print_r($product_data); exit;
 $allow_data = array(
    'Prices'=>$product_data[0]['Prices'],
    'Original_Prices'=>$product_data[0]['Original_Prices'],
    'Product_Name'=>$product_data[0]['Product_Name'],
    'verified_status'=>$product_data[0]['verified_status'],
    'offer_specification'=>$product_data[0]['offer_specification'],
    'Product_Attribute'=>$product_data[0]['Product_Attribute'],

    'Product_id'=>$product_data[0]['ID'],
    'product_allow_id'=>$product_id


);
            // echo '<pre>'; print_r($allow_data); exit;
 $order_id = $this->Model->updateData('allow_data_my_digital',$allow_data,array('ID'=>$Replace_ID));
        // echo '<pre>'; print_r($order_id); exit;
        // $i++;
        // }
 $this->session->set_flashdata('msg' ,' Add successfully.');
 redirect('Slider/Replace_system');

}
function My_Digital_allow_no(){
    $product_allow_id = $_POST['Product_allow_id'];
    $i = 0;
    foreach ($product_allow_id as $key => $value) {
        $var['allow_data'] = '0';
        $this->Model->updateData('wellness',$var,array('ID'=>$value));
        $i++;
    }
    $this->session->set_flashdata('msg' ,' Add successfully.');
    redirect('Slider/List_of_Allow_Product_For_Digital_Marketing');
}
function E_panelist_Out_for_Delivery_Confirmation(){
   $ID = $_POST['ID'];
   $Out_For_Delivery_confirmation_info = $_POST['Out_For_Delivery_confirmation_info'];








   $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));
//  echo "<pre>";
//  print_r($data);

//  $servername='172.19.2.230';
// $username='membero_oxiinc';
// $password='YD4{B@Cp;[wS';
// $dbname = "membero_oxiinc";
// $conn=mysqli_connect($servername,$username,$password,"$dbname");

// $result=mysqli_query($conn,'select * from login where employee_id = '.$data[0]['shipping_employee_id']);
// $gagan=mysqli_fetch_assoc($result);
   $data_info['id']=$data[0]['shipping_employee_id'];
   $gagan=json_decode($this->epanelist_information($data_info),true);

   $item_in_cart='';

   $item_in_cart.='

   <tr>
   <td valign="top" width="187">
   <table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#dedede">
   <tr>
   <td>
   <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#ffffff">
   <tr>
   <td class="img" style="font-size:0pt; line-height:0pt; text-align:left"><a href="#" target="_blank">

   <img src="'.$data[0]['Product_Picture'].'" alt="" border="0" width="175" height="130" />


   </a></td>
   </tr>
   </table>
   </td>
   </tr>
   </table>
   <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

   <div style="font-size:0pt; line-height:0pt; height:15px"><img src="images/empty.gif" width="1" height="15" style="height:15px" alt="" /></div>

   </td>

   <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

   <td valign="top" width="374">
   <div class="text2-center" style="color:#bebebe; font-family:Tahoma; font-size:12px; line-height:18px; ">
   <div>
   <table>
   <tr>
   <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Product_Name'].'</td>
   <td width="25"></td>
   <td style="color: black;font-weight: 700;font-size: 13px;" >Size: '.$data[0]['size'].'</td>
   </tr>
   <tr>
   <td style="color: black;font-weight: 700;font-size: 13px;">'.$data[0]['Prices'].' </td>
   <td width="25"></td>
   <td style="color: black;font-weight: 700;font-size: 13px;" >Qty: '.$data[0]['product_qty'].'</td>
   </tr>



   </table>
   </div>
   </div>
   </td>

   <td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="30"></td>

   </tr>


   ';






   $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
   $row_gagan = $query->row(); 

//                                      echo"<pre>";print_r($row_gagan);
//  exit(); 

//         $user_name = $user_name;
//      $user_names = $user_name;
   $to_email_address = $gagan[0]['primary_email'];
   $subject = 'Thankyou For shopping With as, Oxiinc Group';
   $emailer = 'emailer/tracking_admin.html';
   $mail_content = file_get_contents($emailer);

   $mail_content = str_replace('@_mail_@',$item_in_cart, $mail_content);

                // $mail_content = str_replace('@_shipping_@',$Shipping_address, $mail_content);
   $mail_content = str_replace('@_promo_@',$data[0]['Promo_amount'], $mail_content);
   $mail_content = str_replace('@_total_@',$data[0]['total_amount'], $mail_content);
   $mail_content = str_replace('@_img_@',"https://i.imgsafe.org/14/14e6228623.png", $mail_content);
   $mail_content = str_replace('@_action_@',"out for deliverd", $mail_content);

   $mail_content = str_replace('@_method_@',$data[0]['payment_method'], $mail_content);
   $mail_content = str_replace(' @_orderid_@',$data[0]['txnid'], $mail_content);  
   $mail_content = str_replace(' @_gst_@',$data[0]['total_gst'], $mail_content); 
   $mail_content = str_replace('@_charge_@',$data[0]['total_shipping'], $mail_content); 
   $mail_content = str_replace('@_address_@',$row_gagan->address, $mail_content);
   $mail_content = str_replace('@_Locality_@',$row_gagan->Locality, $mail_content);
   $mail_content = str_replace('@_state_@',$row_gagan->state, $mail_content);
   $mail_content = str_replace('@_pincode_@',$row_gagan->Pincode, $mail_content);
   $mail_content = str_replace('@_City_@',$row_gagan->City, $mail_content);
   $headers = "From:no-reply@oxiinc.in\r\n" .
   'Reply-To: myorder@oxiinc.in' . "\r\n" .
   "MIME-Version: 1.0\r\n".
   "Content-Type: text/html; charset=ISO-8859-1\r\n";
   'X-Mailer: PHP/';
   mail($to_email_address, $subject, $mail_content, $headers);

   $status['out_for_delivery']='1';
   $status['Out_For_Delivery_confirmation_info']=$Out_For_Delivery_confirmation_info;

   $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

   $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
   redirect('Slider/E_panelist_Out_For_Delivery');
}
public function Stock_Management_System()
{
  $sql = "select * from wellness  WHERE status ='1' AND stock_status>='1'order by ID desc";
  $data['Stock_Management_System'] = $this->Model->getSqlData($sql);
   // echo '<pre>'; print_r( $data['Stock_Management_System']); exit;
  $data['main_containt']='Stock_Management_System';
  $this->load->view('containt',$data);
}
public function Out_Stock_Product()
{
  $sql = "select * from wellness  WHERE status ='1' AND stock_status<='0' order by ID desc";
  $data['out_Stock_Management_System'] = $this->Model->getSqlData($sql);

  $data['main_containt']='Out_Stock_Product';
  $this->load->view('containt',$data);
}
public function Update_stock()
{
   $ID = $_GET['ID'];
   $data['table'] = $this->Model->getData('wellness',array('ID'=>$ID));
   $data['main_containt']='Update_stock';

   $this->load->view('containt',$data);
}
public function update_information()
{
    $postData = $_POST;
    $ID = $this->input->get_post('ID');
    $this->Model->updateData('wellness',$postData,array('ID'=>$ID)); 
    $this->session->set_flashdata('msg' ,'The Product has been Updated successfully.');
    redirect('Slider/Stock_Management_System');
}

public function load_more_total_epanelist(){
    // echo"<pre>";print_r();
   $query = $this->db->query('SELECT * from e_paenlist_order_data order by ID  DESC limit 0,'.$_POST['id']);

   $Out_For_Delivery= $query->result_array();
   ?>
   <?php  $i=0; if(isset($Out_For_Delivery) && !empty($Out_For_Delivery)) foreach ($Out_For_Delivery as $orderdata) {  
                                            // echo(arg1)ho '<pre>'; print_r($row['status']); exit;
    if ($orderdata['order_confirmation']==1){
        $status_label ="success";
        $status_desc = "order Confirm";
    }else{
        $status_label ="default";
        $status_desc = "UN-order Confirm";

    }
    if($orderdata['dispatchment_confirmation']=='0'){
      $label =   "UN-Dispatchment  Confirm";
  }else{
      $label = "Dispatchment  Confirm";
  }
  if($orderdata['shipping_confirmation']=='0'){
      $labels =   "UN-Shipped Confirm";
  }else{
      $labels = "Shipped Confirm";
  }
  if($orderdata['order_intransit']=='0'){
      $labelsss =   "UN-In Transit Confirm";
  }else{
      $labelsss = "In Transit Confirm";
  }
  ?>
  <tr>  
    <td><?php echo ++$i;?></td>
    <td><?php echo $orderdata['ID'];?></td> 
    <td><?php echo $orderdata['shipping_Name'];?></td>
    <!-- <td><?php echo $orderdata['email_id'];?></td> -->
    <td><?php echo $orderdata['shipping_Phone_number'];?></td>
    <td><?php echo $orderdata['Product_Name'];?></td>
    <td><a target="_blank"  href="<?php echo base_url('Slider/epanelist_invoice').'?ID='.$orderdata['ID'];?>"><?php echo $orderdata['txnid'];?></a></td>
    <td><?php echo $orderdata['Prices'];?></td>
    <td><?php echo date('Y-M-d',strtotime($orderdata['order_date_time']));?></td>
    <td><span class="label label-<?= $status_label ?>"><?= $status_desc?></span></td> 
    <td><?= $label?></td>
    <td><?= $labels?></td>
    <td><?= $labelsss?></td>
    <td>
        <?php
        if($orderdata['status']=="1"){
            ?>
            <a href="<?php echo base_url('Slider/epanelist_order_deactive').'?ID='.$orderdata['ID'];?>">Active</a>        
            <?php
        }

        ?>
        <?php
        if($orderdata['status']=="0"){
            ?>
            <a href="<?php echo base_url('Slider/epanelist_order_active').'?ID='.$orderdata['ID'];?>">DE-Active</a>        
            <?php
        }

        ?>
    </td>
    <td>

      <button type="button" style="background-color: red;" class="btn btn-primary" ><a onclick="return confirm('Are you sure?')" href="<?php echo base_url("slider/delete_epanelist/".$orderdata['ID']); ?>" style="color:white;" >Delete Order</a></button>


      <!--  <a href="#"><button type="button" class="btn btn-primary mb-control" data-box="#message-box-success<?php echo $orderdata['ID'];?>">Out For Delivery Confirmation</button></a> --></td>

      <td><?php echo $orderdata['payment_method'];?></td>

      <td><a href="" data-toggle="modal" data-target="#exampleModalgagan<?php echo $orderdata['ID'];?>"><?php echo $orderdata['dispatchment_confirmation_info'];?></a></td>
      <td><a href="" data-toggle="modal" data-target="#exampleModalgagan<?php echo $orderdata['ID'];?>"><?php echo $orderdata['Shipping_confirmation_info'];?></a></td>
      <td><a href="" data-toggle="modal" data-target="#exampleModalgagan<?php echo $orderdata['ID'];?>"><?php echo $orderdata['In_Transit_confirmation_info'];?></a></td>
      <td><a href="" data-toggle="modal" data-target="#exampleModalgagan<?php echo $orderdata['ID'];?>"><?php echo $orderdata['Out_For_Delivery_confirmation_info'];?></a></td>
      <td><a href="" data-toggle="modal" data-target="#exampleModalgagan<?php echo $orderdata['ID'];?>"><?php echo $orderdata['Delivered_confirmation_info'];?></a></td>


  </tr>  






  <div class="modal fade" id="exampleModalgagan<?php echo $orderdata['ID'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">confirmation_info</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url('Slider/dispatchment_confirmation_info') ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="ID" id="ID" value="<?php echo $orderdata['ID'];?>">
            dispatchment_confirmation_info: <textarea  name="dispatchment_confirmation_info" rows="4" cols="75" ><?php echo $orderdata['dispatchment_confirmation_info']; ?></textarea>
            Shipping_confirmation_info: <textarea  name="Shipping_confirmation_info" rows="4" cols="75" ><?php echo $orderdata['Shipping_confirmation_info']; ?></textarea>
            In_Transit_confirmation_info: <textarea  name="In_Transit_confirmation_info" rows="4" cols="75" ><?php echo $orderdata['In_Transit_confirmation_info']; ?></textarea>
            Out_For_Delivery_confirmation_info: <textarea  name="Out_For_Delivery_confirmation_info" rows="4" cols="75" ><?php echo $orderdata['Out_For_Delivery_confirmation_info']; ?></textarea>
            Delivered_confirmation_info: <textarea  name="Delivered_confirmation_info" rows="4" cols="75" ><?php echo $orderdata['Delivered_confirmation_info']; ?></textarea>


        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" style=" background-color: #1CAF9A" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>
</div>
</div>

<?php }  
?>

<?php
}
function total_epanelist_date(){
    // $sql = "select * from e_paenlist_order_data  WHERE  order by ID desc";
    // $data['Out_For_Delivery']  = $this->Model->getSqlData($sql);
    // $data['Out_For_Delivery'] = $this->Model->getData('e_paenlist_order_data');
    $query = $this->db->query("select * from e_paenlist_order_data 
        where order_year_month_data_time between '".$_POST['start']."' and '".$_POST['end']."' ");


    $data['Out_For_Delivery']= $query->result_array();

    $data['main_containt']='total_epanelist';
    $this->load->view('containt',$data);
}

function delete_epanelist(){

    $user_id = $this->uri->segment(3);
    $this->Model->deleteData('e_paenlist_order_data',array('id'=>$user_id));

    $this->session->set_flashdata('msg' ,'The File has been deleted successfully.');

    redirect('Slider/total_epanelist');
}
function reject_epanelist(){

 echo $user_id = $this->uri->segment(3);
 $_POST['order_confirmation']="2";
        // $this->Model->deleteData('e_paenlist_order_data',array('id'=>$user_id));
        // print_r($_POST);
        // exit();
 $this->Model->updateData('e_paenlist_order_data',$_POST,array('id'=>$user_id));
 $this->session->set_flashdata('msg' ,'The File has been hold successfully.');

 redirect('Slider/E_panelist_List_Of_Dispatchment');
}
function remove_reject_epanelist(){

 echo $user_id = $this->uri->segment(3);
 $_POST['order_confirmation']="1";
        // $this->Model->deleteData('e_paenlist_order_data',array('id'=>$user_id));
        // print_r($_POST);
        // exit();
 $this->Model->updateData('e_paenlist_order_data',$_POST,array('id'=>$user_id));
 $this->session->set_flashdata('msg' ,'The File has been Back Order successfully.');

 redirect('Slider/List_hold');
}

function dispatchment_confirmation_info(){

    $this->Model->updateData('e_paenlist_order_data',$_POST,array('ID'=>$_POST['ID'])); 
    $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
    redirect('Slider/total_epanelist');
    
}

function dispatchment_confirmation_info_normal(){
    // echo "<pre>";print_r($_POST);exit;
    $this->Model->updateData('order_data',$_POST,array('ID'=>$_POST['ID'])); 
    $this->session->set_flashdata('msg' ,'The File has been Updated successfully.');
    redirect('Slider/List_Of_order_confirmation');
    // echo "<pre>";print_r($_POST);exit;
//     $data['Out_For_Delivery'] = $this->Model->getData('e_paenlist_order_data');
//     // echo "<pre>";print_r($data['Out_For_Delivery']);exit;
//  $data['main_containt']='total_epanelist';
//   $this->load->view('containt',$data);
}

function E_panelist_List_Of_Post(){
   $data['order_delivered'] = $this->Model->getData('e_paenlist_order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
   $data['main_containt']='E_panelist_List_Of_Post';
   $this->load->view('containt',$data);
}


function E_panelist_List_Of_Post_data(){
   $data['order_delivered'] = $this->Model->getData('e_paenlist_order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
   $data['main_containt']='E_panelist_List_Of_Post_data';
   $this->load->view('containt',$data);
}

function List_Of_Vendor_data(){
   $data['order_delivered'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
   $data['main_containt']='List_Of_Vendor_data';
   $this->load->view('containt',$data);
}
public function Transfer_to_normal_category()
{
    // $ID = $_GET['ID'];
   $data['category_data'] = $this->Model->getData('category');
   $data['table'] = $this->Model->getData('wellness',array('status'=>1,'transfer'=>0));
   $data['main_containt']='Transfer_to_normal_category';
// echo '<pre>'; print_r( $data['table']); exit;
   $this->load->view('containt',$data);
}
public function Transfer_to_normal_category_add()
{
   $ID = $_POST['id'];
   $category_id = $_POST['category_id'];
   $sub_category_id = $_POST['sub_category_id'];
   $product_category_id = $_POST['product_category_id'];
   $i = 0;
   foreach ($ID as $key => $value) {
    $var['category_id'] = $category_id;
    $var['sub_category_id'] = $sub_category_id;
    $var['product_category_id'] = $product_category_id;
    $var['transfer'] = '1';
    $this->Model->updateData('wellness',$var,array('ID'=>$value));
    $i++;
}
$this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Slider/Transfer_to_normal_category');
}
public function Define_product_E_panelist_normal()
{
    // $data['category_data'] = $this->Model->getData('category');
   $data['table'] = $this->Model->getData('wellness',array('status'=>1,'define_product'=>0));
   $data['main_containt']='Define_product_E_panelist_normal';
// echo '<pre>'; print_r( $data['table']); exit;
   $this->load->view('containt',$data);
}
public function Define_Product_as_a_normal_or_epanelist()
{
    // echo '<pre>'; print_r($_POST); exit;
 $ID = $_POST['id'];

 $i = 0;
 foreach ($ID as $key => $value) {
    $var['define_product'] = '1';
    $this->Model->updateData('wellness',$var,array('ID'=>$value));
    $i++;
}
$this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Slider/Define_product_E_panelist_normal');
}
public function transfered_product_normal()
{
    $data['category_data'] = $this->Model->getData('category');
    $data['table'] = $this->Model->getData('wellness',array('status'=>1,'transfer'=>1));
    $data['main_containt']='transfered_product_normal';
// echo '<pre>'; print_r( $data['table']); exit;
    $this->load->view('containt',$data);
}
public function Transfer_to_normal_category_add_to()
{
   $ID = $_POST['id'];
   $category_id = $_POST['category_id'];
   $sub_category_id = $_POST['sub_category_id'];
   $product_category_id = $_POST['product_category_id'];
   $i = 0;
   foreach ($ID as $key => $value) {
    $var['category_id'] = $category_id;
    $var['sub_category_id'] = $sub_category_id;
    $var['product_category_id'] = $product_category_id;
    $var['transfer'] = '1';
    $this->Model->updateData('wellness',$var,array('ID'=>$value));
    $i++;
}
$this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Slider/transfered_product_normal');
}
public function Stock_Order()
{
  $sql = "select * from wellness  WHERE status ='1'  order by ID desc";
  $data['Stock_Management_System'] = $this->Model->getSqlData($sql);
   // echo '<pre>'; print_r( $data['Stock_Management_System']); exit;
  $data['main_containt']='Stock_Order';
  $this->load->view('containt',$data);
}
public function define_product_as_e_panelist()
{
 $data['table'] = $this->Model->getData('wellness',array('status'=>1,'define_product'=>1));
 $data['main_containt']='define_product_as_e_panelist';
// echo '<pre>'; print_r( $data['table']); exit;
 $this->load->view('containt',$data);
}
public function Define_Product_as_a_normal_()
{
 $ID = $_POST['id'];

 $i = 0;
 foreach ($ID as $key => $value) {
    $var['define_product'] = '0';
    $this->Model->updateData('wellness',$var,array('ID'=>$value));
    $i++;
}
$this->session->set_flashdata('msg' ,' Add successfully.');
redirect('Slider/define_product_as_e_panelist');
}
function List_Of_Vendor_post_data(){
   $data['order_delivered'] = $this->Model->getData('order_data',array('dispatchment_confirmation'=>'1','shipping_confirmation'=>'0'));
   $data['main_containt']='List_Of_Vendor_post_data';
   $this->load->view('containt',$data);
}
public function order_change()
{
    # code...
    $data['main_containt']='Order_Change_new';
    $this->load->view('containt',$data);
}
public function order_change_edit()
{
    # code...
   include("third_party/PHPExcel.php");
   include("third_party/PHPExcel/IOFactory.php");
   $reader = PHPExcel_IOFactory::createReader('Excel5');
   $reader->setReadDataOnly(true);
   $file = isset($_FILES["uploadexcel"]['tmp_name']) ? $_FILES["uploadexcel"]['tmp_name'] : '';
   $objPHPExcel = $reader->load($file);
   $objWorksheet = $objPHPExcel->getActiveSheet();
   $header=true;
   if ($header) {
    $highestRow = $objWorksheet->getHighestRow();
    $highestColumn = $objWorksheet->getHighestColumn();
    $headingsArray = $objWorksheet->rangeToArray('A1:' . $highestColumn . '1', null, true, true, true);
    $headingsArray = $headingsArray[1];
    $r = -1;
    $namedDataArray = array();
    for ($row = 2; $row <= $highestRow; ++$row) {
        $dataRow = $objWorksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, true, true);
        if ((isset($dataRow[$row]['A'])) && ($dataRow[$row]['A'] > '')) {
            ++$r;
            foreach ($headingsArray as $columnKey => $columnHeading) {
                $namedDataArray[$r][$columnHeading] = $dataRow[$row][$columnKey];
            }
        }
    }
} else {
        //excel sheet with no header
    $namedDataArray = $objWorksheet->toArray(null, true, true, true);

}
    // echo "<pre>";print_r($namedDataArray);
foreach ($namedDataArray as $key => $value) {
   $data=$this->Model->getData('e_paenlist_order_data',array('ID'=>$value['ID']));
   if ($data) {
             # code...
    $postData['dispatchment_confirmation']=1;
    $postData['dispatchment_confirmation_info']="your order has been packed confirm";
    $this->Model->updateData('e_paenlist_order_data',$this->security->xss_clean($postData),array('ID'=>$value['ID'])); 
    echo $value['ID']."---"."Done"."<br>";
}else{
    echo $value['ID']."---"."not_exit"."<br>";
}
          // echo "<pre>";print_r($value['ID']);
}

}

public function Pending_Reseller_approval(){
    $var['id'] = $_POST['id'];
    $var['approval_status'] = $_POST['approval_status'];
    $var['remark'] = $_POST['remark'];    
    //echo "<pre>";print_r($var);die();
    $this->Model->updateData('reseller', $var, array('id'=>$_POST['id']));
    redirect(base_url('slider/'.$_POST['url']));
}

public function blulk_upload_form()
{
 $category_data =$this->Model->getData('category',array('status'=>'1'));
 $data['category_data'] = $category_data;
        // echo "<pre>";print_r($category_data);exit();
 $data['main_containt']='blulk_upload_form_view';
 $this->load->view('containt',$data);

}
public function blulk_upload_form_add()
{
  // echo "<pre>";print_r($_POST);exit();
    $ext = pathinfo($_FILES['Product_Image']['name'][0][1], PATHINFO_EXTENSION);

    if(($ext=="jpg") || ($ext=="png") || ($ext=="gif") || ($ext=="jpeg") ){
      $i=0;
      $Product_data=" ";
  // echo sizeof($_POST['Product_Name']);

      foreach ($_POST['Product_Name'] as $key => $value) {
    # code...


        $sub_category_name=$this->Model->getData('subcategory',array('sub_category_id'=>$_POST['sub_category_id']));
        $Product_data = array(
            'category_id' =>$_REQUEST['category_id'],
            'sub_category_id' =>$_REQUEST['sub_category_id'],
            'sub_category_name' =>$sub_category_name[0]['sub_category_name'],
            'product_category_id' =>$_REQUEST['product_category_id'],

            'Product_Name' =>$_REQUEST['Product_Name'][$i] ,
            'Original_Prices' =>$_REQUEST['Original_Prices'][$i],
            'Prices' =>$_REQUEST['Prices'][$i],
            'Short_Description' =>$_REQUEST['Short_Description'][$i] ,
            'large_Description' =>$_REQUEST['large_Description'] [$i],
            'visible' =>$_REQUEST['visible'] [$i],
            'GST_Persentage' =>$_REQUEST['GST_Persentage'][$i] ,
            'Shipping_Charges' =>$_REQUEST['Shipping_Charges'][$i] ,
            'Product_Attribute' =>implode( ",", $_REQUEST['sizes'][$i]) ,

        );
        $ID=$this->Model->insertData('wellness',$Product_data);

        $multiple_picture_upload=$_FILES['Product_Image']['name'][$i];
        $count=sizeof($multiple_picture_upload);
        for ($k=0; $k < $count; $k++) { 
  # code...
            if(!empty($_FILES['Product_Image'])){
                $uploaddir = './uploads/Multiple_Picture/';
                $rand_file_name=rand().".png";
                $uploadfile = $uploaddir .$rand_file_name;

                if (move_uploaded_file($_FILES['Product_Image']['tmp_name'][$i][$k], $uploadfile)) {
              // echo "File is valid, and was successfully uploaded.\n";
                  $image_data = $rand_file_name;
              }
          }
          $multiple_picture=array(
            'Product_id' =>$ID ,
            'Product_Picture_Mult' =>$image_data,
            'status' =>1);

          $multiple_picture_id=$this->Model->insertData('multiple_picture',$multiple_picture);
      }
// exit();
    // $multiple_picture_id=$this->Model->insertData('multiple_picture',$multiple_picture);

    // $stock_sizes_data=explode(",",$_POST['stock_sizes'][$i]);
    // $sizes_data=explode(",",$_POST['sizes'][$i]);
    // echo "<pre>";print_r($sizes_data);
      $add_total_stock=0;
      $j=0;  
      foreach ($_POST['sizes'][$i] as $key => $question) {

       $stock_sizes_add = array(
        'p_id'=>$ID,

        'size'=>$_POST['sizes'][$i][$j],
        'stock'=>$_POST['stock_sizes'][$i][$j]
    );
          // echo "<pre>";print_r($stock_sizes_add);exit();
       $this->Model->insertData('size_manage',$stock_sizes_add);
       $add_total_stock+=$_POST['stock_sizes'][$i][$j];
       $j++;

   }
   $stock_sizes_Update['stock_status']=$add_total_stock;

   $this->Model->updateData('wellness',$stock_sizes_Update,array('ID'=>$ID));
   $i++;
}
$this->session->set_flashdata('msg','Product uploaded successfully.');
redirect('slider/blulk_upload_form');
}else{
    $this->session->set_flashdata('msg','Something went wrong.');
    redirect('slider/blulk_upload_form');
}
  // echo "<pre>";print_r($Product_data);
}
    // function Url_append_edit_form(){
    //     // echo '<pre>'; print_r($_POST); exit;
    //     $ID = $this->input->get_post('ID');
    //     $Product_Name = $this->input->get_post('Product_Name');
    //     $Product_offer = $this->input->get_post('Product_offer');
    //     $Product_short_name = $this->input->get_post('Product_short_name');




    //         if($_FILES['Product_Picture']['name'] != ''){

    //             $uploaddir = './uploads/append/';
    //             $filename = rand().basename($_FILES['Product_Picture']['name']);
    //             $uploadfile = $uploaddir.$filename;


    //             if (move_uploaded_file($_FILES['Product_Picture']['tmp_name'], $uploadfile)) {
    //               echo "File is valid, and was successfully uploaded.\n";
    //               $picture = $filename;
    //             } else {
    //                echo "Upload failed";
    //                $picture = "";
    //             }
    //         }
    //         else{
    //            $picture =  $_POST['Product_Picture'];
    //         }
    //         $update_data = array(
    //             'Product_Name'=>$Product_Name,
    //             'Product_offer'=>$Product_offer,
    //             'Product_short_name'=>$Product_short_name,

    //             'Product_Picture' => $picture
    //         );
    //         $this->Model->updateData('url_append_info',$update_data,array('ID'=>$ID));


    //         $this->session->set_flashdata('msg','Supplier updated successfully.');
    //         redirect('Slider/Url_Upend_information_list');
    //     }
//     function editprojectimage_pro($ID)  
// {

//   $config['upload_path'] = './uploads/append/';
//   $config['allowed_types'] = 'jpg|jpeg|png|gif';
//   // $config['max_size'] = '2000';


//   $this->load->library('upload', $config);

//   if ( ! $this->upload->do_upload())
//   {
//    //check for errors with the upload
//    $error = array('error' => $this->upload->display_errors());
//    // $this->load->view('templates/header');
//    // $this->load->view('edit-project-image');
//    // $this->load->view('templates/footer');
//   }
//   else
//   {
//    //upload the new image
//    $upload_data = $this->upload->data();
//    $image_name = $upload_data['Product_Picture'];

//    if($_POST){

//    $data = array(
//     'Product_Name' => $this->input->post('Product_Name'),
//                 'Product_offer' => $this->input->post('Product_offer'),
//                 'Product_short_name' => $this->input->post('Product_short_name'),
//     'Product_Picture'=>$image_name

//    );

//                         //update
//    $this->Text->update_project($data);
//    }

//    redirect(base_url().'slider/Add_Advertisement_banner');

//   }
// }
    // function Url_append_edit_form(){
    //     $ID = $this->input->get_post('ID');

    //     if($this->input->post('userSubmit')){
    //         // echo '<pre>'; print_r($_FILES); exit;

    //         //Check whether user upload picture
    //         if(!empty($_FILES['Product_Picture']['name'])){
    //             $config['upload_path'] = 'uploads/Advertisement/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['Product_Picture']['name'];

    //             //Load upload library and initialize configuration
    //             $this->load->library('upload',$config);
    //             $this->upload->initialize($config);

    //             if($this->upload->do_upload('Product_Picture')){
    //                 $uploadData = $this->upload->data();
    //                 $picture = $uploadData['file_name'];
    //             }else{
    //                 $picture = '';
    //             }
    //         }else{
    //             $picture = '';
    //         }

    //         //Prepare array of user data
    //         $userData = array(
    //             'Product_Name' => $this->input->post('Product_Name'),
    //             'Product_offer' => $this->input->post('Product_offer'),
    //             'Product_short_name' => $this->input->post('Product_short_name'),
    //             'Product_Picture' => $picture
    //         );


    //         //Pass user data to model
    //         $this->Model->updateData('url_append_info',$userData,array('ID'=>$ID));
    //         // $insertUserData = $this->Advertisement_add->insert($userData);
    //         $this->session->set_flashdata('msg','successfully your Banner image uploaded');
    //         redirect('slider/Add_Advertisement_banner');


    //     }
    //     //Form for adding user data
    //     // $this->load->view('views/camera_wrap');

    // }
    // function update_supplier_form(){
    //     $ID = $this->input->get_post('ID');
    //     $banner_name = $this->input->get_post('banner_name');
    //     $category_id = $this->input->get_post('category_id');
    //     $sub_category_id = $this->input->get_post('sub_category_id');

    //         if(!empty($_FILES['banner_Picture']['name']))
    //         {

    //             $config['upload_path'] = 'uploads/banner/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['banner_Picture']['name'];
    //              $this->load->library('upload',$config);
    //              $this->upload->initialize($config);

    //             if (move_uploaded_file($_FILES['banner_Picture']['tmp_name'], $config)) {
    //               echo "File is valid, and was successfully uploaded.\n";
    //               $picture = $file_name;
    //             } else {
    //                echo "Upload failed";
    //                $picture = "";
    //             }
    //         }
    //         else{
    //            $picture =  $_POST['picture'];
    //         }


    //         $update_data = array(
    //             'banner_name'=>$banner_name,
    //             'category_id'=>$category_id,
    //             'sub_category_id'=>$sub_category_id,
    //             'banner_Picture' => $picture
    //         );
    //         // print_array($update_data);
    //         $this->model->updateData('banner',$update_data,array('ID'=>$ID)); 
    //         $this->session->set_flashdata('msg','banner updated successfully.');
    //         redirect('slider/list_banner');

    //   }
    //   function add(){
    //     if($this->input->post('userSubmit')){
    //         // echo '<pre>'; print_r($_FILES); exit;

    //         //Check whether user upload picture
    //         if(!empty($_FILES['Product_Picture']['name'])){
    //             $config['upload_path'] = 'uploads/product/';
    //             $config['allowed_types'] = 'jpg|jpeg|png|gif';
    //             $config['file_name'] = $_FILES['Product_Picture']['name'];

    //             //Load upload library and initialize configuration
    //             $this->load->library('upload',$config);
    //             $this->upload->initialize($config);

    //             if($this->upload->do_upload('Product_Picture')){
    //                 $uploadData = $this->upload->data();
    //                 $picture = $uploadData['file_name'];
    //             }else{
    //                 $picture = '';
    //             }
    //         }else{
    //             $picture = '';
    //         }

    //         //Prepare array of user data
    //         $userData = array(
    //             'Product_Name' => $this->input->post('Product_Name'),
    //             'category_id' => $this->input->post('category_id'),
    //             'sub_category_id' => $this->input->post('sub_category_id'),
    //             'sub_category_name' => $this->input->post('sub_category_name'),
    //             'Short_Description' => $this->input->post('Short_Description'),
    //             'Original_Prices' => $this->input->post('Original_Prices'),
    //             'Prices' => $this->input->post('Prices'),
    //             'Product_Picture' => $picture
    //         );


    //         //Pass user data to model
    //         $insertUserData = $this->wellness_add->insert($userData);
    //         $this->session->set_flashdata('msg','successfully your Product image uploaded');
    //         redirect('Product/add_product');


    //     }
    //     //Form for adding user data
    //     // $this->load->view('views/camera_wrap');

    // }

public function user_tracking_information()
{
   $query1 = $this->db->query('select * from users_tracking order by id  DESC');

// $data['Out_For_Delivery']= $query->result_array();

   $this->load->library('pagination');
   $config=[
    'base_url' => base_url("Slider/user_tracking_information"),
    'per_page' =>10,
    'total_rows' => $query1->num_rows()
];
$config['full_tag_open'] = "<ul class='pagination'>";
$config['full_tag_close'] ="</ul>";
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
$config['next_tag_open'] = "<li>";
$config['next_tagl_close'] = "</li>";
$config['prev_tag_open'] = "<li>";
$config['prev_tagl_close'] = "</li>";
$config['first_tag_open'] = "<li>";
$config['first_tagl_close'] = "</li>";
$config['last_tag_open'] = "<li>";
$config['last_tagl_close'] = "</li>";
//  $config["num_links"] = 10;
if($this->uri->segment(3)){
 $limit=$this->uri->segment(3);  
 $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
 $query = $this->db->query("select * from users_tracking order by id  DESC limit $limit,10");   
}else{
   $limit1=0;
   $limit=10;  

   $query = $this->db->query("select * from users_tracking order by id  DESC limit $limit1,10");
}
$data['user_tracking_info']= $query->result_array();
$this->pagination->initialize($config);
$data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r($data['Out_For_Delivery']);exit();

$this->load->view('containt',$data);
}
public function user_tracking_information_pagination()
{ 
    if($_POST['username']){
       $sql="select * from users_tracking where username='".$_POST['username']."' and date_1 between '" .$_POST['start']. " 00:00:00' and  '" . $_POST['end'] . " 00:00:00'  order by id  desc";
       $data['username']=$_POST['username'];
       $data['start']=$_POST['start'];
       $data['end']=$_POST['end'];
   }else{
      $sql="select * from users_tracking where   date_1 between '" .$_POST['start']. " 00:00:00' and  '" . $_POST['end'] . " 00:00:00'  order by id  desc";
      $data['start']=$_POST['start'];
      $data['end']=$_POST['end'];
  }
  $query1 = $this->db->query($sql);
  $this->load->library('pagination');
  $config=[
    'base_url' => base_url("Slider/user_tracking_information_pagination_call/".$_POST['username']."/".$_POST['start']."/".$_POST['end']),
    'per_page' =>10,
    'total_rows' => $query1->num_rows(),

    'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
    'full_tag_close'=>'</ul>',

    'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
    'cur_tag_close'=>'</a></li>',

    'num_tag_open'=>'<li>',
    'num_tag_close'=>'</li>',

    'first_link'=>'First',
    'first_tag_open'=>'<li>',
    'first_tag_close'=>'</li>',

    'last_link'=>'Last',
    'last_tag_open'=>'<li>',
    'last_tag_close'=>'</li>',

    'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
    'prev_tag_open'=>'<li>',
    'prev_tag_close'=>'</li>',

    'next_link'=>'<span aria-hidden="true">&raquo;</span>',
    'next_tag_open'=>'<li>',
    'next_tag_close'=>'</li>'
];
//  $config["num_links"] = 10;
if($this->uri->segment(6)){
 $limit=$this->uri->segment(6);  
 $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
 $run_data=$sql." limit $limit,10";
 
}else{
   $limit1=0;
   $limit=10;  

   $run_data= $sql." limit $limit1,10";
}
 // echo $run_data;
$query_data = $this->db->query($run_data);   
$data['user_tracking_info']= $query_data->result_array();
$this->pagination->initialize($config);
$data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r( $query_data->result_array());exit();
$this->load->view('containt',$data);
}

public function user_tracking_information_pagination_call()
{ 
    if($this->uri->segment(3)){
       $sql="select * from users_tracking where username='".$this->uri->segment(3)."' and date_1 between '" .$this->uri->segment(4). " 00:00:00' and  '" . $this->uri->segment(5) . " 00:00:00'  order by id  desc";

       $data['username']=$_POST['username'];
       $data['start']=$_POST['start'];
       $data['end']=$_POST['end'];
   }else{
      $sql="select * from users_tracking where   date_1 between '" .$this->uri->segment(4). " 00:00:00' and  '" . $this->uri->segment(5) . " 00:00:00'  order by id  desc";
      $data['start']=$_POST['start'];
      $data['end']=$_POST['end'];
  }
  $query1 = $this->db->query($sql);
  $this->load->library('pagination');
  $config=[
    'base_url' => base_url("Slider/user_tracking_information_pagination_call/".$this->uri->segment(3)."/".$this->uri->segment(4)."/".$this->uri->segment(5)),
    'per_page' =>10,
    'total_rows' => $query1->num_rows(),

    'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
    'full_tag_close'=>'</ul>',

    'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
    'cur_tag_close'=>'</a></li>',

    'num_tag_open'=>'<li>',
    'num_tag_close'=>'</li>',

    'first_link'=>'First',
    'first_tag_open'=>'<li>',
    'first_tag_close'=>'</li>',

    'last_link'=>'Last',
    'last_tag_open'=>'<li>',
    'last_tag_close'=>'</li>',

    'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
    'prev_tag_open'=>'<li>',
    'prev_tag_close'=>'</li>',

    'next_link'=>'<span aria-hidden="true">&raquo;</span>',
    'next_tag_open'=>'<li>',
    'next_tag_close'=>'</li>'
];
//  $config["num_links"] = 10;
if($this->uri->segment(6)){
 $limit=$this->uri->segment(6);  
 $limit1=$limit+10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
 $run_data=$sql." limit $limit,10";
 
}else{
   $limit1=0;
   $limit=10;  

   $run_data= $sql." limit $limit1,10";
}
 // echo $run_data;
$query_data = $this->db->query($run_data);   
$data['user_tracking_info']= $query_data->result_array();
$this->pagination->initialize($config);
$data['main_containt']='user_tracking_info_view';
 // echo"<pre>";print_r($sql);exit();
$this->load->view('containt',$data);
}

public function ddc_wise_report()
{   

   $sql='SELECT SUM(CASE WHEN order_confirmation=1 AND dispatchment_confirmation=0 THEN 1 ELSE 0 END) AS COUNT,SUM(CASE WHEN shipping_confirmation=1 AND order_intransit=0 THEN 1 ELSE 0 END) AS shipping_confirmation,SUM(CASE WHEN dispatchment_confirmation=1 AND shipping_confirmation=0 THEN 1 ELSE 0 END) AS dispatchment_confirmation,username,SUM(CASE WHEN order_intransit=1 AND order_delivered=0 THEN 1 ELSE 0 END) AS order_intransit,SUM(CASE WHEN out_for_delivery=1 THEN 1 ELSE 0 END) AS out_for_delivery,SUM(CASE WHEN order_delivered=1 THEN 1 ELSE 0 END) AS order_delivered,username,full_name,company_address,city_name,state_name,pincode,company_name,employee_id FROM e_paenlist_order_data GROUP BY username';
   $query_data = $this->db->query($sql);   
   $data['ddc_wise_report']= $query_data->result_array();
   $data['main_containt']='ddc_wise_report_view';

   $this->load->view('containt',$data);
}
public function ddc_order_report()
{

    $query1 = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" order by ID  DESC');

    $this->load->library('pagination');
    $config=[
        'base_url' => base_url("Slider/total_epanelist"),
        'per_page' =>10,
        'total_rows' => $query1->num_rows(),

        'full_tag_open'=>'<nav aria-label="Page navigation"><ul class="pagination">',
        'full_tag_close'=>'</ul>',

        'cur_tag_open'=>'<li class=""><a href="#" style="background-color:red;color:white" >',
        'cur_tag_close'=>'</a></li>',

        'num_tag_open'=>'<li>',
        'num_tag_close'=>'</li>',

        'first_link'=>'First',
        'first_tag_open'=>'<li>',
        'first_tag_close'=>'</li>',

        'last_link'=>'Last',
        'last_tag_open'=>'<li>',
        'last_tag_close'=>'</li>',

        'prev_link'=>'<span aria-hidden="true">&laquo;</span>',
        'prev_tag_open'=>'<li>',
        'prev_tag_close'=>'</li>',

        'next_link'=>'<span aria-hidden="true">&raquo;</span>',
        'next_tag_open'=>'<li>',
        'next_tag_close'=>'</li>'
    ];
//  $config["num_links"] = 10;
    if($this->uri->segment(3)){
     $limit=$this->uri->segment(3);  
     $limit1=$limit-10;
    // echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
 }else{
   $limit1=0;
   $limit=10;  
    //   echo "select * from e_paenlist_order_data order by ID  DESC limit $limit1,$limit";
}

$query = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" AND shipping_confirmation="1" AND order_intransit="0" order by ID  DESC');
$data['shipping_confirmation']= $query->result_array();
$query = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" AND dispatchment_confirmation="1" AND shipping_confirmation="0" order by ID  DESC');
$data['dispatchment_confirmation']= $query->result_array();
$query = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" AND out_for_delivery="1"  order by ID  DESC');
$data['out_for_delivery']= $query->result_array();
$query = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" AND order_intransit=1 AND order_delivered=0  order by ID  DESC');
$data['order_intransit']= $query->result_array();
$query = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" AND order_delivered="1"  order by ID  DESC');
$data['order_delivered']= $query->result_array();
$this->pagination->initialize($config);
$data['main_containt']='ddc_order_report_view';
$this->load->view('containt',$data);
}
public function ddc_slip()
{
   $query = $this->db->query('select * from e_paenlist_order_data where employee_id="'.$this->uri->segment(3).'" and order_confirmation=1 and dispatchment_confirmation=1 and shipping_confirmation=0 order by ID  DESC');

   $data['ddc_slip']= $query->result_array();

   $this->load->view('ddc_slip',$data);
}
public function payment_verification()
{   

   $sql="SELECT w.*,sm.p_id AS request
   FROM payment_request AS w
   LEFT JOIN payment_response AS sm ON sm.order_id = w.order_id WHERE w.order_id != '' ORDER BY w.p_id DESC ";
   $query_data = $this->db->query($sql);   
   $data['payment_verification']= $query_data->result_array();
    // echo "<pre>"; print_r($data); exit();

   $data['main_containt']='payment_verification_view';

   $this->load->view('containt',$data);
}
public function fectch_data()
{

}
public function epanelist_information($data){ 
    $url = "https://www.oxiinc.com/api/customers_info_repect_to_emp_id?".http_build_query($data);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

public function payout_status(){
    $data = array('status' => $_POST['status'],'admin_response_date'=> date("Y-m-d H:i:s"));

    if($_POST['status'] == 1){
        $status = '1';
    }elseif ($_POST['status'] == 2) {
        $status = '2';

        $amt_status = '1';
    }elseif($_POST['status'] == 0){
        $status = '0';
    }else{
        $status = '0';
    }

    $updatePayout ="UPDATE payout_statement SET status =".$_POST['status'].", admin_response_date = '". date("Y-m-d H:i:s")."' Where id = ". $_POST['id'];
    if($this->db->query($updatePayout)){
     $updatePayoutAccount ="UPDATE reseller_wallet SET admin_response_status =".$_POST['status'].", response_date = '". date("Y-m-d H:i:s")."', transaction_status=".$_POST['status']." Where payment_id = ". $_POST['id'] . " AND payment_tb = 'payout'";
     if($this->db->query($updatePayoutAccount)){
        $msg = "<p class='alert alert-success'>Successfully ".$status." Payout Request .</p>";
        $ajax_request = array('status' => 'success', 'message' => $msg);
    }else{
        $msg = "<p class='alert alert-danger'>Something Went Wrong Please Try Again Later.</p> ";
        $ajax_request = array('status' => 'error', 'message' => $msg);
    }   
}else{
    $msg = "<p class='alert alert-danger'>Something Went Wrong Please Try Again Later.</p> ";
    $ajax_request = array('status' => 'error', 'message' => $msg);

}
echo json_encode($ajax_request); 
}
    

public function get_packing_material()
{
   $sql = "SELECT A.*,B.product_name AS paking_material FROM reseller_packing_material_request AS A LEFT JOIN packing_material AS B ON B.id = A.product_name WHERE A.bank_deposite_id=".$_POST['id'];
   $query = $this->db->query($sql);
   $bank_deposit_statement = $query->result_array();

   echo json_encode($bank_deposit_statement);
}
function  E_panelist_Dispatchment_Confirmation_New(){
    $ID = $this->input->post('ID');    
    if(!empty($ID)){       
        foreach ($ID as $key => $val) {            
        $dispatchment_confirmation_info = $_POST['dispatchment_confirmation_info'];
        $status['dispatchment_confirmation']='1';
        $status['dispatchment_datetime']= date('Y-m-d H:i:s');
        $status['dispatchment_confirmation_info']= $dispatchment_confirmation_info;
        $Update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$val));

        //Send Mail Notification
        $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $val));        

        $data_info['id']=$data[0]['shipping_employee_id'];
        $gagan=json_decode($this->epanelist_information($data_info),true);

        $from_email = "no-reply@oxiinc.in";
        $to_email = $gagan[0]['primary_email'];
        $subject = 'Thank You For Shopping With as, Oxiinc Group';
        $emailer = 'emailer/tracking_admin.html';
        //Load email library 
        $config = Array(
            'protocol' => 'mail',
            'smtp_host' => 'mail.oxiinc.in',
            'smtp_port' => 25,
            'smtp_user' => 'noreply@oxiinc.com',
            'smtp_pass' => '@@noreply@@',
            'mailtype' => 'html',
            'charset' => 'iso-8859-1'
        );
        $this->load->library('email'); 
        $this->email->initialize($config);
        $this->email->from($from_email, 'No Reply'); 
        $this->email->to($to_email);
        $this->email->subject($subject); 
        $data_new=array();
        $data_new['email'] = $to_email;
        $data_new['messages'] = 'We are Happy to inform that your product has been packed';
        $data_new['Product_invoice'] = $data;
        $message = $this->load->view('new_design_update/common/order_confirmation.php',$data_new,true);
        $this->email->message($message); 
        if($this->email->send()){
            $this->session->set_flashdata('msg','Dispatchment Confirmation Update Successfully ');
            redirect('Slider/E_panelist_List_Of_Dispatchment');
        }else{
            $this->session->set_flashdata('merror','Something Went Wrong.');
            redirect('Slider/E_panelist_List_Of_Dispatchment');
        }
    }

    }   

    
}
function E_panelist_shipping_Confirmation_New(){
    $ID = $_POST['ID'];
    $Shipping_confirmation_info = $_POST['Shipping_confirmation_info'];
    $status['shipping_confirmation']='1';
    $status['shipping_datetime']=date('Y-m-d H:i:s');
    $status['Shipping_confirmation_info']=$Shipping_confirmation_info;
    $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

    $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));

    $data_info['id']=$data[0]['shipping_employee_id'];
    $gagan=json_decode($this->epanelist_information($data_info),true);

    $from_email = "no-reply@oxiinc.in";
    $to_email = $gagan[0]['primary_email'];
    $subject = 'Thank You For Shopping With as, Oxiinc Group';
    $emailer = 'emailer/tracking_admin.html';
    //Load email library 
    $config = Array(
        'protocol' => 'mail',
        'smtp_host' => 'mail.oxiinc.in',
        'smtp_port' => 25,
        'smtp_user' => 'noreply@oxiinc.com',
        'smtp_pass' => '@@noreply@@',
        'mailtype' => 'html',
        'charset' => 'iso-8859-1'
    );
    $this->load->library('email'); 
    $this->email->initialize($config);
    $this->email->from($from_email, 'No Reply'); 
    $this->email->to($to_email);
    $this->email->subject($subject); 
    $data_new=array();
    $data_new['email'] = $to_email;
    $data_new['messages'] = $Shipping_confirmation_info;
    $data_new['Product_invoice'] = $data;
    $message = $this->load->view('new_design_update/common/order_confirmation.php',$data_new,true);
    $this->email->message($message); 
    if($this->email->send()){
        $this->session->set_flashdata('msg','Shipping Confirmation Update Successfully');
        redirect('Slider/E_panelist_List_Of_Shipping');
    }else{
        $this->session->set_flashdata('merror','Something Went Wrong.');
        redirect('Slider/E_panelist_List_Of_Shipping');
    }    
}

    public function E_panelist_In_transit_Confirmation_New(){
        $ID = $_POST['ID'];
        $In_Transit_confirmation_info = $_POST['In_Transit_confirmation_info'];
        $status['order_intransit']='1';
        $status['order_Intransit_datetime']=date('Y-m-d H:i:s');
        $status['In_Transit_confirmation_info']= $In_Transit_confirmation_info;
        $update_id =  $this->Model->updateData('e_paenlist_order_data',$status,array('ID'=>$ID));

        $data = $this->Model->getData('e_paenlist_order_data',array('ID'=> $ID));
        //  echo "<pre>";
        //  print_r($data);

        $data_info['id']=$data[0]['shipping_employee_id'];
        $gagan=json_decode($this->epanelist_information($data_info),true);

        $query = $this->db->query('select * from epanelist_manage_addresses where ID='.$data[0]['address_id']);
        $row_gagan = $query->row(); 

        $from_email = "no-reply@oxiinc.in";
        $to_email = $gagan[0]['primary_email'];
        $subject = 'Thank You For Shopping With as, Oxiinc Group';
        // $emailer = 'emailer/tracking_admin.html';
        //Load email library 
        $config = Array(
            'protocol' => 'mail',
            'smtp_host' => 'mail.oxiinc.in',
            'smtp_port' => 25,
            'smtp_user' => 'noreply@oxiinc.com',
            'smtp_pass' => '@@noreply@@',
            'mailtype' => 'html',
            'charset' => 'iso-8859-1'
        );
        $this->load->library('email'); 
        $this->email->initialize($config);
        $this->email->from($from_email, 'No Reply'); 
        $this->email->to($to_email);
        $this->email->subject($subject); 
        $data_new=array();
        $data_new['email'] = $to_email;
        $data_new['messages'] = $In_Transit_confirmation_info;
        $data_new['Product_invoice'] = $data;
        $message = $this->load->view('new_design_update/common/order_confirmation.php',$data_new,true);
        $this->email->message($message); 
        if($this->email->send()){
            $this->session->set_flashdata('msg','In Transit Confirmation Update Successfully ');
            redirect('Slider/E_panelist_List_Of_Vendor');
        }else{
            $this->session->set_flashdata('merr','Something Went Wrong.');
            redirect('Slider/E_panelist_List_Of_Vendor');
        }   
    }

    /*public function update_aadhar_card(){
        $wellness_query = $this->db->query("SELECT DAC.director_id, DAC.reseller_id, DAC.aadhar_card_photo, DD.d_adhar_card_image, DD.d_id, DD.d_reseller_id FROM director_aadhar_card AS DAC INNER JOIN director_details AS DD ON DD.d_id = DAC.director_id AND DD.d_reseller_id = DAC.reseller_id");
        $wellness_data = $wellness_query->result_array();
        //echo "<pre>";print_r($wellness_data);die();

        foreach ($wellness_data as $key => $value) {

            $data['d_adhar_card_image'] = $value['aadhar_card_photo'];

            $asdf = $this->Model->updateData('director_details', $data, array('d_id'=>$value['director_id'], 'd_reseller_id'=>$value['reseller_id']));

            echo "<pre>";print_r($asdf);//die();
        }
    }*/

}