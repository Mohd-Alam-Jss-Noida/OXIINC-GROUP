<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//header('Access-Control-Allow-Origin: *');

class Reseller_dashboard extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('Model');
        $this->load->model('Text');
        $this->load->model('Files');
        $this->load->model('Cart_model');
        $this->load->model('Add_category_model');
        $this->load->model('Dbs');
        $this->load->helper('common_helper');
        date_default_timezone_set("Asia/Kolkata");

        if(!$this->session->userdata('reseller_logged_in')){
            redirect('seller');
        }
    }

    public function index(){
        $data['oxiinc_reseller'] = $this->Model->getData('reseller',array('id'=>$this->session->userdata('r_id')));
        $data['reseller_skip'] = $this->Model->getData('reseller_skip',array('reseller_id'=>$this->session->userdata('r_id')));
        if($data['oxiinc_reseller'][0]['approval_status'] == 1){
            redirect('Reseller_dashboard/dashboard');
        }
        else{
            $data['oxiinc_reseller_bank'] = $this->Model->getData('reseller_bank_details', array('reseller_id'=>$this->session->userdata('r_id')));
            $data['reseller_company_details'] = $this->Model->getData('reseller_company_details', array('c_reseller_id'=>$this->session->userdata('r_id')));
            $data['director_details'] = $this->Model->getData('director_details', array('d_reseller_id'=>$this->session->userdata('r_id')));
            //echo "<pre>";print_r($data);die();
            $data['main_containt'] = 'reseller_user/index';
            $this->load->view('reseller_user/containt', $data);
        }
    }

    public function dashboard(){
        $total_order_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id')));
        $total_order_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id')));
        $data['total_order'] = $total_order_paenlist + $total_order_guest;

        $order_confirm_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id'), 'order_confirmation'=>'1', 'dispatchment_confirmation'=>'0'));
        $order_confirm_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id'), 'order_confirmation'=>'1', 'dispatchment_confirmation'=>'0'));
        $data['order_confirm'] = $order_confirm_paenlist + $order_confirm_guest;

        $packed_order_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id'), 'dispatchment_confirmation'=>'1', 'shipping_confirmation'=>'0'));
        $packed_order_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id'), 'dispatchment_confirmation'=>'1', 'shipping_confirmation'=>'0'));
        $data['order_packed'] = $packed_order_paenlist + $packed_order_guest;

        $order_shipped_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id'), 'shipping_confirmation'=>'1', 'order_intransit'=>'0'));
        $order_shipped_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id'), 'shipping_confirmation'=>'1', 'order_intransit'=>'0'));
        $data['order_shipped'] = $order_shipped_paenlist + $order_shipped_guest;

        $order_intransit_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id'), 'order_intransit'=>'1', 'out_for_delivery'=>'0'));
        $order_intransit_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id'), 'order_intransit'=>'1', 'out_for_delivery'=>'0'));
        $data['order_intransit'] = $order_intransit_paenlist + $order_intransit_guest;

        $out_for_delivery_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id'), 'out_for_delivery'=>'1', 'order_delivered'=>'0'));
        $out_for_delivery_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id'), 'out_for_delivery'=>'1', 'order_delivered'=>'0'));
        $data['order_out_for_delivery'] = $out_for_delivery_paenlist + $out_for_delivery_guest;

        $order_delivered_paenlist = $this->Model->CountWhereRecord('e_paenlist_order_data', array('reseller_id' => $this->session->userdata('r_id'), 'order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1'));
        $order_delivered_guest = $this->Model->CountWhereRecord('order_data', array('reseller_id' => $this->session->userdata('r_id'), 'order_confirmation' => '1','dispatchment_confirmation'=>'1','order_intransit'=>'1','out_for_delivery'=>'1','order_delivered'=>'1'));
        $data['order_delivered'] = $order_delivered_paenlist + $order_delivered_guest;

        $cancle_query1 = $this->db->query("SELECT COUNT(ID) AS count FROM  e_paenlist_order_data WHERE reseller_id = ".$this->session->userdata('r_id')." AND order_confirmation = 0");
        $cancle_paenlist = $cancle_query1->result_array();
        $cancle_query2 = $this->db->query("SELECT COUNT(ID) AS count FROM  order_data WHERE reseller_id = ".$this->session->userdata('r_id')." AND order_confirmation = 0");
        $cancle_order_data = $cancle_query2->result_array();
        $data['total_cancle_order'] = $cancle_paenlist[0]['count'] + $cancle_order_data[0]['count'];

        //Product list count
        $product_approval_pending = $this->db->query("SELECT COUNT(ID) as count FROM  wellness WHERE reseller_id = ".$this->session->userdata('r_id')." AND product_approval_status = 0");
        $data['product_approval']['pending'] = $product_approval_pending->result_array();
        $data['pending_product'] = $data['product_approval']['pending'][0]['count'];

        $product_approval_approved = $this->db->query("SELECT COUNT(ID) as count FROM  wellness WHERE reseller_id = ".$this->session->userdata('r_id')." AND product_approval_status = 1");
        $data['product_approval']['approved'] = $product_approval_approved->result_array();
        $data['approved_product'] = $data['product_approval']['approved'][0]['count'];

        $product_approval_rejected = $this->db->query("SELECT COUNT(ID) as count FROM  wellness WHERE reseller_id = ".$this->session->userdata('r_id')." AND product_approval_status = 2");
        $data['product_approval']['rejected'] = $product_approval_rejected->result_array();
        $data['rejected_product'] = $data['product_approval']['rejected'][0]['count'];
        
        $product_stock_status_query = $this->db->query("SELECT COUNT(ID) as count FROM  wellness WHERE reseller_id = ".$this->session->userdata('r_id')." AND stock_status = 0");
        $product_stock_status = $product_stock_status_query->result_array();
        $data['out_of_stock_product'] = $product_stock_status[0]['count'];

        //Packing Material list count
        $packing_material_query1 = $this->db->query("SELECT COUNT(reseller_id) AS pending_count FROM  packing_material_bank_deposite_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 0");
        $pending_array = $packing_material_query1->result_array();
        $data['packing_material_pending'] = $pending_array[0]['pending_count'];

        $packing_material_query2 = $this->db->query("SELECT COUNT(reseller_id) AS approved_count FROM  packing_material_bank_deposite_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 1");
        $approved_array = $packing_material_query2->result_array();
        $data['packing_material_approved'] = $approved_array[0]['approved_count'];

        $packing_material_query3 = $this->db->query("SELECT COUNT(reseller_id) AS rejected_count FROM  packing_material_bank_deposite_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 2");
        $rejected_array = $packing_material_query3->result_array();
        $data['packing_material_rejected'] = $rejected_array[0]['rejected_count'];

        
        $sql_material="SELECT reseller_id FROM `reseller_packing_material_request` WHERE reseller_id='".$this->session->userdata('r_id')."' AND STATUS='1'";
        $order_packaging_material = $this->db->query($sql_material);
        $packaging_order_comfirm= $order_packaging_material->result_array();
        if($packaging_order_comfirm){
            $data['packaging_recieved']='1';
        }else{
            $data['packaging_recieved']='0';
        }

        $pending_payout_query = $this->db->query("SELECT SUM(amount_after_tax) AS pending_amount FROM payout_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 0");
        $data['pending_payout'] = $pending_payout_query->result_array();

        $approved_payout_query = $this->db->query("SELECT SUM(amount_after_tax) AS approved_amount FROM payout_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 1");
        $data['approved_payout'] = $approved_payout_query->result_array();

        $rejected_payout_query = $this->db->query("SELECT SUM(amount_after_tax) AS rejected_amount FROM payout_statement WHERE reseller_id = ".$this->session->userdata('r_id')." AND status = 2");
        $data['rejected_payout'] = $rejected_payout_query->result_array();

        //echo "<pre>";print_r($data);die();
        $data['main_containt'] = 'reseller_user/dashboard';
        $this->load->view('reseller_user/containt', $data);
    }

    public function total_order(){
        $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id='.$this->session->userdata('r_id').' order by ID  DESC');

       $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='.$this->session->userdata('r_id').' order by ID DESC');

        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
            $items[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $items_normal[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_confirm(){
        $query_paenlist = $this->db->query("SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE  reseller_id='".$this->session->userdata('r_id')."' and order_confirmation=1 and dispatchment_confirmation = 0 order by ID  DESC ");

        $query_normal = $this->db->query("SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='".$this->session->userdata('r_id')."' and order_confirmation = 1 and dispatchment_confirmation = 0 order by ID  DESC ");

        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
            $items[] = array(       
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $items_normal[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_packed(){
        $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id='.$this->session->userdata('r_id').' and dispatchment_confirmation = 1 and shipping_confirmation = 0 order by ID  DESC');

        $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='.$this->session->userdata('r_id').' and dispatchment_confirmation = 1 and shipping_confirmation = 0 order by ID  DESC');
        
        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value){
            $items[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $items_normal[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_shipped(){
       $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id='.$this->session->userdata('r_id').' and shipping_confirmation = 1 and order_intransit = 0 order by ID  DESC');

       $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='.$this->session->userdata('r_id').' and shipping_confirmation = 1 and order_intransit = 0 order by ID  DESC');
       
        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
          $items[] = array(        
            'order_id' => $value['ID'],
            'reseller_id'=>$value['reseller_id'],
            'product_id'=>$value['product_id'],
            'transaction_id' => $value['txnid'],
            'customer_name' => $value['shipping_Name'],
            'mobile' => $value['shipping_Phone_number'],
            'address' => $value['shipping_address_in'],
            'city' => $value['shipping_City'],
            'state' => $value['shipping_state'],
            'district' => $value['shipping_City'],
            'pincode' => $value['shipping_Pincode'],
            'order_date' => $value['order_date_time'],
            'Product_Picture'=>$value['Product_Picture'],
            'reseller_sold_price'=>$value['reseller_sold_price'],
            'Shipping_Charges'=>$value['Shipping_Charges'],
            'datatime'=>$value['datatime'],
            'Product_Name'=>$value['Product_Name'],
            'product_qty'=>$value['product_qty'],
            'size'=>$value['size'],
            'user_role' => '1',
            'user_type' => 'e-panelist',
            'order_confirmation'=>$value['order_confirmation'],
            'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
            'shipping_confirmation'=>$value['shipping_confirmation'],
            'order_intransit'=>$value['order_intransit'],
            'out_for_delivery'=>$value['out_for_delivery'],
            'order_delivered'=>$value['order_delivered'],
            'order_delivered_datetime'=>$value['order_delivered_datetime']
        );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
          $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
          $items_normal[] = array(        
            'order_id' => $value['ID'],
            'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
            'transaction_id' => $value['txnid'],
            'customer_name' => $address_id[0]['Name'],
            'mobile' => $address_id[0]['Phone_number'],
            'address' => $address_id[0]['address'],
            'city' => $address_id[0]['City'],
            'state' => $value['state'],
            'district' => $address_id[0]['City'],
            'pincode' => $address_id[0]['Pincode'],
            'order_date' => $value['order_year_month_data_time'],
            'Product_Picture'=>$value['Product_Picture'],
            'reseller_sold_price'=>$value['reseller_sold_price'],
            'Shipping_Charges'=>$value['Shipping_Charges'],
            'datatime'=>$value['datatime'],
            'Product_Name'=>$value['Product_Name'],
            'product_qty'=>$value['product_qty'],
            'size'=>$value['size'],
            'user_role' => '0',
            'user_type' => 'normal',
            'order_confirmation'=>$value['order_confirmation'],
            'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
            'shipping_confirmation'=>$value['shipping_confirmation'],
            'order_intransit'=>$value['order_intransit'],
            'out_for_delivery'=>$value['out_for_delivery'],
            'order_delivered'=>$value['order_delivered'],
            'order_delivered_datetime'=>$value['order_delivered_datetime'],
            'contact_number'=>$value['contact_number']
        );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_intransit(){
        $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id='.$this->session->userdata('r_id').' and order_intransit = 1 and out_for_delivery = 0 order by ID  DESC');

        $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='.$this->session->userdata('r_id').' and order_intransit = 1 and out_for_delivery = 0 order by ID  DESC');
        
        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
            $items[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $items_normal[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_out_for_delivery(){
        $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id='.$this->session->userdata('r_id').' and order_delivered=0 and out_for_delivery=1 order by ID  DESC');

        $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='.$this->session->userdata('r_id').' and order_delivered=0 and out_for_delivery=1 order by ID  DESC');

        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
            $items[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $items_normal[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_delivered(){
        $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id='.$this->session->userdata('r_id').' and order_delivered=1 and out_for_delivery=1 order by ID  DESC');

        $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id='.$this->session->userdata('r_id').' and order_delivered=1 and out_for_delivery=1 order by ID  DESC');
        
        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
            $items[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $items_normal[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $total_order_data = array_merge((array)$items_normal,(array)$items);
        $data['order_data'] = $total_order_data;
        $data['main_containt'] = 'reseller_user/total_order_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_view(){
        $query_paenlist = $this->db->query('SELECT ID, reseller_id, product_id, txnid, shipping_Name, shipping_Phone_number, shipping_address_in, shipping_City, shipping_state, shipping_Pincode, order_date_time, Product_Picture, reseller_sold_price, Shipping_Charges, Product_Name, Original_Prices, Prices, gst_price, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime FROM e_paenlist_order_data WHERE reseller_id ='.$this->session->userdata('r_id').' AND ID ='.$this->uri->segment(3));

        $query_normal = $this->db->query('SELECT ID, reseller_id, product_id, txnid, order_year_month_data_time, Product_Picture, reseller_sold_price, Shipping_Charges, address_id, Product_Name, Original_Prices, Prices, gst_price, product_qty, size, order_confirmation, dispatchment_confirmation, shipping_confirmation, order_intransit, out_for_delivery, order_delivered, order_delivered_datetime, datatime, contact_number FROM order_data WHERE reseller_id ='.$this->session->userdata('r_id').' AND ID ='.$this->uri->segment(3));

        $paenlist_data_array = $query_paenlist->result_array();
        foreach ($paenlist_data_array as $key => $value) {
            $paenlist_data[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $value['shipping_Name'],
                'mobile' => $value['shipping_Phone_number'],
                'address' => $value['shipping_address_in'],
                'city' => $value['shipping_City'],
                'state' => $value['shipping_state'],
                'district' => $value['shipping_City'],
                'pincode' => $value['shipping_Pincode'],
                'order_date' => $value['order_date_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'Original_Prices'=>$value['Original_Prices'],
                'Prices'=>$value['Prices'],
                'gst_price'=>$value['gst_price'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '1',
                'user_type' => 'e-panelist',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime']
            );
        }
        $normal_data_array = $query_normal->result_array();
        foreach ($normal_data_array as $key => $value) {
            $address_id = $this->Model->getData('manage_addresses',array('ID'=>$value['address_id']));
            $normal_data[] = array(        
                'order_id' => $value['ID'],
                'reseller_id'=>$value['reseller_id'],
                'product_id'=>$value['product_id'],
                'transaction_id' => $value['txnid'],
                'customer_name' => $address_id[0]['Name'],
                'mobile' => $address_id[0]['Phone_number'],
                'address' => $address_id[0]['address'],
                'city' => $address_id[0]['City'],
                'state' => $value['state'],
                'district' => $address_id[0]['City'],
                'pincode' => $address_id[0]['Pincode'],
                'order_date' => $value['order_year_month_data_time'],
                'Product_Picture'=>$value['Product_Picture'],
                'reseller_sold_price'=>$value['reseller_sold_price'],
                'Shipping_Charges'=>$value['Shipping_Charges'],
                'datatime'=>$value['datatime'],
                'Product_Name'=>$value['Product_Name'],
                'Original_Prices'=>$value['Original_Prices'],
                'Prices'=>$value['Prices'],
                'gst_price'=>$value['gst_price'],
                'product_qty'=>$value['product_qty'],
                'size'=>$value['size'],
                'user_role' => '0',
                'user_type' => 'normal',
                'order_confirmation'=>$value['order_confirmation'],
                'dispatchment_confirmation'=>$value['dispatchment_confirmation'],
                'shipping_confirmation'=>$value['shipping_confirmation'],
                'order_intransit'=>$value['order_intransit'],
                'out_for_delivery'=>$value['out_for_delivery'],
                'order_delivered'=>$value['order_delivered'],
                'order_delivered_datetime'=>$value['order_delivered_datetime'],
                'contact_number'=>$value['contact_number']
            );
        }
        $data['order_view_details'] = array_merge((array)$paenlist_data, (array)$normal_data);
        $data['main_containt'] = 'reseller_user/order_view';
        $this->load->view('reseller_user/containt', $data);
    }

    public function order_packed_confirmation(){
        //echo "<pre>";print_r($_POST);//die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['dispatchment_confirmation'] = ($_POST['update_value'] == 1) ? 0 : 1;
            $postdata['dispatchment_confirmation_info'] = $_POST['order_remark'];
            if ($_POST['user_type'] == 'e-panelist') {
                $update_id = $this->Model->updateData('e_paenlist_order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            else{
                $update_id = $this->Model->updateData('order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            echo (isset($update_id) && !empty($update_id)) ? $update_id : 'error_1';
        }
    }

    public function order_shipping_confirmation(){
        //echo "<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['shipping_confirmation'] = ($_POST['update_value'] == 1) ? 0 : 1;
            $postdata['Shipping_confirmation_info'] = $_POST['order_remark'];
            if ($_POST['user_type'] == 'e-panelist') {
                $update_id = $this->Model->updateData('e_paenlist_order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            else{
                $update_id = $this->Model->updateData('order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            echo (isset($update_id) && !empty($update_id)) ? $update_id : 'error_1';
        }
    }

    public function order_intransit_confirmation(){
        //echo "<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['order_intransit'] = ($_POST['update_value'] == 1) ? 0 : 1;
            $postdata['In_Transit_confirmation_info'] = $_POST['order_remark'];
            if ($_POST['user_type'] == 'e-panelist') {
                $update_id = $this->Model->updateData('e_paenlist_order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            else{
                $update_id = $this->Model->updateData('order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            echo (isset($update_id) && !empty($update_id)) ? $update_id : 'error_1';
        }
    }

    public function order_delivery_confirmation(){
        //echo "<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['out_for_delivery'] = ($_POST['update_value'] == 1) ? 0 : 1;
            $postdata['Out_For_Delivery_confirmation_info'] = $_POST['order_remark'];
            if ($_POST['user_type'] == 'e-panelist') {
                $update_id = $this->Model->updateData('e_paenlist_order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            else{
                $update_id = $this->Model->updateData('order_data', $postdata, array('ID'=>$_POST['order_id']));
            }
            echo (isset($update_id) && !empty($update_id)) ? $update_id : 'error_1';
        }
    }

    public function order_delivery_success(){
        //echo "<pre>";print_r($_POST);die();
        if(isset($_POST['submit']) && !empty($_POST['submit'])){
            $postdata['order_delivered'] = ($_POST['update_value'] == 1) ? 0 : 1;
            $postdata['Delivered_confirmation_info'] = $_POST['order_remark'];
            $postdata['order_delivered_datetime'] = date('Y-m-d H:i:s');

            $check_query = $this->db->query("SELECT COUNT(id) AS count_id FROM seller_wallet WHERE reseller_id = ".$this->session->userdata('r_id')." AND order_id = ".$_POST['order_id']);
            $seller_count = $check_query->result_array();
            //echo "<pre>";print_r($seller_count);//die();
            if ($seller_count[0]['count_id'] == 0){
                if($_POST['user_type'] == 'e-panelist'){
                    $update_id = $this->Model->updateData('e_paenlist_order_data', $postdata, array('ID'=>$_POST['order_id']));
                    $order_details = $this->Model->getData('e_paenlist_order_data', array('ID'=>$_POST['order_id']));
                    $order_type = 1;
                }
                else{
                    $update_id = $this->Model->updateData('order_data', $postdata, array('ID'=>$_POST['order_id']));
                    $order_details = $this->Model->getData('order_data', array('ID'=>$_POST['order_id']));
                    $order_type = 0;
                }
                if($update_id && $order_details){

                    $gst_query = $this->db->query("SELECT GST_Persentage FROM wellness WHERE reseller_id = ".$this->session->userdata('r_id')." AND ID = ".$order_details[0]['product_id']);
                    $gst = $gst_query->result_array();

                    $total_sold_price = $order_details[0]['reseller_sold_price'];
                    $gst_persentage = $gst[0]['GST_Persentage'];
                    $gst_price = ($total_sold_price * $gst_persentage) / 100;
                    $shipping_charges = $order_details[0]['Shipping_Charges'];

                    $reseller_credit = $total_sold_price + $gst_price + $shipping_charges;

                    $oxiinc_credit = $order_details[0]['markup_price'];

                    $seller_query = $this->db->query("SELECT reseller_closing_amount AS RCA FROM seller_wallet WHERE reseller_id = '".$order_details[0]['reseller_id']."' ORDER BY id DESC LIMIT 1");
                    $seller_closing = $seller_query->result_array();
                    $reseller_closing_amount = $seller_closing[0]['RCA'] + $reseller_credit;

                    $oxiinc_query = $this->db->query("SELECT oxiinc_closing_amount AS OCA FROM oxiinc_wallet WHERE reseller_id = '".$order_details[0]['reseller_id']."' ORDER BY id DESC LIMIT 1");
                    $oxiinc_closing = $oxiinc_query->result_array();
                    $oxiinc_closing_amount = $oxiinc_closing[0]['OCA'] + $oxiinc_credit;

                    $seller_data = array(
                        'reseller_id' => $order_details[0]['reseller_id'],
                        'transaction_id' => $order_details[0]['txnid'],
                        'order_id' => $order_details[0]['ID'],
                        'order_type' => $order_type,
                        'product_id' => $order_details[0]['product_id'],
                        'total_sold_price' => $total_sold_price,
                        'gst_persentage' => $gst_persentage,
                        'gst_price' => $gst_price,
                        'shipping_charges' => $shipping_charges,
                        'reseller_credit_amount' => $reseller_credit,
                        'reseller_debit_amount' => 0,
                        'reseller_closing_amount' => $reseller_closing_amount
                    );

                    $oxiinc_data = array(
                        'reseller_id' => $order_details[0]['reseller_id'],
                        'transaction_id' => $order_details[0]['txnid'],
                        'order_id' => $order_details[0]['ID'],
                        'order_type' => $order_type,
                        'product_id' => $order_details[0]['product_id'],
                        'oxiinc_credit_amount' => $oxiinc_credit,
                        'oxiinc_debit_amount' => 0,
                        'oxiinc_closing_amount' => $oxiinc_closing_amount
                    );
                    //echo "<pre>";print_r($seller_data);//die();
                    //echo "<pre>";print_r($oxiinc_data);die();

                    $seller_wallet_id = $this->Model->insertData('seller_wallet', $this->security->xss_clean($seller_data));
                    $oxiinc_wallet_id = $this->Model->insertData('oxiinc_wallet', $this->security->xss_clean($oxiinc_data));

                    echo (isset($update_id) && !empty($update_id)) ? $update_id : 'error_1';
                }
                else{
                    echo 'error_2';
                }
            }
            else{
                echo 'error_3';
            }
        }
    }

    public function order_invoice(){
        $order_id = $this->uri->segment(3);
        $order_type = $this->uri->segment(4);
        if ($order_type == 1){
            $data['Product_invoice'] = $this->Model->getData('e_paenlist_order_data', array('ID'=>$order_id, 'reseller_id'=>$this->session->userdata('r_id')));
            $data['reseller_company_data'] = $this->Model->getData('reseller_company_details', array('c_reseller_id'=>$this->session->userdata('r_id')));
            $reseller_query = $this->db->query("SELECT signature_upload FROM reseller WHERE id = ".$this->session->userdata('r_id')." LIMIT 1");
            $data['reseller_data'] = $reseller_query->result_array();
            //echo "<pre>";print_r($data); exit;
            $this->load->view('oxiinc_reseller/order_invoice_paenlist', $data);
        }elseif ($order_type == 0){
            $data['Product_invoice'] = $this->Model->getData('order_data', array('ID'=>$order_id,'reseller_id'=>$this->session->userdata('r_id')));
            if ($data['Product_invoice']){
                $manage_addresses = $this->Model->getData('manage_addresses', array('ID'=>$data['Product_invoice'][0]['address_id']));
                $data['manage_addresses'] = $manage_addresses[0];
                $reseller_query = $this->db->query("SELECT signature_upload FROM reseller WHERE id = ".$this->session->userdata('r_id')." LIMIT 1");
                $reseller_data = $reseller_query->result_array();
                if ($reseller_data) {
                    $data['reseller_data'] = $reseller_data[0];
                }else{
                    $data['reseller_data'] = '';
                }
                
                $reseller_company_data = $this->Model->getData('reseller_company_details', array('c_reseller_id'=>$this->session->userdata('r_id')));

                if ($reseller_company_data) {
                    $data['reseller_company_data'] = $reseller_company_data[0];
                }else{
                    $data['reseller_company_data'] = '';
                }
                // echo "<pre>";print_r($data); exit; 
                $this->load->view('oxiinc_reseller/order_invoice_normal', $data);
            }
            else{
                redirect();
            }
        }
        else{
            redirect('seller');
        }
    }

    public function reseller_order_invoice(){
        /*if($this->session->userdata('r_email') != TEST_USER){
            echo "<h2>Work is Progress Please Wait Some time.</h2>";die();
        }*/
        $order_id = $this->uri->segment(3);
        $order_type = $this->uri->segment(4);

        $data['reseller_company_data'] = $this->Model->getData('reseller_company_details', array('c_reseller_id'=>$this->session->userdata('r_id')));
        $reseller_query = $this->db->query("SELECT signature_upload FROM reseller WHERE id = ".$this->session->userdata('r_id')." LIMIT 1");
        $signature = $reseller_query->result_array();
        $data['reseller_signature'] = (isset($signature[0]['signature_upload']) && !empty($signature[0]['signature_upload']) && file_exists('reseller_files/reseller_documents/'.$signature[0]['signature_upload'])) ? base_url('reseller_files/reseller_documents/'.$signature[0]['signature_upload']) : '';

        if ($order_type == 1){
            $data['Product_invoice'] = $this->Model->getData('e_paenlist_order_data', array('ID'=>$order_id, 'reseller_id'=>$this->session->userdata('r_id')));
            $data['Product'] = $this->Model->getData('wellness', array('ID'=>$data['Product_invoice'][0]['product_id']));
            $this->load->view('reseller_user/order_invoice_paenlist', $data);
        } elseif ($order_type == 0){
            $data['Product_invoice'] = $this->Model->getData('order_data', array('ID'=>$order_id, 'reseller_id'=>$this->session->userdata('r_id')));
            $data['Product'] = $this->Model->getData('wellness', array('ID'=>$data['Product_invoice'][0]['product_id']));
            $data['manage_addresses'] = $this->Model->getData('manage_addresses', array('ID'=>$data['Product_invoice'][0]['address_id']));
            $this->load->view('reseller_user/order_invoice_normal', $data);
        }
        else{
            redirect('seller');
        }
    }

    public function order_cancellation_request(){
        $ID = $this->input->post('ID');
        $user_type = $this->input->post('cancel_user_type');
        if ($user_type == 1){
            $Order_details = $this->Model->getData('e_paenlist_order_data', array('ID'=>$ID, 'order_confirmation'=>'1'));
            $data['user_name'] = $Order_details[0]['shipping_Name'];
            $data['email_id'] = $Order_details[0]['email_id'];
            $data['contact_number'] = $Order_details[0]['shipping_Phone_number'];
            $data['customer_id'] = $Order_details[0]['user_id'];
        }
        else{
            $Order_details = $this->Model->getData('order_data', array('ID'=>$ID, 'order_confirmation'=>'1'));
            $data['user_name'] = $Order_details[0]['user_name'];
            $data['email_id'] = $Order_details[0]['email_id'];
            $data['contact_number'] = $Order_details[0]['contact_number'];
            $data['customer_id'] = $Order_details[0]['customer_id'];
        }
        //echo "<pre>";print_r($Order_details);die();
        $data['reason_info'] = $this->input->post('reason_info');
        $data['Cancellation_info'] = $this->input->post('Cancellation_info');
        $data['can_Payment_method'] = $Order_details[0]['payment_method'];
        $data['ordre_id'] = $Order_details[0]['ID'];
        $data['product_id'] = $Order_details[0]['product_id'];
        $data['Product_Name'] = $Order_details[0]['Product_Name'];
        $data['Product_Picture'] = $Order_details[0]['Product_Picture'];
        $data['Original_Prices'] = $Order_details[0]['Original_Prices'];
        $data['Prices'] = $Order_details[0]['Prices'];
        $data['gst_price'] = $Order_details[0]['gst_price'];
        $data['total_gst'] = $Order_details[0]['total_gst'];
        $data['product_qty'] = $Order_details[0]['product_qty'];
        $data['txnid'] = $Order_details[0]['txnid'];
        $data['total_amount'] = $Order_details[0]['total_amount'];
        $data['after_discounted_amount'] = $Order_details[0]['after_discounted_amount'];
        $data['payment_method'] = $Order_details[0]['payment_method'];
        $data['address_id'] = $Order_details[0]['address_id'];
        $data['order_date_time'] = $Order_details[0]['order_date_time'];
        $data['cancel_month']=  date('m');
        $data['cancel_year']= date('Y');
        $data['cancel_day']= date('d');
        $data['cancel_year_month']= date('Y-m');
        $data['rcancel_year_month_data']=date('Y-m-d');
        $data['cancel_year_month_data_time']= date('Y-m-d H:i:s');
        //echo "<pre>";print_r($data);die();

        $wellness_data = $this->Model->getData('wellness', array('ID'=>$Order_details[0]['product_id']));
        $stock_data['stock_status'] = $wellness_data[0]['stock_status'] + $Order_details[0]['product_qty'];
        $stock_update_id = $this->Model->updateData('wellness', $stock_data, array('ID'=>$Order_details[0]['product_id']));
        if(empty($stock_update_id)){
            $ajax_request = array('status' => 'error', 'message' => 'Wellness Stock Status Updated Failed?. Please try Again.');
            echo json_encode($ajax_request);die();
        }

        $product_size = $this->Model->getData('size_manage', array('p_id'=>$Order_details[0]['product_id'], 'size'=>$Order_details[0]['size']));
        $product_size_stock['stock'] = $product_size[0]['stock'] + $Order_details[0]['product_qty'];
        $size_update_id = $this->Model->updateData('size_manage', $product_size_stock, array('id'=>$product_size[0]['id']));
        if(empty($size_update_id)){
            $ajax_request = array('status' => 'error', 'message' => 'Product Size Stock Status Updated Failed?. Please try Again.');
            echo json_encode($ajax_request);die();
        }
        
        if ($user_type == 1){
            $status['order_confirmation'] = 0;
            $order_update_id = $this->Model->updateData('e_paenlist_order_data', $status, array('ID'=>$ID));
        }
        else{
            $status['order_confirmation'] = 0;
            $order_update_id = $this->Model->updateData('order_data', $status, array('ID'=>$ID));
        }

        if(empty($order_update_id)){
            $ajax_request = array('status' => 'error', 'message' => 'Product Order Confirmation Updated Failed?. Please try Again.');
            echo json_encode($ajax_request);die();
        }

        $cancel_id = $this->Model->insertData('cancellation_request', $data);
        if(empty($cancel_id)){
            $ajax_request = array('status' => 'error', 'message' => 'Order Cancelled Failed.');
            echo json_encode($ajax_request);die();
        }
        else{
            $ajax_request = array('status' => 'success', 'message' => 'Order Successfully Cancelled Thank You.');
            echo json_encode($ajax_request);die();
        }
    }

    public function company_details(){
        //echo "<pre>";print_r($_POST);//die();
        //echo "<pre>";print_r($_FILES);//die();

        if(!empty($_POST['c_email'])){
            $c_email = $this->db->query("SELECT c_id FROM reseller_company_details WHERE c_email='".$_POST['c_email']."' ");
            $data_c_email = $c_email->result_array();
        }

        if(!empty($_POST['c_gst_number'])){
           $c_gst_number = $this->db->query("SELECT c_id FROM reseller_company_details WHERE c_gst_number='".$_POST['c_gst_number']."' ");
           $data_c_gst_number = $c_gst_number->result_array();
        }

        if(!empty($_POST['c_pan_number'])){
           $c_pan_number = $this->db->query("SELECT c_id FROM reseller_company_details WHERE c_pan_number='".$_POST['c_pan_number']."' ");
           $data_c_pan_number = $c_pan_number->result_array();
        }

        if(!empty($_POST['c_mobile_number'])){
            $c_mobile_number = $this->db->query("SELECT c_id FROM reseller_company_details WHERE c_mobile_number='".$_POST['c_mobile_number']."' ");
            $data_c_mobile_number = $c_mobile_number->result_array();
        }

        if(!empty($_POST['c_r_number'])){
            $c_r_number = $this->db->query("SELECT c_id FROM reseller_company_details WHERE c_r_number='".$_POST['c_r_number']."' ");
            $data_c_r_number = $c_r_number->result_array();
        }

        if (!empty($data_c_email)) {
            $ajax_request = array('status' => 'error', 'message' => 'Email id already exit.');
        } else if (!empty($data_c_r_number)) {
            $ajax_request = array('status' => 'error', 'message' => 'Company registration number already exit.');
        } else if (!empty($data_c_gst_number)) {
            $ajax_request = array('status' => 'error', 'message' => 'GST number already exit.');
        } else if (!empty($data_c_pan_number)) {
            $ajax_request = array('status' => 'error', 'message' => 'Pan card already exit.');
        } else if (!empty($data_c_mobile_number)) {
            $ajax_request = array('status' => 'error', 'message' => 'Mobile number already exit.');
        } else{
            $postdata = $_POST;
            $postdata['c_reseller_id'] = $this->session->userdata('r_id');

            $uploaddir = 'reseller_files/reseller_documents/';
            if(!empty($_FILES['c_cin_number_img'])){
                $ext_1 = pathinfo($_FILES['c_cin_number_img']['name'], PATHINFO_EXTENSION);
                $oxiinc_1 = rand(). '.' .$ext_1;
                $upload_file_1 = $uploaddir . $oxiinc_1;
                if (move_uploaded_file($_FILES['c_cin_number_img']['tmp_name'], $upload_file_1)) {
                    $postdata['c_cin_number_img'] = $oxiinc_1;
                }
            }
            else{
                $postdata['c_cin_number_img'] = "";
            }

            if(!empty($_FILES['c_r_number_img'])){
                $ext_2 = pathinfo($_FILES['c_r_number_img']['name'], PATHINFO_EXTENSION);
                $oxiinc_2 = rand(). '.' .$ext_2;
                $upload_file_2 = $uploaddir . $oxiinc_2;
                if (move_uploaded_file($_FILES['c_r_number_img']['tmp_name'], $upload_file_2)) {
                    $postdata['c_r_number_img'] = $oxiinc_2;
                }
            }
            else{
                $postdata['c_r_number_img'] = "";
            }

            if(!empty($_FILES['c_pan_number_img'])){
                $ext_3 = pathinfo($_FILES['c_pan_number_img']['name'], PATHINFO_EXTENSION);
                $oxiinc_3 = rand(). '.' .$ext_3;
                $upload_file_3 = $uploaddir . $oxiinc_3;
                if (move_uploaded_file($_FILES['c_pan_number_img']['tmp_name'], $upload_file_3)) {
                    $postdata['c_pan_number_img'] = $oxiinc_3;
                }
            }
            else{
                $postdata['c_pan_number_img'] = "";
            }

            if(!empty($_FILES['c_gst_img'])){
                $ext_4 = pathinfo($_FILES['c_gst_img']['name'], PATHINFO_EXTENSION);
                $oxiinc_4 = rand(). '.' .$ext_4;
                $upload_file_4 = $uploaddir . $oxiinc_4;
                if (move_uploaded_file($_FILES['c_gst_img']['tmp_name'], $upload_file_4)) {
                    $postdata['c_gst_img'] = $oxiinc_4;
                }
            }
            else{
                $postdata['c_gst_img'] = "";
            }
            //echo "<pre>";print_r($postdata);die();
            $this->Model->insertData('reseller_company_details', $this->security->xss_clean($postdata));
            $ajax_request = array('status' => 'success', 'message' => 'Company Details Successfully Uploaded.');
        }
        echo json_encode($ajax_request);
    }

    public function company_detail(){
        $data['company_data'] = $this->Model->getData('reseller_company_details', array('c_reseller_id'=>$this->session->userdata('r_id')));
        //echo "<pre>";print_r($data);die();
        $data['main_containt'] = 'reseller_user/company_detail';
        $this->load->view('reseller_user/containt', $data);
    }

    public function company_details_update(){
        //echo "<pre>";print_r($_POST);die();
        $upload_dir = 'reseller_files/reseller_documents/';
        if(!empty($_FILES['c_pan_number_img']['name'])){
            $ext = pathinfo($_FILES['c_pan_number_img']['name'], PATHINFO_EXTENSION);
            $oxiinc = rand(). '.' .$ext;
            $uploadfile = $upload_dir . $oxiinc;
            if (move_uploaded_file($_FILES['c_pan_number_img']['tmp_name'], $uploadfile)){
                $pan_img = $oxiinc;
            }
        }
        else{
            $pan_img = $this->input->get_post('old_pan_img');
        }

        if(!empty($_FILES['c_gst_img']['name'])){
            $ext = pathinfo($_FILES['c_gst_img']['name'], PATHINFO_EXTENSION);
            $oxiinc2 = rand(). '.' .$ext;
            $uploadfile2 = $upload_dir . $oxiinc2;
            if (move_uploaded_file($_FILES['c_gst_img']['tmp_name'], $uploadfile2)){
                $gst_img = $oxiinc2;
            }
        }
        else{
            $gst_img = $this->input->get_post('old_gst_img');
        }

        if(!empty($_FILES['c_cin_number_img']['name'])){
            $ext = pathinfo($_FILES['c_cin_number_img']['name'], PATHINFO_EXTENSION);
            $oxiinc3 = rand(). '.' .$ext;
            $uploadfile2 = $upload_dir . $oxiinc3;
            if (move_uploaded_file($_FILES['c_cin_number_img']['tmp_name'], $uploadfile2)){
                $cin_img = $oxiinc3;
            }
        }
        else{
            $cin_img = $this->input->get_post('old_cin_img');
        }

        if(!empty($_FILES['c_r_number_img']['name'])){
            $ext = pathinfo($_FILES['c_r_number_img']['name'], PATHINFO_EXTENSION);
            $oxiinc4 = rand(). '.' .$ext;
            $uploadfile1 = $upload_dir . $oxiinc4;
            if (move_uploaded_file($_FILES['c_r_number_img']['tmp_name'], $uploadfile1)){
                $cr_img = $oxiinc4;
            }
        }
        else{
            $cr_img = $this->input->get_post('old_cr_img');
        }
        
        $postdata = array(
            'c_reseller_id' => $this->input->post('c_reseller_id'),
            'c_type' => $this->input->post('c_type'),
            'c_pan_number' => $this->input->post('c_pan_number'),
            'c_gst_number' => $this->input->post('c_gst_number'),
            'c_cin_number' => $this->input->post('c_cin_number'),
            'c_r_number' => $this->input->post('c_r_number'),
            'c_pan_number_img' => $pan_img,
            'c_gst_img' => $gst_img,
            'c_cin_number_img' => $cin_img,
            'c_r_number_img' => $cr_img,
            'c_address' => $this->input->post('c_address'),
            'c_city' => $this->input->post('c_city'),
            'c_district' => $this->input->post('c_district'),
            'c_state' => $this->input->post('c_state'),
            'c_pincode' => $this->input->post('c_pincode'),
            'c_mobile_number' => $this->input->post('c_mobile_number'),
            'c_telephone' => $this->input->post('c_telephone'),
            'c_website' => $this->input->post('c_website')
        );
        //echo"<pre>";print_r($postdata);exit();
        if(!empty($_POST['c_id'])){
            $insert_id = $this->Model->updateData('reseller_company_details', $this->security->xss_clean($postdata), array('c_reseller_id'=>$postdata['c_reseller_id']));
        }
        else{
            $insert_id = $this->Model->insertData('reseller_company_details', $this->security->xss_clean($postdata));
        }
        if($insert_id){
            $flash_data = array('text_msg'=>'Company details updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Company details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/company_detail');
    }

    public function director(){
        $data['main_containt'] = 'reseller_user/director';
        $this->load->view('reseller_user/containt', $data);
    }

    public function director_details_insert(){
        //echo "<pre>";print_r($_POST);
        //echo "<pre>";print_r($_FILES);die();
        $name = $_POST['name'];
        $upload_dir = './reseller_files/reseller_documents/director_info/';
        $i = 0;  
        foreach ($name as $key){
            if(!empty($_FILES['pan_card_img']['name'][$i])){
                $pan_ext = pathinfo($_FILES['pan_card_img']['name'][$i], PATHINFO_EXTENSION);
                if( ($pan_ext=="png") || ($pan_ext=="jpg") || ($pan_ext=="jpeg") ){
                    $pan_card_file = rand(). '.' .$pan_ext;
                    $upload_pan_card = $upload_dir . $pan_card_file;
                    if (move_uploaded_file($_FILES['pan_card_img']['tmp_name'][$i], $upload_pan_card)){
                        $pan_card_image = $pan_card_file;
                    }
                }
            }
            if(!empty($_FILES['adhar_card_img']['name'][$i])){
                $adhar_ext = pathinfo($_FILES['adhar_card_img']['name'][$i], PATHINFO_EXTENSION);
                if( ($adhar_ext=="png") || ($adhar_ext=="jpg") || ($adhar_ext=="jpeg") ){
                    $adhar_card_file = rand(). '.' .$adhar_ext;
                    $upload_adhar_card = $upload_dir . $adhar_card_file;
                    if (move_uploaded_file($_FILES['adhar_card_img']['tmp_name'][$i], $upload_adhar_card)){
                        $adhar_card_image = $adhar_card_file;
                    }
                }
            }
            $post_data = array(
                'd_reseller_id'=>$this->session->userdata('r_id'),
                'd_name'=>$_POST['name'][$i],
                'd_address'=>$_POST['d_address'][$i],
                'd_email'=>$_POST['email'][$i],
                'd_mobile'=>$_POST['Mobile'][$i],
                'd_pan_no'=>$_POST['pan_no'][$i],
                'd_pan_card'=>$pan_card_image,
                'd_adhar_card'=>$_POST['Aadhar'][$i],
                'd_adhar_img'=>$adhar_card_image
            );
            $id = $this->Model->insertData('director_details', $this->security->xss_clean($post_data));
            $i++;
        }
        if($id){
            $flash_data = array('text_msg'=>'Director Details Uploaded successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data =array('text_msg'=>'Director Details Uploaded Failed? Please Try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        if($_POST['url'] == 'director'){
            redirect('Reseller_dashboard/director_details');
        }
        else{
            redirect('Reseller_dashboard');
        }
    }

    public function director_details(){
        $data['director_result'] = $this->Model->getData('director_details', array('d_reseller_id'=>$this->session->userdata('r_id')));
        $data['main_containt'] = 'reseller_user/director_details';
        $this->load->view('reseller_user/containt', $data);
    }

    public function director_details_edit(){
        $data['director_data'] = $this->Model->getData('director_details', array('d_id'=>$this->uri->segment(3)));
        $data['main_containt'] = 'reseller_user/director_details_edit';
        $this->load->view('reseller_user/containt', $data);
    }

    public function director_details_update(){
        //echo"<pre>";print_r($_POST);die();
        $upload_dir = 'reseller_files/reseller_documents/director_info/';
        if(!empty($_FILES['d_pan_card']['name'])){
            $ext = pathinfo($_FILES['d_pan_card']['name'], PATHINFO_EXTENSION);
            $oxiinc = rand(). '.' .$ext;
            $uploadfile = $upload_dir . $oxiinc;
            if(move_uploaded_file($_FILES['d_pan_card']['tmp_name'], $uploadfile)){
                $d_pan_card_img = $oxiinc;
                unlink($upload_dir . $this->input->post('old_pan_img'));
            }
        }
        else{
            $d_pan_card_img = $this->input->post('old_pan_img');
        }

        if(!empty($_FILES['d_adhar_img']['name'])){
            $ext1 = pathinfo($_FILES['d_adhar_img']['name'], PATHINFO_EXTENSION);
            $oxiinc1 = rand(). '.' .$ext1;
            $uploadfile1 = $upload_dir . $oxiinc1;
            if(move_uploaded_file($_FILES['d_adhar_img']['tmp_name'], $uploadfile1)){
                $d_adhar_card_img = $oxiinc1;
                unlink($upload_dir . $this->input->post('old_adhar_img'));
            }
        }
        else{
            $d_adhar_card_img = $this->input->post('old_adhar_img');
        }
        $postdata = array(
            'd_name' => $this->input->post('d_name'),
            'd_email' => $this->input->post('d_email'),
            'd_mobile' => $this->input->post('d_mobile'),
            'd_address' => $this->input->post('d_address'),
            'd_pan_no' => $this->input->post('d_pan_no'),
            'd_pan_card' => $d_pan_card_img,
            'd_adhar_card' => $this->input->post('d_adhar_card'),
            'd_adhar_img' => $d_adhar_card_img,
            'd_update_time' => date('Y-m-d H:i:s')
        );
        //echo"<pre>";print_r($postdata);exit();
        $update_id = $this->Model->updateData('director_details', $this->security->xss_clean($postdata), array('d_id'=>$_POST['d_id'], 'd_reseller_id'=>$_POST['d_reseller_id']));

        if ($update_id){
            $flash_data = array('text_msg'=>'Director details updated successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Director details updated failed? please try again.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/director_details');
    }

    public function seller_profile_update(){
        //echo "<pre>";print_r($_POST);
        //echo "<pre>";print_r($_FILES);exit();
        if(!empty($_FILES['seller_image']['name'])){
            $upload_dir = 'reseller_files/seller_profile_image/';
            $ext = pathinfo($_FILES['seller_image']['name'], PATHINFO_EXTENSION);
            if(($ext == "png") || ($ext == "jpg") || ($ext == "jpeg")){
                $oxiinc = rand(). '.' .$ext;
                $uploadfile = $upload_dir . $oxiinc;
                if(move_uploaded_file($_FILES['seller_image']['tmp_name'], $uploadfile)){
                    $uploaded_img = $oxiinc;
                    unlink($upload_dir . $this->input->post('old_seller_image'));
                }
            }
            else{
               $ajax_request = array('status' => 'error', 'message' => 'Please select correct image formate, e.g. - png, jpg, jpeg.');
               echo json_encode($ajax_request);die();
            }
        }
        else{
            $uploaded_img = $this->input->post('old_seller_image');
        }
        $post_data = array(
            'full_name'=>$_POST['full_name'],
            'store_name'=>$_POST['store_name'],
            'store_description'=>$_POST['store_description'],
            'seller_image'=>$uploaded_img
        );

        $reseller_id = $this->Model->updateData('reseller', $this->security->xss_clean($post_data), array('id'=>$this->session->userdata('r_id')));
        if($reseller_id){
            $ajax_request = array('status' => 'success', 'message' => 'Seller Profile updated successfully.');
        }
        else{
            $ajax_request = array('status' => 'error', 'message' => 'Seller Profile updated failed? please try again.');
        }
        echo json_encode($ajax_request);
    }

    public function notification_details(){
        //echo "<pre>";print_r($_POST['id']);die();
        $notification_data = $this->Model->getData('seller_notification', array('id'=>$_POST['id']));
        //echo "<pre>";print_r($notification_data);die();
        if($notification_data){
            $ajax_request = array('status' => 'success', 'noti_title' =>$notification_data[0]['noti_title'], 'noti_description' =>$notification_data[0]['noti_description'], 'message' => '' );
        }
        else{
            $ajax_request = array('status' => 'error', 'message' => 'Record not found please try again thankyou.');
        }
        echo json_encode($ajax_request);die; 
    }

    public function update_gst(){
        if(empty($_POST['gst'])){
            $ajax_request = array('status' => 'error', 'message' => '<p style="color:red">Please Enter GST Number.</p>');
            echo json_encode($ajax_request);die;
        }
        $oxiinc_reseller_gst = $this->Model->getData('reseller', array('gst'=>$_POST['gst']));
        if (!empty($oxiinc_reseller_gst)) {
            $ajax_request = array('status' => 'error', 'message' => '<p style="color:red">GST number already exit.</p>');
            echo json_encode($ajax_request);die;
        }
        else{
            $this->Model->updateData('reseller', $_POST, array('id'=>$this->session->userdata('r_id'))); 
            $ajax_request = array('status' => 'success');
        }
        echo json_encode($ajax_request);
    }

    public function update_gst_skip(){
        $check_id = $this->Model->getData('reseller_skip',array('reseller_id'=>$this->session->userdata('r_id')));
        $skip_data['gst_skip']='1';
        if(empty($check_id)){
          $skip_data['reseller_id']=$this->session->userdata('r_id'); 
          $id=$this->Model->insertData('reseller_skip',$this->security->xss_clean($skip_data));
      }else{
          $this->Model->updateData('reseller_skip', $skip_data ,array('reseller_id'=>$this->session->userdata('r_id'))); 
      }
      $ajax_request = array('status' => 'success');
      echo json_encode($ajax_request);die;
    }

    public function update_signature_skip(){
        $check_id = $this->Model->getData('reseller_skip',array('reseller_id'=>$this->session->userdata('r_id')));
        //echo "<pre>";print_r($check_id);die;
        $skip_data['sign_skip']='1';
        if(empty($check_id)){
          $skip_data['reseller_id']=$this->session->userdata('r_id'); 
          $id=$this->Model->insertData('reseller_skip',$this->security->xss_clean($skip_data));
      }else{
          $this->Model->updateData('reseller_skip', $skip_data ,array('reseller_id'=>$this->session->userdata('r_id'))); 
      }
      $ajax_request = array('status' => 'success');
      echo json_encode($ajax_request);die;
    }

    public function update_cheque_skip(){
        $check_id = $this->Model->getData('reseller_skip',array('reseller_id'=>$this->session->userdata('r_id')));
        //echo "<pre>";print_r($check_id);die;
        $skip_data['cheque_skip']='1';
        if(empty($check_id)){
          $skip_data['reseller_id']=$this->session->userdata('r_id'); 
          $id=$this->Model->insertData('reseller_skip',$this->security->xss_clean($skip_data));
      }else{
          $this->Model->updateData('reseller_skip', $skip_data ,array('reseller_id'=>$this->session->userdata('r_id'))); 
      }
      $ajax_request = array('status' => 'success');
      echo json_encode($ajax_request);die;
    }

    public function signature_upload(){
        if(!empty($_FILES['signature_upload'])){
            $uploaddir = 'reseller_files/reseller_documents/';
            $oxiinc = rand().".png";
            $uploadfile = $uploaddir . $oxiinc;
            if (move_uploaded_file($_FILES['signature_upload']['tmp_name'], $uploadfile)){
                $postData['signature_upload'] = $oxiinc;
                $this->Model->updateData('reseller', $postData, array('id'=>$this->session->userdata('r_id')));
                $flash_data = array('text_msg'=>'Reseller Signature Image Uploaded successfully.', 'text_class'=>'form-sucessmsg');
            }
            else{
                $flash_data = array('text_msg'=>'Reseller Signature Image Uploaded Failed.', 'text_class'=>'form-errormsg');
            }
        }
        else{
            $flash_data = array('text_msg'=>'Please Choose Reseller Signature Image.', 'text_class'=>'form-errormsg');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard');
    }

    public function update_bank_information(){
        //echo "<pre>";print_r($_FILES);die();
        if(!empty($_FILES['Cancelled_Cheque_Img']['name'])){
            $uploaddir = 'reseller_files/reseller_documents/';
            $oxiinc = rand().".png";
            $uploadfile = $uploaddir . $oxiinc;
            if (move_uploaded_file($_FILES['Cancelled_Cheque_Img']['tmp_name'], $uploadfile)){
                $postData['Bank_Cancelled_Cheque'] = $oxiinc;

                $oxiinc_reseller_bank = $this->Model->getData('reseller_bank_details', array('reseller_id'=>$this->session->userdata('r_id')));
                if(!empty($oxiinc_reseller_bank)){
                    $id = $this->Model->updateData('reseller_bank_details',$this->security->xss_clean($postData),array('reseller_id'=>$this->session->userdata('r_id')));
                    unlink("reseller_files/reseller_documents/".$oxiinc_reseller_bank[0]['Bank_Cancelled_Cheque']);
                    $ajax_request = array('status' => 'success', 'message' => 'Reseller Cancelled Cheque Imgage Updated successfully.');
                }
                else{
                    $postData['reseller_id'] = $this->session->userdata('r_id');
                    $id = $this->Model->insertData('reseller_bank_details', $this->security->xss_clean($postData));
                    $ajax_request = array('status' => 'success', 'message' => 'Reseller Cancelled Cheque Imgage Inserted successfully.');
                }
            }
            else{
                $ajax_request = array('status' => 'error', 'message' => 'Reseller Cancelled Cheque Imgage Uploaded Failed.');
            }
        }
        else{
            $ajax_request = array('status' => 'error', 'message' => 'Please Choose Reseller Cancelled Cheque Imgage.');
        }
        echo json_encode($ajax_request);
    }

    public function verify_ifsc_code(){
        $query = $this->db->query('SELECT * from ifsc_code where IFSC="'.$_POST['ifsc_code'].'" ');
        $data =$query->result_array();
        if(empty($data)){
            $ajax_request = array('status' => 'error', 'message' => 'You have entered the wrong IFSC code.');
        }
        else{
            $ajax_request = array('status' => 'success', 'BANK' =>$data[0]['BANK'], 'ADDRESS' =>$data[0]['ADDRESS'], 'message' => 'You have Entered Valid IFSC Code' );
        }
        echo json_encode($ajax_request);die; 
    }

    public function update_bank_information_data(){
        //echo "<pre>";print_r($_POST);die();
        $postData = $_POST;
        $oxiinc_reseller_bank_account = $this->Model->getData('reseller_bank_details', array('Bank_Account_Number'=>$_POST['Bank_Account_Number'], 'reseller_id'=>$this->session->userdata('r_id')));
        if (!empty($oxiinc_reseller_bank_account)){
            $ajax_request = array('status' => 'error', 'message' => 'Bank Account Number Already Exit.');
        }
        else{
            $oxiinc_reseller_bank = $this->Model->getData('reseller_bank_details', array('reseller_id'=>$this->session->userdata('r_id')));
            if(!empty($oxiinc_reseller_bank)){
                $this->Model->updateData('reseller_bank_details',$this->security->xss_clean($postData), array('reseller_id'=>$this->session->userdata('r_id')));
            }
            else{
                $bank_data = $postData;
                $bank_data['reseller_id'] = $this->session->userdata('r_id');
                $id = $this->Model->insertData('reseller_bank_details', $this->security->xss_clean($bank_data));
            }
                $ajax_request = array('status' => 'success', 'message' => 'Bank details updated successfully.');
        }
        echo json_encode($ajax_request);die;
    }

    public function logout(){
        $this->session->set_userdata(array('reseller_logged_in' => FALSE));
        $this->session->sess_destroy();
        redirect('seller');
    }

    public function product_upload(){
        $category_data = $this->Model->getData('category',array('status'=>'1'));
        $data['category_data'] = $category_data;
        $data['main_containt'] = 'reseller_user/product_upload';
        $this->load->view('reseller_user/containt', $data);
        //$this->load->view('oxiinc_reseller/blulk_upload_form_view',$data);
    }

    public function blulk_upload_form_add($value=''){
        //echo "<pre>";print_r($_POST);die();
        //echo "<pre>";print_r($_FILES);die();
        $remove[] = "'";
        $remove[] = '"';
        $ext = pathinfo($_FILES['Product_Image']['name'][0][0], PATHINFO_EXTENSION);
        if(($ext=="png") || ($ext=="jpg") || ($ext=="jpeg")){
            $i = 0;
            $Product_data = " ";
            $user_id = $this->session->userdata('r_id');
            $sql = "SELECT store_name FROM reseller WHERE id ='".$user_id."'";
            $brand_data = $this->Model->getSqlData($sql);
            $brand = $brand_data[0]['store_name'];
            foreach ($_POST['Product_Name'] as $key => $value){
                $sub_category_name = $this->Model->getData('subcategory',array('sub_category_id'=>$_POST['sub_category_id']));
                $Product_data = array(
                    'category_id' =>$_REQUEST['category_id'],
                    'sub_category_id' =>$_REQUEST['sub_category_id'],
                    'sub_category_name' =>$sub_category_name[0]['sub_category_name'],
                    'product_category_id' =>$_REQUEST['product_category_id'],
                    'Product_Name' =>str_replace($remove, "", $_REQUEST['Product_Name'][$i]),
                    'Original_Prices' =>$_REQUEST['Original_Prices'][$i],
                    'Prices' =>$_REQUEST['Prices'][$i],
                    'reseller_original_prices' =>$_REQUEST['Original_Prices'][$i],
                    'reseller_prices' =>$_REQUEST['Prices'][$i],
                    'Short_Description' =>$_REQUEST['Short_Description'][$i] ,
                    'large_Description' =>$_REQUEST['large_Description'] [$i],
                    'GST_Persentage' =>$_REQUEST['GST_Persentage'][$i],
                    'hsn_code' =>$_REQUEST['hsn_code'][$i],
                    'Shipping_Charges' =>$_REQUEST['Shipping_Charges'][$i] ,
                    'product_color' =>$_REQUEST['product_color'][$i] ,
                    'Product_Attribute' =>implode( ",", $_REQUEST['sizes'][$i]) ,
                    'status' =>0,
                    'company_name' =>$brand,
                    'product_approval_status'=>0,
                    'reseller_id' =>$user_id
                );
                $ID = $this->Model->insertData('wellness', $Product_data);
                $this->load->library('email');
                $subject = 'Product uploaded successfully.';
                //$mail_content=$otp_code." your email verification otp for forgot password.";
                $config = Array(
                    'protocol' => 'mail',
                    'smtp_host' => 'mail.oxiinc.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'no_reply@oxiinc.in',
                    'smtp_pass' => '@@noreply@@',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('no_reply@oxiinc.in', 'Oxiinc Reseller');
                $this->email->to($this->session->userdata('r_email'));
                $emailer = 'emailer/product_approval.html';
                $mail_content = file_get_contents($emailer);
                $mail_content = str_replace('@_first_@',$_REQUEST['company_name_product'], $mail_content);
                $mail_content = str_replace('@_product_name_@',$_REQUEST['Product_Name'][$i], $mail_content);
                $this->email->subject($subject); 
                $this->email->message($mail_content);
                // $this->email->attach($mail_content);
                $this->email->send();
                $multiple_picture_upload = $_FILES['Product_Image']['name'][$i];
                $count = sizeof($multiple_picture_upload);
                for($k=0; $k < $count; $k++){
                    if(!empty($_FILES['Product_Image'])){
                        $uploaddir = './uploads/Multiple_Picture/';
                        $rand_file_name = rand().".png";
                        $uploadfile = $uploaddir .$rand_file_name;
                        if (move_uploaded_file($_FILES['Product_Image']['tmp_name'][$i][$k], $uploadfile)){
                            $image_data = $rand_file_name;
                        }
                    }
                    $multiple_picture = array(
                        'Product_id' =>$ID ,
                        'Product_Picture_Mult' =>$image_data,
                        'status' =>1
                    );
                    $multiple_picture_id = $this->Model->insertData('multiple_picture', $multiple_picture);
                }
                $stock_sizes_data = explode(",", $_POST['stock_sizes'][$i]);
                $sizes_data = explode(",",$_POST['sizes'][$i]);
                $add_total_stock = '';
                $j = 0;  
                foreach ($_POST['sizes'][$i] as $key => $question){
                    $stock_sizes_add = array(
                        'p_id'=>$ID,
                        'size'=>$_POST['sizes'][$i][$j],
                        'stock'=>$_POST['stock_sizes'][$i][$j]
                    );
                    $this->Model->insertData('size_manage', $stock_sizes_add);
                    $add_total_stock += $_POST['stock_sizes'][$i][$j];
                    $j++;
                }
                $stock_sizes_Update['stock_status'] = $add_total_stock;
                $this->Model->updateData('wellness', $stock_sizes_Update, array('ID'=>$ID));
                $i++;
            }
            if($ID){
                $flash_data = array('text_msg'=>'Product Uploaded Successfully Please Wait For Approval.', 'text_class'=>'form-sucessmsg text-center');
            }
            else{
                $flash_data = array('text_msg'=>'Product Uploaded Failed? Please try Again.', 'text_class'=>'form-errormsg text-center');
            }
        }
        else{
            $flash_data = array('text_msg'=>'Please Select Correct Image Formate, e.g. - png, jpg, jpeg.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/Product_list');
    }

    public function Product_list(){
        $data['Product_list']=$this->Model->getDataOrderBy('wellness', array('reseller_id'=>$this->session->userdata('r_id')), 'ID','DESC');
        $data['main_containt'] = 'reseller_user/product_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function pending_product_list(){
        $data['Product_list'] = $this->Model->getDataOrderBy('wellness',array('reseller_id'=>$this->session->userdata('r_id'), 'product_approval_status'=> 0), 'ID','DESC');
        $data['main_containt'] = 'reseller_user/product_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function approved_product_list(){
        $data['Product_list'] = $this->Model->getDataOrderBy('wellness',array('reseller_id'=>$this->session->userdata('r_id'), 'product_approval_status'=> 1), 'ID','DESC');
        $data['main_containt'] = 'reseller_user/product_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function rejected_product_list(){
        $data['Product_list'] = $this->Model->getDataOrderBy('wellness',array('reseller_id'=>$this->session->userdata('r_id'), 'product_approval_status'=> 2), 'ID','DESC');
        $data['main_containt'] = 'reseller_user/product_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function out_of_stock_product_list(){
        $data['Product_list'] =$this->Model->getDataOrderBy('wellness',array('reseller_id'=>$this->session->userdata('r_id'), 'stock_status'=> 0), 'ID','DESC');
        $data['main_containt'] = 'reseller_user/product_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function product_information_view_stock_wise(){
       $data['size_manage'] = $this->Model->getData('size_manage', array('p_id'=>$_POST['id']));
       $this->load->view('reseller_user/product_stock_wise_ajax_view', $data);
    }

    public function product_information_view_stock_wise_size(){
        //echo "<pre>";print_r($_POST);die();
        $total_stock=" ";
        $j = 0;  
        foreach ($_POST['id'] as $key => $question){
            $stock_sizes_add = array(
                'id'=>$_POST['id'][$j],
                'size'=>$_POST['size'][$j],
                'stock'=>$_POST['stock'][$j]
            );
            $this->Model->updateData('size_manage',$stock_sizes_add, array('id'=>$_POST['id'][$j]));
            $total_stock += $_POST['stock'][$j];
            $j++;
        }
        $update_Product_stock['stock_status'] = $total_stock;
        $update_stock = $this->Model->updateData('wellness', $update_Product_stock, array('ID'=>$_POST['Product_id']));
        if ($update_stock){
            $flash_data = array('text_msg'=>'Product Size With Stock Updated Successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Product Size With Stock Updated Failed.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/Product_list');
    }

    public function delete_size_stock(){
        //echo "<pre>";print_r($_POST);die();
        $this->Model->deleteData('size_manage', array('id'=>$_POST['id']));
        $update_stock = $this->db->query("UPDATE wellness SET stock_status = stock_status - '".$_POST['stock']."' WHERE ID ='".$_POST['Product_id']."' ");
        if ($update_stock) {
            $ajax_request = array('status' => 'success', 'message' => 'Product Size With Stock Deleted Successfully.');
        }
        else{
            $ajax_request = array('status' => 'error', 'message' => 'Product Size With Stock Deleted Failed.');
        }
        echo json_encode($ajax_request);die;
    }

    public function product_stock_with_size(){
        //echo "<pre>";print_r($_POST);die();
        $ID = $_POST['id'];
        if ($ID!='' && !empty($_POST['sizes']) && !empty($_POST['stock_sizes'])){
            $total_stock = "";
            $i = 0;  
            foreach ($_POST['sizes'] as $key => $question){
                $order_data = array(
                    'p_id'=>$ID,
                    'size'=>$_POST['sizes'][$i],
                    'stock'=>$_POST['stock_sizes'][$i]
                );
                $vcsdc = $this->Dbs->add('size_manage', $order_data);
                $total_stock += $_POST['stock_sizes'][$i];
                $i++;
            }
            $update_stock = $this->db->query('UPDATE wellness SET stock_status = stock_status + '.$total_stock.' WHERE ID ='.$ID);
            if ($update_stock){
                $flash_data = array('text_msg'=>'Added New Product Size With Stock Successfully.', 'text_class'=>'form-sucessmsg text-center');
            }
            else{
                $flash_data = array('text_msg'=>'Added New Product Size With Stock Failed.', 'text_class'=>'form-errormsg text-center');
            }
        }
        else{
            $flash_data = array('text_msg'=>'Something Went Wrong To Added New Product Size With Stock Failed.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/Product_list');
    }

    public function fetch_product_images_data(){
       $data['product_images_information'] = $this->Model->getData('multiple_picture', array('Product_id'=>$_POST['id']));
       $this->load->view('reseller_user/product_images_ajax_view', $data);
    }

    public function fetch_product_images_data_delete(){
        //echo "<pre>";print_r($_POST);die();
        $delete_id = $this->Model->deleteData('multiple_picture', array('ID'=>$_POST['ID'], 'Product_id'=>$_POST['Product_id']));
        if ($delete_id) {
            $ajax_request = array('status' => 'success', 'message' => 'Product Image Deleted Successfully.');
        }
        else{
            $ajax_request = array('status' => 'error', 'message' => 'Product Image Deleted Failed.');
        }
        echo json_encode($ajax_request);die;
    }

    public function upload_more_product_images(){
        //echo "<pre>";print_r($_FILES);die();
        $i = 0;
        foreach ($_FILES['Product_Images'] as $key => $value){
            $ext = pathinfo($_FILES['Product_Images']['name'][$i], PATHINFO_EXTENSION);
            if(!empty($_FILES['Product_Images']['name'][$i])){
                if(($ext == "png") || ($ext == "jpg") || ($ext == "jpeg")){
                    $uploaddir = './uploads/Multiple_Picture/';
                    $rand_file_name = rand().'.'.$ext;
                    $uploadfile = $uploaddir .$rand_file_name;
                    if (move_uploaded_file($_FILES['Product_Images']['tmp_name'][$i], $uploadfile)){
                        $image_data = $rand_file_name;
                        $stock_sizes_add = array(
                            'Product_id'=>$_POST['Product_id'],
                            'Product_Picture_Mult'=>$image_data,
                            'status'=>1
                        );
                        $this->Model->insertData('multiple_picture', $stock_sizes_add);
                        $flash_data = array('text_msg'=>'Product Images Uploaded successfully.', 'text_class'=>'form-sucessmsg text-center');
                    }
                    else{
                        $flash_data = array('text_msg'=>'Product Images Uploaded Failed.', 'text_class'=>'form-errormsg text-center');
                    }
                }
                else{
                    $flash_data = array('text_msg'=>'Please Select Correct Image Formate, e.g. - png, jpg, jpeg.', 'text_class'=>'form-errormsg text-center');
                }
            }
        $i++;
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/Product_list');
    }

    public function fetch_product_data(){
        $data['product_information'] = $this->Model->getData('wellness', array('ID'=>$_POST['id']));
        $this->load->view('reseller_user/product_update_ajax_view',$data);
    }

    public function fetch_product_data_update(){
        //echo "<pre>";print_r($_POST);//die();
        $Product_data = array(
            'Product_Name' =>$_REQUEST['Product_Name'],
            'product_color' =>$_REQUEST['product_color'],
            'Short_Description' =>$_REQUEST['Short_Description'],
            'large_Description' =>$_REQUEST['large_Description'],
            'modified' => date("Y-m-d H:i:s")
        );
        //echo "<pre>";print_r($Product_data);die();
        $update_id = $this->Model->updateData('wellness', $Product_data, array('ID'=>$_POST['ID']));
        if ($update_id){
            $flash_data = array('text_msg'=>'Product Information Updated Successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Product Information Updated Failed.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/Product_list');
    }

    public function fetch_product_data_delete(){
       $delete_id = $this->Model->deleteData('wellness', array('ID'=>$this->uri->segment(3)));
       if ($delete_id){
            $flash_data = array('text_msg'=>'Product Information Deleted Successfully.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Product Information Deleted Failed.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/Product_list');
    }

    public function update_product_image(){
        //echo "<pre>";print_r($_FILES);die();
        $postData = $_POST;
        if(!empty($_FILES['product_image'])){
            $uploaddir = './uploads/Multiple_Picture/';
            $oxiinc=rand()."oxiinc_reseller.png";
            $uploadfile = $uploaddir . $oxiinc;
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadfile)) {
                $postData['Product_Picture_Mult'] = $oxiinc;
            }
            echo $oxiinc;
        }
        $this->Model->updateData('multiple_picture', $this->security->xss_clean($postData), array('ID'=>$_POST['ID'])); 
    }

    public function getSubCategory(){
       $postData = $_POST;
       $sub_category_list = $this->Model->getData('subcategory',array('status'=>'1'));
       $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['category_id'] == $value['category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }

    public function getproCategory(){
        $postData = $_POST;
        $sub_category_list = $this->Model->getData('product_category',array('status'=>'1'));
        $sub_cats = array();
        foreach ($sub_category_list as $key => $value) {
            if($postData['sub_category_id'] == $value['sub_category_id']){
                $sub_cats[] = $value;
            }
        }
        echo json_encode($sub_cats);
    }

    public function inventory_mangement(){
    }

    public function wallet_balance(){
        $days = $this->weekDay_count();
        $sql = "SELECT * FROM payout_statement WHERE date(user_request_date) BETWEEN '".$days['week_start_date']."' AND '".$days['week_end_date']."' AND reseller_id=".$this->session->userdata('r_id');
        $query = $this->db->query($sql);
        $customer_payout_details['weekly_transaction'] = $query->result_array();
        //echo "<pre>";print_r($customer_payout_details);die();

        $sql_pendding = "SELECT * FROM payout_statement WHERE status = '0' AND reseller_id=".$this->session->userdata('r_id')." ORDER BY id DESC";
        $query_pendding = $this->db->query($sql_pendding);
        $customer_payout_details['transaction_pendding'] = $query_pendding->result_array();

        $sql_aproval = "SELECT * FROM payout_statement WHERE status = '1' AND reseller_id=".$this->session->userdata('r_id')." ORDER BY id DESC";
        $query_aproval = $this->db->query($sql_aproval);
        $customer_payout_details['transaction_aproval'] = $query_aproval->result_array();

        $sql_rejected = "SELECT * FROM payout_statement WHERE status = '2' AND reseller_id=".$this->session->userdata('r_id')." ORDER BY id DESC";
        $query_rejected = $this->db->query($sql_rejected);
        $customer_payout_details['transaction_rejected'] = $query_rejected->result_array();

        $query_payout = $this->db->query("SELECT * FROM payout_statement WHERE reseller_id=".$this->session->userdata('r_id')." ORDER BY id DESC");
        $customer_payout_details['payout_details'] = $query_payout->result_array();

        //echo '<pre>'; print_r($customer_payout_details);die();
        $customer_payout_details['main_containt'] = 'reseller_user/payout';
        $this->load->view('reseller_user/containt', $customer_payout_details);
        //$this->load->view('oxiinc_reseller/payout', $customer_payout_details);
    }

    public function weekDay_count(){
        $monday = strtotime("last monday");
        $monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
        $sunday = strtotime(date("Y-m-d",$monday)." +6 days");
        $weekDates['week_start_date'] = date("Y-m-d",$monday);
        $weekDates['week_end_date'] = date("Y-m-d",$sunday);
        for($i=$monday; $i<=$sunday; $i+=86400) {  
            $weekDates['all_current_week_date'][] = date("Y-m-d", $i);  
        } 
        return $weekDates;
    }

    public function payout_request(){
        //echo '<pre>'; print_r($_POST);die();
        $bank_query = $this->db->query("SELECT Bank_Holder_Name, Bank_Account_Number, Bank_ifsc, Bank_name, Bank_address FROM reseller_bank_details WHERE reseller_id = ".$this->session->userdata('r_id'));
        $bank_details = $bank_query->result_array();
        
        $amount = $_POST['payouts_amount'];
        $admin_charge = ($amount * 5) / 100;
        $TDS = ($amount * 3.75) / 100;
        $amount_after_tax = $amount - $admin_charge - $TDS;

        $reseller_payout_request['reseller_id'] = $this->session->userdata('r_id');
        $reseller_payout_request['name'] = $this->session->userdata('r_full_name');
        $reseller_payout_request['reseller_email'] = $this->session->userdata('r_email');
        $reseller_payout_request['bank_holder_name'] = $bank_details[0]['Bank_Holder_Name'];
        $reseller_payout_request['account_number'] = $bank_details[0]['Bank_Account_Number'];
        $reseller_payout_request['ifsc'] = $bank_details[0]['Bank_ifsc'];
        $reseller_payout_request['branch'] = $bank_details[0]['Bank_name'];
        $reseller_payout_request['bank_address'] = $bank_details[0]['Bank_address'];
        $reseller_payout_request['amount'] = $amount;
        $reseller_payout_request['admin_charge'] = $admin_charge;
        $reseller_payout_request['TDS'] = $TDS;
        $reseller_payout_request['amount_after_tax'] = $amount_after_tax;
        $reseller_payout_request['remarks'] = $_POST['payouts_remark'];

        $payout_id = $this->Model->insertData('payout_statement', $reseller_payout_request);

        if($payout_id){
            $debit_amount['reseller_id'] = $this->session->userdata('r_id');
            $debit_amount['payout_id'] =  $payout_id;
            $debit_amount['reseller_credit_amount'] = 0;
            $debit_amount['reseller_debit_amount'] = $_POST['payouts_amount'];
            $debit_amount['reseller_closing_amount'] = $_POST['balance_amount'] - $_POST['payouts_amount'];

            $seller_id = $this->Model->insertData('seller_wallet', $debit_amount);

            if($seller_id){
            	$flash_data = array('text_msg'=>'Your payout request send successfully. please wait for admin approval.', 'text_class'=>'form-sucessmsg text-center');
            }
            else{
            	$flash_data = array('text_msg'=>'Reseller wallet deduction failed. please try again? thank you.', 'text_class'=>'form-errormsg text-center');
            }
        }
        else{
        	$flash_data = array('text_msg'=>'Payout request statement failed. please try again later.', 'text_class'=>'form-errormsg text-center');
        }
		$this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/wallet_balance');
    }

    public function packaging_material_order(){
        $data['packing_material'] = $this->Model->getData('packing_material', array('status !='=>3));
        //$this->load->view('oxiinc_reseller/packing_material_bank_deposit_statement_view',$data);
        $data['main_containt'] = 'reseller_user/packaging_material_order';
        $this->load->view('reseller_user/containt', $data);
    }

    public function add_packing_material_bank_deposit_statement(){
    //echo '<pre>'; print_r($_POST);die();
    $bank_deposit_statement = $this->Model->getData('packing_material_bank_deposite_statement', array('transcation_number'=>$_POST['transcation_number']));
    if(!empty($bank_deposit_statement)){
        $flash_data = array('text_msg'=>'Duplicate Transaction Number Not Allowed please Try Again.', 'text_class'=>'form-errormsg text-center');
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/packaging_material_status');
    }
    else{
        $data['reseller_id'] = $this->session->userdata('r_id');
        $data['payee_bank'] = $_POST['payee_bank'];
        $data['payment_mode'] = $_POST['payment_mode'];
        $data['amount'] = $_POST['amount'];
        $data['remark'] = $_POST['remark'];
        $data['transcation_number'] = $_POST['transcation_number'];
        $data['branchdepositebank'] = $_POST['branchdepositebank'];
        $data['payment_depositedate'] = date('Y-m-d', strtotime($_POST['payment_depositedate']));
        if(!empty($_FILES['bank_statement_image']['name'])){
            $ext = pathinfo($_FILES['bank_statement_image']['name'], PATHINFO_EXTENSION);
            if(($ext=="png") || ($ext=="jpg") || ($ext=="jpeg")){
                $oxiinc = 'bank_statement_'.rand(). '.' .$ext;
                $uploaddir = './reseller_files/reseller_documents/bank_deposite_statement/';
                $uploadfile = $uploaddir . $oxiinc;
                if (move_uploaded_file($_FILES['bank_statement_image']['tmp_name'], $uploadfile)) {
                    $data['images'] = $oxiinc;
                }
                $id = $this->Model->insertData('packing_material_bank_deposite_statement', $data);
            }
            else{
                $flash_data = array('text_msg'=>'Please Select Correct Image Formate, e.g. - png, jpg, jpeg.', 'text_class'=>'form-errormsg text-center');
                $this->session->set_flashdata('msg', $flash_data);
                redirect('Reseller_dashboard/packaging_material_status');
            }
        }
        else{
            $flash_data = array('text_msg'=>'Please Upload Bank Statement Images.', 'text_class'=>'form-errormsg text-center');
            $this->session->set_flashdata('msg', $flash_data);
            redirect('Reseller_dashboard/packaging_material_status');
        }
        
        $i = 0;
        foreach($_POST['product_name'] as $key => $value){
            $postdata['reseller_id'] = $this->session->userdata('r_id');
            $postdata['bank_deposite_id'] = $id;
            $postdata['product_name'] = $_POST['product_name'][$i];
            $postdata['product_qty'] = $_POST['product_qty'][$i];
            $postdata['product_price'] = $_POST['product_price'][$i];
            $postdata['product_price_total'] = $_POST['product_price_total'][$i];
            
            $this->Model->insertData('reseller_packing_material_request',$postdata);
            $i++;
        }
        if ($id){
            $flash_data = array('text_msg'=>'Order Package Material Request Successfully Please Wait For Admin Reply.', 'text_class'=>'form-sucessmsg text-center');
        }
        else{
            $flash_data = array('text_msg'=>'Order Package Material Request Failed.', 'text_class'=>'form-errormsg text-center');
        }
        $this->session->set_flashdata('msg', $flash_data);
        redirect('Reseller_dashboard/packaging_material_status');
    }
    
}

    public function packaging_material_status(){
        $data['bank_deposit_statement'] = $this->Model->getData('packing_material_bank_deposite_statement',array('reseller_id'=>$this->session->userdata('r_id')));
        $data['main_containt'] = 'reseller_user/packaging_material_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function packing_material_pending(){
        $data['bank_deposit_statement'] = $this->Model->getData('packing_material_bank_deposite_statement',array('reseller_id'=>$this->session->userdata('r_id'), 'status' =>0));
        $data['main_containt'] = 'reseller_user/packaging_material_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function packing_material_approved(){
        $data['bank_deposit_statement'] = $this->Model->getData('packing_material_bank_deposite_statement',array('reseller_id'=>$this->session->userdata('r_id'), 'status' =>1));
        $data['main_containt'] = 'reseller_user/packaging_material_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function packing_material_rejected(){
        $data['bank_deposit_statement'] = $this->Model->getData('packing_material_bank_deposite_statement',array('reseller_id'=>$this->session->userdata('r_id'), 'status' =>2));
        $data['main_containt'] = 'reseller_user/packaging_material_listing';
        $this->load->view('reseller_user/containt', $data);
    }

    public function get_packing_material(){
        $sql = "SELECT A.* ,B.product_name AS paking_material FROM reseller_packing_material_request AS A LEFT JOIN packing_material AS B ON B.id = A.product_name WHERE A.bank_deposite_id=".$_POST['id'];
        $query = $this->db->query($sql);
        $bank_deposit_statement = $query->result_array();
        echo json_encode($bank_deposit_statement);die;
    }

    public function bank_deposit_statement(){
        $data['main_containt'] = 'reseller_user/bank_deposit_statement';
        $this->load->view('reseller_user/containt', $data);
        //$this->load->view('oxiinc_reseller/bank_deposit_statement_view');
    }

    public function add_bank_deposit_statement(){
        //echo "<pre>";print_r($_POST);die();
        $postData = $_POST;
        $bank_deposit_statement = $this->Model->getData('bank_deposite_statement', array('transcation_number'=>$_POST['transcation_number']));
        if(!empty($bank_deposit_statement)){
            $ajax_request = array('status' => 'error', 'message' => 'Duplicate Transcation Number Not Accepted.');
        }
        else{
            $postData['reseller_id'] = $this->session->userdata('r_id');
            if(!empty($_FILES['images'])){
                $uploaddir = './reseller_files/reseller_documents/bank_deposite_statement/';
                $oxiinc = rand()."_oxiinc_reseller.png";
                $uploadfile = $uploaddir . $oxiinc;
                if (move_uploaded_file($_FILES['images']['tmp_name'], $uploadfile)) {
                    $postData['images'] = $oxiinc;
                }
            }
            $this->Model->insertData('bank_deposite_statement', $postData);
            $ajax_request = array('status' => 'success', 'message' => 'Your request has been submited we proceed soon, Thank You.');
        }
        echo json_encode($ajax_request);die;
    }

    public function view_bank_deposit_statement(){
        $data['bank_deposit_details'] = $this->Model->getData('bank_deposite_statement', array('reseller_id'=>$this->session->userdata('r_id')));
        $data['main_containt'] = 'reseller_user/bank_deposit_statement_listing';
        $this->load->view('reseller_user/containt', $data);
    }
}