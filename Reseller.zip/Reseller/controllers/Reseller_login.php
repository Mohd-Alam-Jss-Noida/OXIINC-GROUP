<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reseller_login extends CI_Controller {
    
    function __construct() {
        parent::__construct(); 
        $this->load->model('Model');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    public function index(){
        if($this->session->userdata('is_logged_in')){
            redirect('Reseller_admin');
        }
        else{
            $this->load->view('reseller_admin/login');
            
        }
    }

    public function old(){
        $this->load->view('oxiinc_reseller/reseller_login/auth/login');
    }

    public function process(){
        if(isset($_POST["submit"]) && !empty($_POST["submit"])){
            //echo "<pre>";print_r($_POST);//die();
            $this->form_validation->set_rules('user_email', 'User Email', 'required');
            $this->form_validation->set_rules('user_password', 'Password', 'required');
            if ($this->form_validation->run()){
                $user_email = $_POST['user_email'];
                $password = md5($_POST['user_password']);
                $login = $this->Model->getData('users', array('user_email'=>$user_email, 'user_password'=>$password));
                if($login){
                    $session_array = array(
                        'user_email' =>$user_email,
                        'user_name' =>$login[0]['user_name'],
                        'admin_id' =>$login[0]['id'],
                        'is_logged_in'=>true
                    );
                    $this->session->set_userdata($session_array);
                    $this->session->set_flashdata('msg', 'You are successfully logged in. Welcome Reseller Admin Dashboard.');
                    redirect('Reseller_admin');
                }
                else{
                    $this->session->set_flashdata('msg', 'Invalid User Email and Password. Please Try Again.');
                    redirect('Reseller_login');
                }
            }
            else{
                $this->load->view('reseller_admin/login');
            }
        }
        else{
            $this->load->view('reseller_admin/login');
        }
    }
    
    public function logout(){
        $this->session->set_userdata(array('is_logged_in' => FALSE));
        $this->session->sess_destroy();
        redirect('Reseller_login');
    }
}