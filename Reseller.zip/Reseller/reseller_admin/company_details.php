<?php
    $pan_image = (isset($company_data[0]['c_pan_number_img']) && !empty($company_data[0]['c_pan_number_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_pan_number_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_pan_number_img']) : base_url('reseller_user_assets/images/image_not_found.png');

    $gst_image = (isset($company_data[0]['c_gst_img']) && !empty($company_data[0]['c_gst_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_gst_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_gst_img']) : base_url('reseller_user_assets/images/image_not_found.png');

    $cin_image = (isset($company_data[0]['c_cin_number_img']) && !empty($company_data[0]['c_cin_number_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_cin_number_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_cin_number_img']) : base_url('reseller_user_assets/images/image_not_found.png');

    $cr_image = (isset($company_data[0]['c_r_number_img']) && !empty($company_data[0]['c_r_number_img']) && file_exists('reseller_files/reseller_documents/'.$company_data[0]['c_r_number_img'])) ? base_url('reseller_files/reseller_documents/'.$company_data[0]['c_r_number_img']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">View and Update Company details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a>
                            </li>
                            <li class="breadcrumb-item active">View and Update Company details
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg');?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <div class="card">
                <div class="card-body">
                    <form class="form" action="<?php echo base_url('Reseller_admin/company_details_update');?>" method="POST" enctype="multipart/form-data">
                        <div class="form-body">
                            <input type="hidden" name="c_id" value="<?php echo $company_data[0]['c_id'];?>">
                            <input type="hidden" name="c_reseller_id" value="<?php echo $company_data[0]['c_reseller_id'];?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Company Name</label>
                                        <input type="text" name="c_name" value="<?php echo $company_data[0]['c_name'];?>" class="form-control border-primary" placeholder="Enter Company Name" name="Enter Company Name" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Company Email</label>
                                        <input type="email" name="c_email" value="<?php echo $company_data[0]['c_email'];?>" class="form-control border-primary" placeholder="Enter Company Email" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Company Type</label>
                                        <select class="form-control border-primary" name="c_type" autocomplete="off">
                                            <option value="public" <?php echo ($company_data[0]['c_type'] == "public") ? 'selected = selected' : '';?>>Public</option>
                                            <option value="private" <?php echo ($company_data[0]['c_type'] == "private") ? 'selected = selected' : '';?>>Private</option>
                                            <option value="partnerships" <?php echo ($company_data[0]['c_type'] == "partnerships") ? 'selected = selected' : '';?>>Partnerships</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Company Website</label>
                                        <input type="text" name="c_website" value="<?php echo $company_data[0]['c_website'];?>" class="form-control border-primary" placeholder="Enter Company Website" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Mobile Number</label>
                                            <input type="text" name="c_mobile_number" value="<?php echo $company_data[0]['c_mobile_number'];?>" class="form-control border-primary" placeholder="Enter Mobile Number" autocomplete="off" required maxlength="10" onkeypress="return isNumberKey(event)">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Telephone Number</label>
                                            <input type="text" name="c_telephone" value="<?php echo $company_data[0]['c_telephone'];?>" class="form-control border-primary" placeholder="Enter Telephone Number" autocomplete="off" maxlength="11" onkeypress="return isNumberKey(event)">
                                        </div>
                                    </div>
                                </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Address</label>
                                        <input type="text" name="c_address" value="<?php echo $company_data[0]['c_address'];?>" class="form-control border-primary" placeholder="Enter Address" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input type="text" name="c_city" value="<?php echo $company_data[0]['c_city'];?>" class="form-control border-primary" placeholder="Enter Cty" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">District</label>
                                        <input type="text" name="c_district" value="<?php echo $company_data[0]['c_district'];?>" class="form-control border-primary" placeholder="Enter District" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">State</label>
                                        <input type="text" name="c_state" value="<?php echo $company_data[0]['c_state'];?>" class="form-control border-primary" placeholder="Enter State" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Pincode</label>
                                        <input type="text" name="c_pincode" value="<?php echo $company_data[0]['c_pincode'];?>" class="form-control border-primary" placeholder="Enter Pincode" autocomplete="off" maxlength="6" onkeypress="return isNumberKey(event)">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">PAN No.</label>
                                        <input type="text" name="c_pan_number" value="<?php echo $company_data[0]['c_pan_number'];?>" class="form-control border-primary" maxlength="10" placeholder="Enter PAN No." autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">GST No.</label>
                                        <input type="text" name="c_gst_number" value="<?php echo $company_data[0]['c_gst_number'];?>" class="form-control border-primary" maxlength="15" placeholder="Enter GST No." autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="company_image_statement('<?php echo $pan_image;?>')" src="<?php echo $pan_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="company_image_statement('<?php echo $gst_image;?>')" src="<?php echo $gst_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">PAN Certificate</label>
                                        <input type="file" name="c_pan_number_img" class="form-control border-primary">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">GST Certificate</label>
                                        <input type="file" name="c_gst_img" class="form-control border-primary">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">CIN No.</label>
                                        <input type="text" name="c_cin_number" value="<?php echo $company_data[0]['c_cin_number'];?>" class="form-control border-primary" maxlength="21" placeholder="Enter CIN No." autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Company Registration No.</label>
                                        <input type="text" name="c_r_number" value="<?php echo $company_data[0]['c_r_number'];?>" class="form-control border-primary" maxlength="21" placeholder="Enter CIN No." autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="company_image_statement('<?php echo $cin_image;?>')" src="<?php echo $cin_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="company_image_statement('<?php echo $cr_image;?>')" src="<?php echo $cr_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">CIN Certificate</label>
                                        <input type="file" name="c_cin_number_img" class="form-control border-primary">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Company Registration Certificate</label>
                                        <input type="file" name="c_r_number_img" class="form-control border-primary">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="old_pan_img" value="<?php echo $company_data[0]['c_pan_number_img'];?>" readonly="">
                        <input type="hidden" name="old_gst_img" value="<?php echo $company_data[0]['c_gst_img'];?>" readonly="">
                        <input type="hidden" name="old_cin_img" value="<?php echo $company_data[0]['c_cin_number_img'];?>" readonly="">
                        <input type="hidden" name="old_cr_img" value="<?php echo $company_data[0]['c_r_number_img'];?>" readonly="">
                        <div class="form-actions text-center">
                            <button type="submit" class="btn btn-outline-primary"><i class="la la-check-square-o"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- company show image model -->
<div class="modal fade text-left" id="company_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View image statement</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="company_pan_aadhar_image" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function company_image_statement(img_src) {
        $('#company_image_model').modal('show');
        document.getElementById("company_pan_aadhar_image").src = img_src;
    }
</script>