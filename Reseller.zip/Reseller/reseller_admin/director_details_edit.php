<?php
    $pan_image = (isset($director_data[0]['d_pan_card']) && !empty($director_data[0]['d_pan_card']) && file_exists('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_pan_card'])) ? base_url('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_pan_card']) : base_url('reseller_user_assets/images/image_not_found.png');

    $aadhar_image = (isset($director_data[0]['d_adhar_img']) && !empty($director_data[0]['d_adhar_img']) && file_exists('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_adhar_img'])) ? base_url('reseller_files/reseller_documents/director_info/'.$director_data[0]['d_adhar_img']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">View and Update Director details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">View and Update Director details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="card">
                <div class="card-body">
                    <form class="form" action="<?php echo base_url('Reseller_admin/director_details_update');?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="d_id" value="<?php echo $director_data[0]['d_id'];?>" readonly>
                        <input type="hidden" name="d_reseller_id" value="<?php echo $director_data[0]['d_reseller_id'];?>" readonly>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Director Name</label>
                                        <input type="text" id="d_name" name="d_name" value="<?php echo $director_data[0]['d_name'];?>" class="form-control border-primary" placeholder="Enter Director Name" autocomplete="off" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Director Email</label>
                                        <input type="email" id="d_email" name="d_email" value="<?php echo $director_data[0]['d_email'];?>" class="form-control border-primary" placeholder="Enter Director Email" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Mobile Number</label>
                                        <input type="text" id="d_mobile" name="d_mobile" value="<?php echo $director_data[0]['d_mobile'];?>" class="form-control border-primary" placeholder="Enter Director Mobile Number" autocomplete="off" required maxlength="10" onkeypress="return isNumberKey(event)">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Director Address</label>
                                        <input type="text" id="d_address" name="d_address" value="<?php echo $director_data[0]['d_address'];?>" class="form-control border-primary" placeholder="Enter Director Address" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Pan Card No.</label>
                                        <input type="text" id="d_pan_no" name="d_pan_no" value="<?php echo $director_data[0]['d_pan_no'];?>" class="form-control border-primary" placeholder="Enter Director Pan Card No." autocomplete="off" required maxlength="10">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="userinput6">Aadhar Card No.</label>
                                        <input type="text" id="d_adhar_card" name="d_adhar_card" value="<?php echo $director_data[0]['d_adhar_card'];?>" class="form-control border-primary" placeholder="Enter Director Aadhar Card No." autocomplete="off" required maxlength="12" onkeypress="return isNumberKey(event)">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">PAN Certiticate</label>
                                        <input type="file" id="d_pan_card" name="d_pan_card" class="form-control border-primary">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Aadhar Certiticate</label>
                                        <input type="file" id="d_adhar_img" name="d_adhar_img" class="form-control border-primary">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="director_image_statement('<?php echo $pan_image;?>')" src="<?php echo $pan_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="director_image_statement('<?php echo $aadhar_image;?>')" src="<?php echo $aadhar_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="old_pan_img" value="<?php echo $director_data[0]['d_pan_card'];?>" readonly="">
                        <input type="hidden" name="old_adhar_img" value="<?php echo $director_data[0]['d_adhar_img'];?>" readonly="">
                        <div class="form-actions text-center">
                            <button type="submit" class="btn btn-outline-primary"><i class="la la-check-square-o"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- director show image model -->
<div class="modal fade text-left" id="director_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View image statement</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="director_pan_aadhar_image" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function director_image_statement(img_src) {
        $('#director_image_model').modal('show');
        document.getElementById("director_pan_aadhar_image").src = img_src;
    }
</script>