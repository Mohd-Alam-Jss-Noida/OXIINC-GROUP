<?php
    $package_status = $material_details[0]['status'];
    if ($package_status == 0){
        $heading = 'Reseller pending packing material request';
        $heading_color = 'text-warning';
    }
    if ($package_status == 1){
        $heading = 'Reseller approved packing material request';
        $heading_color = 'text-success';
    }
    if ($package_status == 2){
        $heading = 'Reseller rejected packing material request';
        $heading_color = 'text-danger';
    }
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title <?php echo $heading_color;?>"><?php echo $heading;?></h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a></li>
                            <li class="breadcrumb-item active"><?php echo $heading;?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <section id="file-export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered file-export responsive">
                                            <thead>
                                                <tr>
                                                    <th>Sr.No</th>
                                                    <th>Reseller ID</th>
                                                    <th>Customer Name</th>
                                                    <th>Payable<br>Amount</th>
                                                    <th>Trancation<br>Number</th>
                                                    <th>Bank Deposit<br>Statement</th>
                                                    <th>View Order Materials</th>
                                                    <th>Payment Status</th>
                                                    <th>Delivery Status</th>
                                                    <th>Payment Mode</th>
                                                    <th>Payee Bank</th>
                                                    <th>Deposit Branch</th>
                                                    <th>Reseller Remark</th>
                                                    <th>Payment Remark</th>
                                                    <th>Delivery Remark</th>
                                                    <th>Deposite Date</th>
                                                    <th>Delivery Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = 0;
                                                    //echo "<pre>";print_r($material_details);die();
                                                    if(isset($material_details) && !empty($material_details)) foreach ($material_details as $value){
                                                        $deposite_image = (isset($value['images']) && !empty($value['images']) && file_exists('reseller_files/reseller_documents/bank_deposite_statement/'.$value['images'])) ? base_url('reseller_files/reseller_documents/bank_deposite_statement/'.$value['images']) : base_url('reseller_user_assets/images/image_not_found.png');

                                                        if ($value['status'] == 0){
                                                            $status = 'Pending';
                                                            $status_color = 'btn btn-warning';
                                                        } else if ($value['status'] == 1){
                                                            $status = 'Approved';
                                                            $status_color = 'btn btn-success';
                                                        } else if ($value['status'] == 2){
                                                            $status = 'Rejected';
                                                            $status_color = 'btn btn-danger';
                                                        }

                                                        if ($value['delivery_status'] == 0){
                                                            $delivery_status = 'Pending';
                                                            $delivery_color = 'btn btn-warning';
                                                        }
                                                        if ($value['delivery_status'] == 1){
                                                            $delivery_status = 'Done';
                                                            $delivery_color = 'btn btn-success';
                                                        }
                                                        ?>
                                                        <tr>
                                                            <td><?php echo ++$i; ?></td>
                                                            <td><?php echo $value['reseller_id']; ?></td>
                                                            <td><?php echo $value['full_name']; ?></td>
                                                            <td><?php echo $value['amount']; ?></td>
                                                            <td><?php echo $value['transcation_number']; ?></td>

                                                            <td><img onclick="material_deposite_statement('<?php echo $deposite_image;?>')" src="<?php echo $deposite_image;?>" style="cursor: pointer; width: 100px; height: 100px;"></td>

                                                            <td onclick="get_packing_material(<?php echo $value['id'];?>)"><button type="button" class="btn btn-success">View Order Materials</button></td>

                                                            <td><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 <?php echo $status_color;?>" data-toggle="modal" data-target="#payment_status_model<?php echo $value['id'];?>"><?php echo $status;?></button></td>

                                                            <?php
                                                                if($value['status'] == 1){ ?>
                                                                    <td><button type="button" class="<?php echo $delivery_color;?>" data-toggle="modal" data-target="#delivery_status_model<?php echo $value['id']; ?>"><?php echo $delivery_status;?></button></td>
                                                                    <?php
                                                                }
                                                                else{ ?>
                                                                    <td><button type="button" class="<?php echo $delivery_color;?>" onclick="return confirm('After Payment approval You can Approved Delivery status.');"><?php echo $delivery_status;?></button></td>
                                                                    <?php
                                                                }
                                                            ?>

                                                            <td><?php echo $value['payment_mode'];?></td>
                                                            <td><?php echo $value['payee_bank'];?></td>
                                                            <td><?php echo $value['branchdepositebank'];?></td>
                                                            <td><?php echo $value['admin_remark']; ?></td>
                                                            <td><?php echo $value['delivery_remark']; ?></td>
                                                            <td><?php echo $value['remark'];?></td>
                                                            <td><?php echo date("d-m-Y", strtotime($value['payment_depositedate']));?></td>
                                                            <td><?php echo $value['delivery_date']; ?></td>
                                                        </tr>
                                                        <!-- Reseller package status model -->
                                                        <div class="modal fade text-left" id="payment_status_model<?php echo $value['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title">Update Packing Material Payment Status</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form class="form" action="<?php echo base_url('Reseller_admin/packing_material_payment_status_update'); ?>" method="post">
                                                                            <div class="form-body">
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <input type="hidden" name="id" value="<?php echo $value['id'];?>" class="form-control border-primary">
                                                                                            <input type="hidden" name="reseller_id" value="<?php echo $value['reseller_id'];?>" class="form-control border-primary">
                                                                                            <input type="hidden" name="url" value="<?php echo $this->uri->segment(3);?>" class="form-control border-primary">
                                                                                            <label for="">Payment Status</label>
                                                                                            <select id="status" name="status" class="form-control border-primary">
                                                                                                <option value="0"<?php echo ($value['status'] == 0) ? 'selected' : '';?>>Pending</option>
                                                                                                <option value="1"<?php echo ($value['status'] == 1) ? 'selected' : '';?>>Approved</option>
                                                                                                <option value="2"<?php echo ($value['status'] == 2) ? 'selected' : '';?>>Rejected</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <label for="">Payment Status Remark</label>
                                                                                            <input type="text" name="status_remark" class="form-control border-primary" placeholder="Enter Admin Status Remark" autocomplete="off" required>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-actions text-right">
                                                                                <button type="submit" name="submit" value="submit" class="btn btn-outline-primary">
                                                                                    <i class="la la-check-square-o"></i> Submit
                                                                                </button>
                                                                                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                                                                                    <i class="ft-x"></i> Cancel
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Reseller delivery status model -->
                                                        <div class="modal fade text-left" id="delivery_status_model<?php echo $value['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title">Update Packing Material Delivery Status</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form class="form" action="<?php echo base_url('Reseller_admin/packing_material_delivery_status_update'); ?>" method="post">
                                                                            <div class="form-body">
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <input type="hidden" name="id" value="<?php echo $value['id'];?>" class="form-control border-primary">
                                                                                            <input type="hidden" name="reseller_id" value="<?php echo $value['reseller_id'];?>" class="form-control border-primary">
                                                                                            <input type="hidden" name="url" value="<?php echo $this->uri->segment(3);?>" class="form-control border-primary">
                                                                                            <label for="">Delivery Status</label>
                                                                                            <select name="delivery_status" class="form-control border-primary">
                                                                                                <option value="0"<?php echo ($value['delivery_status'] == 0) ? 'selected' : '';?>>Pending</option>
                                                                                                <option value="1"<?php echo ($value['delivery_status'] == 1) ? 'selected' : '';?>>Approved</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <label for="">Delivery Status Remark</label>
                                                                                            <input type="text" name="delivery_remark" class="form-control border-primary" placeholder="Enter Admin Status Remark" autocomplete="off" required>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-actions text-right">
                                                                                <button type="submit" name="submit" value="submit" class="btn btn-outline-primary">
                                                                                    <i class="la la-check-square-o"></i> Submit
                                                                                </button>
                                                                                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                                                                                    <i class="ft-x"></i> Cancel
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- company show image model -->
<div class="modal fade text-left" id="material_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View image statement</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="bank_deposite_image" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Packing Material Modal -->
<div class="modal fade text-left" id="packing_material_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View Order Packing Material</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                            <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Product Name</th>
                                        <th>Product Qty</th>
                                        <th>Product Price</th>
                                        <th>Total Price</th>
                                    </tr>
                                </thead>
                                <tbody id="order_packing_material">
                                </tbody>
                            </table>
                        </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function material_deposite_statement(img_src) {
        $('#material_image_model').modal('show');
        document.getElementById("bank_deposite_image").src = img_src;
    }
    function get_packing_material(id){
        //$('#packing_material_model').modal('show');
        $.ajax({
            type:'POST',
            url:"<?php echo base_url('Reseller_dashboard/get_packing_material'); ?>",
            data:{id: id},
            success:function(data){
                var obj = JSON.parse(data);
                var html = "";
                var grand_total = 0;
                $.each(obj, function(i, data1){
                    grand_total += parseInt(data1.product_price_total);
                    html += '<tr><td>'+ (1+i) +'</td><td>'+data1.paking_material+'</td><td>'+data1.product_qty+'</td><td>'+data1.product_price+'</td><td>'+data1.product_price_total+'</td></tr>';
                });
                html += '<tr><th colspan="4">Grand Total Price</th><th>'+grand_total+'</th></tr>';
                $('#order_packing_material').html(html);
                $('#packing_material_model').modal('show');
            }
        });
    }
</script>