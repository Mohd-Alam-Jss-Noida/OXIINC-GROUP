<?php
    $notification_image = (isset($notification_data[0]['noti_image']) && !empty($notification_data[0]['noti_image']) && file_exists('reseller_files/seller_notification_image/'.$notification_data[0]['noti_image'])) ? base_url('reseller_files/seller_notification_image/'.$notification_data[0]['noti_image']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">View and Update seller notification details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">View and Update seller notification details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <div class="card">
                <div class="card-body">
                    <form class="form" action="<?php echo base_url('Reseller_admin/notification_update_submit');?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $notification_data[0]['id'];?>" readonly>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Notification Title</label>
                                        <input type="text" name="noti_title" id="noti_title" value="<?php echo $notification_data[0]['noti_title'];?>" class="form-control border-primary" placeholder="Enter Notification Title" autocomplete="off" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Notification Image</label>
                                        <input type="file" name="noti_image" id="noti_image" accept=".png, .jpg, .jpeg" class="form-control border-primary">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Notification Description</label>
                                        <textarea name="noti_description" id="noti_description" class="form-control border-primary" placeholder="Enter Notification Description"  autocomplete="off" required><?php echo $notification_data[0]['noti_description'];?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="cancel_cheque_statement('<?php echo $notification_image;?>')" src="<?php echo $notification_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="old_noti_image" value="<?php echo $notification_data[0]['noti_image'];?>" readonly>
                        <div class="form-actions text-center">
                            <button type="submit" class="btn btn-outline-primary"><i class="la la-check-square-o"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- director show image model -->
<div class="modal fade text-left" id="cheque_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View image statement</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="reseller_cancel_cheque" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function cancel_cheque_statement(img_src) {
        $('#cheque_image_model').modal('show');
        document.getElementById("reseller_cancel_cheque").src = img_src;
    }
</script>