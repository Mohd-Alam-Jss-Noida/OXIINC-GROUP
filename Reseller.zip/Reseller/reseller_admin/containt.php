<?Php
    $this->load->view('reseller_admin/header');
	$this->load->view($main_containt);
	$this->load->view('reseller_admin/footer');
?>