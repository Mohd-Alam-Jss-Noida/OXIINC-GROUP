<?php
    $cheque_img = (isset($bank_data[0]['Bank_Cancelled_Cheque']) && !empty($bank_data[0]['Bank_Cancelled_Cheque']) && file_exists('reseller_files/reseller_documents/'.$bank_data[0]['Bank_Cancelled_Cheque'])) ? base_url('reseller_files/reseller_documents/'.$bank_data[0]['Bank_Cancelled_Cheque']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">View and Update Reseller Bank details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">View and Update Reseller Bank details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <div class="card">
                <div class="card-body">
                    <form class="form" action="<?php echo base_url('Reseller_admin/bank_details_update');?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $bank_data[0]['id'];?>" readonly>
                        <input type="hidden" name="reseller_id" value="<?php echo $bank_data[0]['reseller_id'];?>" readonly>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Bank Holder Name</label>
                                        <input type="text" name="Bank_Holder_Name" value="<?php echo $bank_data[0]['Bank_Holder_Name'];?>" class="form-control border-primary" placeholder="Enter Bank Holder Name" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Bank Account Number</label>
                                        <input type="text" name="Bank_Account_Number" value="<?php echo $bank_data[0]['Bank_Account_Number'];?>" class="form-control border-primary" placeholder="Enter Bank Account Number" autocomplete="off" onkeypress="return isNumberKey(event)">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Bank IFSC Code</label>
                                        <input type="text" name="Bank_ifsc" value="<?php echo $bank_data[0]['Bank_ifsc'];?>" class="form-control border-primary" placeholder="Enter Bank IFSC Code" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Bank Name</label>
                                        <input type="text" name="Bank_name" value="<?php echo $bank_data[0]['Bank_name'];?>" class="form-control border-primary" placeholder="Enter Bank Name" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Approval Status</label>
                                        <select id="" name="rb_status" class="form-control border-primary" autocomplete="off">
                                            <option value="0" <?php echo ($bank_data[0]['rb_status'] == 0) ? 'selected = selected' : '';?>>Pending</option>
                                            <option value="1" <?php echo ($bank_data[0]['rb_status'] == 1) ? 'selected = selected' : '';?>>Approved</option>
                                            <option value="2" <?php echo ($bank_data[0]['rb_status'] == 2) ? 'selected = selected' : '';?>>Rejected</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Remark</label>
                                        <input type="text" name="admin_remark" value="<?php echo $bank_data[0]['admin_remark'];?>" class="form-control border-primary" placeholder="Enter Remark" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Cancel Check Copy</label>
                                        <input type="file" name="Bank_Cancelled_Cheque" class="form-control border-primary">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Bank Address</label>
                                        <textarea name="Bank_address" class="form-control border-primary" placeholder="Enter Bank Address"><?php echo $bank_data[0]['Bank_address'];?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="cancel_cheque_statement('<?php echo $cheque_img;?>')" src="<?php echo $cheque_img;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="old_cheque_img" value="<?php echo $bank_data[0]['Bank_Cancelled_Cheque'];?>" readonly>
                        <div class="form-actions text-center">
                            <button type="submit" class="btn btn-outline-primary"><i class="la la-check-square-o"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- director show image model -->
<div class="modal fade text-left" id="cheque_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View image statement</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="reseller_cancel_cheque" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function cancel_cheque_statement(img_src) {
        $('#cheque_image_model').modal('show');
        document.getElementById("reseller_cancel_cheque").src = img_src;
    }
</script>