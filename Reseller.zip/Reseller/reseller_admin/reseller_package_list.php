<?php
    $package_status = $package_details[0]['status'];
    if ($package_status == 0){
        $heading = 'Reseller pending packages details';
        $heading_color = 'text-warning';
    }
    if ($package_status == 1){
        $heading = 'Reseller approved packages details';
        $heading_color = 'text-success';
    }
    if ($package_status == 2){
        $heading = 'Reseller rejected packages details';
        $heading_color = 'text-danger';
    }
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title <?php echo $heading_color;?>"><?php echo $heading;?></h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a></li>
                            <li class="breadcrumb-item active"><?php echo $heading;?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <section id="file-export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered file-export responsive">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No</th>
                                                    <th>Reseller Id</th>
                                                    <th>Customer Name</th>
                                                    <th>Package</th>
                                                    <th>Amount</th>
                                                    <th>Transcation Number</th>
                                                    <th>Bank Deposite <br>Statement</th>
                                                    <th>package Status</th>
                                                    <th>Payment Mode</th>
                                                    <th>Payee Bank</th>
                                                    <th>Deposite Branch</th>
                                                    <th>Reseller Remark</th>
                                                    <th>Payment deposite Date</th>
                                                    <td>Admin Remark</td>
                                                    <th>Created Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = 0;
                                                    //echo "<pre>";print_r($package_details);die();
                                                    if(isset($package_details) && !empty($package_details)) foreach ($package_details as $value){
                                                        $deposite_image = (isset($value['images']) && !empty($value['images']) && file_exists('reseller_files/reseller_documents/bank_deposite_statement/'.$value['images'])) ? base_url('reseller_files/reseller_documents/bank_deposite_statement/'.$value['images']) : base_url('reseller_user_assets/images/image_not_found.png');

                                                        if ($value['status'] == 0){
                                                            $status = 'Pending';
                                                            $status_color = 'btn btn-warning';
                                                        } else if ($value['status'] == 1){
                                                            $status = 'Approved';
                                                            $status_color = 'btn btn-success';
                                                        } else if ($value['status'] == 2){
                                                            $status = 'Rejected';
                                                            $status_color = 'btn btn-danger';
                                                        }
                                                        ?>
                                                        <tr>
                                                            <td><?php echo ++$i;?></td>
                                                            <td><?php echo $value['reseller_id'];?></td>
                                                            <td><?php echo $value['full_name'];?></td>
                                                            <td><?php echo $value['package'];?></td>
                                                            <td><?php echo $value['amount'];?></td>
                                                            <td><?php echo $value['transcation_number'];?></td>
                                                            <td><img onclick="Package_deposite_statement('<?php echo $deposite_image;?>')" src="<?php echo $deposite_image;?>" style="cursor: pointer; width: 100px; height: 100px;"></td>
                                                            <td><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 <?php echo $status_color;?>" data-toggle="modal" data-target="#package_status_<?php echo $value['id'];?>"><?php echo $status;?></button></td>
                                                            <td><?php echo $value['payment_mode'];?></td>
                                                            <td><?php echo $value['payee_bank'];?></td>
                                                            <td><?php echo $value['branchdepositebank'];?></td>
                                                            <td><?php echo $value['remark'];?></td>
                                                            <td><?php echo $value['payment_depositedate'];?></td>
                                                            <td><?php echo $value['status_remark'];?></td>
                                                            <td><?php echo date("d-m-Y H:i:s", strtotime($value['created_date']));?></td>
                                                        </tr>
                                                        <!-- Reseller package status model -->
                                                        <div class="modal fade text-left" id="package_status_<?php echo $value['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title">Update Package Approval Status</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form class="form" action="<?php echo base_url('Reseller_admin/reseller_package_status_update'); ?>" method="post">
                                                                            <div class="form-body">
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <input type="hidden" name="id" value="<?php echo $value['id'];?>" class="form-control border-primary">
                                                                                            <input type="hidden" name="reseller_id" value="<?php echo $value['reseller_id'];?>" class="form-control border-primary">
                                                                                            <input type="hidden" name="url" value="<?php echo $this->uri->segment(3);?>" class="form-control border-primary">
                                                                                            <label for="">Package Approval Status</label>
                                                                                            <select id="status" name="status" class="form-control border-primary">
                                                                                                <option value="0"<?php echo ($value['status'] == 0) ? 'selected' : '';?>>Pending</option>
                                                                                                <option value="1"<?php echo ($value['status'] == 1) ? 'selected' : '';?>>Approved</option>
                                                                                                <option value="2"<?php echo ($value['status'] == 2) ? 'selected' : '';?>>Rejected</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <label for="">Admin Status Remark</label>
                                                                                            <input type="text" name="status_remark" class="form-control border-primary" placeholder="Enter Admin Status Remark" autocomplete="off" required>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-actions text-right">
                                                                                <button type="submit" name="submit" value="submit" class="btn btn-outline-primary">
                                                                                    <i class="la la-check-square-o"></i> Submit
                                                                                </button>
                                                                                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                                                                                    <i class="ft-x"></i> Cancel
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- company show image model -->
<div class="modal fade text-left" id="package_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View image statement</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="bank_deposite_image" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function Package_deposite_statement(img_src) {
        $('#package_image_model').modal('show');
        document.getElementById("bank_deposite_image").src = img_src;
    }
</script>