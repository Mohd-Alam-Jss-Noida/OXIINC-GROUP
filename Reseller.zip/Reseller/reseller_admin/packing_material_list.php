<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">Packing Material Details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a></li>
                            <li class="breadcrumb-item active">Packing Material Details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <section id="file-export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <!-- <h4 class="card-title">Packing Material</h4> -->
                                <div class="heading-elements">
                                    <ul class="list-inline mb-0">
                                        <li>
                                            <div class="form-group">
                                                <button type="button" class="btn btn-info btn-min-width mr-1 mb-1" data-toggle="modal" data-target="#packing_material_model" onclick="packing_material_add()">Add Material <i class="ft-settings icon-plus"></i></button>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered file-export responsive">
                                            <thead>
                                                <tr>
                                                    <th>Sr.No.</th>
                                                    <th>Material Name</th>
                                                    <th>Material Price</th>
                                                    <th>Created Date</th>
                                                    <th>Status</th>
                                                    <th>Action(Edit)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = 0;
                                                    if(isset($reseller_packing) && !empty($reseller_packing)) foreach ($reseller_packing as $value){
                                                        if ($value['status'] == 1){
                                                            $status = 'Active';
                                                            $status_color = 'btn btn-success';
                                                        }
                                                        else{
                                                            $status = 'De-Active';
                                                            $status_color = 'btn btn-danger';
                                                        }
                                                        ?>
                                                        <tr>
                                                            <td><?php echo ++$i;?></td>
                                                            <td><?php echo $value['product_name'];?></td>
                                                            <td><?php echo $value['product_price'];?></td>
                                                            <td><?php echo date("m-d-Y H:i:s", strtotime($value['created_date']));?></td>
                                                            <td><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 <?php echo $status_color;?>" data-toggle="modal" data-target="#material_status_<?php echo $value['id'];?>"><?php echo $status;?></button></td>
                                                            <td><button type="button" class="btn btn-primary btn-min-width box-shadow-2 mr-1 mb-1" data-toggle="modal" data-target="#packing_material_model" onclick="packing_material_update('<?php echo $value['product_name'];?>', <?php echo $value['product_price'];?>, <?php echo $value['id'];?>)">Edit <i class="ft-settings icon-edit"></i></button></td>
                                                        </tr>
                                                        <!-- packing material status model -->
                                                        <div class="modal fade text-left" id="material_status_<?php echo $value['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title">Update Packing Material Status</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form class="form" action="<?php echo base_url('Reseller_admin/packing_material_status'); ?>" method="post">
                                                                            <div class="form-body">
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="form-group">
                                                                                            <input type="hidden" name="id" value="<?php echo $value['id'];?>" class="form-control border-primary">
                                                                                            <label for="">Approval Status</label>
                                                                                            <select id="status" name="status" class="form-control border-primary">
                                                                                                <option value="1"<?php echo ($value['status'] == 1) ? 'selected' : '';?>>Active</option>
                                                                                                <option value="0"<?php echo ($value['status'] == 0) ? 'selected' : '';?>>De-Active</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-actions text-right">
                                                                                <button type="submit" name="submit" value="submit" class="btn btn-outline-primary">
                                                                                    <i class="la la-check-square-o"></i> Submit
                                                                                </button>
                                                                                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                                                                                    <i class="ft-x"></i> Cancel
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- packing material update model -->
<div class="modal fade text-left" id="packing_material_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <form class="form" action="<?php echo base_url('Reseller_admin/packing_material_add_update'); ?>" method="POST">
                    <div class="form-body">
                        <div class="row">
                            <h2 class="modal_title" id="title_heading"></h2>
                            <div class="col-md-12">
                                <input type="hidden" name="id" id="id" class="form-control border-primary">
                                <div class="form-group">
                                    <label for="">Material Name</label>
                                    <input type="text" name="product_name" id="product_name" class="form-control border-primary" placeholder="Enter Material Name" autocomplete="off" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Material Price</label>
                                    <input type="text" name="product_price" id="product_price" class="form-control border-primary" placeholder="Enter Material Price" onkeypress="return isNumberKey(event)" autocomplete="off" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions text-right">
                        <button type="submit" name="submit" value="submit" class="btn btn-outline-primary">
                            <i class="la la-check-square-o"></i> Submit
                        </button>
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                            <i class="ft-x"></i> Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function packing_material_update(product_name, product_price, id){
        $('#product_name').val(product_name);
        $('#product_price').val(product_price);
        $('#id').val(id);
        $('#title_heading').text("Update Packing Material");
    }

    function packing_material_add() {
        $('#product_name').val('');
        $('#product_price').val('');
        $('#id').val('');
        $('#title_heading').text("Add Packing Material");
    }
</script>