<?php
    $product_image = (isset($multiple_image[0]['Product_Picture_Mult']) && !empty($multiple_image[0]['Product_Picture_Mult']) && file_exists('uploads/Multiple_Picture/'.$multiple_image[0]['Product_Picture_Mult'])) ? base_url('uploads/Multiple_Picture/'.$multiple_image[0]['Product_Picture_Mult']) : base_url('reseller_user_assets/images/image_not_found.png');
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">View and update reseller product details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a>
                            </li>
                            <li class="breadcrumb-item active">View and update reseller product details
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg');?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <div class="card">
                <div class="card-body">
                    <form class="form" action="<?php echo base_url('Reseller_admin/reseller_product_submit');?>" method="POST" enctype="multipart/form-data">
                        <div class="form-body">
                            <input type="hidden" name="ID" value="<?php echo $product_details[0]['ID'];?>">
                            <input type="hidden" name="reseller_id" value="<?php echo $product_details[0]['reseller_id'];?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Select Category</label>
                                        <select class="form-control border-primary" name="category_id" id="product_category" autocomplete="off" required onchange="getSubCategory();">
                                            <option value="">Select category</option>
                                            <?php if(isset($category_name) && !empty($category_name)) foreach ($category_name as $category_key => $c_value) { ?>
                                                <option value="<?php echo $c_value['category_id']; ?>" <?php if($c_value['category_id'] == $product_details[0]['category_id']){ echo "selected"; } ?> ><?php echo $c_value['category_name']; ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Select Sub Category</label>
                                        <select class="form-control border-primary" name="sub_category_id" id="sub_category_id" autocomplete="off" required onchange="getproCategory();">
                                            <option value="" data-id="">Select Sub Category</option>
                                            <?php if(isset($sub_category_name) && !empty($sub_category_name)) foreach ($sub_category_name as $category_key => $c_value) { ?>
                                            <option value="<?php echo $c_value['sub_category_id']; ?>" <?php if($c_value['sub_category_id'] == $product_details[0]['sub_category_id']){ echo "selected"; } ?> ><?php echo $c_value['sub_category_name'];?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Select Product Category</label>
                                        <select class="form-control border-primary" name="product_category_id" id="product_category_id" autocomplete="off" required>
                                            <option value="">Select Product Category</option>
                                            <?php if(isset($product_category_name) && !empty($product_category_name)) foreach ($product_category_name as $category_key => $c_value) {?>
                                                <option value="<?php echo $c_value['product_category_id']; ?>" <?php if($c_value['product_category_id'] == $product_details[0]['product_category_id']){ echo "selected"; } ?> ><?php echo $c_value['product_category_name']; ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Product Name</label>
                                        <input type="text" name="Product_Name" value="<?php echo $product_details[0]['Product_Name'];?>" class="form-control border-primary" placeholder="Enter Product Name" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Product MRP</label>
                                            <input type="text" name="Original_Prices" value="<?php echo $product_details[0]['Original_Prices'];?>" class="form-control border-primary" placeholder="Enter Product MRP" autocomplete="off" required onkeypress="return isNumberKey(event)">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="">Product Price</label>
                                            <input type="text" name="Prices" value="<?php echo $product_details[0]['Prices'];?>" class="form-control border-primary" placeholder="Enter Product Price" autocomplete="off" required onkeypress="return isNumberKey(event)">
                                        </div>
                                    </div>
                                </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Shipping Charges</label>
                                        <input type="text" name="Shipping_Charges" value="<?php echo $product_details[0]['Shipping_Charges'];?>" class="form-control border-primary" placeholder="Enter Shipping Charges" autocomplete="off" required onkeypress="return isNumberKey(event)">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">GST Percentage</label>
                                        <select class="form-control border-primary" name="GST_Persentage" autocomplete="off" required>
                                            <option value="">Select GST Persentage</option>
                                            <option value="0" <?php echo ($product_details[0]['GST_Persentage'] == 0) ? 'selected = selected' : '';?>>0%</option>
                                            <option value="5" <?php echo ($product_details[0]['GST_Persentage'] == 5) ? 'selected = selected' : '';?>>5%</option>
                                            <option value="12" <?php echo ($product_details[0]['GST_Persentage'] == 12) ? 'selected = selected' : '';?>>12%</option>
                                            <option value="18" <?php echo ($product_details[0]['GST_Persentage'] == 18) ? 'selected = selected' : '';?>>18%</option>
                                            <option value="28" <?php echo ($product_details[0]['GST_Persentage'] == 28) ? 'selected = selected' : '';?>>28%</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Product Color</label>
                                        <input type="text" name="product_color" value="<?php echo $product_details[0]['product_color'];?>" class="form-control border-primary" placeholder="Enter Product Color" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">HSN Code</label>
                                        <input type="text" name="hsn_code" value="<?php echo $product_details[0]['hsn_code'];?>" class="form-control border-primary" placeholder="Enter HSN Code" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Short Info</label>
                                        <textarea name="Short_Description" class="form-control border-primary" placeholder="Enter Short Info"><?php echo $product_details[0]['Short_Description'];?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Long Info</label>
                                        <textarea name="large_Description" class="form-control border-primary" placeholder="Enter Long Info"><?php echo $product_details[0]['large_Description'];?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Upload Product Image</label>
                                        <input type="file" name="Product_Picture_Mult" class="form-control border-primary">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Product Approval States</label>
                                        <select class="form-control border-primary" name="product_approval_status" autocomplete="off">
                                            <option value="0" <?php echo ($product_details[0]['product_approval_status'] == 0) ? 'selected = selected' : '';?>>pending</option>
                                            <option value="1" <?php echo ($product_details[0]['product_approval_status'] == 1) ? 'selected = selected' : '';?>>Approved</option>
                                            <option value="2" <?php echo ($product_details[0]['product_approval_status'] == 2) ? 'selected = selected' : '';?>>Rejected</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <img onclick="product_image_statement('<?php echo $product_image;?>')" src="<?php echo $product_image;?>" style="cursor: pointer; width: 200px;">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Approval States Remark</label>
                                        <input type="text" name="admin_remark" value="<?php echo $product_details[0]['admin_remark'];?>" class="form-control border-primary" placeholder="Enter Approval States Remark" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="old_product_img" value="<?php echo $multiple_image[0]['Product_Picture_Mult'];?>" readonly="">
                        <input type="hidden" name="image_id" value="<?php echo $multiple_image[0]['ID'];?>" readonly="">
                        <div class="form-actions text-center">
                            <button type="submit" class="btn btn-outline-primary"><i class="la la-check-square-o"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- product show image model -->
<div class="modal fade text-left" id="product_image_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="headding-01">View Product Image</h2>
            </div>
            <div class="modal-body">
                <form class="form">
                    <div class="form-group">
                        <img src="" id="show_product_image" style="width: 100%">
                    </div>
                    <div class="form-actions text-right">
                        <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function product_image_statement(img_src) {
        $('#product_image_model').modal('show');
        document.getElementById("show_product_image").src = img_src;
    }

    function getSubCategory(){
        var category_id = $('#product_category').val();
        var postData = {
            'category_id' : category_id
        }
        $.post('<?php echo base_url('Product/getSubCategory')?>',postData,function(data){
            var subcats = $.parseJSON(data);
            $('#sub_category_id').html('');
            var html = '<option value="">Select Sub Category</option>';
            $.each(subcats,function(i,val){
                html += '<option value="'+val.sub_category_id+'" data-id="'+val.sub_category_name+'">'+val.sub_category_name+'</option>';
            })
            $('#sub_category_id').html(html);
            $('#product_category_id').html('');
            $('#product_category_id').html('<option value="">Select product Category</option>');
        });
    }

    function getproCategory(){
        var sub_category_id = $('#sub_category_id').val();
        var postData = {
            'sub_category_id' : sub_category_id
        }
        $.post('<?php echo base_url('Product/getproCategory')?>',postData,function(data){
            var subcats = $.parseJSON(data);
            $('#product_category_id').html('');
            var html = '<option value="">Select product Category</option>';
            $.each(subcats,function(i,val){
                html += '<option value="'+val.product_category_id+'" data-id="'+val.product_category_name+'">'+val.product_category_name+'</option>';
            })
            $('#product_category_id').html(html);
        });
    }
</script>