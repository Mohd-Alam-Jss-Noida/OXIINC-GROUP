<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title><?php echo ($title) ? $title : 'Reseller Admin Dashboard';?></title>
    <link rel="apple-touch-icon" href="<?php echo base_url('reseller_admin_assets/');?>images/ico/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('reseller_admin_assets/');?>images/ico/apple-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>vendors/css/tables/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>vendors/css/tables/extensions/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>vendors/css/tables/datatable/buttons.bootstrap4.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/core/menu/menu-types/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/core/colors/palette-gradient.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/style.css">
    <!-- END: Custom CSS-->

    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="//at.alicdn.com/t/font_o5hd5vvqpoqiwwmi.css">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/fontawesome.min.css">
    <style type="text/css">
        .menu-expanded .navbar .navbar-header .brand-logo{
            display: none !important;
        }
        @media (max-width: 767.98px){
            .header-navbar .navbar-header .navbar-brand .brand-logo{
                display: none;
            }
        }
    </style>
</head>
<body class="vertical-layout vertical-menu 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu" data-col="2-columns">
    <nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-light bg-info navbar-shadow">
        <div class="navbar-wrapper">
            <div class="navbar-header">
                <ul class="nav navbar-nav flex-row">
                    <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="javascript:void(0);"><i class="las la-bars font-large-1"></i></a></li>
                    <li class="nav-item">
                        <a class="navbar-brand" href="<?php echo site_url('Reseller_admin');?>">
                            <img class="brand-logo" alt="modern admin logo" src="<?php echo base_url('reseller_admin_assets/');?>images/ico/apple-icon.png">
                            <h3 class="brand-text"><img src="<?php echo base_url('reseller_admin_assets/');?>images/logo/logo123.png" width="150"></h3>
                        </a>
                    </li>
                    <li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a></li>
                </ul>
            </div>
            <div class="navbar-container content">
                <div class="collapse navbar-collapse" id="navbar-mobile">
                    <ul class="nav navbar-nav mr-auto float-left">
                        <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="javascript:void(0);"><i class="las la-bars font-large-1"></i></a></li>
                    </ul>
                    <ul class="nav navbar-nav float-right">
                        <li class="dropdown dropdown-user nav-item">
                            <a class="dropdown-toggle nav-link dropdown-user-link" href="javascript:void(0);" data-toggle="dropdown"><span class="mr-1 user-name text-bold-700"><?php echo ($this->session->userdata('user_name')) ? strtoupper($this->session->userdata('user_name')) : strtolower($this->session->userdata('user_email'));?></span><span class="avatar avatar-online"><img src="<?php echo base_url('reseller_admin_assets/');?>images/portrait/small/avatar-s-19.png" alt="avatar"><i></i></span></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="<?php echo site_url('Reseller_login/logout');?>"><i class="ft-power"></i> Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow " data-scroll-to-active="true">
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" navigation-header"><span>Main Menu</span><i class="la la-ellipsis-h" data-toggle="tooltip" data-placement="right" data-original-title="Main Menu"></i>
                </li>
                <li class="nav-item"><a href="<?php echo site_url('Reseller_admin');?>"><i class="la la-home"></i><span class="menu-title">Home </span></a></li>
                <li class=" nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Reseller Packing Material</span></a>
                    <ul class="menu-content">
                        <li><a class="active" href="<?php echo site_url('Reseller_admin/packing_material_list');?>"><i></i><span>Packing Material Listing</span></a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Reseller Accounts</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/pending_reseller');?>"><i></i><span>Pending Reseller List</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/approved_reseller');?>"><i></i><span>Approved Reseller List</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/rejected_reseller');?>"><i></i><span>Rejected Reseller List</span></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Reseller Product</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_pending_product');?>"><i></i><span>Reseller Pending Product</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_approved_product');?>"><i></i><span>Reseller Approved Product</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_rejected_product');?>"><i></i><span>Reseller Rejected Product</span></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Reseller Packages</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_package/0');?>"><i></i><span>Reseller Pending Packages</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_package/1');?>"><i></i><span>Reseller Approved Packages</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_package/2');?>"><i></i><span>Reseller Rejected Packages</span></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Packing Material Request</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/packing_material_request/0');?>"><i></i><span>Material Request Pending</span></a></li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/packing_material_request/1');?>"><i></i><span>Material Request Approved</span></a>
                        </li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/packing_material_request/2');?>"><i></i><span>Material Request Rejected</span></a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Reseller Payout Request</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/bank_format_payout_request');?>"><i></i><span>Bank Format Payout Request</span></a></li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/bank_payout_upload_excel');?>"><i></i><span>Bank Payout Upload Excel</span></a></li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_payout_request/0');?>"><i></i><span>Pending Payout Request</span></a></li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_payout_request/1');?>"><i></i><span>Approved Payout Request</span></a></li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/reseller_payout_request/2');?>"><i></i><span>Rejected Payout Request</span></a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="javascript:void(0);"><i class="la la-plus-circle"></i><span class="menu-title">Reseller Notification</span></a>
                    <ul class="menu-content">
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/notification');?>"><i></i><span>Add Notification</span></a></li>
                        <li><a class="menu-item" href="<?php echo site_url('Reseller_admin/notification_details');?>"><i></i><span>Notification Details</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>

