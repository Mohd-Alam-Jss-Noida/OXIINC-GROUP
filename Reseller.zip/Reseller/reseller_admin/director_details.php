<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">Director Details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a></li>
                            <li class="breadcrumb-item active">Director Details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg');?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <section id="file-export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered file-export responsive">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No</th>
                                                    <th>Name</th>
                                                    <th>Email Id</th>
                                                    <th>Contact number</th>
                                                    <th>View Details</th>
                                                    <th>Date of joining</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = 0;
                                                    if(isset($director_data) && !empty($director_data)) foreach ($director_data as $value){ ?>
                                                        <tr>
                                                            <td><?php echo ++$i;?></td>
                                                            <td><?php echo $value['d_name'];?></td>
                                                            <td><?php echo $value['d_email'];?></td>
                                                            <td><?php echo $value['d_mobile'];?></td>
                                                            <td><a href="<?php echo base_url('Reseller_admin/director_details_edit/'.$value['d_id']);?>"><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 btn btn-success">Director Details</button></a></td>
                                                            <td><?php echo date("m-d-Y H:i:s", strtotime($value['d_date_time']));?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>