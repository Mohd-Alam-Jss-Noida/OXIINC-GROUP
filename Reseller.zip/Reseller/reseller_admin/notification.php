<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title">Add seller notification details</h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">Add seller notification details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="card">
                <div class="card-body">
                    <form class="form" action="<?php echo base_url('Reseller_admin/notification_insert');?>" method="POST" enctype="multipart/form-data">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Notification Title</label>
                                        <input type="text" name="noti_title" id="noti_title" value="<?php echo $bank_data[0]['noti_title'];?>" class="form-control border-primary" placeholder="Enter Notification Title" autocomplete="off" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Notification Image</label>
                                        <input type="file" name="noti_image" id="noti_image" class="form-control border-primary" accept=".png, .jpg, .jpeg" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Notification Description</label>
                                        <textarea name="noti_description" id="noti_description" class="form-control border-primary" placeholder="Enter Notification Description" autocomplete="off" required><?php echo $bank_data[0]['noti_description'];?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-actions text-center">
                            <button type="submit" class="btn btn-outline-primary"><i class="la la-check-square-o"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>