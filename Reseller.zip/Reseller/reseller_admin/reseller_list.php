<?php
    $reseller_status = $reseller_data[0]['approval_status'];
    if ($reseller_status == 0){
        $heading = '<b>Pending</b> Reseller details';
        $heading_color = 'text-warning';
    }
    if ($reseller_status == 1){
        $heading = '<b>Approved</b> Reseller details';
        $heading_color = 'text-success';
    }
    if ($reseller_status == 2){
        $heading = '<b>Rejected</b> Reseller details';
        $heading_color = 'text-danger';
    }
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title <?php echo $heading_color;?>"><?php echo $heading;?></h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a></li>
                            <li class="breadcrumb-item active"><?php echo $heading;?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <section id="file-export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered file-export responsive">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No</th>
                                                    <th>Reseller Id</th>
                                                    <th>Name</th>
                                                    <th>Email Id</th>
                                                    <th>Contact number</th>
                                                    <th>Mobile verify</th>
                                                    <th>Director Details</th>
                                                    <th>Company Details</th>
                                                    <th>Bank Details</th>
                                                    <th>Date of joining</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = 0;
                                                    //echo "<pre>";print_r($reseller_data);die();
                                                    if(isset($reseller_data) && !empty($reseller_data)) foreach ($reseller_data as $value){

                                                        if ($value['mobile_verify'] == 1){
                                                            $mobile_status = 'Verified';
                                                            $mobile_color = 'badge badge-success';
                                                        }
                                                        else{
                                                            $mobile_status = 'Not Verify';
                                                            $mobile_color = 'badge badge-danger';
                                                        }
                                                        ?>
                                                        <tr>
                                                            <td><?php echo ++$i;?></td>
                                                            <td><?php echo $value['id'];?></td>
                                                            <td><?php echo $value['full_name'];?></td>
                                                            <td><?php echo $value['email'];?></td>
                                                            <td><?php echo $value['mobile_number'];?></td>
                                                            <td><center><span class="<?php echo $mobile_color;?>"><?php echo $mobile_status;?></span></center></td>
                                                            <td><a href="<?php echo base_url('Reseller_admin/director_details/'.$value['id']);?>"><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 btn btn-primary">Director Details</button></a></td>
                                                            <td><a href="<?php echo base_url('Reseller_admin/company_details/'.$value['id']);?>"><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 btn btn-primary">Company Details</button></a></td>
                                                            <td><a href="<?php echo base_url('Reseller_admin/bank_details/'.$value['id']);?>"><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 btn btn-success">Verify Document</button></a></td>
                                                            <td><?php echo date("d-m-Y H:i:s", strtotime($value['date_of_joining']));?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>