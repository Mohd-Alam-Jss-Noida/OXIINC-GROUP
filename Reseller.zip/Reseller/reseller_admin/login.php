<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
		<title>Reseller Admin</title>
		<link rel="apple-touch-icon" href="<?php echo base_url('reseller_admin_assets/');?>images/ico/apple-icon.png">
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('reseller_admin_assets/');?>images/ico/apple-icon.png">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
		<!-- BEGIN: Vendor CSS-->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>vendors/css/vendors.min.css">
		<!-- END: Vendor CSS-->
		<!-- BEGIN: Theme CSS-->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/bootstrap-extended.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/components.min.css">
		<!-- END: Theme CSS-->
		<!-- BEGIN: Custom CSS-->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('reseller_admin_assets/');?>css/style.css">
		<!-- END: Custom CSS-->
		<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="//at.alicdn.com/t/font_o5hd5vvqpoqiwwmi.css">
		<style type="text/css">
			@media (min-width: 992px){
			body.vertical-layout.vertical-menu .content, body.vertical-layout.vertical-menu .footer {
			margin-left:0px;
			}
			}
			@media (max-width: 992.98px){
			.header-navbar .navbar-header {
			width: 100%!important;
			padding: .5rem 1rem;
			position: relative;
			}
			.navbar-light .navbar-header .navbar-nav .nav-link, .navbar-semi-light .navbar-header .navbar-nav .nav-link {
			color: #fff;
			}
			.header-navbar .navbar-header .navbar-brand {
			position: absolute;
			left: 50%;
			top: 0;
			transform: translate(-50%, 0);
			}
			body.vertical-layout.vertical-menu .main-menu .navigation li.navigation-header span, body.vertical-layout.vertical-menu .main-menu .navigation>li>a>span, body.vertical-layout.vertical-menu .navbar .navbar-header .brand-text {
			visibility: visible;
			}
			#login_footer{
			margin-left: 0px;
			}
			}
		</style>
	</head>
	<body class="vertical-layout vertical-menu 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu" data-col="2-columns">
		<!-- BEGIN: Header-->
		<nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-light bg-info navbar-shadow">
			<div class="navbar-wrapper">
				<div class="navbar-header">
					<ul class="nav navbar-nav flex-row">
						<li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="las la-bars font-large-1"></i></a></li>
						<li class="nav-item">
							<a class="navbar-brand" href="javascript:void(0);">
								<h3 class="brand-text"><img src="<?php echo base_url('reseller_admin_assets/');?>images/logo/logo123.png" width="150"></h3>
							</a>
						</li>
						<li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- END: Header-->
		<!-- BEGIN: Content-->
		<div class="app-content content">
		<div class="content-overlay"></div>
		<div class="content-wrapper" id="login_form_container">
			<div class="content-body">
				<section id="basic-form-layouts">
					<div class="row justify-content-md-center">
						<div class="col-md-6">
							<div class="card">
								<div class="card-content collapse show">
									<div class="card-body">
										<div class="card-text">
											<h2>
												<center>Reseller Admin Login Form</center>
											</h2>
										</div>
										<?php if($this->session->flashdata('msg')) { ?>
										<div class="alert alert-danger text-center" id="danger-alert" style="margin-top: 20px;">
											<button type="button" class="close" data-dismiss="alert">x</button>
											<strong>Error Message! </strong><?php echo $this->session->flashdata('msg');?>
										</div>
										<?php } ?>
										<form class="form" action="<?php echo base_url('Reseller_login/process');?>" method="POST">
											<div class="form-body">
												<div class="form-group">
													<label for="">Email</label>
													<div class="position-relative has-icon-left">
														<input type="email" name="user_email" id="user_email" value="<?php echo set_value('user_email'); ?>" class="form-control" placeholder="Email" autocomplete="off">
														<div class="form-control-position">
															<i class="ft-user"></i>
														</div>
														<span class="text-danger"><?php echo form_error('user_email');?></span>
													</div>
												</div>
												<div class="form-group">
													<label for="">Password</label>
													<div class="position-relative has-icon-left">
														<input type="password" name="user_password" id="user_password" value="<?php echo set_value('user_password'); ?>" class="form-control" placeholder="Password" autocomplete="off">
														<div class="form-control-position">
															<i class="las la-lock"></i>
														</div>
														<span class="text-danger"><?php echo form_error('user_password');?></span>
													</div>
												</div>
												<div class="form-actions center">
													<button type="submit" name="submit" value="submit" class="btn btn-primary"><i class="la la-check-square-o"></i> Login</button>
												</div>
										</form>
										</div>
									</div>
								</div>
							</div>
						</div>
				</section>
				</div>
			</div>
		</div>
		<!-- END: Content-->
		<div class="sidenav-overlay"></div>
		<div class="drag-target"></div>
		<!-- BEGIN: Footer-->
		<footer class="footer footer-static footer-light navbar-border navbar-shadow" id="login_footer">
			<p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2020 <a class="text-bold-800 grey darken-2" href="https://www.oxiincgroup.com/" target="_blank">Oxiincgroup</a></span></p>
		</footer>
		<!-- END: Footer-->
	</body>
	<!-- END: Body-->
</html>

