<?php
    $product_status = $product_data[0]['product_approval_status'];
    if ($product_status == 0){
        $heading = 'Reseller pending product details';
        $heading_color = 'text-warning';
    }
    if ($product_status == 1){
        $heading = 'Reseller approved product details';
        $heading_color = 'text-success';
    }
    if ($product_status == 2){
        $heading = 'Reseller rejected product details';
        $heading_color = 'text-danger';
    }
?>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <h3 class="content-header-title <?php echo $heading_color;?>"><?php echo $heading;?></h3>
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url('Reseller_admin');?>">Home</a></li>
                            <li class="breadcrumb-item active"><?php echo $heading;?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <?php
            if($this->session->flashdata('msg')){
                $flash_array = $this->session->flashdata('msg'); ?>
                <div class="fadeout_flash_msg <?php echo $flash_array['text_class'];?>" id="flash_msg"><?php echo $flash_array['text_msg'];?></div>
            <?php } ?>
            <section id="file-export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered file-export responsive">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No</th>
                                                    <th>Product Id</th>
                                                    <th>Reseller Id</th>
                                                    <th>Reseller Name</th>
                                                    <th>Product Name</th>
                                                    <th>Original Prices</th>
                                                    <th>Prices</th>
                                                    <th>GST Persentage</th>
                                                    <th>Shipping Charges</th>
                                                    <th>Stock Status</th>
                                                    <th>Product Status</th>
                                                    <th>Created Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = 0;
                                                    //echo "<pre>";print_r($product_data);die();
                                                    if(isset($product_data) && !empty($product_data)) foreach ($product_data as $value){ ?>
                                                        <tr>
                                                            <td><?php echo ++$i;?></td>
                                                            <td><?php echo $value['ID'];?></td>
                                                            <td><?php echo $value['reseller_id'];?></td>
                                                            <td><?php echo $value['full_name'];?></td>
                                                            <td><?php echo $value['Product_Name'];?></td>
                                                            <td><?php echo $value['Original_Prices'];?></td>
                                                            <td><?php echo $value['Prices'];?></td>
                                                            <td><?php echo $value['GST_Persentage'];?></td>
                                                            <td><?php echo $value['Shipping_Charges'];?></td>
                                                            <td><?php echo $value['stock_status'];?></td>
                                                            <td><button type="button" class="btn-min-width box-shadow-2 mr-1 mb-1 btn btn-success" onclick="reseller_product_edit(<?php echo $value['ID'];?>, <?php echo $value['reseller_id'];?>);">View Status</button></td>
                                                            <td><?php echo date("d-m-Y H:i:s", strtotime($value['created']));?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<script type="text/javascript">
    function reseller_product_edit(ID, reseller_id){
        window.location = "<?php echo base_url('Reseller_admin/reseller_product_edit/');?>" + ID + "/" + reseller_id;
    }
</script>