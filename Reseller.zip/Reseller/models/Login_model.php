<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {
    function __construct() {
        $this->tableName = 'custumer_login';
        $this->primaryKey = 'id';
    }
    
    /*
     * Insert / Update facebook profile data into the database
     * @param array the data for inserting into the table
     */
    public function checkUser($userData = array()){
        if(!empty($userData)){
            //check whether user data already exists in database with same oauth info
            $this->db->select($this->primaryKey);
            $this->db->from($this->tableName);
            $this->db->where(array('oauth_provider'=>$userData['oauth_provider'], 'oauth_uid'=>$userData['oauth_uid']));
            $prevQuery = $this->db->get();
            $prevCheck = $prevQuery->num_rows();
            
            if($prevCheck > 0){
                $prevResult = $prevQuery->row_array();
                
                //update user data
                $userData['modified_on'] = date("Y-m-d H:i:s");
                $update = $this->db->update($this->tableName, $userData, array('id' => $prevResult['id']));
                
                //get user ID
                $userID = $prevResult['id'];
            }else{
                //insert user data
                $insert = $this->db->insert($this->tableName, $userData);
                
                //get user ID
                $userID = $this->db->insert_id();
            }
        }
        
        //return user ID
        return $userID?$userID:FALSE;
    }
    function Is_already_register($id)
     {
      $this->db->where('oauth_uid', $id);
      $query = $this->db->get('custumer_login');
      $rowcnt = $query->num_rows(); 
      if($rowcnt > 0)
      {
       return 1;
      }
      else
      {
       return 0;
      }
     }

     function Update_user_data($data, $id)
     {
      $this->db->where('oauth_uid', $id);
      $this->db->update('custumer_login', $data);
     }

     function Insert_user_data($data)
     {
      $this->db->insert('custumer_login', $data);
     }
     function getDataByOauthId($id){
        $this->db->select('id as user_id');
        $this->db->from('custumer_login');
        $this->db->where('oauth_uid', $id);
        $query = $this->db->get()->row_array();
        return $query['user_id'];
     }
}