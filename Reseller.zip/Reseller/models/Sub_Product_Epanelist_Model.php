<?php

class Sub_Product_Epanelist_Model extends CI_Model
{
 function fetch_filter_type($type,$db)
 {
  $this->db->distinct();
  $this->db->select($type);
  $this->db->from($db);
  $this->db->where('status', '1');
  $this->db->where('product_category_id', $this->uri->segment(3));
  return $this->db->get();
 }

 function make_query($minimum_price, $maximum_price, $brand, $ram , $cat,$sub_cat)
 {
  if(is_numeric($cat) && $cat!='js'){
  $query = "
  SELECT w.* FROM wellness w, size_manage sm 
  WHERE w.is_deleted = 0 AND w.status = '1' AND w.product_category_id=".$cat." AND sm.p_id=w.id
  ";

  if ($this->session->userdata('in_logged_in')) {
   
  }else{
     $query .= " AND w.visible='0'";
  }

  if(isset($minimum_price, $maximum_price) && !empty($minimum_price) &&  !empty($maximum_price))
  {
   $query .= "
    AND cast(w.Prices as unsigned) BETWEEN '".$minimum_price."' AND '".$maximum_price."'
   ";
  }

  if(isset($brand))
  {
   $brand_filter = implode("','", $brand);
   $query .= "
    AND w.company_name IN('".$brand_filter."')
   ";
  }

   if(isset($ram))
  {
   // $query .= "AND sm.p_id=w.id"; 
   $ram_filter = implode("','", $ram);
   $query .= "
    AND sm.size IN('".$ram_filter."')
   ";
  }
   $query .= "GROUP BY w.id";  
  return $query;
}
 }

 function count_all($minimum_price, $maximum_price, $brand, $ram ,$cat,$sub_cat){
  $query = $this->make_query($minimum_price, $maximum_price, $brand, $ram ,$cat,$sub_cat);
  $data = $this->db->query($query);
  return $data->num_rows();
 }

function fetch_data($limit, $start, $minimum_price, $maximum_price, $brand, $ram,  $order ,$cat ,$sub_cat){
    $data = array();
    $query = $this->make_query($minimum_price, $maximum_price, $brand, $ram , $cat ,$sub_cat);
    if($order == '1'){
      $query .=  ' ORDER BY Prices ASC LIMIT '.abs($start).', ' . abs($limit);
    } else if($order == '2'){
      $query .=  ' ORDER BY Prices DESC LIMIT '.abs($start).', ' . abs($limit);
    } elseif($order == '3'){
      $query .=  ' ORDER BY ID DESC LIMIT '.abs($start).', ' . abs($limit);
    } else{
      $query .=  ' ORDER BY Prices ASC LIMIT '.abs($start).', ' . abs($limit);
    }
  
  $data = $this->db->query($query);  
  $output = '';
  $stock = '';
  $starttimestamp = '';
  $endtimestamp = '';
  $difference = '';
  $_url='';
  if(count($data) > 0){
   $_url=base_url('cart/product_view');
   foreach($data->result_array() as $row)
   {
       if($row['stock_status']=='0' || $row['stock_status']=='' ){
         $stock= 'Restocking soon';          
           
       }else{
        $stock= '';
       }
       if (!empty($row['reseller_id'])) {
        if(!$cache_data_performer[$cat]){
          $sql = 'SELECT * FROM product_markup AS w where w.product_category_id="'.$cat.'"';;
            $markup_values = $this->Model->getSqlData($sql);
            $markup_data= $cache_data_performer[$cat];
            if($markup_values[0]['markup']===$markup_data){
              $markup=(($row['Prices']*$markup_data)/100);
              $markup_Original_Prices=(($row['Prices']*$markup_data)/100);
            }else{
              $markup=(($row['Prices']*$markup_values[0]['markup'])/100);
              $markup_Original_Prices=(($row['Original_Prices']*$markup_values[0]['markup'])/100);
            }              
          }
        }else{
          $markup=0;
          $markup_Original_Prices=0;
        }

       $add_cart='';
       $add_cart= base_url('cart/product_view').'?ID='.$row['ID'].'&?Product_Name='.$row['Product_Name'].'?Prices='.$row['Prices'].'?Original_Prices='.$row['Original_Prices'].'?Code='.$row['SKU'];
    $_images='';
    $_small ='';
$query_images = $this->db->query('select * from multiple_picture where Product_id='.$row['ID']);

$row_images= $query_images->result_array();
foreach ($row_images as $key => $value){
  $_small.='<img src="https://www.oxiinc.in/uploads/Multiple_Picture/'.$value['Product_Picture_Mult'].'" style="    border: 2px solid #3E4095;
            border-radius: 26px;
            width: 32px;
            background-color: black;" >';
  $_images.='<img src="https://www.oxiinc.in/uploads/Multiple_Picture/'.$value['Product_Picture_Mult'].'" style="background-repeat: no-repeat;" alt="image01"/>';
}
    $output .= '
    <a href="'.$add_cart.'" target="_blank">
    <div class="col-xl-3 col-md-4 col-sm-6" id="thumbnail">
                                <div class="product-single product-thumb hover14">
                                        <a href="'.$add_cart.'">
                                            <div class="product-thumb">
                                                <center><img src="https://www.oxiinc.in/uploads/Multiple_Picture/'.$value['Product_Picture_Mult'].'" style="height:209px;"></center>
                                                <div class="product-quick-view">
                                                    <div class="hs-wrapper" style="background-size: cover !important;
    background-image: url(https://www.oxiinc.in/uploads/Multiple_Picture/'.$row_images[0]['Product_Picture_Mult'].');">
                                                        '.$_images.'
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                        <div class="product-title">
                                            <h4 style="font-size: 14px;color:black;text-decoration: none;text-transform: none !important;"><a href="'.$add_cart.'">'. $row['Product_Name'] .'</a></h4>
                                        </div>
                                        <div class="product-price-rating">
                                            <div class="pull-left">
                                                <span>₹'. number_format($row['Prices']+$markup) .'</span>
                                                <del>₹'. number_format($row['Original_Prices']+$markup_Original_Prices) .'</del>
                                            </div>
                                            <div class="pull-right">
                                            </div>
                                        </div>
                                        <div class="best_offer">
                                            <div class="pull-left">
                                                <img src="https://www.oxiinc.in/image/fa_8b4b59.png">
                                            </div>
                                            <div class="pull-right">
                                                <span>Offer</span>
                                                <span class="seller">Best Seller</span>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            </a>';
   }
  }
  else
  {
   $output = '<h3>No Data Found</h3>';
  }
  return $output;
 }

 /* Code added by surya */
 public function menu(){
    if($this->session->userdata('in_logged_in') == 1){
      $category_list = $this->Model->getSqlData("select category_id,category_name from category where status='1' limit 7");  
    }else{
      $category_list = $this->Model->getSqlData("select category_id,category_name from category where status='1' and category_id !=11 limit 7");        
    }
    $category_list = array_column($category_list, 'category_name', 'category_id'); 
    // echo '<pre>'; print_r($category_list);
    $sub_category_list = $this->Model->getSqlData("select category_id,sub_category_name,sub_category_id,seo_sub_category_name from subcategory where status='1'");
     $product_category_list = $this->Model->getSqlData("select category_id,product_category_name,sub_category_id,product_category_id as id,seo_product_category_name from product_category where status='1'");
    $final_menu=[];
    foreach ($product_category_list as $key => $value) {
      $new_array_product[$value['category_id']][$value['sub_category_id']][$key]['product_name']=$value['product_category_name'];
      $new_array_product[$value['category_id']][$value['sub_category_id']][$key]['id']=$value['id'];
      $new_array_product[$value['category_id']][$value['sub_category_id']][$key]['product_seo']=$value['seo_product_category_name'];
    }
    //echo '<pre>'; print_r($new_array_product);
    foreach ($sub_category_list as $key => $value) {
      $new_array[$value['category_id']][$key]['name']=$value['sub_category_name'];
      $new_array[$value['category_id']][$key]['id']=$value['sub_category_id'];
      $new_array[$value['category_id']][$key]['sub_category_seo']=$value['seo_sub_category_name'];
      $new_array[$value['category_id']][$key]['products']=$new_array_product[$value['category_id']][$value['sub_category_id']];

    }
     foreach ($category_list as $key => $value) {
        $final_menu[$key]['category_name']=$value;
        $final_menu[$key]['sub_category_name']=$new_array[$key];
     }
    $upper_category_list = $this->Model->getSqlData("select * from home_page_contents where status='A' order by id desc");

    foreach ($upper_category_list as $key => $value) {
      $cat_list[$value['category']][]=$value;
    }
    //echo '<pre>'; print_r($cat_list); exit;  
    $data['upper_data'] = $cat_list;
    $data['mid_data'] = (array)$this->Text->get_url_upend();
    $data['menu']= $final_menu;
    return $data;
  }
}

?>