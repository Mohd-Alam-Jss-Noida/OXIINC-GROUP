 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class addusers extends CI_Model {

	function insertData($data){
		// print_r($data);
   	 $this->db->insert('users',$data);
	}
}