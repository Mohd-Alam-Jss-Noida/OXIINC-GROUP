<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders_model extends CI_Model {

	function insertData($data){
		// print_r($data);
   	 $this->db->insert('orders',$data);
	}
	function insertfile($data){
		// print_r($data);
   	 $this->db->insert('camera_wrap',$data);
	}
   
   function get($table,$where=array()){
		 print_r($data);
   	  $this->db->select('ID','Purchased_From','created_by','Bill_to_Name','Ship_to_Name','  Grand_Total','Total_Paid',' Status');
   	 	// $query = $this->db->get_where($table,$where);s
      $data = $this->db->get('orders')->result_array();
   	 	return $data;
	}

        function update($table,$data,$where=array()){
		// print_r($data);
   	            $this->db->update($table,$data,$where);
	}
	function insertCategory($data){
		// print_r($data);
   	 $this->db->insert('category',$data);
	}

     
}
