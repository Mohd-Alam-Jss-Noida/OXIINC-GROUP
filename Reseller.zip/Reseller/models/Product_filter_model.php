
<?php

class Product_filter_model extends CI_Model
{
 function fetch_filter_type($type,$db)
 {
  $this->db->distinct();
  $this->db->select($type);
  $this->db->from($db);
  $this->db->where('status', '1');
  $this->db->where('sub_category_id', $this->uri->segment(3));
  return $this->db->get();
 }

 function make_query($minimum_price, $maximum_price, $brand, $ram , $cat,$sub_cat)
 {
  if(is_numeric($cat) && $cat!='js'){
  $query = " SELECT w.* FROM wellness w, size_manage sm  WHERE w.status = '1' AND w.sub_category_id=".$cat." AND sm.p_id=w.id
  ";

  if ($this->session->userdata('in_logged_in')) {
   
  }else{
     $query .= " AND w.visible='0'";
  }

  if(isset($minimum_price, $maximum_price) && !empty($minimum_price) &&  !empty($maximum_price))
  {
   $query .= "
    AND cast(w.Prices as unsigned) BETWEEN '".$minimum_price."' AND '".$maximum_price."'
   ";
  }

  if(isset($brand))
  {
   $brand_filter = implode("','", $brand);
   $query .= "
    AND w.company_name IN('".$brand_filter."')
   ";
  }

  if(isset($ram))
  {
   // $query .= "AND sm.p_id=w.id"; 
   $ram_filter = implode("','", $ram);
   $query .= "
    AND sm.size IN('".$ram_filter."')
   ";
  }
  
   if(isset($sub_cat))
  {
   $sub_cat_filter = implode("','", $sub_cat);
   $query .= "
    AND product_category_id IN('".$sub_cat_filter."')
   ";

  }
   $query .= "GROUP BY w.id";
  // if(isset($storage))
  // {
   
  //  $query .= "
  //   AND verified_status =".$storage."
  //  ";
  // }
  return $query;
}
 }


 function count_all($minimum_price, $maximum_price, $brand, $ram ,$cat,$sub_cat)
 {
  $query = $this->make_query($minimum_price, $maximum_price, $brand, $ram ,$cat,$sub_cat);
  $data = $this->db->query($query);
  return $data->num_rows();
 }

 function fetch_data($limit, $start, $minimum_price, $maximum_price, $brand, $ram,  $order ,$cat ,$sub_cat)
 {
  $query = $this->make_query($minimum_price, $maximum_price, $brand, $ram , $cat ,$sub_cat);

  $query .=  ' ORDER BY  w.stock_status DESC , cast(w.Prices as unsigned)'.$order.'  LIMIT '.abs($start).', ' . abs($limit) ;
// echo $order;
  $data = $this->db->query($query);

  $output = '';
  $stock = '';
  $starttimestamp = '';
  $endtimestamp = '';
  $difference = '';
  $_url='';
  if($data->num_rows() > 0)
  {
      $_url=base_url('Home/add_to_cart');
   foreach($data->result_array() as $row)
   {
       if($row['stock_status']=='0' || $row['stock_status']=='' ){
//           $starttimestamp = strtotime($row['modified']);
//   $endtimestamp = strtotime(date());
//   $difference = abs($endtimestamp - $starttimestamp)/3600;
  // echo  $difference;
//   if($difference>=24){
//   $stock= 'Restoking Soon';
//   }else{
//       $stock= 'Sold Out';
//       }
         $stock= 'Restocking soon';          
           
       }else{
        $stock= '';
       }
       $add_cart='';
       $add_cart= base_url('Home/add_to_cart').'?ID='.$row['ID'].'&?Product_Name='.$row['Product_Name'].'?Prices='.$row['Prices'].'?Original_Prices='.$row['Original_Prices'].'?Code='.$row['SKU'];
    $_images='';
    $_small ='';
$query_images = $this->db->query('select * from multiple_picture where Product_id='.$row['ID']);

$row_images= $query_images->result_array();

foreach ($row_images as $key => $value) {
  # code...
  $_small.='<img src="https://www.oxiinc.in/uploads/Multiple_Picture/'.$value['Product_Picture_Mult'].'" style="    border: 2px solid #3E4095;
            border-radius: 26px;
            width: 32px;
            background-color: black;" >';
  $_images.='<img src="https://www.oxiinc.in/uploads/Multiple_Picture/'.$value['Product_Picture_Mult'].'" style="background-repeat: no-repeat;" width="100%" height="200" alt="image01"/>';
}
if (!empty($row['reseller_id'])) {
    $cache_name = 'memcache_test';
    $cache_data_performer=$this->cache->memcached->get($cache_name);
     if ($cache_data_performer[$row['product_category_id']])
      {
       $markup_data= $cache_data_performer[$row['product_category_id']];
       $markup=(($row['Prices']*$markup_data)/100);
       $markup_Original_Prices=(($row['Original_Prices']*$markup_data)/100);
      }
}else{
  $markup='0';
  $markup_Original_Prices='0';
}
    $output .= '
    <a href="'.$add_cart.'" target="_blank">
    <div class="product-layout product-grid col-lg-3 col-md-3 col-sm-3 col-xs-12" id="thumbnail">

                                <div class="grid">

                                    <figure class="effect-steve">

                                        <div class="product-thumb hover14" style="height: 400px;">
                                            <div class="image" >
                                                
                                                <div class="hs-wrapper" style=" background-position: center; 
  background-repeat: no-repeat;
  background-size: cover;
    background-image: url(https://www.oxiinc.in/uploads/Multiple_Picture/'.$row_images[0]['Product_Picture_Mult'].');">
                                                '.$_images.'
                                            </div>
 
                                            </div>
                                            <div>
                                                <div class="captiont">
                                                    <h4 style="font-size: 14px;color:black;text-decoration: none;text-transform: none !important;"><a href="'.$add_cart.'">'. $row['Product_Name'] .'</a></h4>
                                                            
                                                    <h4 class="price"> <span class="price-new">₹'. number_format($row['Prices']+$markup) .'</span> <span class="price-old">₹'. number_format($row['Original_Prices']+$markup_Original_Prices) .'</span> <span class="price-tax">Ex Tax: ₹90.00</span> </h4>
                                                  <span style="color:red;font-size: 12px">'.$stock.'</span>
                                                  <h4 style="font-size: 12px">
                                        
                                        <spam> <img src="https://www.oxiinc.in/image/fa_8b4b59.png" style="width: 69px;margin: 0px 12px -7px;"> </spam>
                                        </h4>
                                          <h6><span style="font-size: 14px;color:#388e3c;font-weight: 900">Offer</span>
                                                <sapn>  '. $row['offer_specification'] .' </sapn>
                                            </h6>

                                                  

                                                </div>

                                            </div>
                                       <p style="font-weight: 500;color:#3E4095">   <sapn>'.$row['Product_Attribute'].'</sapn></p>
                                       <p>'.$_small.'</p>
                                        </div>
                                    </figure>

                                </div>
                            </div>
                            </a>
    ';
   }
  }
  else
  {
   $output = '<div class="col-sm-12"> 
                                            <img style="margin-left: auto;margin-right: auto;" class="img-responsive" src="https://www.oxiinc.in/uploads/product/no-product-found.jpg">
                                        </div>';
  }
  return $output;
 }
}

?>