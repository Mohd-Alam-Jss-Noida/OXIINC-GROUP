<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class part1_model extends CI_Model {

	function add($data){
		// print_r($data);
   	 $this->db->insert('table',$data);
	}
   
   function get($table,$where=array()){
		// print_r($data);
   		//$this->db->select('gdgh,fg,fy');
   	 	$query = $this->db->get_where($table,$where);
   	 	$data = $query->result_array();
   	 	return $data;
	}

        function update($table,$data,$where=array()){
		// print_r($data);
   	            $this->db->update($table,$data,$where);
	}

}
