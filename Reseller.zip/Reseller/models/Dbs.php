<?php
    class Dbs extends CI_Model{
        public function add($tb,$values)
        {
            $this->db->insert($tb,$values);
        }   

        public function delete($tb1,$where)
        {
            $this->db->delete($tb1,$where);
        }   
        public function edit($tb2,$where2,$set)
        {
            $this->db->update($tb2,$set,$where2);
        }   
    }
?>